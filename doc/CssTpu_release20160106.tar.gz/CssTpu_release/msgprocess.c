/*********************************************************
*程序名称:		msgprocess.cpp
*版本号:		0.1			
*功能描述:  	提供所有命令处理功能
*作者:			王洪峰			
*创建日期:		2015.01.13		
*修改记录:		
				
*其他:						
***********************************************************/

#include "msgprocess.h"
#include "RWBusiness/RWBusiness.h"
#include "comm232.h"
#include "XPublic/crc.h"

static unsigned short m_MsgLen1;	//返回消息结构体1长度
static unsigned char m_ucMsgBuffer1[MAX_COM_DATA_FIELD_LEN]; //返回消息结构体1
static unsigned short m_MsgLen2;	//返回消息结构体2长度
static unsigned char m_ucMsgBuffer2[MAX_COM_DATA_FIELD_LEN]; //返回消息结构体2

RECVCOMMDATA g_RecvCommData; //接收数据结构体
SENDCOMMDATA g_SendCommData; //接收发送结构体
SENDCOMMDATA g_LastSendCommData; //上次发送数据结构体

static void GetStruApiParam(StruAPIParam * p)
{
	p->Reserved0Param = g_RecvCommData.ucParam0; //预留参数  
	p->AntennaMode	  =(g_RecvCommData.ucParam1&03);//天线模式
	p->BuzzerCount	  =((g_RecvCommData.ucParam1>>2)&03);//蜂鸣器次数
	p->Reserved1Param =(g_RecvCommData.ucParam1>>4)	;//参数预留高4位置内容
	memcpy(p->ucTimeStamp,g_RecvCommData.TimeStamp,7);
	PrintLog("File[%s]Line[%d] received TimeStamp",__FILE__,__LINE__);
	PrintBuffer((char*)p->ucTimeStamp,7);

}



static void FillSendBufferData(RetInfo ri,WORD wLen1,			//检测到的SAM卡个数(当前字段值为8)
						  unsigned char * pMsg1,//pSAMCount个SAM卡中每个SAM卡槽的状态, 0为可用
						  WORD wLen2,			//预留信息的数据长度(目前默认为0)
						  unsigned char * pMsg2)//预留信息的内容.(目前没有预留信息)
{
	

	unsigned char *p=g_SendCommData.ucData;

	memcpy(p,(void *)&ri,sizeof(ri));
	p+=sizeof(ri);

	//数据域长度，可以等于0；最大为4KByte
	g_SendCommData.usDataLen=sizeof(ri)+2+ m_MsgLen1 +2+ m_MsgLen2;

	//消息1长度字段为2字节
	//*(unsigned short *)p=wLen1;
	memcpy(p,&wLen1,sizeof(unsigned short));
	p+=2;
	//消息1内容
	if(wLen1>0)
	{
		memcpy(p,pMsg1,wLen1);
		p+=wLen1;
	}

	//消息2长度字段为2字节
	//*(unsigned short *)p=wLen2;
	memcpy(p,&wLen2,sizeof(unsigned short));
	p+=2;
	if(m_MsgLen2>0)
	{
		memcpy(p,pMsg2,wLen2);
		p+=wLen2;
	}
}

//对上位机消息解析分发处理函数
int MsgProcess(void)
{
	int iCmd ; //获取指定代码,以便于执行对应的函数
	int iReturn=-1;
	RetInfo  ri={0};	//返回值
	StruAPIParam StruApiParam={0};	
	

	m_MsgLen1=0;
	m_MsgLen2=0;
	memset(&g_SendCommData,0,sizeof(g_SendCommData));

	iCmd =  (((int)g_RecvCommData.ucCmdClass)<<8 | g_RecvCommData.ucCmdCode);
	GetStruApiParam(&StruApiParam);	//获取参数内容

	PrintLog("File[%s]Line[%d] received cmd[%02X]",__FILE__,__LINE__,iCmd);
	switch(iCmd)
	{
	case MSG_COMMON_INITIALIZE_DEVICE:	//设备环境初始化
		{
			BYTE bStationID[2];	
			BYTE bDeviceType;	
			BYTE bDeviceID[2];	
			bStationID[0]	= BCD_to_Decimal(g_RecvCommData.ucData[0]);//线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
			bStationID[1]	= BCD_to_Decimal(g_RecvCommData.ucData[1]);
			bDeviceType		= BCD_to_Decimal(g_RecvCommData.ucData[2]);//设备类型，十进制表示。1字节BCD编码
			bDeviceID[0]	= BCD_to_Decimal(g_RecvCommData.ucData[3]);//线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
			bDeviceID[1]	= BCD_to_Decimal(g_RecvCommData.ucData[4]);
 			PrintLog("执行命令:设备环境初始化Common_Initialize_Device",__FILE__,__LINE__);
			iReturn=Common_Initialize_Device(StruApiParam,&ri,bStationID,bDeviceType,bDeviceID,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
			g_BRContext.emCsRwStatus=EM_CS_RW_STATUS_FREE;
		}
		break;
	case  MSG_COMMON_GETVERSION:		//获取版本信息 
		PrintLog("执行命令:设备环境初始化Common_Initialize_Device",__FILE__,__LINE__);
		iReturn=Common_GetVersion(StruApiParam,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		break;
	case  MSG_COMMON_GETSAMINFO:		//获取SAM卡信息	ALL
		PrintLog("执行命令:获取SAM卡信息Common_GetSamInfo",__FILE__,__LINE__);
		iReturn=Common_GetSamInfo(StruApiParam,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		break;
			
	case  MSG_COMMON_SETDEGRADEMODE: 	//降级模式消息	ALL
		{
			DEGRADECMD DegradeCmd;
			PrintLog("执行命令:设备降级模式Common_SetDegradeMode",__FILE__,__LINE__);
			memcpy(&DegradeCmd,g_RecvCommData.ucData,sizeof(DegradeCmd));

			DegradeCmd.bStationID[0]=BCD_to_Decimal(DegradeCmd.bStationID[0]);
			DegradeCmd.bStationID[1]=BCD_to_Decimal(DegradeCmd.bStationID[1]);
			iReturn = Common_SetDegradeMode(StruApiParam,DegradeCmd,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}
		break;		
 
			
	case  MSG_COMM_GETFARE:				//获取到本站的票价	ALL
		{
			BYTE bTicketType[2];	
			BYTE bStationID[2];	
			bTicketType[0]	= BCD_to_Decimal(g_RecvCommData.ucData[0]);//线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
			bTicketType[1]	= BCD_to_Decimal(g_RecvCommData.ucData[1]);
			bStationID[0]	= BCD_to_Decimal(g_RecvCommData.ucData[2]);//线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
			bStationID[1]	= BCD_to_Decimal(g_RecvCommData.ucData[3]);
			PrintLog("执行命令:获取到本站的票价Comm_GetFare",__FILE__,__LINE__);
			iReturn=Comm_GetFare(StruApiParam,bTicketType,bStationID,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
			
		}
		break;

	case  MSG_COMM_GETPARAMINFO:		//获取参数信息	ALL 
		{
			unsigned short wParamType  = *(unsigned short *)g_RecvCommData.ucData;
			PrintLog("执行命令:获取参数信息Comm_GetParamInfo",__FILE__,__LINE__);
			wParamType=htons(wParamType);
			iReturn=Comm_GetParamInfo(StruApiParam,wParamType,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}
		break;
			
	case  MSG_GET_REG_VALUE:			//获取单个寄存器值	ALL
		{
			unsigned short wRegID  = *(unsigned short *)g_RecvCommData.ucData;
			PrintLog("执行命令:获取单个寄存器值Get_Reg_Value",__FILE__,__LINE__);
			iReturn=Get_Reg_Value(StruApiParam,wRegID,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}
		break;
			
	case  MSG_GET_REG_INF:				//获取所有寄存器值	ALL
		PrintLog("执行命令:获取所有寄存器值Get_Reg_Info",__FILE__,__LINE__);
		iReturn=Get_Reg_Info(StruApiParam,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		break;
			
	case  MSG_RESET_REF_INF:			//重置寄存器	ALL
		break;
		
	case  MSG_COMMON_LASTTRADE:			//获取上次通讯数据	ALL
		{
			PrintLog("执行命令:MSG_COMMON_LASTTRADE",__FILE__,__LINE__);
			memcpy(&g_SendCommData,&g_LastSendCommData,sizeof(g_LastSendCommData));
			iReturn=CE_OK;
		}
		break;
			
	case  MSG_GATE_AISLEMODEL:			//设置专用通道	AGM
		{
			BYTE bDeviceType = g_RecvCommData.ucData[0];
			PrintLog("执行命令:通道类型设置Gate_AisleModel",__FILE__,__LINE__);
			iReturn=Gate_AisleModel(StruApiParam,bDeviceType,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}		
		break;
			
	case  MSG_GATE_ENTRYFLOW:			//进闸	AGM
		{
			PrintLog("执行命令:入闸处理Gate_AisleModel",__FILE__,__LINE__);
			iReturn=Gate_EntryFlow(StruApiParam,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}		
		break;
			
	case  MSG_GATE_EXITFLOW:			//出闸	AGM
		{
			PrintLog("执行命令:出闸处理Gate_AisleModel",__FILE__,__LINE__);

			iReturn=Gate_ExitFlow(StruApiParam,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}
		break;
			
	case  MSG_TVM_TICKET_SALE:			//车票发售	TVM
		{
			//PrintLog("执行命令:出闸处理Gate_AisleModel");
			uint16 u16TranValue=0;
			uint8 u8PaymentType=0;
			memcpy(&u16TranValue,g_RecvCommData.ucData,2);
			u8PaymentType=BCD_to_Decimal(g_RecvCommData.ucData[2]);
			iReturn=Tvm_SjtSale(StruApiParam,u16TranValue,u8PaymentType,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}
		break;
			
	case  MSG_TVM_SJTCLEAR:				//单程票余额清零	TVM
			iReturn=Tvm_SjtClear(StruApiParam,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		break;
			
	case  MSG_TVM_TICKETANALYZE:		//分析	TVM
		{
			iReturn=Tvm_SvtAnalyze(StruApiParam,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}
		break;
			
	case  MSG_TVM_PURSEDECREASE:		//票卡减值	TVM
		{
			uint32 uPrice=0;
			memcpy(&uPrice,g_RecvCommData.ucData,4);
			PrintLog("执行命令:MSG_TVM_PURSEDECREASE uPrice[%d]",__FILE__,__LINE__,uPrice);
			iReturn=Tvm_SvtDecrease(StruApiParam,uPrice,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}
		break;
	case  MSG_BOM_LOGIN:				//BOM操作员登录	BOM
	{
		char OperId[7]={0};
		uint8 u8ClassId=0;
		memcpy(OperId,g_RecvCommData.ucData,6);
		u8ClassId=BCD_to_Decimal(g_RecvCommData.ucData[6]);
		iReturn=SetOperaterInfo (StruApiParam, OperId, u8ClassId, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
	}
		break;
			
	case  MSG_BOM_TICKETANALYZE:		//票卡分析	BOM
		{
			uint16 u8IsDegradeMode=0;
			uint8 u8WorkArea=0;
			memcpy(&u8IsDegradeMode,g_RecvCommData.ucData,1);
			memcpy(&u8WorkArea,g_RecvCommData.ucData+1,1);
			PrintLog("File[%s]Line[%d] u8IsDegradeMode[%d]",__FILE__,__LINE__,u8IsDegradeMode);
			PrintLog("File[%s]Line[%d] u8WorkArea[%d]",__FILE__,__LINE__,u8WorkArea);
			iReturn=Bom_TicketAnalyze(StruApiParam, u8IsDegradeMode, u8WorkArea, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
			if(iReturn==CE_OK)
			{
				g_BRContext.emCsRwStatus=EM_CS_RW_STATUS_READED;
			}
		}
		break;
			
	case  MSG_BOM_GETTICKETINFO:		//验票	BOM
			iReturn=Bom_GetTicketInfo(StruApiParam, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		break;
			
	case  MSG_BOM_TICKET_SALE:			//车票发售	BOM
		if((EM_CS_RW_STATUS)g_BRContext.emCsRwStatus==EM_CS_RW_STATUS_READED)
		{
			uint16 u16TranValue=0;
			uint8 u8PaymentType=0;
			uint8 u8MoneyType=0;
			memcpy(&u16TranValue,g_RecvCommData.ucData,2);
			u8PaymentType=BCD_to_Decimal(g_RecvCommData.ucData[2]);
			memcpy(&u8MoneyType,g_RecvCommData.ucData+3,1);
			//u16TranValue=htons(u16TranValue);
			PrintLog("File[%s]Line[%d] u16TranValue[%d]",__FILE__,__LINE__,u16TranValue);
			PrintLog("File[%s]Line[%d] u8PaymentType[%d]",__FILE__,__LINE__,u8PaymentType);
			iReturn=Bom_SaleTicket(StruApiParam,u16TranValue,u8PaymentType,u8MoneyType,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}else
		{
		   ri.wErrCode=RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT;
		}
		g_BRContext.emCsRwStatus=EM_CS_RW_STATUS_FREE;
		break;
			
	case  MSG_BOM_TRANSACTCONFIRM:		//交易确认	BOM
		if(g_BRContext.emCsRwStatus==EM_CS_RW_STATUS_READED)
		{
			uint8 u8Option=0;
			memcpy(&u8Option,g_RecvCommData.ucData,1);
			iReturn=Bom_ConfirmTran(StruApiParam,u8Option,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}else
		{
		   ri.wErrCode=RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT;
		}
		g_BRContext.emCsRwStatus=EM_CS_RW_STATUS_FREE;
		break;
			
	case  MSG_BOM_EXITSALE:				//发售出站票	BOM
		if(g_BRContext.emCsRwStatus==EM_CS_RW_STATUS_READED)
		{
			uint16 uPrice=0;
			memcpy(&uPrice,g_RecvCommData.ucData,2);
			//uPrice=htons(uPrice);
			PrintLog("File[%s]Line[%d] uPrice[%d]",__FILE__,__LINE__,uPrice);
			iReturn=Bom_SaleExitSJT(StruApiParam,uPrice,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}else
		{
			PrintLog("File[%s]Line[%d] g_BRContext.emCsRwStatus[%02X]",__FILE__,__LINE__,g_BRContext.emCsRwStatus);
		   ri.wErrCode=RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT;
		}
		g_BRContext.emCsRwStatus=EM_CS_RW_STATUS_FREE;
		break;
			
	case  MSG_BOM_TICKETUPDATE:			//	票卡更新	BOM
		if(g_BRContext.emCsRwStatus==EM_CS_RW_STATUS_READED)
		{
			uint8 u8UpdateCode=0;
			uint8 u8EntryStationCode[2]={0};
			uint16 u16EntryStationCode=0;
			uint16 u16TranValue=0;
			uint8 u8PaymentType=0;
			memcpy(&u8UpdateCode,g_RecvCommData.ucData,1);
			u8EntryStationCode[0]=BCD_to_Decimal(g_RecvCommData.ucData[1]);
			u8EntryStationCode[1]=BCD_to_Decimal(g_RecvCommData.ucData[2]);
			memcpy(&u16EntryStationCode,u8EntryStationCode,2);
			memcpy(&u16TranValue,g_RecvCommData.ucData+3,2);
			memcpy(&u8PaymentType,g_RecvCommData.ucData+5,1);
			PrintLog("File[%s]Line[%d] u8UpdateCode[%d]",__FILE__,__LINE__,u8UpdateCode);
			PrintLog("File[%s]Line[%d] u16EntryStationCode[%02X]",__FILE__,__LINE__,u16EntryStationCode);
			PrintLog("File[%s]Line[%d] u16TranValue[%d]",__FILE__,__LINE__,u16TranValue);
			PrintLog("File[%s]Line[%d] u8PaymentType[%d]",__FILE__,__LINE__,u8PaymentType);
			iReturn=Bom_Update(StruApiParam,u8UpdateCode,u16EntryStationCode,u16TranValue,u8PaymentType,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}else
		{
		   ri.wErrCode=RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT;
		}
		//g_BRContext.emCsRwStatus=EM_CS_RW_STATUS_FREE;
		break;
			
	case  MSG_BOM_PURSEDECREASE:		//	票卡减值	BOM
		//if(g_BRContext.emCsRwStatus==EM_CS_RW_STATUS_READED)
		{
			uint32 uPrice=0;
			memcpy(&uPrice,g_RecvCommData.ucData,4);
			PrintLog("执行命令:MSG_BOM_PURSEDECREASE uPrice[%d]",__FILE__,__LINE__,uPrice);
			iReturn=Bom_SvtDecrease(StruApiParam,uPrice,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		//}else
		//{
		  // ri.wErrCode=RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT;
		}
		//g_BRContext.emCsRwStatus=EM_CS_RW_STATUS_FREE;
		break;
			
	case  MSG_BOM_DIRECTREFUND:			//	即时退款	BOM
		if(g_BRContext.emCsRwStatus==EM_CS_RW_STATUS_READED)
		{
			uint8 u8RefundOption=0;
			uint8 u8RefundCode=0;
			uint16 u16TranValue=0;
			memcpy(&u8RefundOption,g_RecvCommData.ucData,1);
			memcpy(&u16TranValue,g_RecvCommData.ucData+1,2);
			u8RefundCode=BCD_to_Decimal(g_RecvCommData.ucData[3]);
			PrintLog("File[%s]Line[%d] u8RefundOption[%d]",__FILE__,__LINE__,u8RefundOption);
			PrintLog("File[%s]Line[%d] u8RefundCode[%d]",__FILE__,__LINE__,u8RefundCode);
			PrintLog("File[%s]Line[%d] u16TranValue[%d]",__FILE__,__LINE__,u16TranValue);
			iReturn=Bom_Refund(StruApiParam,u8RefundOption,u8RefundCode,u16TranValue,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}else
		{
		   ri.wErrCode=RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT;
		}
		g_BRContext.emCsRwStatus=EM_CS_RW_STATUS_FREE;
		break;
			
	case  MSG_BOM_TICKETDEFER:			//	延期	BOM
		if(g_BRContext.emCsRwStatus==EM_CS_RW_STATUS_READED)
		{
			iReturn=Bom_Deffer(StruApiParam,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}else
		{
		   ri.wErrCode=RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT;
		}
		g_BRContext.emCsRwStatus=EM_CS_RW_STATUS_FREE;
		break;
			
	case  MSG_BOM_TICKETUNLOCK:			//	解锁	BOM
		if(g_BRContext.emCsRwStatus==EM_CS_RW_STATUS_READED)
		{
			iReturn=Bom_Unblock(StruApiParam,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}else
		{
		   ri.wErrCode=RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT;
		}
		g_BRContext.emCsRwStatus=EM_CS_RW_STATUS_FREE;
		break;
	case  MSG_TVM_SVTINCREASE1:			//在线充值-初始化	TVM
	case  MSG_BOM_SVTINCREASE1:			//在线充值-初始化	BOM
	{
			uint8 TopupType=0;
			uint32 TopupValue=0;
			uint8 NetPoint[16]={0};
			TopupType=g_RecvCommData.ucData[0];
			TopupValue=g_RecvCommData.ucData[4]*0x1000000+g_RecvCommData.ucData[3]*0x10000+g_RecvCommData.ucData[2]*0x100+g_RecvCommData.ucData[1];
			memcpy(NetPoint,&g_RecvCommData.ucData[5],sizeof(NetPoint));
			Bom_TopupInit(StruApiParam,TopupType,TopupValue,NetPoint, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
	}
	break;

	case  MSG_TVM_SVTINCREASE2:			//在线充值-充值操作    TVM
	case  MSG_BOM_SVTINCREASE2:			//在线充值-充值操作	BOM
		{
				TopupRequestServer st_TopupRequestServer;
				memcpy(&st_TopupRequestServer,g_RecvCommData.ucData,sizeof(st_TopupRequestServer));
				Bom_TopupOperate(StruApiParam,st_TopupRequestServer, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}
		break;
	case  MSG_BOM_FUNACTIVE1:			//功能激活信息获取	BOM
	{
		iReturn=Bom_GetActiveInfo(StruApiParam, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		//FillSendBufferDataOnLine(ri,m_MsgLen1,m_ucMsgBuffer1);
		//WriteCommMsg();
	}
	break;
			
	case  MSG_BOM_FUNACTIVE2:			//读写器功能激活操作	BOM
	{
		EquipmentActivateServer st_EquipmentActivateServer;
		memcpy(&st_EquipmentActivateServer,g_RecvCommData.ucData,sizeof(st_EquipmentActivateServer));
		Bom_Active(StruApiParam,st_EquipmentActivateServer, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		//FillSendBufferDataOnLine(ri,m_MsgLen1,m_ucMsgBuffer1);
		//WriteCommMsg();
	}
	break;
	case  MSG_BOM_CHARGE_DESCIND1:		//充值撤销初始化	BOM
	{
			uint8 Type=0;
			uint32 Value=0;
			long   remainningvalue=0;
			Type=g_RecvCommData.ucData[0];
			Value=g_RecvCommData.ucData[4]*0x1000000+g_RecvCommData.ucData[3]*0x10000+g_RecvCommData.ucData[2]*0x100+g_RecvCommData.ucData[1];
			remainningvalue=g_RecvCommData.ucData[8]*0x1000000+g_RecvCommData.ucData[7]*0x10000+g_RecvCommData.ucData[6]*0x100+g_RecvCommData.ucData[5];
			ChargeBackInit(StruApiParam,Type,Value,remainningvalue, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
	}
	break;
			
	case  MSG_BOM_CHARGE_DESCIND2:		//充值撤销	BOM
	{
		 ChargeBackOperate(StruApiParam,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
	}
	break;
			
	case  MSG_BOM_QUERY_POLICY_PENALTY:	//查询行政罚金	BOM
		{
			BYTE bTicketType[2]={0};
			BYTE bPenaltyCode=0;
			bTicketType[0]	= BCD_to_Decimal(g_RecvCommData.ucData[0]);//线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
			bTicketType[1]	= BCD_to_Decimal(g_RecvCommData.ucData[1]);
			bPenaltyCode=g_RecvCommData.ucData[2];
			PrintLog("File[%s]Line[%d] excute MSG_BOM_QUERY_POLICY_PENALTY bTicketType[0x%02X%02X] bPenaltyCode[%d]",__FILE__,__LINE__,bTicketType[0],bTicketType[1],bPenaltyCode);
			iReturn=Bom_GetPenalty(StruApiParam,bTicketType,bPenaltyCode, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}
		break;
			
	case  MSG_BOM_QUERY_OVERTRIP_VAL:	//查询车费差价	BOM
		{
			BYTE bTicketType[2];
			BYTE bStationID[2];
			int iRemainngValue=0;
			bTicketType[0]	= BCD_to_Decimal(g_RecvCommData.ucData[0]);//线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
			bTicketType[1]	= BCD_to_Decimal(g_RecvCommData.ucData[1]);
			PrintLog("File[%s]Line[%d] excute MSG_BOM_QUERY_OVERTRIP_VAL bTicketType[0x%02X%02X]",__FILE__,__LINE__,bTicketType[0],bTicketType[1]);
			memcpy(&iRemainngValue,g_RecvCommData.ucData+2,4);
			//iRemainngValue=htonl(iRemainngValue);
			PrintLog("File[%s]Line[%d] excute MSG_BOM_QUERY_OVERTRIP_VAL iRemainngValue[%d]",__FILE__,__LINE__,iRemainngValue);
			bStationID[0]	= BCD_to_Decimal(g_RecvCommData.ucData[6]);//线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
			bStationID[1]	= BCD_to_Decimal(g_RecvCommData.ucData[7]);
			PrintLog("File[%s]Line[%d] excute MSG_BOM_QUERY_OVERTRIP_VAL bStationID[0x%02X%02X]",__FILE__,__LINE__,bStationID[0],bStationID[1]);
			iReturn=Bom_GetPriceDiff(StruApiParam,bTicketType,bStationID,iRemainngValue, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		}
		 break;
			
	case  MSG_TCM_GETTICKETINFO:		//Private	TCM
			iReturn=Tcm_GetTicketInfo(StruApiParam, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		break;
			
	case  MSG_PARAM_DOWNLOAD_NOFIFY:	//参数下载/生效通知		
		{
			PrintLog("File[%s]Line[%d] excute MSG_PARAM_DOWNLOAD_NOFIFY",__FILE__,__LINE__);
			ST_Parameter_Info stParameterInfo;
			memcpy(&stParameterInfo.u8MessageType,g_RecvCommData.ucData,1);
			memcpy(&stParameterInfo.u32FileSize,g_RecvCommData.ucData+1,4);
			memcpy(stParameterInfo.u8CRC,g_RecvCommData.ucData+5,4);
			memcpy(&stParameterInfo.u8FileNameLength,g_RecvCommData.ucData+9,1);
			memcpy(stParameterInfo.FileName,g_RecvCommData.ucData+10,stParameterInfo.u8FileNameLength);

			if(stParameterInfo.u8MessageType==0x00)
			{
				PrintLog("File[%s]Line[%d] excute MSG_PARAM_DOWNLOAD_NOFIFY begin ",__FILE__,__LINE__);
				iReturn=StartToDownloadParameter(StruApiParam,stParameterInfo, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
			}else if(stParameterInfo.u8MessageType==0x01)
			{
				PrintLog("File[%s]Line[%d] excute MSG_PARAM_DOWNLOAD_NOFIFY end ",__FILE__,__LINE__);
				iReturn=EffectParameter(StruApiParam,stParameterInfo, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);

				//程序升级 特殊处理
				if(iReturn==1)
				{


					FillSendBufferData(ri,m_MsgLen1,m_ucMsgBuffer1,m_MsgLen2,m_ucMsgBuffer2);

					WriteCommMsg();

					sleep(1);

					system("sh boottpu.sh");

					PrintLog("File[%s]Line[%d] EffectParameter Cmd[sh boottpu.sh] !",__FILE__,__LINE__);

					exit(1);
				}
			}else
			{
				ri.wErrCode=RW_EC_INVALID_INPUT_PARAM;
			}

		}
		break;
			
	case  MSG_PARAM_DOWNLOAD_DATA:		//MSG_参数内容传输		
	{
		PrintLog("File[%s]Line[%d] excute MSG_PARAM_DOWNLOAD_DATA",__FILE__,__LINE__);
		uint16 u16BufferLength;
		uint32 u32RemainnigLength;

		memcpy(&u16BufferLength,g_RecvCommData.ucData,2);
		PrintLog("File[%s]Line[%d]   u16BufferLength[%d]",__FILE__,__LINE__,u16BufferLength);

		memcpy(&u32RemainnigLength,g_RecvCommData.ucData+2,4);
		PrintLog("File[%s]Line[%d]   u32RemainnigLength[%d]",__FILE__,__LINE__,u32RemainnigLength);

		char   buffer[u16BufferLength+1];
		memset(buffer,0,sizeof(buffer));

		memcpy(buffer,g_RecvCommData.ucData+6,u16BufferLength);
		PrintLog("File[%s]Line[%d]   u32RemainnigLength[%d]",__FILE__,__LINE__,u32RemainnigLength);
		iReturn=DownloadParameter(StruApiParam, u16BufferLength, u32RemainnigLength,buffer, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
	}
		break;
			
	case  MSG_REMOTE_REBOOT_APPLICATION://远程重启读写器应用
	{
		FillSendBufferData(ri,m_MsgLen1,m_ucMsgBuffer1,m_MsgLen2,m_ucMsgBuffer2);
		WriteCommMsg();
		sleep(1);
		system("sh boottpu.sh");
		PrintLog("File[%s]Line[%d] MSG_REMOTE_REBOOT_APPLICATION Cmd[sh boottpu.sh] !",__FILE__,__LINE__);
		exit(1);
	}
		break;
		
	case  MSG_REMOTE_REBOOT_SYSTEM:		//MD_远程重启读写器系统
	{
		FillSendBufferData(ri,m_MsgLen1,m_ucMsgBuffer1,m_MsgLen2,m_ucMsgBuffer2);
		WriteCommMsg();
		sleep(1);
		system("reboot -f");
		PrintLog("File[%s]Line[%d] MSG_REMOTE_REBOOT_SYSTEM Cmd[reboot -f] !",__FILE__,__LINE__);
		exit(1);
	}
		break;
	case MSG_READ_ACC_ULCARD:     // Test Read Acc ULcard
		iReturn=Test_Read_Acc_ULCard( StruApiParam, &ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
		break;
	case MSG_WRITE_ACC_ULCARD:   //Test  Write Acc ULcard
	{
		uint8   szTestbuffer[64];
		memset(szTestbuffer,0,sizeof(szTestbuffer));
		memcpy(szTestbuffer,g_RecvCommData.ucData,g_RecvCommData.usDataLen);
		iReturn=Test_Write_Acc_ULCard(StruApiParam,szTestbuffer,&ri,&m_MsgLen1,m_ucMsgBuffer1,&m_MsgLen2,m_ucMsgBuffer2);
	}
		break;
	case  MSG_GET_LOGFILE_SIZE:			//获取日志文件大小	ALL
	{
 		BYTE bLogFileType;   //日志文件类型
		BYTE bLogFileDate[4]; //yyymmdd 日志文件时间
		uint32 dwLogFileSize=0; //日志文件大小

		bLogFileType		= g_RecvCommData.ucData[0];//设备类型，十进制表示。1字节BCD编码
		memcpy(bLogFileDate,g_RecvCommData.ucData+1,4);//BCD格式

		PrintLog("Process Msg[0x%04X]:MSG_GET_LOGFILE_SIZE()\n",MSG_GET_LOGFILE_SIZE);

		Common_GetLogFileSize(StruApiParam,&ri,bLogFileType, bLogFileDate,&dwLogFileSize);

		if(ri.wErrCode==RW_EC_OK)
		{
			FillSendBufferData(ri,sizeof(dwLogFileSize),(unsigned char *)&dwLogFileSize,0,NULL);
		}
		else
			FillSendBufferData(ri,0,NULL,0,NULL);

		WriteCommMsg();//将全局结构体g_SendCommData数据发送给上位机作为应答
		return 0;
  	}

	case  MSG_GET_LOGFILE_DATA:			//获取日志文件大小	ALL
	{
 		BYTE bLogFileType;   //日志文件类型
		BYTE bLogFileDate[4]; //yyymmdd 日志文件时间
		uint32 dwLogFilePos=0; //日志文件大小
		WORD  wReadCount = 0;
		BYTE  bFileDataBuffer[MAX_COM_DATA_FIELD_LEN];

		bLogFileType		= g_RecvCommData.ucData[0]; //设备类型，十进制表示。1字节BCD编码
		memcpy(bLogFileDate,g_RecvCommData.ucData+1,4); //BCD格式
		memcpy(&dwLogFilePos,g_RecvCommData.ucData+5,4); //读取文件开始位置
		memcpy(&wReadCount,g_RecvCommData.ucData+9,2);   //读取文件长度

		PrintLog("Process Msg[0x%04X]:MSG_GET_LOGFILE_DATA()\n",MSG_GET_LOGFILE_SIZE);

		Common_GetLogFileData(StruApiParam,&ri,bLogFileType, bLogFileDate,dwLogFilePos ,wReadCount,bFileDataBuffer);
		if(ri.wErrCode==RW_EC_OK)
		{
			FillSendBufferData(ri,wReadCount,bFileDataBuffer,0,NULL);
		}
		else
			FillSendBufferData(ri,0,NULL,0,NULL);

		WriteCommMsg();//将全局结构体g_SendCommData数据发送给上位机作为应答
		return 0;
  	}
	default://未知命令
		PrintLog("File[%s]Line[%d] unkonwn cmd[%02X]",__FILE__,__LINE__,iCmd);
		ri.wErrCode=RW_EC_UNKNOWN_COMMAND;
		break;
	}
	//对上位机即返回函数执行结果.
	PrintLog("File[%s]Line[%d] excute ri->wErrCode[%02X]",__FILE__,__LINE__,ri.wErrCode);
	PrintLog("File[%s]Line[%d] excute m_MsgLen1[%02X]",__FILE__,__LINE__,m_MsgLen1);
	PrintLog("File[%s]Line[%d] excute m_MsgLen2[%02X]",__FILE__,__LINE__,m_MsgLen2);

	FillSendBufferData(ri,m_MsgLen1,m_ucMsgBuffer1,m_MsgLen2,m_ucMsgBuffer2);
	WriteCommMsg();

	FlushDisk();

	//写UD
	if(m_MsgLen1!=0)
	{
		PrintLog("File[%s]Line[%d] Write UD Length[%d]",__FILE__,__LINE__,m_MsgLen1);
		PrintUD((const char *)m_ucMsgBuffer1,m_MsgLen1);
	}

	if(m_MsgLen2!=0)
	{
		PrintLog("File[%s]Line[%d] Write UD Length[%d]",__FILE__,__LINE__,m_MsgLen2);
		PrintUD((const char *)m_ucMsgBuffer2,m_MsgLen2);
	}


	return 0;
}




 

//在指定的时间内读取消息头字段0xAA
BOOL ReadMsgStx(int iTimeout)
{
	unsigned char cStx = 0;
	//DWORD dwToRead =1 ;
	unsigned long ReadedCount;
	//int uiCurTime = time((time_t*)NULL);
	if(ReadCommBuffer((char *)&cStx, 1,iTimeout,&ReadedCount))
	{
		if(ReadedCount ==1 )
		{
			if(cStx==MSG_SEND2RW_HEADER )
			{
				g_RecvCommData.ucHeadStx = MSG_SEND2RW_HEADER;
				return TRUE;
			}
		}
	}
	return FALSE;
}


//读取串口数据消息体(除了标志头以外的内容)
int ReadCommMsgBody(int iReadTimeout)//设备通信端口编号
{

	//RetInfo retinfo;
	int iRet=-1;
	//读取应答
	DWORD dwToRead = 0;
	unsigned long ReadedCount=0;
	BOOL  bReadStatus =FALSE; //判断是否读数据成功

	//先读取15个字节(从节点编码到长度字段)
	dwToRead = 15;
	if(ReadCommBuffer((char *)&g_RecvCommData+1,dwToRead,iReadTimeout,&ReadedCount))
	{
		if(ReadedCount == dwToRead) //数据读取成功
		{
			//读取剩余部分
			dwToRead = g_RecvCommData.usDataLen+2;//增加2个字节校验码
			PrintLog("File[%s]Line[%d] dwToRead[%02X]",__FILE__,__LINE__,dwToRead);
			if((dwToRead <=MAX_COM_DATA_FIELD_LEN)
				&& ReadCommBuffer((char *)g_RecvCommData.ucData,dwToRead,iReadTimeout,&ReadedCount))//1秒钟以内
			{
				if(ReadedCount==dwToRead)//读取到了所有的数据
				{
					bReadStatus = TRUE;
				}
			}
		}
	}
	
	PrintLog("File[%s]Line[%d] dwToRead[%02X] ReadedCount[%02X]",__FILE__,__LINE__,dwToRead,ReadedCount);

	if(bReadStatus ==TRUE)
	{
		PrintHexMsg((char *)&g_RecvCommData,MSG_SEND2RW_FIX_LEN+g_RecvCommData.usDataLen,FALSE);
		unsigned short usCRC16 = 0;//*(unsigned short *)(g_RecvCommData.ucData+g_RecvCommData.usDataLen);
		memcpy(&usCRC16,g_RecvCommData.ucData+g_RecvCommData.usDataLen,2);
		//判断校验值是否出错
		if(usCRC16==crc16_ccitt((unsigned char*)&g_RecvCommData,MSG_SEND2RW_FIX_LEN-2+g_RecvCommData.usDataLen))
		{
			//数据完全读取成功
			//判断数据区域1和数据区域2的长度字段是否正确
			//晚些时候再判断
			iRet = RW_EC_OK; //成功

		} else
		{
			iRet =RW_EC_COMM_DATA_INVALID;	//错误码:通讯数据非法","数据不完整，格式错误或者校验错误
		}
	}else //读取数据失败
	{
		iRet = RW_EC_COMM_READ_FAILED; //通讯接收数据失败","GUI需要关闭读写器连接，然后重新打开"},
	}
	return iRet;
}


//将g_SendCommData结构体发送到上位机.
BOOL WriteCommMsg(void)
{

	unsigned short usCRC16;
	//消息头部	1	0	byte	BB（读写器发送）
	g_SendCommData.ucHeadStx = MSG_RECV_FROM_RW_HEADER; //0xBB卡器给上位机给发送应答的固定头长度
	
	//节点编码	1	1	byte	本设备地址码，用于一个端口接多个读写器
	g_SendCommData.ucNodeID = g_RecvCommData.ucNodeID;
	
	//报文序列号,	由上位机管理，0开始，每次通讯完加1，到0xFF后重新归零。
	g_SendCommData.ucMsgSeq = g_RecvCommData.ucMsgSeq;
	
	//指令类码
	g_SendCommData.ucCmdClass = g_RecvCommData.ucCmdClass;
	
	//命令码
	g_SendCommData.ucCmdCode = g_RecvCommData.ucCmdCode;

	//长度字段已经在之前进行具体业务功能是填写过了.
	if(g_SendCommData.usDataLen>MAX_COM_DATA_FIELD_LEN)
	{
		//g_SendCommData.usDataLen = MAX_COM_DATA_FIELD_LEN;//避免溢出
		return FALSE;
	}

	////计算CRC16位数据
	usCRC16 = crc16_ccitt((unsigned char *)&g_SendCommData,g_SendCommData.usDataLen+MSG_RECV_FROM_RW_FIX_LEN-2);
	//*(unsigned short *)(g_SendCommData.ucData+g_SendCommData.usDataLen) =usCRC16; //这句话在JC5000B读卡器，不好用
	memcpy(&g_SendCommData.ucData[g_SendCommData.usDataLen],&usCRC16,sizeof(usCRC16));

	PrintHexMsg((char *)&g_SendCommData,MSG_RECV_FROM_RW_FIX_LEN+g_SendCommData.usDataLen,TRUE);

	//memcpy(szSendBuffer,&g_SendCommData,g_SendCommData.usDataLen+MSG_RECV_FROM_RW_FIX_LEN);

	//记录上次数据
	memcpy(&g_LastSendCommData,&g_SendCommData,sizeof(SENDCOMMDATA));

	if(!WriteCommBuffer((char *)&g_SendCommData,
			MSG_RECV_FROM_RW_FIX_LEN+g_SendCommData.usDataLen)) //18为通讯固定头固定长度
	{
		return FALSE;
	}
	return TRUE;
}
