#ifndef __RWPARAMETER_H__
#define __RWPARAMETER_H__

#include "DataTypeDefine.h"
#include "../CSReaderCode.h"
#include "XPublic/crc.h"
#include "XPublic/XTime.h"
#include "XPublic/HashDictionary.h"
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<dirent.h>
#include<unistd.h>

//szp add code start --------------------------------/
#define FILE_ACC_DEVICE_CONTRORL			0x0101			//0101   设备控制参数
#define FILE_ACC_STATION_TABLE				0x0202			//0202   车站配置表
#define FILE_ACC_CHANGSHA_SAM				0x0203			//0203   SAM卡对照表
#define FILE_ACC_TRAN_STATION				0x0204			//0204   换乘车站代码表
#define FILE_ACC_CHANGSHA_TICKETTYPE		0x0301			//0301   票卡参数
#define FILE_ACC_CHANGSHA_AG				0x0302			//0302   闸机专用通道参数
#define FILE_ACC_TRIPS_TICKET				0x0303			//0303   乘次票专用参数
#define FILE_ACC_CHANGSHA_TICKETVALUE		0x0400			//0401   收费区段表
															//0402   收费配置表
															//0403   票价表
															//0404   节假日定义表
															//0405   非繁忙时间定义表
#define FILE_ACC_CHANGSHA_DEGRADE_HISTORY	0x0501			//0501   降级模式使用记录
#define FILE_ACC_CHANGSHA_SINGLEBLACKLIST	0x0601			//0601   地铁单个黑名单
#define FILE_ACC_CHANGSHA_BATCHBLACKLIST	0x0602			//0602   地铁黑名单段
#define FILE_YKT_CHANGSHA_SINGLEBLACKLIST	0x0603			//0603   公交一卡通单个黑名单
#define FILE_YKT_CHANGSHA_BATCHBLACKLIST	0x0604			//0604   公交一卡通黑名单段
#define FILE_ACC_CHANGSHA_XZSFFJ			0x0801			//0801   行政收费罚金参数
#define FILE_BOM_TPU						0x9320			//9320   BOMTPU程序
#define FILE_TVM_TPU						0x9220			//9220   BOMTPU程序
#define FILE_AG_TPU							0x9120			//9120   BOMTPU程序
#define FILE_TCM_TPU						0x9420			//9420   BOMTPU程序
#define FILE_PCA_TPU						0x9520			//9520   BOMTPU程序
//szp add code end -----------------------------------/


#pragma pack(push,1)
//#pragma pack(push)
//#pragma pack(1)

//0101   设备系统运营控制使用的参数
typedef struct  _Para0101{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	Param0[4];//SC操作员无操作自动注销时间    CHAR	4	单位：秒
	uint8	Param1[4];//SC重新连接LCC的周期	CHAR	4	单位：秒
	uint8	Param2[4];//BOM运营人员自动注销时间	CHAR	4	单位：秒
	uint8	Param3[4];//进/出闸超时	CHAR	4	单位：秒
	uint8	DegradeValidDate[2];//降级模式的影响有效期	CHAR	2	单位：天
	uint8	SVTTopupLimited[8];//储值卡充值钱包充值上限。	CHAR	8	Unit：分
	uint8	Param4[8];//积分钱包充值上限	CHAR	8	Unit：次
	uint8	Param6[8];//单程票发售钱包充值上限	CHAR	8	Unit：张
	uint8	Param7[8];//储值卡钱包充值下限	CHAR	8	Unit：分
	uint8	Param8[8];//积分钱包充值下限	CHAR	8	Unit：次
	uint8	Param9[8];//单程票发售钱包充值下限	CHAR	8	Unit：张

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0101;

//0202   车站配置表
typedef struct  _Para0202{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	DeviceCode[9];//车站代码	CHAR	4  设备编号	CHAR	3 设备类型	CHAR	2
	uint8	Param0[1];//设备所含的CSC读写器数量	CHAR	1
	uint8	Param1[3];//闸机或TVM所属的阵列编号	CHAR	3
	uint8	Param2[3];//车站内的区域编号	CHAR	3
	uint8	Param3[15];//设备IP地址	CHAR	15
	uint8	Param4[30];//设备名称	CHAR	30

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0202;

//0203   SAM卡对照表
typedef struct  _Para0203{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	SAM_Num[16];//Sam卡逻辑卡号	CHAR	16	不足16位时右对齐，左补0
	uint8	SAM_Type[1];//Sam卡类型	CHAR	1	1:地铁SAM 2:公交SAM-CPU 3:公交SAM-M1
	uint8	StationCode[4];//车站代码	CHAR	4
	uint8	EquipmentNum[3];//设备编号	CHAR	3
	uint8	EquipmentTpye[2];//设备类型	CHAR	2

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0203;

//0204   换乘站参数
typedef struct  _Para0204{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	TranStation_A[4];//换乘站车站A代码	CHAR	4
	uint8	TranStation_B[4];//换乘站车站B代码	CHAR	4

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0204;

//0301   票卡参数
typedef struct  _Para0301{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	TicketMainType[2];//票卡主类型	CHAR	2
	uint8	TicketSubType[2];//票卡子类型	CHAR	2
	uint8	TicketValueType[1];//钱包值类型	CHAR	1	0：无值类型；1：金额；2：次数；3：天数；
	uint8	UpperLimit[6];//车票余额/次上限	CHAR	6	单位：分/次
	uint8	Overdraft[1];//是否允许透支	CHAR	1	0：禁止， 1：允许。
	uint8	Overdraftlimit[6];//透支额度	CHAR	6	单位：分
	uint8	TopUp[1];//是否允许充值	CHAR	1	0：禁止， 1：允许。
	uint8	TopUplimit[6];//每次充值上限	CHAR	6	单位：分/次。
	uint8	UpdateManner[1];//更新时收费方式	CHAR	1	0：现金，1：卡， 2：卡或现金。
	uint8	PaintPlaceCheck1[1];//付费区非本站更新检查标志	CHAR	1	0：不检查，1：检查
	uint8	PaintPlaceCheck2[1];//付费区非本日更新检查标志	CHAR	1	0：不检查，1：检查
	uint8	Refund[1];//是否允许退款	CHAR	1	0-禁止，1-允许
	uint8	RefundLimitCount[3];//退款时使用次数限制	CHAR	3	000：表示不限制。使用次数未达到此限制时不允许退款。
	uint8	OneDayLimitCount[2];//日乘坐次数上限	CHAR	2	00：表示不限制
	uint8	OneMouthLimitCount[4];//月乘坐次数上限	CHAR	4	0000：表示不限制
	uint8	ValidityMin[16];//有效期	CHAR	16	单位：分钟。从发售时开始多少天内有效，以分钟计 
	uint8	Delay[1];//是否允许延期	CHAR	1	0：禁止, 1：允许
	uint8	DelayDayTime[4];//可延长时间	CHAR	4	单位：天。每次延长有效期时可延长的时间
	uint8	Deposit[6];//押金	CHAR	6	单位：分
	uint8	SellingPrice[6];//售价	CHAR	6	单位：分
	uint8	SaleHandingCharge[6];//发售手续费	CHAR	6	单位：分
	uint8	ActivateFlag[1];//使用前是否需激活	CHAR	1	0：不需要，1：需要
	uint8	CheckBlackList[1];//是否检查黑名单	CHAR	1	0：不检查，1：检查
	uint8	RemainCheck[1];//是否检查余额/余次	CHAR	1	0：不检查，1：检查
	uint8	PhysicsCheck[1];//逻辑及物理有效期检查	CHAR	1	0：不检查逻辑及物理有效期；1：检查逻辑及物理有效期；2：检查逻辑但不检查物理有效期；3：不检查逻辑期但检查物理有效期
	uint8	InOutOrderCheck[1];//进出站次序检查	CHAR	1	0：进出站均不检查进出站次序1：进出站均检查进出站次序2：进站不检查进出站次序，出站检查进出站次序3：进站检查进出站次序，出站不检查进出站次序
	uint8	OverTimeCheck[1];//是否检查超时	CHAR	1	0：不检查，1：检查
	uint8	OverTaken[1];//是否检查超乘	CHAR	1	0：不检查，1：检查
	uint8	StationCheck[1];//是否限制进出站点	CHAR	1	0：否，1：是。具体限制的进出站信息制票时写在票卡上。
	uint8	CurrentStationCheck[1];//是否只允许本站进出	CHAR	1	0：否，1：是。即本站进的只能本站出，不能在其他站出。
	uint8	TopUpDevice[16];//充值设备	CHAR	16	设备类的字符信息代码（见设备字符信息代码）0：不可以，1：可以
	uint8	UseDevice[16];//哪种设备可使用	CHAR	16	设备类的字符信息代码（见设备字符信息代码）0：不可以，1：可以
	uint8	SailStationCheck[1];//本站发售控制标记	CHAR	1	0：表示只有在本在购买的单程票才能进站1：表示从其它车站购买的单程票，可以在本站进入
	uint8	RefundMoneyLimit[6];//退款余额上限	CHAR	6	单位：分
	uint8	RefundHandingCharge[6];//退款手续费	CHAR	6	单位：分
	uint8	SaleDevice[16];//发售设备	CHAR	16	设备类的字符信息代码（见设备字符信息代码）0：不可以，1：可以
	uint8	IsRefundDeposit[1];//是退押金	CHAR	1	0：不检查，1：检查
	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0301;

//0302   闸机专用通道参数
typedef struct  _Para0302{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	TicketType[4];//票卡类型	CHAR	4
	uint8	PreferentialCard[1];//是否优惠票	CHAR	1	0：普通票 1：优惠票
	uint8	VoicePrompt[1];//是否启用语音提示	CHAR	1	0：否 1：是

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0302;

//0401   收费区段表
typedef struct  _Para0401{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	InGateStation[4];//进站的车站代码	CHAR	4
	uint8	OutGateStation[4];//出站的车站代码	CHAR	4
	uint8	FareZone[2];//收费区段	CHAR	2
	uint8	JourneyTimeLimit[5];//乘车时间限制 (单位：分钟)	CHAR	5	单位：分钟
	uint8	TimeoutsFines[4];//超时罚金	CHAR	4

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0401;

//0402   收费配置表
typedef struct  _Para0402{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	CardType[4];//票种代码	CHAR	4
	uint8	RidingTime[1];//乘车时间代码	CHAR	1
	uint8	TrainTicketTableID[3];//票价表ID	CHAR	3

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0402;

//0403   票价表
typedef struct  _Para0403{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	TrainTicketTableID[3];//票价表ID	CHAR	3
	uint8	FareZone[2];//收费区段	CHAR	2
	uint8	Fare[10];//收费 (单位：分或次)	CHAR	10

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0403;

//0404   节假日定义表
typedef struct  _Para0404{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	HolidayCode[1];//节假日代码	CHAR	1
	uint8	StartDate[8];//开始日期	CHAR	8
	uint8	CloseDate[8];//结束日期	CHAR	8

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0404;

//0405   非繁忙时间定义表
typedef struct  _Para0405{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	WeekTime[1];//星期时间	CHAR	1
	uint8	StartTime[4];//开始时间	CHAR	4	HH：MM
	uint8	CloseTime[4];//结束时间	CHAR	4	HH：MM

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0405;


typedef struct  _Para0400Price{
	uint8	Valid[1];//是否有效，0无效，1有效

	uint8	FareZone[2];//收费区段	CHAR	2
	uint8	CardType[4];//票种代码	CHAR	4
	uint8	RidingTime[1];//乘车时间代码	CHAR	1
	uint8	TrainTicketTableID[3];//票价表ID	CHAR	3
	uint8	Fare[10];//收费 (单位：分或次)	CHAR	10
}Para0400Price;

//0501   降级模式使用记录
typedef struct  _Para0501{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	StationCode[4];//发生模式的车站	CHAR	4	1
	uint8	ModeType[3];//模式的类型	CHAR	3	001-006 参见11.2节状态代码表
	uint8	BeginDateTime[14];//发生降级模式的时间	CHAR	14	YYYYMMDDHHMMSS
	uint8	EndDateTime[14];//降级模式的结束时间	CHAR	14	YYYYMMDDHHMMSS，默认为14个空格
	uint8	OpertorID0[6];//设置模式的操作员ID	CHAR	6
	uint8	OpertorID1[6];//取消模式的操作员ID	CHAR	6	取消模式的操作员ID，默认为6个空格

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0501;

//0601   地铁单个黑名单
typedef struct  _Para0601{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	CardNum[20];//逻辑卡号	CHAR	20
	uint8	WorkedCode[3];//设备处理代码	CHAR	3	预留字段

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0601;

//0602   地铁黑名单段
typedef struct  _Para0602{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	StarCardNum[20];//起始逻辑卡号	CHAR	20
	uint8	EndCardNum[20];//终止逻辑卡号	CHAR	20
	uint8	WorkedCode[3];//设备处理代码	CHAR	3	预留字段

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0602;

//0603   公交一卡通单个黑名单
typedef struct  _Para0603{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	CardNum[20];//逻辑卡号	CHAR	20
	uint8	WorkedCode[3];//设备处理代码	CHAR	3	预留字段

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0603;

//0604   公交一卡通黑名单段
typedef struct  _Para0604{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	StarCardNum[20];//起始逻辑卡号	CHAR	20
	uint8	EndCardNum[20];//终止逻辑卡号	CHAR	20
	uint8	WorkedCode[3];//设备处理代码	CHAR	3	预留字段

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0604;

//0801   行政收费罚金参数
typedef struct  _Para0801{
	uint8	FileHead[4];//参数文件标识
	uint8	Separator[1];//':'

	uint8	XZCode[2];//行政代码	CHAR	2
	uint8	PenaltyValue[4];//罚金 单位 分
	uint8	StationCode[4];//车站代码
	uint8	TicketType[4];//票卡类型

	uint8	EndFlag[2];//回车键0x0d 0x0a
}Para0801;

/*
struct _FileAllocationTable_t
{
    uint16 FileID;
    uint16 Filelength;
    uint8* FileStartPoint;
    uint8 Reserve[10];
};
typedef struct _FileAllocationTable_t FileAllocationTable_t;
*/

#pragma pack(pop)

typedef struct _CDFileVar_t
{
    uint16 FileID;
    char   FileName[256];
    uint32 FileLen;
    uint8 *FileData;
}CDFileVar_t;


//初始化参数信息
int32 InitParam();

int32 ReadAndCheckFile(char* FileName,char **FileBuffer,uint32 *FileSize);
//解析参数文件
int32 ParseParam(uint16 u16ParamID);

int32 AddParamInfo(uint16 u16ParamID,char * szFileName);

//获取参数文件信息
int32 GetParamInfo(uint16 u16ParamID,char * szFileName);

int32 SetParamInfo(uint16 u16ParamID,char * szFileName);


int CheckAllParamInfo(uint8 u8DeviceType);

//===============================================================
// 函 数 名：BR_GetParaTicketsTypeTable _h
// 功能描述：获取"票卡参数"(0301)
// 输入参数：MainType	车票主类型,	SubType	车票子类型	
// 输出参数：输出对应的的"票卡参数"结构信息:p_TicketsPara = &g_BRContext.TicktPara0301
// 函数返回值 :成功返回0；失败返回相应错误代码
// 创建日期：2015-01-22
// 修改日期：
// 作    者：szp
// 附加说明：
// 设计修改日志：
//===============================================================
uint32 BR_GetParaTicketsTypeTable_h( uint8 MainType, uint8 SubType ,uint8 * p_TicketsPara );

//===============================================================
// 函 数 名：BR_CheckBlacklistCardACC_h
// 功能描述：检查票是否在地铁黑名单里
// 输入参数：逻辑卡号
// 输出参数：输出设备处理代码
// 函数返回值 :如果卡在黑名单内，返回0，否则返回错误代码
// 创建日期：2015-01-23
// 修改日期：
// 作    者：szp
// 附加说明：
// 设计修改日志：
//===============================================================
uint32 BR_CheckBlacklistCardACC_h(uint8 * LogicID,uint8 * BlackListControl);

	//===============================================================
// 函 数 名：BR_CheckBlacklistCardYKT_h
// 功能描述：检查票是否在公交一卡通黑名单里
// 输入参数：逻辑卡号
// 输出参数：输出设备处理代码
// 函数返回值 :如果卡在黑名单内，返回0，否则返回错误代码
// 创建日期：2015-01-23
// 修改日期：
// 作    者：szp
// 附加说明：
// 设计修改日志：
//===============================================================
uint32 BR_CheckBlacklistCardYKT_h(uint8 * LogicID,uint8 * BlackListControl);

//===============================================================
// 函 数 名：BR_CalcAmountConsumption _h
// 功能描述：计算消费金额
// 输入参数：字符串
	//uint8 m_InGateStation[4]={0};'0201'
	//uint8 m_OutGateStation[4]={0};'0201'
	//uint8 m_CardType[4]={0};'0201'
	//uint8 m_InGateTime[14]={0};'20150123143723'
	//uint8 m_OutGateTime[14]={0};'20150123145112'
	//uint8 m_weekdayIn[1]={0};'0~6'
	//uint8 m_weekdayOut[1]={0};'0~6'
// 输出参数：字符串
	//uint8 m_FareZone[2]={0};//收费区段	CHAR	2
	//uint8 m_JourneyTimeLimit[5]={0};//乘车时间限制 (单位：分钟)	CHAR	5	单位：分钟
	//uint8 m_TimeoutsFines[4]={0};//超时罚金	CHAR	4
	//uint8 m_RidingTime[1]={0};//乘车时间代码	CHAR	1
	//uint8 m_TrainTicketTableID[3]={0};//票价表ID	CHAR	3
	//uint8 m_Fare[10]={0};//收费 (单位：分或次)	CHAR	10
// 函数返回值 :成功返回0；失败返回相应错误代码
// 创建日期：2015-01-23
// 修改日期：
// 作    者：szp
// 附加说明：
// 设计修改日志：
//===============================================================
uint32 BR_CalcAmountConsumption_h(uint8* m_CardType, uint8* m_InGateStation, uint8* m_OutGateStation, uint8* m_InGateTime,uint8* m_OutGateTime,uint8* m_weekdayIn,uint8* m_weekdayOut, 
	uint8* m_FareZone, uint8* m_JourneyTimeLimit, uint8* m_TimeoutsFines, uint8* m_RidingTime, uint8* m_TrainTicketTableID, uint8* m_Fare);

BOOL GetCDFilePointer(uint16 CDfileflag, uint32 *FileLen,	uint8 **pFiledata);

uint32 BR_CalcPrice(uint8 *u8CardType,uint8 *u8InGateStation,uint8 *u8OutGateStation,uint8* u8BCDInGateTime,uint8* u8BCDOutGateTime,
		uint16* FareZone,uint16*JourneyTimeLimit,uint16*TimeoutsFines,uint8 *RidingTime,uint8 *TrainTicketTableID,uint32* Fare);

uint32 BR_GetMinPrice(uint8 *u8CardType,uint8 *u8CurrentStation,uint8* u8CurrentTime,uint32 * u32MinPrice);

uint32 BR_GetPaneltyValue(uint8 MainType, uint8 SubType,uint8 *u8CurrentStation,uint8 u8PaneltyCode,uint16 * u16PaneltyValue);

uint32 BR_LoadStationList();


// return
uint32 BR_GetDegradeValidDate( char *DegradeValidDay);

uint32 BR_IsExsitStationCode(  char *StationCode);

//DeviceCode  0201 + 001 +03  车站 + 设备序列号 + 设备类型
uint32 BR_IsExsitDeviceCode(  char *DeviceCode);

//DeviceCode  0201 + 001 +03  车站 + 设备序列号 + 设备类型
uint32 BR_IsExsitSAMLogicCode(  char *SamLogicCode,  char samType,char *DeviceCode);


uint32 BR_GetTicketLastProcessStationMode( char *ucStationCode,Para0501 * pstPara0501);

uint32 BR_GetAgTicketPara(uint8 MainType,uint8 SubType,Para0302 *pstPara0302);


uint32 BR_GetTranStationPara(  char *StationCode1, char *StationCode2);

BOOL Check_IsTranStaton(uint8 * szStation1,uint8 *szStation2);


#endif
