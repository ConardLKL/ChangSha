

#include "RWParameter.h"
#include "XPublic/Log.h"

static  CDFileVar_t	CDFileVar[50];
static  uint8 m_CDFileVarLength;

static HashDictionary  m_StationList;

//初始化参数信息
int32 InitParam()
{


	int iRet=-1;
    char cHexString[5]={0};
	DIR *dirp = NULL;
	struct dirent *direp=NULL;
	uint16 u16ParamID=0;
    char FileName[256]={0};
    char *FileBuffer=NULL;
    uint32 FileSize=0;

	m_CDFileVarLength=0;

	if(!(dirp=opendir(PARAM_PATH)))
	{
		PrintLog("File[%s]Line[%d] open dir[%s] fail.",__FILE__,__LINE__,PARAM_PATH);
		return -1;
	}

	while(1)
	 {
		direp = readdir(dirp);
		if(!direp)
		{
			PrintLog("File[%s]Line[%d] direp is NULL",__FILE__,__LINE__);
			break;
		}

		if (direp->d_type==4)
		{
			PrintLog("File[%s]Line[%d] direp->d_type[%d]",__FILE__,__LINE__,direp->d_type);
		    continue;
		}

		PrintLog("File[%s]Line[%d] direp->d_type[%d]",__FILE__,__LINE__,direp->d_type);

		strcpy(FileName,direp->d_name);

		PrintLog("File[%s]Line[%d] FileName[%s]",__FILE__,__LINE__,FileName);


		iRet= ReadAndCheckFile(FileName,&FileBuffer,&FileSize);

		if(iRet!=RW_EC_OK)
		{
			continue;
		}

		strncpy(cHexString,FileName+4,4);

		u16ParamID=strtol(cHexString,NULL,16);

		PrintLog("File[%s]Line[%d] u16ParamID[%02X]",__FILE__,__LINE__,u16ParamID);

		strcpy(CDFileVar[m_CDFileVarLength].FileName,FileName);

		CDFileVar[m_CDFileVarLength].FileID=u16ParamID;

		PrintLog("File[%s]Line[%d] u16ParamID[%02X]",__FILE__,__LINE__,CDFileVar[m_CDFileVarLength].FileID);

		CDFileVar[m_CDFileVarLength].FileData=malloc(FileSize);

		memcpy(CDFileVar[m_CDFileVarLength].FileData,FileBuffer,FileSize);

		CDFileVar[m_CDFileVarLength].FileLen=FileSize;

		m_CDFileVarLength++;

		if(FileBuffer!=NULL)
		{
			free(FileBuffer);
			FileBuffer=NULL;
		}

	 }

	//init station list

	Initialize(&m_StationList,3);

	BR_LoadStationList();

	return 0;
}

int32 ReadAndCheckFile(char* FileName,char **FileBuffer,uint32 *FileSize)
{
	FILE    *fp ;

	char szFilePath[256]={0};

	int iReadFileSize=-1;

	uint32 u32FileSize=0;

	sprintf(szFilePath,"%s/%s",PARAM_PATH,FileName);


	if(access(szFilePath,0)!=0)
	{
		return -1;
	}

	fp=fopen(szFilePath,"r") ;
	if(fp==(FILE *)0)
	{
		return -1;
	}

	 fseek (fp, 0, SEEK_END);   ///将文件指针移动文件结尾

	 u32FileSize=ftell (fp); ///求出当前文件指针距离文件开始的字节数

	 *FileSize=u32FileSize;

	 *FileBuffer= malloc(u32FileSize);

	 fseek (fp, 0, SEEK_SET);

	 iReadFileSize=fread(*FileBuffer,1,u32FileSize,fp);
	 if(iReadFileSize!=u32FileSize)
	 {
		 fclose(fp);
		 return -1;
	 }

	 //todo:检差CRC


	 fclose(fp);

	 return 0;
}

int CheckAllParamInfo(uint8 u8DeviceType)
{
    int iRet=0;
    char szFileName[128]={0};

    //---public
    //0101   设备控制参数
    iRet=GetParamInfo(FILE_ACC_DEVICE_CONTRORL,szFileName); if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
    //0202   车站配置表
    iRet=GetParamInfo(FILE_ACC_STATION_TABLE,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
    //0203   SAM卡对照表
    iRet=GetParamInfo(FILE_ACC_CHANGSHA_SAM,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
    //0204   换乘车站代码表
    iRet=GetParamInfo(FILE_ACC_TRAN_STATION,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
    //0301   票卡参数
    iRet=GetParamInfo(FILE_ACC_CHANGSHA_TICKETTYPE,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
    //0303   乘次票专用参数
    iRet=GetParamInfo(FILE_ACC_TRIPS_TICKET,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
    //0401   收费区段表
    iRet=GetParamInfo(FILE_ACC_CHANGSHA_TICKETVALUE,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;


    if(u8DeviceType!=EM_DEVICE_TYPE_TVM)
    {
		//0501   降级模式使用记录
		iRet=GetParamInfo(FILE_ACC_CHANGSHA_DEGRADE_HISTORY,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
		//0601   地铁单个黑名单
		iRet=GetParamInfo(FILE_ACC_CHANGSHA_SINGLEBLACKLIST,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
		//0602   地铁黑名单段
		iRet=GetParamInfo(FILE_ACC_CHANGSHA_BATCHBLACKLIST,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
		//0603   公交一卡通单个黑名单
		iRet=GetParamInfo(FILE_YKT_CHANGSHA_SINGLEBLACKLIST,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
		//0604   公交一卡通黑名单段
		iRet=GetParamInfo(FILE_YKT_CHANGSHA_BATCHBLACKLIST,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
    }

	if(u8DeviceType==EM_DEVICE_TYPE_AGM_ENTRY||u8DeviceType==EM_DEVICE_TYPE_AGM_EXIT||u8DeviceType==EM_DEVICE_TYPE_AGM_DOUBLE)
	{
	    //0302   闸机专用通道参数
	    iRet=GetParamInfo(FILE_ACC_CHANGSHA_AG,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
	}
	if(u8DeviceType==EM_DEVICE_TYPE_BOM)
	{
		//0801   行政收费罚金参数
	    iRet=GetParamInfo(FILE_ACC_CHANGSHA_XZSFFJ,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;
	}
//	//9320   BOMTPU程序
//	iRet=GetParamInfo(FILE_BOM_TPU	,szFileName);	if(iRet==-1)return RW_EC_PARAMETER_FILE_NOT_EXIST;

	return CE_OK;
}


int32 GetParamInfo(uint16 u16ParamID,char * szFileName)
{
	int iIndex=0;
	if(szFileName==NULL)
	{
		return -1;
	}

	while(iIndex<m_CDFileVarLength)
	{
		if(CDFileVar[iIndex].FileID==u16ParamID)
		{
			strcpy(szFileName,CDFileVar[iIndex].FileName);
			return iIndex;
		}

		iIndex++;
	}
	PrintLog("File[%s]Line[%d] GetParamInfo  ParamID[0x%02X] Not Exist ",__FILE__,__LINE__,u16ParamID);
	return -1;
}

int32 AddParamInfo(uint16 u16ParamID,char * szFileName)
{

	if(szFileName==NULL)
	{
		return -1;
	}


	CDFileVar[m_CDFileVarLength].FileID=u16ParamID;

	strcpy(CDFileVar[m_CDFileVarLength].FileName,szFileName);

	m_CDFileVarLength++;

	return CE_OK;

}

int32 SetParamInfo(uint16 u16ParamID,char * szFileName)
{
	int iIndex=0;
	if(szFileName==NULL)
	{
		return -1;
	}

	while(iIndex<=m_CDFileVarLength)
	{
		if(CDFileVar[iIndex].FileID==u16ParamID)
		{
			memset(CDFileVar[iIndex].FileName,0,sizeof(CDFileVar[iIndex].FileName));
			strcpy(CDFileVar[iIndex].FileName,szFileName);
			return iIndex;
		}

		iIndex++;
	}

	return -1;
}

int32 ParseParam(uint16 u16ParamID)
{

	FILE    *fp ;

	char szFileName[256]={0};
	char szFilePath[256]={0};

	uint8 u8Index=0;


	uint32 u32FileSize=0;


	u8Index=GetParamInfo(u16ParamID,szFileName);
	if(-1==u8Index)
	{
		return -1;
	}

	sprintf(szFilePath,"%s/%s",PARAM_PATH,szFileName);


	if(access(szFilePath,0)!=0)
	{
		return -1;
	}

	fp=fopen(szFilePath,"r") ;
	if(fp==(FILE *)0)
	{
		return -1;
	}

	 fseek (fp, 0, SEEK_END);   ///将文件指针移动文件结尾
	 u32FileSize=ftell (fp); ///求出当前文件指针距离文件开始的字节数


	 CDFileVar[u8Index].FileLen=u32FileSize;

	 if(CDFileVar[u8Index].FileData!=NULL)
	 {
		 free(CDFileVar[u8Index].FileData);
	 }
	 CDFileVar[u8Index].FileData=malloc(u32FileSize+1);

	 fseek (fp, 0, SEEK_SET);

	 fread(CDFileVar[u8Index].FileData,u32FileSize,1,fp);


	 fclose(fp);



	return 0;
}


///-----------------------------------------------------------------------------
///函数名称:	GetCDFilePointer
///功能:		取得FileID对应的内存地址
///输入参数:	uint16 CDfileflag 文件ID
///输出参数:	uint8 **pFiledata 文件ID对应的存储地址
///输入输出:	无
///返回值:		BOOL值,函数执行是否成功
///-----------------------------------------------------------------------------
BOOL GetCDFilePointer(uint16 CDfileflag, uint32 *FileLen,	uint8 **pFiledata)
{
	uint8 i=0;
	
	for(i=0; i<sizeof(CDFileVar)/sizeof(CDFileVar_t); i ++ )
	{
		if((CDFileVar[i].FileID == CDfileflag)&&(CDFileVar[i].FileData != NULL))
		{
			*FileLen = CDFileVar[i].FileLen;
			*pFiledata = CDFileVar[i].FileData;
			return TRUE;
		}
		else if(CDFileVar[i].FileID == 0)	//说明找不到此参数
		{
			return FALSE;
		}
	}
    return FALSE;
}




uint32 BR_GetDegradeValidDate( char *DegradeValidDay)
{

	BOOL bResult=FALSE;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	Para0101  stTicketPara;

	if(NULL==DegradeValidDay)
	{
		return CE_CHECKERROR;//详细错误代码以后添加
	}

	memset(&stTicketPara,0,sizeof(Para0101));

	uint8 *pFile=NULL;
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_DEVICE_CONTRORL,	&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)
	{
		return CE_CHECKERROR;//详细错误代码以后添加
	}
	pFile=tmp_pFiledata;

	uint32 pos=0;//偏移量
	memcpy(&stTicketPara,  pFile+pos, sizeof(Para0101));

	memcpy(DegradeValidDay,stTicketPara.DegradeValidDate,sizeof(stTicketPara.DegradeValidDate));

	return CE_OK;
}

uint32 BR_IsExsitStationCode(  char *StationCode)
{

	Entry *pEntry=NULL;
	char szKey[5]={0};

	if(StationCode==NULL)
	{
		return CE_CHECKERROR;
	}
	memcpy(szKey,StationCode,4);
	pEntry= FindEntry(&m_StationList,szKey);
	if(NULL!=pEntry)
	{
		 return CE_OK;
	}

	return CE_CHECKERROR;
}

uint32 BR_IsExsitDeviceCode(  char *DeviceCode)
{
	BOOL bResult=FALSE;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	Para0202  stStationPara;

	if(DeviceCode==NULL)
	{
		return CE_CHECKERROR;
	}

	uint8 *pFile=NULL;
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_STATION_TABLE,&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	uint32 pos=0;//偏移量
	uint32 k=0;
	for(k=0;k<(FileLen/sizeof(Para0202));k++)
	{
		memcpy(&stStationPara,  pFile+pos, sizeof(Para0202));
		if(memcmp(stStationPara.DeviceCode,DeviceCode,9)==0)
		{
			return CE_OK;
		}
		pos += sizeof(Para0202);
	}

	return CE_CHECKERROR;
}

uint32 BR_IsExsitSAMLogicCode(  char *SamLogicCode, char samType, char *DeviceCode)
{
	BOOL bResult=FALSE;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	Para0203  stStationPara;

	if(SamLogicCode==NULL||DeviceCode==NULL)
	{
		return CE_CHECKERROR;
	}

	uint8 *pFile=NULL;
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_CHANGSHA_SAM,&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	uint32 pos=0;//偏移量
	uint32 k=0;
	for(k=0;k<(FileLen/sizeof(Para0203));k++)
	{
		memcpy(&stStationPara,  pFile+pos, sizeof(Para0203));
		if(memcmp(stStationPara.StationCode,DeviceCode,9)==0&&memcmp(stStationPara.SAM_Num,SamLogicCode,16)==0&&
				samType==stStationPara.SAM_Type[0])
		{
			return CE_OK;
		}
		pos += sizeof(Para0203);
	}

	return CE_CHECKERROR;
}


uint32 BR_GetTicketLastProcessStationMode( char *ucStationCode,Para0501 * pstPara0501)
{
	BOOL bResult=FALSE;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	Para0501  stTmpPara;

	if(ucStationCode==NULL||pstPara0501==NULL)
	{
		return CE_CHECKERROR;
	}

	uint8 *pFile=NULL;
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_CHANGSHA_DEGRADE_HISTORY,&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	uint32 pos=0;//偏移量
	uint32 k=0;
	for(k=0;k<(FileLen/sizeof(Para0501));k++)
	{
		memcpy(&stTmpPara,  pFile+pos, sizeof(Para0501));
		if(memcmp(stTmpPara.StationCode,ucStationCode,4)==0)
		{
			memcpy(pstPara0501,&stTmpPara,sizeof(Para0501));
			return CE_OK;
		}
		pos += sizeof(Para0501);
	}

	return CE_CHECKERROR;
}
uint32 BR_GetAgTicketPara(uint8 MainType,uint8 SubType,Para0302 *pstPara0302)
{

	BOOL bResult=FALSE;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	Para0302  stTmpPara;

	char TicketType[5]={0};

	if(TicketType==NULL||NULL==pstPara0302)
	{
		return CE_CHECKERROR;
	}

	sprintf(TicketType,"%02X%02X",MainType,SubType);

	uint8 *pFile=NULL;
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_CHANGSHA_AG,&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	uint32 pos=0;//偏移量
	uint32 k=0;
	for(k=0;k<(FileLen/sizeof(Para0302));k++)
	{
		memcpy(&stTmpPara,  pFile+pos, sizeof(Para0302));
		if(memcmp(stTmpPara.TicketType,TicketType,4)==0)
		{
			memcpy(pstPara0302,&stTmpPara,sizeof(Para0302));
			return CE_OK;
		}
		pos += sizeof(Para0302);
	}

	return CE_CHECKERROR;

}

uint32 BR_GetTranStationPara(  char *StationCode1, char *StationCode2)
{


	BOOL bResult=FALSE;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	Para0204  stTmpPara;

	if(StationCode1==NULL||NULL==StationCode2)
	{
		return CE_CHECKERROR;
	}

	uint8 *pFile=NULL;
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_TRAN_STATION,&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	uint32 pos=0;//偏移量
	uint32 k=0;
	for(k=0;k<(FileLen/sizeof(Para0204));k++)
	{
		memcpy(&stTmpPara,  pFile+pos, sizeof(Para0204));
		if(memcmp(stTmpPara.TranStation_A,StationCode1,4)==0&&memcmp(stTmpPara.TranStation_B,StationCode2,4)==0)
		{
			return CE_OK;
		}
		pos += sizeof(Para0204);
	}

	return CE_CHECKERROR;


}

//===============================================================
// 函 数 名：BR_GetParaTicketsTypeTable _h
// 功能描述：获取"票卡参数"(0301)
// 输入参数：MainType	车票主类型,	SubType	车票子类型	
// 输出参数：输出对应的的"票卡参数"结构信息:p_TicketsPara = &g_BRContext.TicktPara0301
// 函数返回值 :成功返回0；失败返回相应错误代码
// 创建日期：2015-01-22
// 修改日期：
// 作    者：szp
// 附加说明：
// 设计修改日志：
//===============================================================
uint32 BR_GetParaTicketsTypeTable_h( uint8 MainType, uint8 SubType ,uint8 * p_TicketsPara )
{
	BOOL bResult=FALSE;
	uint8 tmp_MainType;
	uint8 tmp_SubType;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	Para0301*  pTicketPara;
	pTicketPara = (Para0301*)p_TicketsPara;

	if(p_TicketsPara==NULL)
	{
		return CE_CHECKERROR;
	}


	uint8 *pFile=NULL;
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_CHANGSHA_TICKETTYPE,	&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	uint32 pos=0;//偏移量
	uint32 k=0;
	for(k=0;k<(FileLen/sizeof(Para0301));k++)
	{
		memcpy(pTicketPara,  pFile+pos, sizeof(Para0301));
		tmp_MainType = ((pTicketPara->TicketMainType[0]-'0')<<4)+(pTicketPara->TicketMainType[1]-'0');
		tmp_SubType = ((pTicketPara->TicketSubType[0]-'0')<<4)+(pTicketPara->TicketSubType[1]-'0');
		if(tmp_MainType==MainType && tmp_SubType==SubType)
		{
			return CE_OK;
		}
		pos += sizeof(Para0301);
	}

	return CE_CHECKERROR;
}





//===============================================================
// 函 数 名：BR_CalcAmountConsumption _h
// 功能描述：计算消费金额
// 输入参数：字符串
	//uint8 m_InGateStation[4]={0};'0201'
	//uint8 m_OutGateStation[4]={0};'0201'
	//uint8 m_CardType[4]={0};'0201'
	//uint8 m_InGateTime[14]={0};'20150123143723'
	//uint8 m_OutGateTime[14]={0};'20150123145112'
	//uint8 m_weekdayIn[1]={0};'0~6'
	//uint8 m_weekdayOut[1]={0};'0~6'
// 输出参数：字符串
	//uint8 m_FareZone[2]={0};//收费区段	CHAR	2
	//uint8 m_JourneyTimeLimit[5]={0};//乘车时间限制 (单位：分钟)	CHAR	5	单位：分钟
	//uint8 m_TimeoutsFines[4]={0};//超时罚金	CHAR	4
	//uint8 m_RidingTime[1]={0};//乘车时间代码	CHAR	1
	//uint8 m_TrainTicketTableID[3]={0};//票价表ID	CHAR	3
	//uint8 m_Fare[10]={0};//收费 (单位：分或次)	CHAR	10
// 函数返回值 :成功返回0；失败返回相应错误代码
// 创建日期：2015-01-23
// 修改日期：
// 作    者：szp
// 附加说明：
// 设计修改日志：
//===============================================================
uint32 BR_CalcAmountConsumption_h(uint8* m_CardType, uint8* m_InGateStation, uint8* m_OutGateStation, uint8* m_InGateTime,uint8* m_OutGateTime,uint8* m_weekdayIn,uint8* m_weekdayOut, 
	uint8* m_FareZone, uint8* m_JourneyTimeLimit, uint8* m_TimeoutsFines, uint8* m_RidingTime, uint8* m_TrainTicketTableID, uint8* m_Fare)
{
	BOOL bResult=FALSE;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	uint32 k=0;

	uint8 *pFile=NULL;
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_CHANGSHA_TICKETVALUE,	&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;


	
	Para0401 g_para0401;
	Para0402 g_para0402;
	Para0403 g_para0403;
	Para0404 g_para0404;
	Para0405 g_para0405;
	Para0400Price g_para0400Price[6];
	memset(&g_para0401,0x00,sizeof(g_para0401));
	memset(&g_para0402,0x00,sizeof(g_para0402));


	memset(&g_para0403,0x00,sizeof(g_para0403));
	memset(&g_para0404,0x00,sizeof(g_para0404));
	memset(&g_para0405,0x00,sizeof(g_para0405));
	memset(&g_para0400Price,0x00,sizeof(g_para0400Price));
	int i=0,j=0,jj=0;//比较字符串是否一致
	

	uint8*	FilePoint=NULL;
	uint8	FileHead[4]={0};//参数文件标识
	uint8	FileHeadCheck[4]={0};//参数文件标识
	int p_over=0;//指针偏移
	FilePoint = pFile;

	memcpy(FileHead,FilePoint,sizeof(FileHead));
	memcpy(FileHeadCheck,FileHead,sizeof(FileHead));
	//p_over+=sizeof(FileHead);
#if 1
	do
	{

		memcpy(FileHead,FileHeadCheck,sizeof(FileHead));

		//PrintLog("File[%s]Line[%d] Comm_GetFare  FileHead ",__FILE__,__LINE__);
		//PrintBuffer(FileHead,4);
		if(FileHead[0]=='0'&&FileHead[1]=='4'&&FileHead[2]=='0'&&FileHead[3]=='1')
		{

			memcpy(g_para0401.FileHead,FileHead,sizeof(FileHead));
			//my_file.Read(g_para0401.Separator,(sizeof(g_para0401)-sizeof(FileHead)));
			memcpy(&g_para0401,FilePoint+p_over,sizeof(g_para0401));
			p_over+=sizeof(g_para0401);
			i = strncmp((char*)m_InGateStation,(char*)(g_para0401.InGateStation),sizeof(g_para0401.InGateStation));
			j = strncmp((char*)m_OutGateStation,(char*)(g_para0401.OutGateStation),sizeof(g_para0401.OutGateStation));
			if(i==0&&j==0)//赋值
			{
				//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
				memcpy(m_FareZone,g_para0401.FareZone,sizeof(g_para0401.FareZone));
				memcpy(m_JourneyTimeLimit,g_para0401.JourneyTimeLimit,sizeof(g_para0401.JourneyTimeLimit));
				memcpy(m_TimeoutsFines,g_para0401.TimeoutsFines,sizeof(g_para0401.TimeoutsFines));

				for( k=0; k<6; k++)
				{
					//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
					g_para0400Price[k].RidingTime[0] = '0'+k;
					memcpy(g_para0400Price[k].FareZone,m_FareZone,sizeof(g_para0400Price[k].FareZone));
					memcpy(g_para0400Price[k].CardType,m_CardType,sizeof(g_para0400Price[k].CardType));
				}
			}
		}
		else if(FileHead[0]=='0'&&FileHead[1]=='4'&&FileHead[2]=='0'&&FileHead[3]=='2')
		{
			//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
			memcpy(g_para0402.FileHead,FileHead,sizeof(FileHead));
			//my_file.Read(g_para0402.Separator,(sizeof(g_para0402)-sizeof(FileHead)));
			memcpy(&g_para0402,FilePoint+p_over,sizeof(g_para0402));
			p_over+=sizeof(g_para0402);
			i = strncmp((char*)m_CardType,(char*)(g_para0402.CardType),sizeof(g_para0402.CardType));
			if(i==0)
			{
				//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
				for( k=0; k<6; k++)
				{
					//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
					j = strncmp((char*)g_para0400Price[k].RidingTime,(char*)(g_para0402.RidingTime),sizeof(g_para0402.RidingTime));
					if(j==0)//赋值
					{
						//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
						memcpy(g_para0400Price[k].TrainTicketTableID,g_para0402.TrainTicketTableID,sizeof(g_para0402.TrainTicketTableID));
					}
				}
			}
		}
		else if(FileHead[0]=='0'&&FileHead[1]=='4'&&FileHead[2]=='0'&&FileHead[3]=='3')
		{
			//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
			memcpy(g_para0403.FileHead,FileHead,sizeof(FileHead));
			//my_file.Read(g_para0403.Separator,(sizeof(g_para0403)-sizeof(FileHead)));
			memcpy(&g_para0403,FilePoint+p_over,sizeof(g_para0403));
			p_over+=sizeof(g_para0403);
			i = strncmp((char*)m_FareZone,(char*)(g_para0403.FareZone),sizeof(g_para0403.FareZone));
			//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
			if(i==0)
			{
				//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
				for( k=0; k<6; k++)
				{
					//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
					j = strncmp((char*)g_para0400Price[k].TrainTicketTableID,(char*)(g_para0403.TrainTicketTableID),sizeof(g_para0403.TrainTicketTableID));
					if(j==0)//赋值
					{
						//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
						memcpy(g_para0400Price[k].Fare,g_para0403.Fare,sizeof(g_para0403.Fare));
					}
				}
			}
		}
		else if(FileHead[0]=='0'&&FileHead[1]=='4'&&FileHead[2]=='0'&&FileHead[3]=='4')
		{
			//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
			memcpy(g_para0404.FileHead,FileHead,sizeof(FileHead));
			//my_file.Read(g_para0404.Separator,(sizeof(g_para0404)-sizeof(FileHead)));
			memcpy(&g_para0404,FilePoint+p_over,sizeof(g_para0404));
			p_over+=sizeof(g_para0404);
			i = strncmp((char*)m_InGateTime,(char*)(g_para0404.StartDate),sizeof(g_para0404.StartDate));
			j = strncmp((char*)m_InGateTime,(char*)(g_para0404.CloseDate),sizeof(g_para0404.CloseDate));
			if(i>=0&&j<=0)
			{
				//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
				for( k=0; k<6; k++)
				{
					//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
					if(g_para0400Price[k].RidingTime[0]==g_para0404.HolidayCode[0])
					{
						//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
						if(k==5)//学校假期只有学生储值票有效
						{//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
							if(m_CardType[0]=='0'&&m_CardType[1]=='2'&&m_CardType[2]=='0'&&m_CardType[3]=='1')
							{g_para0400Price[k].Valid[0] = 1;break;}
							else
							{g_para0400Price[k].Valid[0] = 0;}
						}
						else
						{//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
							g_para0400Price[k].Valid[0] = 1;break;
						}
					}
				}
			}
		}
		else if(FileHead[0]=='0'&&FileHead[1]=='4'&&FileHead[2]=='0'&&FileHead[3]=='5')
		{//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
			memcpy(g_para0405.FileHead,FileHead,sizeof(FileHead));
			//my_file.Read(g_para0405.Separator,(sizeof(g_para0405)-sizeof(FileHead)));
			memcpy(&g_para0405,FilePoint+p_over,sizeof(g_para0405));
			p_over+=sizeof(g_para0405);
			if(m_CardType[0]=='0'&&m_CardType[1]=='1'&&m_CardType[2]=='0'&&m_CardType[3]=='0')//单程票不采用非繁忙时间收费
			{PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
				if(m_weekdayIn[0]=='6')//周六
				{g_para0400Price[2].Valid[0] = 1;break;}
				else if(m_weekdayIn[0]=='0')//周日
				{g_para0400Price[3].Valid[0] = 1;break;}
				else//工作日
				{g_para0400Price[0].Valid[0] = 1;break;}
			}
			else
			{//PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
				i = strncmp((char*)m_weekdayIn,(char*)(g_para0405.WeekTime),sizeof(g_para0405.WeekTime));
				j = strncmp((char*)&m_InGateTime[8],(char*)(g_para0405.StartTime),sizeof(g_para0405.StartTime));
				jj = strncmp((char*)&m_InGateTime[8],(char*)(g_para0405.CloseTime),sizeof(g_para0405.CloseTime));
				if(m_weekdayIn[0]=='6')//周六
				{
					if(i==0&&j>=0&&jj<=0)
					{g_para0400Price[2].Valid[0] = 1;break;}
				}
				else if(m_weekdayIn[0]=='0')//周日
				{
					if(i==0&&j>=0&&jj<=0)
					{g_para0400Price[3].Valid[0] = 1;break;}
				}
				else//工作日
				{
					if(i==0&&j>=0&&jj<=0)
					{g_para0400Price[1].Valid[0] = 1;break;}
				}

				i = strncmp((char*)m_weekdayOut,(char*)(g_para0405.WeekTime),sizeof(g_para0405.WeekTime));
				j = strncmp((char*)&m_OutGateTime[8],(char*)(g_para0405.StartTime),sizeof(g_para0405.StartTime));
				jj = strncmp((char*)&m_OutGateTime[8],(char*)(g_para0405.CloseTime),sizeof(g_para0405.CloseTime));
				if(m_weekdayIn[0]=='6')//周六
				{
					if(i==0&&j>=0&&jj<=0)
					{g_para0400Price[2].Valid[0] = 1;break;}
				}
				else if(m_weekdayIn[0]=='0')//周日
				{
					if(i==0&&j>=0&&jj<=0)
					{g_para0400Price[3].Valid[0] = 1;break;}
				}
				else//工作日
				{
					if(i==0&&j>=0&&jj<=0)
					{g_para0400Price[1].Valid[0] = 1;break;}
				}
			}

		}
		else//判断是否读取完毕
		{PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType ",__FILE__,__LINE__);
			//所有票卡未找到 非繁忙时间 则按正常乘车时间代码确认
			if(m_weekdayIn[0]=='6')//周六
			{g_para0400Price[2].Valid[0] = 1;break;}
			else if(m_weekdayIn[0]=='0')//周日
			{g_para0400Price[3].Valid[0] = 1;break;}
			else//工作日
			{g_para0400Price[0].Valid[0] = 1;break;}

			break;
		}
		//my_file.Read(FileHeadCheck,sizeof(FileHeadCheck));
		memcpy(FileHeadCheck,FilePoint+p_over,sizeof(FileHeadCheck));
		//p_over+=sizeof(FileHeadCheck);
	}while(1);
#endif

//输出数据赋值
	for( k=0;k<6;k++)
	{

		if(g_para0400Price[k].Valid[0]==1)//有效
		{
			memcpy(m_FareZone,g_para0400Price[k].FareZone,sizeof(g_para0400Price[k].FareZone));
			memcpy(m_RidingTime,g_para0400Price[k].RidingTime,sizeof(g_para0400Price[k].RidingTime));
			memcpy(m_TrainTicketTableID,g_para0400Price[k].TrainTicketTableID,sizeof(g_para0400Price[k].TrainTicketTableID));
			memcpy(m_Fare,g_para0400Price[k].Fare,sizeof(g_para0400Price[k].Fare));

		}
	}

	return CE_OK;
}




//===============================================================
// 函 数 名：BR_CheckBlacklistCardACC_h
// 功能描述：检查票是否在地铁黑名单里
// 输入参数：逻辑卡号
// 输出参数：输出设备处理代码
// 函数返回值 :如果卡在黑名单内，返回0，否则返回错误代码
// 创建日期：2015-01-23
// 修改日期：
// 作    者：szp
// 附加说明：
// 设计修改日志：
//===============================================================
uint32 BR_CheckBlacklistCardACC_h(uint8 * LogicID,uint8 * BlackListControl)
{
	BOOL bResult=FALSE;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	uint8 k=0;

	Para0601 BlackList0601;
	Para0602 BlackList0602;
	memset(&BlackList0601,0x00,sizeof(Para0601));
	memset(&BlackList0602,0x00,sizeof(Para0602));
	uint8 *pFile=NULL;
    //查找地铁单个黑名单
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_CHANGSHA_SINGLEBLACKLIST,	&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	int i=1;//比较字符串
	int j=1;//比较字符串
	uint32 pos=0;//偏移量
	if (FileLen/sizeof(Para0601)<3)//顺序查找，效率比较低
	 {
		for( k=0;k<(FileLen/sizeof(Para0601));k++)
		{
			memcpy(&BlackList0601, pFile+pos, sizeof(Para0601));
			i = strncmp((char*)LogicID,(char*)BlackList0601.CardNum,sizeof(BlackList0601.CardNum));
			if(i==0x00)
			{
				memcpy(BlackListControl,BlackList0601.WorkedCode,sizeof(BlackList0601.WorkedCode));
				return CE_OK;
			}
			pos += sizeof(Para0601);
		}
	 }
	 else//二分法查找
	 {
		int low=0;
		int top=(FileLen/sizeof(Para0601))-1;
		int mid=(low+top)/2;

		while(low!=top)
		{
			mid=(low+top)/2;
			pos = mid*sizeof(Para0601);
			memcpy(&BlackList0601, pFile+pos, sizeof(Para0601));
			i = strncmp((char*)LogicID,(char*)BlackList0601.CardNum,sizeof(BlackList0601.CardNum));
			if(i==0x00)
			{
				memcpy(BlackListControl,BlackList0601.WorkedCode,sizeof(BlackList0601.WorkedCode));
				return CE_OK;
			}
			else if(i<0x00)
			{
				top = mid;

			}
			else if(i>0x00)
			{
				low = mid;
			}
		}
	 }


//查找地铁黑名单段
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_CHANGSHA_BATCHBLACKLIST,	&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	i=1;
	j=1;
	pos=0;
	for( k=0;k<(FileLen/sizeof(Para0602));k++)
	{
		memcpy(&BlackList0602, pFile+pos, sizeof(Para0602));
		i = strncmp((char*)LogicID,(char*)BlackList0602.StarCardNum,sizeof(BlackList0602.StarCardNum));
		j = strncmp((char*)LogicID,(char*)BlackList0602.EndCardNum,sizeof(BlackList0602.EndCardNum));
		if(i>=0x00&&j<=0x00)
		{
			memcpy(BlackListControl,BlackList0602.WorkedCode,sizeof(BlackList0602.WorkedCode));
			return CE_OK;
		}
		pos += sizeof(Para0602);
	}

	return CE_CHECKERROR;
}






//===============================================================
// 函 数 名：BR_CheckBlacklistCardYKT_h
// 功能描述：检查票是否在公交一卡通黑名单里
// 输入参数：逻辑卡号
// 输出参数：输出设备处理代码
// 函数返回值 :如果卡在黑名单内，返回0，否则返回错误代码
// 创建日期：2015-01-23
// 修改日期：
// 作    者：szp
// 附加说明：
// 设计修改日志：
//===============================================================
uint32 BR_CheckBlacklistCardYKT_h(uint8 * LogicID,uint8 * BlackListControl)
{
	BOOL bResult=FALSE;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	uint8 k=0;

	Para0603 BlackList0603;
	Para0604 BlackList0604;
	memset(&BlackList0603,0x00,sizeof(Para0603));
	memset(&BlackList0604,0x00,sizeof(Para0604));
	uint8 *pFile=NULL;
//查找公交一卡通单个黑名单
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_YKT_CHANGSHA_SINGLEBLACKLIST,	&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	int i=1;//比较字符串
	int j=1;//比较字符串
	uint32 pos=0;//偏移量
	if (FileLen/sizeof(Para0601)<3)//顺序查找，效率比较低
	{
		for( k=0;k<(FileLen/sizeof(Para0603));k++)
		{
			memcpy(&BlackList0603, pFile+pos, sizeof(Para0603));
			i = strncmp((char*)LogicID,(char*)BlackList0603.CardNum,sizeof(BlackList0603.CardNum));
			if(i==0x00)
			{
				memcpy(BlackListControl,BlackList0603.WorkedCode,sizeof(BlackList0603.WorkedCode));
				return CE_OK;
			}
			pos += sizeof(Para0601);
		}
	}
	 else//二分法查找
	  {
		int low=0;
		int top=(FileLen/sizeof(Para0603))-1;
		int mid=(low+top)/2;
		while(low!=top)
		{
			mid=(low+top)/2;
			pos = mid*sizeof(Para0603);
			memcpy(&BlackList0603, pFile+pos, sizeof(Para0603));
			i = strncmp((char*)LogicID,(char*)BlackList0603.CardNum,sizeof(BlackList0603.CardNum));
			if(i==0x00)
			{
				memcpy(BlackListControl,BlackList0603.WorkedCode,sizeof(BlackList0603.WorkedCode));
				return CE_OK;
			}
			else if(i<0x00)
			{
				top = mid;
			}
			else if(i>0x00)
			{
				low = mid;
			}
		}
	 }

//查找地铁黑名单段
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_YKT_CHANGSHA_BATCHBLACKLIST,	&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	i=1;
	j=1;
	pos=0;
	for( k=0;k<(FileLen/sizeof(Para0604));k++)
	{
		memcpy(&BlackList0604, pFile+pos, sizeof(Para0604));
		i = strncmp((char*)LogicID,(char*)BlackList0604.StarCardNum,sizeof(BlackList0604.StarCardNum));
		j = strncmp((char*)LogicID,(char*)BlackList0604.EndCardNum,sizeof(BlackList0604.EndCardNum));
		if(i>=0x00&&j<=0x00)
		{
			memcpy(BlackListControl,BlackList0604.WorkedCode,sizeof(BlackList0604.WorkedCode));
			return CE_OK;
		}
		pos += sizeof(Para0604);
	}

	return CE_CHECKERROR;
}

uint32 BR_CalcPrice(uint8 *u8CardType,uint8 *u8InGateStation,uint8 *u8OutGateStation,uint8* u8BCDInGateTime,uint8* u8BCDOutGateTime,
		uint16* FareZone,uint16*JourneyTimeLimit,uint16*TimeoutsFines,uint8 *RidingTime,uint8 *TrainTicketTableID,uint32* Fare)
{
	int iRet=-1;
	int iInWeekDay=0;
	int iOutWeekDay=0;
	//参数判断指针是否为空,避免程序崩溃.
	uint8 szTicketType[5]={0};
	uint8 szInStationID[5]={0};
	uint8 szOutStationID[5]={0};
	uint8 szInGateTime[15]={0};
	uint8 szOutGateTime[15]={0};
	uint8 szInweekday[3]={0};
	uint8 szOutweekday[3]={0};

	uint8 szFareZone[3]={0};//收费区段	CHAR	2
	uint8 szJourneyTimeLimit[6]={0};//乘车时间限制 (单位：分钟)	CHAR	5	单位：分钟
	uint8 szTimeoutsFines[5]={0};//超时罚金	CHAR	4
	uint8 szRidingTime[2]={0};//乘车时间代码	CHAR	1
	uint8 szTrainTicketTableID[4]={0};//票价表ID	CHAR	3
	uint8 szFare[11]={0};//收费 (单位：分或次)	CHAR	10

	if(u8CardType==NULL||u8InGateStation==NULL||u8OutGateStation==NULL||FareZone==NULL
	  ||JourneyTimeLimit==NULL||TimeoutsFines==NULL||RidingTime==NULL||TrainTicketTableID==NULL||Fare==NULL)
	{

		return CE_PARAM_ERROR;
	}

	sprintf((char*)szTicketType,"%02x%02x",u8CardType[0],u8CardType[1]);

	sprintf((char*)szInStationID,"%02d%02d",u8InGateStation[0],u8InGateStation[1]);

	sprintf((char*)szOutStationID,"%02d%02d",u8OutGateStation[0],u8OutGateStation[1]);

	sprintf((char*)szInGateTime,"%02x%02x%02x%02x%02x%02x%02x",u8BCDInGateTime[0],u8BCDInGateTime[1],u8BCDInGateTime[2],
			u8BCDInGateTime[3],u8BCDInGateTime[4],u8BCDInGateTime[5],u8BCDInGateTime[6]);

	sprintf((char*)szOutGateTime,"%02x%02x%02x%02x%02x%02x%02x",u8BCDOutGateTime[0],u8BCDOutGateTime[1],u8BCDOutGateTime[2],
			u8BCDOutGateTime[3],u8BCDOutGateTime[4],u8BCDOutGateTime[5],u8BCDOutGateTime[6]);


	iInWeekDay=GetWeekDayOf7BCDTime(u8BCDInGateTime);
	sprintf((char*)szInweekday,"%d",iInWeekDay);

	iOutWeekDay=GetWeekDayOf7BCDTime(u8BCDOutGateTime);
	sprintf((char*)szOutweekday,"%d",iOutWeekDay);


	iRet=BR_CalcAmountConsumption_h(szTicketType, szInStationID, szOutStationID,szInGateTime,szOutGateTime,szInweekday,szOutweekday,
		   szFareZone, szJourneyTimeLimit, szTimeoutsFines, szRidingTime, szTrainTicketTableID, szFare);

	if(iRet==CE_OK)
	{
		*FareZone=atoi((char*)szFareZone);
		*JourneyTimeLimit=atoi((char*)szJourneyTimeLimit);
		*TimeoutsFines=atoi((char*)szTimeoutsFines);
		*RidingTime=atoi((char*)szRidingTime);
		*TrainTicketTableID=atoi((char*)szTrainTicketTableID);
		* Fare=atoi((char*)szFare);
	}

	return iRet;

}
 uint32 BR_GetMinPrice(uint8 *u8CardType,uint8 *u8CurrentStation,uint8* u8CurrentTime,uint32 * u32MinPrice)
{

	 int iRet=-1;

	 if(u8CardType==NULL||u8CurrentTime==NULL||u32MinPrice==NULL||u8CurrentStation==NULL)
	 {
		 return iRet;
	 }


	 uint16 FareZone=0;
	 uint16 JourneyTimeLimit=0;
	 uint16 TimeoutsFines=0;
	 uint8  RidingTime=0;
	 uint8  TrainTicketTableID=0;

	 iRet=BR_CalcPrice(u8CardType,u8CurrentStation,u8CurrentStation,u8CurrentTime,u8CurrentTime,
	 		&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,u32MinPrice);

	 if(iRet!=CE_OK)
	 {
		 return iRet;
	 }

	 return iRet;
}

 uint32 BR_GetPaneltyValue(uint8 MainType, uint8 SubType,uint8 *u8CurrentStation,uint8 u8PaneltyCode,uint16 * u16PaneltyValue)
{

	 int iRet=-1;

	 if(u16PaneltyValue==NULL||u8CurrentStation==NULL)
	 {
		 return iRet;
	 }

	BOOL bResult=FALSE;
	uint8 tmp_MainType=0;
	uint8 tmp_SubType=0;
	uint8 tmp_PaneltyCode=0;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	Para0801   stTicketPara0801;
    char szPenaltyValue[5]={0};
    char szXZCode[3]={0};
    int iPenltyValue=0;

	uint8 *pFile=NULL;
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_CHANGSHA_XZSFFJ,	&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	uint32 pos=0;//偏移量
	uint32 k=0;
	for(k=0;k<(FileLen/sizeof(Para0801));k++)
	{
		memset(&stTicketPara0801,0,sizeof(Para0801));
		memcpy(&stTicketPara0801,  pFile+pos, sizeof(Para0801));
		tmp_MainType = ((stTicketPara0801.TicketType[0]-'0')<<4)+(stTicketPara0801.TicketType[1]-'0');
		tmp_SubType = ((stTicketPara0801.TicketType[2]-'0')<<4)+(stTicketPara0801.TicketType[3]-'0');
		memcpy(szXZCode,stTicketPara0801.XZCode,2);
		tmp_PaneltyCode= atoi(szXZCode);
		if(tmp_MainType==MainType && tmp_SubType==SubType&& u8PaneltyCode==tmp_PaneltyCode&&(memcmp(u8CurrentStation,stTicketPara0801.StationCode,4)==0))
		{
			memcpy(szPenaltyValue,stTicketPara0801.PenaltyValue,4);
			iPenltyValue=atoi(szPenaltyValue);
			*u16PaneltyValue=iPenltyValue;
			return CE_OK;
		}
		pos += sizeof(Para0801);
	}

	return CE_CHECKERROR;
}

 uint32 BR_LoadStationList()
 {

	BOOL bResult=FALSE;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	Para0202  stStationPara;
	Entry *pEntry=NULL;
	char szKey[5]={0};

	uint8 *pFile=NULL;
	//取得FileID对应的内存地址
	bResult=GetCDFilePointer(FILE_ACC_STATION_TABLE,&FileLen, &tmp_pFiledata);
	if(bResult==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	uint32 pos=0;//偏移量
	uint32 k=0;
	for(k=0;k<(FileLen/sizeof(Para0202));k++)
	{
		memcpy(&stStationPara,  pFile+pos, sizeof(Para0202));

		pos += sizeof(Para0202);

		memcpy(szKey,stStationPara.DeviceCode,4);
		pEntry= FindEntry(&m_StationList,szKey);
		if(NULL==pEntry)
		{
			Insert(&m_StationList,szKey,szKey,FALSE);
		}
	}

	return CE_CHECKERROR;

 }

 BOOL Check_IsTranStaton(uint8 * szStation1,uint8 *szStation2)
 {

	 BOOL bRet=FALSE;
	 int iRet=-1;

	 char szFirstStation[6]={0};
	 char szSecondStation2[6]={0};
	 sprintf(szFirstStation,"%02d%02d",szStation1[0],szStation1[1]);
	 sprintf(szSecondStation2,"%02d%02d",szStation2[0],szStation2[1]);

	 iRet=BR_GetTranStationPara(szFirstStation,szSecondStation2);
	 PrintLog("File[%s]Line[%d] BR_GetTranStationPara iRet=[%d]",__FILE__,__LINE__,iRet);
	 if(iRet==CE_OK)
	 {
		 bRet=TRUE;
	 }
	 return bRet;
 }

