

#ifndef __GLOBLE_H__
#define __GLOBLE_H__

#include "DataStruct.h"


extern    BR_CONTEXT_H			g_BRContext; 	// BRContext变量



#endif
