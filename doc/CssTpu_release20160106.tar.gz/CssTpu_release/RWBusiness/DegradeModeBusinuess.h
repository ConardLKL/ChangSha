/*
 * DegradeModeBusinuess.h
 *
 *  Created on: Nov 29, 2015
 *      Author: root
 */

#ifndef DEGRADEMODEBUSINUESS_H_
#define DEGRADEMODEBUSINUESS_H_

#include "../Globle.h"
#include "../XPublic/XTime.h"
#include "../XPublic/Log.h"
#include "../RWParam/RWParameter.h"
//降级模式类型
typedef enum  _EM_DEGRADE_MODE_CODE_
{
	EM_MODE_NORMAL 				= 0x00,     //0 正常模式
	EM_MODE_TRAIN_FAULT 		= 0x01,		//1	列车故障模式（000000000000001B）
	EM_MODE_FREE_ENTRY			= 0x02,		//2	进站免检模式（000000000100000B）
	EM_MODE_FREE_DATE			= 0x03,		//3	日期免检模式（000000000000100B）
	EM_MODE_FREE_FARE			= 0x05,		//5	车费免检模式（000000000001000B））
	EM_MODE_EMERGENCY			= 0x06,		//6	紧急放行模式（000000010000000B）

} EM_DEGRADE_MODE_CODE;

int InitModeList();

BOOL CheckModeCode(uint8 ModeCode);


int SyncModeHistory(unsigned char *ucTime);

BOOL ClearModeList(unsigned char *ucTime);

int GetLocalStationMode(unsigned char * ucTime,unsigned char *pStationCode);

int SetLocalStationMode(DEGRADECMD stDegradeCmd);

int SetStationModeNotifyList(unsigned char *ucTime,DEGRADECMD stDegradeCmd);

int GetStationModeNotify(unsigned char * ucSysTime,unsigned char * ucTime,unsigned char *pStationCode,int iDegradeMode,ST_RW_DEGRADECMD *stDegradeCmd);

BOOL HasEmergencyModeInModeNotifyList(unsigned char * ucSysTime,unsigned char * ucTime);

BOOL HasEmergencyModeInModeNotifyListByKey(unsigned char * ucSysTime,unsigned char * ucTime,unsigned char *pStationCode);

BOOL HasTrainFaultModeInModeNotifyList(unsigned char * ucSysTime,unsigned char * ucTime,unsigned char *pStationCode);

int Get_Price_InDegrade(uint8 *u8CardType,uint8 *u8InGateStation,uint8* u8BCDInGateTime,uint8* u8BCDOutGateTime,
		uint16* FareZone,uint16*JourneyTimeLimit,uint16*TimeoutsFines,uint8 *RidingTime,uint8 *TrainTicketTableID,uint32* Fare);

BOOL CheckStationMode(DEGRADECMD stCurrentDegradeCmd,DEGRADECMD stNewDegradeCmd);

//ucTime -> tiket last process time
//pStationCode -> last process station
//ucCardStatus -> last ticket stauts
BOOL Allow_Entry_InDegradeMode(unsigned char * ucSysTime,unsigned char * ucTime,unsigned char *pStationCode,unsigned char ucCardStatus);

//ucTime -> current system time
//pStationCode [out] FreeEntryStationCode
BOOL Allow_Exit_InFreeEntryStationCode(unsigned char * ucTime,unsigned char * szCurrentStationCode,unsigned char *pStationCode);





#endif /* DEGRADEMODEBUSINUESS_H_ */
