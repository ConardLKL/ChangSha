

#include "AccCpuCardBusiness.h"

/*内部变量申明；*/
static ST_CARD_ACC_CPU m_stAccCpuCardInfo;

static ST_BOM_OperationStauts m_stOperationStauts;
////  验证卡发行有效性
// int Verify_Issue_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
// {
//	//根据卡信息 判断卡的有效性。
//
//	// 有效性不通过，返回 无效卡。
//
//	return CE_OK;
// }

//验证卡是否在黑名单参数中。0 : not blacklist ,1 : blacklist
 BOOL Verify_Blacklist_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
	 //todo : 
	int iRet=-1;
	char  LogicID[32]={0};
	char  szTempLogicID[32]={0};
	uint8  BlackListControl=0;
	uint8  CheckBlackList=0;
	CheckBlackList=g_BRContext.TicktPara0301.CheckBlackList[0];

	PrintLog("File[%s]Line[%d]Verify_Blacklist_AccCpuCard TicktPara0301.CheckBlackList[%02x]",__FILE__,__LINE__,CheckBlackList);
	if(CheckBlackList=='0')
	{
		return FALSE;//不检查黑名单，返回 0 ：not blacklist
	}

	sprintf(szTempLogicID,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stAccCpuCardInfo.IssueInfo_0005.AppSn[0],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[1],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[2],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[3],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[4],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[5],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[6],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[7]);
	memcpy(LogicID,szTempLogicID,20);
	PrintLog("File[%s]Line[%d] Verify_Blacklist_AccCpuCard  cLogicalID[%s]",__FILE__,__LINE__,LogicID);


	//根据卡逻辑编号，查询黑名单参数。
	iRet=BR_CheckBlacklistCardACC_h((uint8 *)LogicID,&BlackListControl);
	PrintLog("File[%s]Line[%d]Verify_Blacklist_AccCpuCard BR_CheckBlacklistCardACC_h iRet[%d]",__FILE__,__LINE__,iRet);
	if(iRet!=0)
	{
		return FALSE;
	}

	return TRUE;
 }

//验证卡是否已锁。
 BOOL Verify_IsLocked_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
	BOOL bRet=FALSE;
	bRet=(stAccCpuCardInfo.TranRecord_01.AppLockFlag==0x01);
	PrintLog("File[%s]Line[%d]stAccCpuCardInfo.TranRecord_01.AppLockFlag[%d]",__FILE__,__LINE__,stAccCpuCardInfo.TranRecord_01.AppLockFlag);
	return bRet;
 }

//验证是否允许该设备发售。
 BOOL Verify_Issue_Device_AccCpuCard(EM_DEVICE_TYPE emCurrentDeivceType)
 {
	 	/*1、	设备字符信息代码定义：
		字符	描述
		字符1	TVM
		字符2	BOM
		字符3	进站闸机
		字符4	出站闸机
		字符5	双向闸机
		字符6	TCM
		字符7	PCA
		字符8	ES
		字符9~16	预留
		如参数使用设备为TVM、BOM、进站闸机、出站闸机、双向闸机、TCM、PCA、ES则取值“1111111100000000”
*/
	BOOL bRet=FALSE;
	switch(emCurrentDeivceType)
	{
		case EM_DEVICE_TYPE_TVM:
			  bRet= g_BRContext.TicktPara0301.SaleDevice[0];
		break;
		case EM_DEVICE_TYPE_BOM:
			 bRet= g_BRContext.TicktPara0301.SaleDevice[1];
		break;
		default:
			bRet=FALSE;
			break;

	}
	return bRet;
 }

int Inner_Lock_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETLOCK * stLockInfo)
 {
	int iRet=-1;

	//入参检查.
	if(NULL==pRetInfo||NULL==stLockInfo)
	{
		return CE_CHECKERROR;
	}
	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;

	//特殊标记
	m_stAccCpuCardInfo.TranRecord_01.AppLockFlag=0x01;//黑名单

	memcpy(&m_stAccCpuCardInfo.Info_0017[0],&m_stAccCpuCardInfo.TranRecord_01,48);
	iRet=Lock_AccCpuCard_Info(0,APIParam.ucTimeStamp,&m_stAccCpuCardInfo,u8TAC,&u32TerminalTradeNum);
	PrintLog("File[%s]Line[%d] Inner_Lock_AccCpuCard Inner_Write_AccCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	u32TerminalTradeNum=htonl(u32TerminalTradeNum);

	stLockInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	//组UD
	Fill_Lock_AccCpuCard_UD(APIParam,m_stAccCpuCardInfo,stLockInfo);

	//BYTE		bStatus;					// 交易状态代码
	//char		cLockFlag;					// 加解锁标志

	//1：加锁；2：解锁
	stLockInfo->cLockFlag='1';

	stLockInfo->bStatus=RW_LIFECODE_LOCK;

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;
 }
int Inner_Read_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  *stAccCpuCardInfo,BOOL bReadHistory)
 {
	int iRet=-1;

	iRet=Read_AccCpuCard_All_Info(APIParam.AntennaMode,stAccCpuCardInfo, bReadHistory);

	if(CE_OK!=iRet)
	{
		return RW_EC_READ_FAILED;
	}

	// 发卡基本信息文件0005
	memcpy(&stAccCpuCardInfo->IssueInfo_0005,stAccCpuCardInfo->Info_0005,sizeof(ST_ACC_CPU_CARD_MF_EF05));
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard 发卡基本信息文件0005 Info_0005",__FILE__,__LINE__);
	PrintBuffer((const char *)stAccCpuCardInfo->Info_0005,sizeof(ST_ACC_CPU_CARD_MF_EF05));

	// 公共应用基本数据文件0015
	memcpy(&stAccCpuCardInfo->PublicInfo_0015,stAccCpuCardInfo->Info_0015,sizeof(ST_ACC_CPU_CARD_ADF_EF15));
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard 公共应用基本数据文件0015 Info_0015",__FILE__,__LINE__);
	PrintBuffer((const char *)stAccCpuCardInfo->Info_0015,sizeof(ST_ACC_CPU_CARD_ADF_EF15));

	// 持卡人基本信息文件0016
	memcpy(&stAccCpuCardInfo->PersonInfo_0016,stAccCpuCardInfo->Info_0016,sizeof(ST_ACC_CPU_CARD_ADF_EF16));
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard  持卡人基本信息文件0016 Info_0016",__FILE__,__LINE__);
	PrintBuffer((const char *)stAccCpuCardInfo->Info_0016,sizeof(ST_ACC_CPU_CARD_ADF_EF16));

	//公共电子钱包0002
	memcpy(&stAccCpuCardInfo->Purse_EP_0002,stAccCpuCardInfo->Info_0002,4);
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard 公共电子钱包0002 Info_0002",__FILE__,__LINE__);
	PrintBuffer((const char *)stAccCpuCardInfo->Info_0002,4);


	if(bReadHistory==TRUE)
	{
		//本地消费明细文件0018
		memcpy(stAccCpuCardInfo->LocalTradeRecord_0018,stAccCpuCardInfo->Info_0018,sizeof(stAccCpuCardInfo->Info_0018));
		PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard  本地消费明细文件0018 Info_0018",__FILE__,__LINE__);
		PrintBuffer((const char *)stAccCpuCardInfo->Info_0018,sizeof(stAccCpuCardInfo->Info_0018));

		// 异地消费明细文件0010
		memcpy(stAccCpuCardInfo->OtherTradeRecord_0010,stAccCpuCardInfo->Info_0010,sizeof(stAccCpuCardInfo->Info_0010));
		PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard 异地消费明细文件0010 Info_0010",__FILE__,__LINE__);
		PrintBuffer((const char *)stAccCpuCardInfo->Info_0010,sizeof(stAccCpuCardInfo->Info_0010));

		// 充值明细文件001A
		memcpy(stAccCpuCardInfo->TopupTradeRecord_001A,stAccCpuCardInfo->Info_001A,sizeof(stAccCpuCardInfo->Info_001A));
		PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard   充值明细文件001A Info_001A",__FILE__,__LINE__);
		PrintBuffer((const char *)stAccCpuCardInfo->Info_001A,sizeof(stAccCpuCardInfo->Info_001A));
	}else
	{
		//本地消费明细文件0018
		memcpy(stAccCpuCardInfo->LocalTradeRecord_0018,stAccCpuCardInfo->Info_0018,sizeof(stAccCpuCardInfo->Info_0018));
		PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard  本地消费明细文件0018 Info_0018",__FILE__,__LINE__);
		PrintBuffer((const char *)stAccCpuCardInfo->Info_0018,sizeof(stAccCpuCardInfo->Info_0018));

		// 充值明细文件001A
		memcpy(stAccCpuCardInfo->TopupTradeRecord_001A,stAccCpuCardInfo->Info_001A,sizeof(stAccCpuCardInfo->Info_001A));
		PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard   充值明细文件001A Info_001A",__FILE__,__LINE__);
		PrintBuffer((const char *)stAccCpuCardInfo->Info_001A,sizeof(stAccCpuCardInfo->Info_001A));
	}
	// 复合交易记录文件0017 01 交易辅助
	memcpy(&stAccCpuCardInfo->TranRecord_01,stAccCpuCardInfo->Info_0017,48);
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard  复合交易记录文件0017 01 交易辅助 Info_0017",__FILE__,__LINE__);
	PrintBuffer((const char *)stAccCpuCardInfo->Info_0017,sizeof(stAccCpuCardInfo->Info_0017));

	// 复合交易记录文件0017 02 轨道交通
	memcpy(&stAccCpuCardInfo->TranRecord_02,stAccCpuCardInfo->Info_0017[1],48);
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard  复合交易记录文件0017 02 轨道交通 Info_0017",__FILE__,__LINE__);
	PrintBuffer((const char *)stAccCpuCardInfo->Info_0017[1],48);

	stAccCpuCardInfo->TranRecord_02.CardStatus=stAccCpuCardInfo->TranRecord_02.CardStatus0>>3;
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard  CardStatus [0x%02X]",__FILE__,__LINE__,stAccCpuCardInfo->TranRecord_02.CardStatus);

	stAccCpuCardInfo->TranRecord_02.CardSpecialFlag=stAccCpuCardInfo->TranRecord_02.CardStatus0&0x07;
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard  CardSpecialFlag [0x%02X]",__FILE__,__LINE__,stAccCpuCardInfo->TranRecord_02.CardSpecialFlag);

	// 复合交易记录文件0017 02  应用控制记录
	memcpy(&stAccCpuCardInfo->TranRecord_11,stAccCpuCardInfo->Info_0017[6],48);
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard  复合交易记录文件0017 02  应用控制记录 Info_0017",__FILE__,__LINE__);
	PrintBuffer((const char *)stAccCpuCardInfo->Info_0017[6],48);

	//// 辅助信息文件0011
	memcpy(&stAccCpuCardInfo->AssistInfo_0011,stAccCpuCardInfo->Info_0011,sizeof(stAccCpuCardInfo->Info_0011));
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard  辅助信息文件0011 Info_0011",__FILE__,__LINE__);
	PrintBuffer((const char *)stAccCpuCardInfo->Info_0011,sizeof(stAccCpuCardInfo->Info_0011));

	return CE_OK;
 }

int Inner_Write6_AccCpuCard(StruAPIParam APIParam,uint32 u32ConsumeMoney,ST_CARD_ACC_CPU cardProcessInfo,uint8 *TAC,uint32 *u8TerminalTradeNum)
{


	int iRet=-1;

	uint32 TranSn=0;

	PrintLog("File[%s]Line[%d]Inner_Write6_AccCpuCard  u32ConsumeMoney[0x%02X]",__FILE__,__LINE__,u32ConsumeMoney);
	iRet=Write_AccCpuCard_Recombine_Info(u32ConsumeMoney,APIParam.ucTimeStamp,&cardProcessInfo,0x00,TAC,&TranSn);
	PrintLog("File[%s]Line[%d]Write_AccCpuCard_Recombine_Info  iRet[0x%02X]",__FILE__,__LINE__,iRet);
	if(0!=iRet)
	{
		return iRet;
	}

	*u8TerminalTradeNum=htonl(TranSn);

	return CE_OK;
}

 int Inner_Write_AccCpuCard(StruAPIParam APIParam,uint32 u32ConsumeMoney,ST_CARD_ACC_CPU cardProcessInfo,uint8 *TAC,uint32 *u8TerminalTradeNum)
 {

	 int iRet=-1;
	 uint32 TranSn=0;
	 unsigned char DeviceID[2]={0};
	 unsigned short usDeviceID=0;
	 unsigned short usCrc16=0;
	 unsigned char ptr1[19]="CS-METRO-2013@GDMH";
	 unsigned char szTempData[128]={0};
	 BitstreamInitMasks();
	//处理时间
	memcpy(cardProcessInfo.TranRecord_02.ProcessTime,APIParam.ucTimeStamp,7);
	//当前线路
	cardProcessInfo.TranRecord_02.ProcessLine=g_BRContext.bCurrentLineID;
	//当前车站
	cardProcessInfo.TranRecord_02.ProcessStation=g_BRContext.bCurrentStationID[1];
	//设备类型设备编码
	memcpy(&usDeviceID,g_BRContext.bCurrentDeviceID,2);
	usDeviceID=htons(usDeviceID);


	BitStreamPack(g_BRContext.bCurrentDeviceTypeCode,DeviceID,0, 4);

	BitStreamPack(usDeviceID,DeviceID,4, 12);

	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard usDeviceID[%d],g_BRContext.bCurrentDeviceTypeCode[%d]",__FILE__,__LINE__,usDeviceID,g_BRContext.bCurrentDeviceTypeCode);

	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard DeviceID[0x%02X%02X]",__FILE__,__LINE__,DeviceID[0],DeviceID[1]);

	memcpy(&cardProcessInfo.TranRecord_02.ProcessEquCode,DeviceID,2);

	cardProcessInfo.TranRecord_02.CardStatus0=(cardProcessInfo.TranRecord_02.CardStatus<<3)+(cardProcessInfo.TranRecord_02.CardSpecialFlag&0x07);

	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard cardProcessInfo.ProcessLine[%d]",__FILE__,__LINE__,cardProcessInfo.TranRecord_02.ProcessLine);
	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard cardProcessInfo.ProcessStation[%d]",__FILE__,__LINE__,cardProcessInfo.TranRecord_02.ProcessStation);
	//PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard cardProcessInfo.ProcessEquType[%d]",__FILE__,__LINE__,cardProcessInfo.TranRecord_02.ProcessEquType);
	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard cardProcessInfo.ProcessEquCode[0x%02X]",__FILE__,__LINE__,cardProcessInfo.TranRecord_02.ProcessEquCode);
	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard cardProcessInfo.CardStatus[%d]",__FILE__,__LINE__,cardProcessInfo.TranRecord_02.CardStatus);
	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard cardProcessInfo.CardSpecialFlag[%d]",__FILE__,__LINE__,cardProcessInfo.TranRecord_02.CardSpecialFlag);
	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard cardProcessInfo.CardStatus0[%d]",__FILE__,__LINE__,cardProcessInfo.TranRecord_02.CardStatus0);
	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard cardProcessInfo.InGateLine[%d]",__FILE__,__LINE__,cardProcessInfo.TranRecord_02.InGateLine);
	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard cardProcessInfo.InGateStation[%d]",__FILE__,__LINE__,cardProcessInfo.TranRecord_02.InGateStation);

	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard cardProcessInfo.InGateTime",__FILE__,__LINE__);
    PrintBuffer(cardProcessInfo.TranRecord_02.InGateTime,7);

    memcpy(szTempData,ptr1,18);
    memcpy(szTempData+18,&cardProcessInfo.TranRecord_02,46);
    usCrc16=crc16(szTempData,18+46);
    PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard  复合交易记录文件0017 02 轨道交通 Info_0017 usCrc16[%02X]",__FILE__,__LINE__,usCrc16);
    //memset(cardProcessInfo.TranRecord_02.Reserved3,0,sizeof(cardProcessInfo.TranRecord_02.Reserved3));
    memcpy(&cardProcessInfo.TranRecord_02.Reserved3[18],&usCrc16,2);

	// 复合交易记录文件0017 02 轨道交通
	memcpy(&cardProcessInfo.Info_0017[1],&cardProcessInfo.TranRecord_02,48);
	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard  复合交易记录文件0017 02 轨道交通 Info_0017",__FILE__,__LINE__);
	PrintBuffer((const char *)cardProcessInfo.Info_0017[1],48);
	PrintLog("File[%s]Line[%d]Inner_Write_AccCpuCard  u32ConsumeMoney[0x%02X]",__FILE__,__LINE__,u32ConsumeMoney);

	iRet=Write_AccCpuCard_Recombine_Info(u32ConsumeMoney,APIParam.ucTimeStamp,&cardProcessInfo,0x01,TAC,&TranSn);
	PrintLog("File[%s]Line[%d]Write_AccCpuCard_Recombine_Info  iRet[0x%02X]",__FILE__,__LINE__,iRet);
	if(0!=iRet)
	{
		return iRet;
	}
	*u8TerminalTradeNum=htonl(TranSn);
	return CE_OK;
 }

  void Fill_Sale_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,OTHERSALE * pUD)
 {
	  /*	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		bStatus;					// 交易状态代码
	char		cBusinessseqno[12];			// 脱机业务流水号
	char		cSAMID[16];					// SAM卡逻辑卡号（单程票）
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号（单程票）
	BYTE		bAmountType;				// 金额类型
	short		nAmount;					// 押金
	BYTE		dtDate[7];					// 销售时间BCD
	char		cReceiptID[4];				// 支付凭证码
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShfitID;				// BOM班次序号每个BOM每天重置	(BCD)
	long		lBrokerage;					// 手续费
char		cTestFlag;						// 卡应用标识*/
	char temp[128]={0};
	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_SALE_SVT);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);

	// 单程票卡类型
	pUD->bTicketType[0]=stAccCpuCardInfo.IssueInfo_0005.MainType;
	pUD->bTicketType[1]=stAccCpuCardInfo.IssueInfo_0005.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stAccCpuCardInfo.IssueInfo_0005.AppSn[0],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[1],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[2],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[3],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[4],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[5],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[6],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[7]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Update_AccCpuCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Update_AccCpuCard_UD  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);

	//BYTE		dtDate[7];					// 销售时间BCD
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	//cReceiptID[4];				// 支付凭证码
	memcpy(pUD->cReceiptID,szTempZero,4);

	// 操作员代码(Login)
	memcpy(pUD->cOperatorID,g_BRContext.CurrentUserID,6);


	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShfitID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);

	// 卡应用标识
	pUD->cTestFlag=stAccCpuCardInfo.IssueInfo_0005.TestFlag+'0';

 }

 void Fill_Lock_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,TICKETLOCK * pUD)
{
	 /*	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		bStatus;					// 交易状态代码
	char		cLockFlag;					// 加解锁标志
	BYTE		dtDate[7];					// 时间YYYYMMDDHHMMSS
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShfitID;				// BOM班次序号每个BOM每天重置	(BCD)
    char		cTestFlag;						// 卡应用标识
    char		cTkAppMode;						//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	char temp[128]={0};
	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_LOCK);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);

	// 单程票卡类型
	pUD->bTicketType[0]=stAccCpuCardInfo.IssueInfo_0005.MainType;
	pUD->bTicketType[1]=stAccCpuCardInfo.IssueInfo_0005.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stAccCpuCardInfo.IssueInfo_0005.AppSn[0],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[1],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[2],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[3],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[4],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[5],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[6],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[7]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Update_AccCpuCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Update_AccCpuCard_UD  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);

	//BYTE		dtDate[7];					// 销售时间BCD
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	// 操作员代码(Login)
	memcpy(pUD->cOperatorID,g_BRContext.CurrentUserID,6);


	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShfitID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);

	// 卡应用标识
	pUD->cTestFlag=stAccCpuCardInfo.IssueInfo_0005.TestFlag+'0';

	//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	pUD->cTkAppMode='1';

}

void Fill_Refund_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,DIRECTREFUND * pUD)
{
	/*char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];				// 设备类型
	char		cDeviceID[3];					// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;					// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];				// 票卡物理卡号
	BYTE		bStatus;						// 交易状态代码
	long		lBalanceReturned;				// 退还钱包金额, 单位为分
	short		nDepositReturned;				// 退还押金, 单位为分
	short		nForfeiture;					// 罚款, 单位为分
	BYTE		bForfeitReason;				// 罚款原因
	long		lTradeCount;					// 票卡扣款交易计数
	BYTE		bReturnTypeCode;				// 退款类型, 0－即时退款；－非即时退款
	BYTE		dtDate[7];					// 时间YYYYMMDDHHMMSS
	char		cReceiptID[4];				// 凭证ID
	BYTE		dtApplyDate[7];				// 申请日期时间, YYYYMMDDHHMMSS
	char		cMACOrTAC[10];				// 交易认证码
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShfitID;					// BOM班次序号每个BOM每天重置	（BCD）
	long		lBrokerage;					// 手续费
	char		cTestFlag;					// 卡应用标识
	char		cClassicType[2];				// TAC交易分类
	char		cSamPosId[12];				// SAM卡终端编码*/
	char temp[128]={0};
	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_REFUND);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);
	//未实现
	//pUD->lSAMTrSeqNo=
	// 时间
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	// 单程票卡类型
	pUD->bTicketType[0]=stAccCpuCardInfo.IssueInfo_0005.MainType;
	pUD->bTicketType[1]=stAccCpuCardInfo.IssueInfo_0005.SubType;


	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02X%02X%02X%02X000000      ",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Purse_AccCpuCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stAccCpuCardInfo.IssueInfo_0005.AppSn[0],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[1],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[2],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[3],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[4],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[5],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[6],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[7]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Purse_AccCpuCard_UD  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);


	// 交易状态  ---外边赋值

	// 交易金额, 单位为分   ---外边赋值

	// 余额, 单位为分  ---外边赋值

	pUD->nForfeiture=0;

	pUD->bForfeitReason=0;

	// 退款类型, 0－即时退款；1－非即时退款
	pUD->cReturnTypeCode='0';


	// 单程票扣款计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,stAccCpuCardInfo.LocalTradeRecord_0018[0],2);
	pUD->lTradeCount=htons(usTempTradeCount);

	// 支付凭证码
	memcpy(pUD->cReceiptID,szTempZero,4);


	memcpy(pUD->dtApplyDate,APIParam.ucTimeStamp,7);

	// 操作员代码(Login)
	sprintf(pUD->cOperatorID,"%s",g_BRContext.CurrentUserID);

	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShfitID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);


	pUD->lBrokerage=0;


	// 卡应用标识
	pUD->cTestFlag=stAccCpuCardInfo.IssueInfo_0005.TestFlag+'0';


	// TAC交易分类
	sprintf(pUD->cClassicType,"09");//
	/*TAC交易分类
	储值类CPU卡片（地铁卡，公交CPU卡）：
	02：充值
	09：复合消费 （出闸 扣费、出闸更新、退款）
	 06：单次消费（支付罚金、冲正）
	单程票、公交M1卡：所有交易（钱包交易、退款）与二号线保持一致，填写00*/

	// SAM卡终端编码
	char szSamPosID[13]={0};
	sprintf(szSamPosID,"%02X%02X%02X%02X%02X%02X",g_BRContext.u8AccPsamTerminalID[0]
	                                             ,g_BRContext.u8AccPsamTerminalID[1]
	                                             ,g_BRContext.u8AccPsamTerminalID[2]
	                                             ,g_BRContext.u8AccPsamTerminalID[3]
	                                             ,g_BRContext.u8AccPsamTerminalID[4]
	                                             ,g_BRContext.u8AccPsamTerminalID[5]);
	memcpy(pUD->cSamPosId,szSamPosID,12);



}

void Fill_Deffer_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,TICKETDEFER  * pUD)
{
	/*	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];				// 设备类型
	char		cDeviceID[3];					// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;					// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];				// 票卡物理卡号
	BYTE		bStatus;						// 交易状态代码
	BYTE		dtOldExpiryDate[7];			// 原有效时间
	BYTE		dtNewExpiryDate[7];			// 现有效时间
	BYTE		dtOperateDate[7];				// 操作时间
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShfitID;					// BOM班次序号每个BOM每天重置	（BCD）
	char		cTestFlag;					// 卡应用标识*/
	char temp[128]={0};

	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_DELAY);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);

	// 单程票卡类型
	pUD->bTicketType[0]=stAccCpuCardInfo.IssueInfo_0005.MainType;
	pUD->bTicketType[1]=stAccCpuCardInfo.IssueInfo_0005.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stAccCpuCardInfo.IssueInfo_0005.AppSn[0],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[1],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[2],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[3],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[4],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[5],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[6],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[7]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Sale_ULCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);
	// 进站时间
	memcpy(pUD->dtOperateDate,APIParam.ucTimeStamp,7);

	// 操作员代码(Login)
	memcpy(pUD->cOperatorID,g_BRContext.CurrentUserID,6);


	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShfitID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);;

	// 卡应用标识
	pUD->cTestFlag=stAccCpuCardInfo.IssueInfo_0005.TestFlag+'0';


}

void Fill_Update_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,TICKETUPDATE  * pUD)
 {
	/*char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;				// 更新设备SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	long		lTradeCount;				// 票卡扣款交易计数
	BYTE		bStatus;					// 交易状态代码
	char		cUpdateZone;				// 更新区域
	BYTE		bUpdateReasonCode;			// 更新原因
											// 更新原因代码表
											// 原因代码	描述（Description）
											// 付费区：01－出站超时，02-超乘，03-无进站码
											// 非付费区：10－有进站码，
											// 11：非付费区非本站进站
											// 12：进站超时
	BYTE		dtUpdateDate[7];			// 更新日期时间YYYYMMDDHHMMSS
	BYTE		bPaymentMode;				// 罚金支付方式
											// 	1-现金，2-储值卡， 3-一卡通
											//	4-Credit， 5- civil charge '默认值''
	short		nForfeiture;				// 罚金, 需缴纳的罚款金额（现金支付），单位分
	char		cReceiptID[4];				// 支付凭证码
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bEntryStationID[2];			// 进站线路站点代码
	BYTE		bBOMShfitID;				// BOM班次序号每个BOM每天重置	（BCD）
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				// 限制使用模式
	BYTE		bLimitEntryID[2];			// 限制进站代码
	BYTE		bLimitExitID[2];			// 限制出站代码
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	char temp[128]={0};
	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_UPDATE);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);

	// 单程票卡类型
	pUD->bTicketType[0]=stAccCpuCardInfo.IssueInfo_0005.MainType;
	pUD->bTicketType[1]=stAccCpuCardInfo.IssueInfo_0005.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stAccCpuCardInfo.IssueInfo_0005.AppSn[0],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[1],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[2],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[3],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[4],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[5],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[6],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[7]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Update_AccCpuCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Update_AccCpuCard_UD  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);

	 // 单程票扣款计数
	// 单程票扣款计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,stAccCpuCardInfo.LocalTradeRecord_0018[0],2);
	pUD->lTradeCount=htons(usTempTradeCount);

	// 交易状态  ---外边赋值

	// 更新区域  ---外边赋值

	// 更新原因  ---外边赋值

	// 更新日期时间YYYYMMDDHHMMSS
	memcpy(pUD->dtUpdateDate,APIParam.ucTimeStamp,7);

	// 罚金支付方式  ---外边赋值

	// 罚金, 需缴纳的罚款金额（现金支付），单位分  ---外边赋值

	//cReceiptID[4];				// 支付凭证码
	memcpy(pUD->cReceiptID,szTempZero,4);

	// 操作员代码(Login)
	memcpy(pUD->cOperatorID,g_BRContext.CurrentUserID,6);

	// 入口站点代码(BCD)
	pUD->bEntryStationID[0]=Byte_Decimal_to_BCD(stAccCpuCardInfo.TranRecord_02.InGateLine);
	pUD->bEntryStationID[1]=Byte_Decimal_to_BCD(stAccCpuCardInfo.TranRecord_02.InGateStation);

	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShfitID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);

	// 卡应用标识
	pUD->cTestFlag=stAccCpuCardInfo.IssueInfo_0005.TestFlag+'0';

	// 限制使用模式
    memcpy(pUD->cLimitMode,szTempZero,3);
    pUD->bLimitEntryID[0]=0;			// 限制进站代码
	pUD->bLimitEntryID[1]=0;
	pUD->bLimitExitID[0]=0;			// 限制出站代码
	pUD->bLimitEntryID[1]=0;

	//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	pUD->cTkAppMode='1';


 }

  void Fill_Entry_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,ENTRYGATE * pUD)
 {

	  /*
	 char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];				// 设备类型
	char		cDeviceID[3];					// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		dtDate[7];					// 进站日期时间如;20060211160903
	BYTE		bStatus;						// 交易状态代码
	long		lBalance;						// 余额
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				//限制使用模式
	BYTE		bLimitEntryID[2];				//限制进站代码
	BYTE		bLimitExitID[2];				//限制出站代码
	char 		cEntryMode;					//进闸工作模式
	long		lTradeCount;					//扣款计数
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	char temp[128]={0};

	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_ENTRY);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);

	// 单程票卡类型
	pUD->bTicketType[0]=stAccCpuCardInfo.IssueInfo_0005.MainType;
	pUD->bTicketType[1]=stAccCpuCardInfo.IssueInfo_0005.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stAccCpuCardInfo.IssueInfo_0005.AppSn[0],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[1],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[2],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[3],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[4],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[5],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[6],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[7]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Sale_ULCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);
	// 进站时间
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	// 交易状态  ---外边赋值

	// 余额
	pUD->lBalance=htonl(stAccCpuCardInfo.Purse_EP_0002);

	// 卡应用标识
	pUD->cTestFlag=stAccCpuCardInfo.IssueInfo_0005.TestFlag+'0';

	//限制使用模式
    memcpy(pUD->cLimitMode,szTempZero,3);
	//限制进站代码
	pUD->bLimitEntryID[0]=0;;
	pUD->bLimitEntryID[1]=0;;
	//限制出站代码
	pUD->bLimitExitID[0]=0;
	pUD->bLimitExitID[1]=0;
	//进闸工作模式
	//pUD->cEntryMode;
	memcpy(&pUD->cEntryMode,szTempZero,1);
	// 单程票扣款计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,stAccCpuCardInfo.LocalTradeRecord_0018[0],2);
	pUD->lTradeCount=htons(usTempTradeCount);
	PrintLog("File[%s]Line[%d] Fill_Entry_AccCpuCard_UD  lTradeCount= [0x%02X]",__FILE__,__LINE__,pUD->lTradeCount);
	//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	pUD->cTkAppMode='1';


 }

  void Fill_Purse_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,PURSETRADE * pUD)
 {

	  /*	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// 本次交易SAM逻辑卡号
	long		lSAMTrSeqNo;				// 本次交易SAM卡脱机交易流水号
	BYTE		dtDate[7];					// 日期时间(BCD)
	BYTE		bTicketType[2];				// 票卡类型(BCD)
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		bStatus;					// 交易状态代码
	long		lTradeAmount;				// 交易金额, 单位为分
	long		lBalance;					// 余额, 单位为分
	long		lChargeCount;				// 票卡充值计数
	long		lTradeCount;				// 票卡扣款交易计数
	char		cPaymentType[2];			// 支付类型
	char		cReceiptID[4];				// 支付凭证码
	char		cMACorTAC[10];				// 交易认证码
	BYTE		bEntryStationID[2];			// 入口站点代码(BCD)
	char		cEntrySAMID[16];			// 入口SAM逻辑卡号
	BYTE		dtEntryDate[7];				// 进站日期时间(BCD)
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShiftID;				// BOM班次序号
	char		cSamLast[16];				// 上次交易的SAM卡号
	BYTE		dtLast[7];					// 上次交易日期时间
	long		lTradeWallet;				// 钱包交易额，卡片实际需要变动的钱包值
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				// 限制使用模式
	BYTE		bLimitEntryID[2];			// 限制进站代码
	BYTE		bLimitExitID[2];			// 限制出站代码
	char		cExitMode;					//出闸工作模式
	char		cCityCode[4];				// 城市代码
	char		cIndustryCode[4];			// 行业代码
	char		cClassicType[2];			// TAC交易分类
	char		cSamPosId[12];				// SAM卡终端编码
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	char temp[128]={0};
	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_PURSE);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);
	//未实现
	//pUD->lSAMTrSeqNo=
	// 时间
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	// 单程票卡类型
	pUD->bTicketType[0]=stAccCpuCardInfo.IssueInfo_0005.MainType;
	pUD->bTicketType[1]=stAccCpuCardInfo.IssueInfo_0005.SubType;


	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02X%02X%02X%02X000000      ",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Purse_AccCpuCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stAccCpuCardInfo.IssueInfo_0005.AppSn[0],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[1],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[2],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[3],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[4],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[5],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[6],
			stAccCpuCardInfo.IssueInfo_0005.AppSn[7]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Purse_AccCpuCard_UD  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);


	// 交易状态  ---外边赋值

	// 交易金额, 单位为分   ---外边赋值

	// 余额, 单位为分  ---外边赋值

	// 票卡充值计数
	unsigned short usTempChargeCount=0;
	memcpy(&usTempChargeCount,stAccCpuCardInfo.TopupTradeRecord_001A[0],2);
	pUD->lChargeCount=htons(usTempChargeCount);

	// 单程票扣款计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,stAccCpuCardInfo.LocalTradeRecord_0018[0],2);
	pUD->lTradeCount=htons(usTempTradeCount);

	// 支付类型
	pUD->cPaymentType[0]='1';
	pUD->cPaymentType[1]='2';
	// 支付凭证码
	memcpy(pUD->cReceiptID,szTempZero,4);

	// 入口站点代码(BCD)
	pUD->bEntryStationID[0]=Byte_Decimal_to_BCD(stAccCpuCardInfo.TranRecord_02.InGateLine);
	pUD->bEntryStationID[1]=Byte_Decimal_to_BCD(stAccCpuCardInfo.TranRecord_02.InGateStation);

	// 入口SAM逻辑卡号
	memcpy(pUD->cEntrySAMID,szTempZero,16);
	// 进站日期时间(BCD)
	memcpy(pUD->dtEntryDate,stAccCpuCardInfo.TranRecord_02.InGateTime,7);

	// 操作员代码(Login)
	sprintf(pUD->cOperatorID,"%s",g_BRContext.CurrentUserID);

	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShiftID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);

	// 上次交易的SAM卡号pUD->cSamLast[16];
	memcpy(pUD->cSamLast,szTempZero,16);
	// 上次交易日期时间pUD->dtLast[7];
	memcpy(pUD->dtLast,stAccCpuCardInfo.TranRecord_02.ProcessTime,7);

	// 卡应用标识
	pUD->cTestFlag=stAccCpuCardInfo.IssueInfo_0005.TestFlag+'0';

	// 限制使用模式
	memcpy(pUD->cLimitMode,szTempZero,3);
	// 限制进站代码

	// 限制出站代码

	//出闸工作模式
	sprintf(&pUD->cExitMode,"0");

	// 城市代码
	sprintf(pUD->cCityCode,"4100");

	//行业代码
	memcpy(pUD->cIndustryCode,szTempZero,4);
	// TAC交易分类
	sprintf(pUD->cClassicType,"09");//
	/*TAC交易分类
	储值类CPU卡片（地铁卡，公交CPU卡）：
	02：充值
	09：复合消费 （出闸 扣费、出闸更新、退款）
	 06：单次消费（支付罚金、冲正）
	单程票、公交M1卡：所有交易（钱包交易、退款）与二号线保持一致，填写00*/

	// SAM卡终端编码
	char szSamPosID[13]={0};
	sprintf(szSamPosID,"%02X%02X%02X%02X%02X%02X",g_BRContext.u8AccPsamTerminalID[0]
	                                             ,g_BRContext.u8AccPsamTerminalID[1]
	                                             ,g_BRContext.u8AccPsamTerminalID[2]
	                                             ,g_BRContext.u8AccPsamTerminalID[3]
	                                             ,g_BRContext.u8AccPsamTerminalID[4]
	                                             ,g_BRContext.u8AccPsamTerminalID[5]);
	memcpy(pUD->cSamPosId,szSamPosID,12);


	//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	pUD->cTkAppMode='1';


 }

    //付费区分析。
 BOOL PaidArea_Analysis_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  stAccCpuCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis)
 {
	 int iRet=-1;
	 BOOL bRet=FALSE;
	 uint8 szEntryStation[2]={0};
	 uint8 szProcessStation[2]={0};
	 long  lRemainningValue=0;
	 uint8 u8EntryTime[7]={0};

	 unsigned char cardType[2]={0};

	 unsigned char u8stOperationStauts=0;
	 uint32 u32EntryTimeT=0;
	 uint32 u32CurrentTimeT=0;
	 uint32  lPrice=0;
	 uint16 FareZone=0;
	 uint16 JourneyTimeLimit=0;
	 uint16 TimeoutsFines=0;
	 uint8  RidingTime=0;
	 uint8  TrainTicketTableID=0;

	 uint8 cardStatus=stAccCpuCardInfo.TranRecord_02.CardStatus;
	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard cardStatus[%d]",__FILE__,__LINE__,cardStatus);

	 szEntryStation[0]=stAccCpuCardInfo.TranRecord_02.InGateLine;
	 szEntryStation[1]=stAccCpuCardInfo.TranRecord_02.InGateStation;
	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard szEntryStation[%02X%02X]",__FILE__,__LINE__,szEntryStation[0],szEntryStation[1]);


	 cardType[0]=stAccCpuCardInfo.IssueInfo_0005.MainType;
	 cardType[1]=stAccCpuCardInfo.IssueInfo_0005.SubType;

	 BCD_to_TimeT(stAccCpuCardInfo.TranRecord_02.ProcessTime,&u32EntryTimeT);

	 lRemainningValue=htonl(stAccCpuCardInfo.Purse_EP_0002);
	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard lRemainningValue[%d]",__FILE__,__LINE__,lRemainningValue);

	 szProcessStation[0]=stAccCpuCardInfo.TranRecord_02.ProcessLine;
	 szProcessStation[1]=stAccCpuCardInfo.TranRecord_02.ProcessStation;

	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard szProcessStation[%02X%02X]",__FILE__,__LINE__,szProcessStation[0],szProcessStation[1]);

	 memcpy(u8EntryTime,stAccCpuCardInfo.TranRecord_02.InGateTime,7);

	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard InGateTime[%d]",__FILE__,__LINE__,u32EntryTimeT);

	 BCD_to_TimeT(APIParam.ucTimeStamp,&u32CurrentTimeT);

	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard u32CurrentTimeT[%d]",__FILE__,__LINE__,u32CurrentTimeT);

	  bRet=Check_Update_ThisDay_AccCpuCard(APIParam,m_stAccCpuCardInfo);
	  PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  Check_Update_ThisDay_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	  if(!bRet)
		{

		   pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_DATE;
//		   stAnalysis->wError=RW_EC_UPDATE_OTHER_DATE;
//		   m_stOperationStauts.bAllowUpdate=TRUE;
//			iRet=Get_Price_InDegrade(cardType,szEntryStation,u8EntryTime,APIParam.ucTimeStamp,
//								&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);
//			 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard lPrice[%d],JourneyTimeLimit[%d],TimeoutsFines[%d]",__FILE__,__LINE__,lPrice,JourneyTimeLimit,TimeoutsFines);
//			if(iRet!=CE_OK)
//			{
//				 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard GetPrice Failed",__FILE__,__LINE__);
//				 pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
//			}
//			stAnalysis->lPenalty=TimeoutsFines;
			 memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
			 stAnalysis->dwOperationStauts=u8stOperationStauts;
			return CE_OK;
		}
	  bRet=Check_Update_ThisStation_AccCpuCard(m_stAccCpuCardInfo);
	  PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  Check_Update_ThisStation_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	  if(!bRet)
		{
		   pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_SATION;
//		   stAnalysis->wError=RW_EC_UPDATE_OTHER_SATION;
//		   m_stOperationStauts.bAllowUpdate=TRUE;
//		   iRet=BR_GetMinPrice(cardType,szProcessStation,APIParam.ucTimeStamp,&lPrice);
//		   if(iRet!=0)
//		   {
//			   pRetInfo->wErrCode=RW_EC_UNKNOWN;
//		   }
//		   stAnalysis->lPenalty=lPrice;//最小票价,
		   memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
		   stAnalysis->dwOperationStauts=u8stOperationStauts;
		   return CE_OK;
		}


	 switch(cardStatus)
	 {
	   case EM_TICKET_TRAVEL_STATUS_REFUND://已退卡
		   pRetInfo->wErrCode=RW_EC_STATUS_REFUND;
		   m_stOperationStauts.bAllowCharge=FALSE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_INITIALIZATION://初始化
		   pRetInfo->wErrCode=RW_EC_UNSALE;
		   m_stOperationStauts.bAllowCharge=FALSE;
			break;
	   case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES://Init II (Pre-value loaded @E/S)(预赋值)
		   pRetInfo->wErrCode=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;//"付费区无进站码","需要更新"
		   stAnalysis->wError=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;
		   m_stOperationStauts.bAllowUpdate=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_ISSUED://(BOM/TVM)发售
		   pRetInfo->wErrCode=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;//"付费区无进站码","需要更新"
		   stAnalysis->wError=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;
		   m_stOperationStauts.bAllowUpdate=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA://非付费区免费更新(BOM/pca 非付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA://非付费区付费更新(BOM/pca 非付费区)
		   pRetInfo->wErrCode=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;//"付费区无进站码","需要更新"
		   stAnalysis->wError=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;
		   m_stOperationStauts.bAllowUpdate=TRUE;
		   break;
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:  //无进站码更新(BOM/pca 付费区)
			iRet=Get_Price_InDegrade(cardType,szEntryStation,u8EntryTime,APIParam.ucTimeStamp,
								&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);
			if(iRet!=CE_OK)
			{
				 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard BR_CalcPrice Failed[%d]",__FILE__,__LINE__,iRet);
				 pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
				 return CE_OK;
			}
			   //超时 站内滞留时间
			//if(u32CurrentTimeT>u32EntryTimeT+(JourneyTimeLimit*60)&&(g_BRContext.TicktPara0301.OverTimeCheck[0]=='1'))
			if(!Check_Exit_Timeout_AccCpuCard(APIParam,JourneyTimeLimit,stAccCpuCardInfo))
			{
			   pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;//"付费区超时",
			   stAnalysis->wError=RW_EC_EXIT_TIMOUT_PAID_AREA;
			   //stAnalysis->dwOperationStauts|=0x02;//可更新
			   m_stOperationStauts.bAllowUpdate=TRUE;
			   stAnalysis->lPenalty=TimeoutsFines;////更新金额,
			   PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard 超时 lPenalty[%d] ",__FILE__,__LINE__,stAnalysis->lPenalty);
			}
			break;
		case EM_TICKET_TRAVEL_STATUS_ENTRY: ////已进站；
		  //if(memcmp(szEntryStation,(char*)g_BRContext.bCurrentStationID,2)!=0)////入站非本站
		   {
				iRet=Get_Price_InDegrade(cardType,szEntryStation,u8EntryTime,APIParam.ucTimeStamp,
						&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);
				 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard lPrice[%d],JourneyTimeLimit[%d],TimeoutsFines[%d]",__FILE__,__LINE__,lPrice,JourneyTimeLimit,TimeoutsFines);
				if(iRet!=CE_OK)
				{
					 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard GetPrice Failed",__FILE__,__LINE__);
					 pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
					 return CE_OK;
				}
			   //if(lRemainningValue<lPrice&&(g_BRContext.TicktPara0301.OverTaken[0]=='1')) //超乘
				if(!Check_Exit_RemainningValue_AccCpuCard(&lPrice,stAccCpuCardInfo))
			   {
				   pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_PAID_AREA;//"付费区超乘",
				   stAnalysis->wError1=RW_EC_EXIT_OUTRANGE_PAID_AREA;
				   //stAnalysis->dwOperationStauts|=0x02;//可更新
				   m_stOperationStauts.bAllowUpdate=TRUE;
				   stAnalysis->lPenalty1=lPrice-lRemainningValue;//更新金额
				   PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard 超乘 lPenalty1[%d] ",__FILE__,__LINE__,stAnalysis->lPenalty1);
			   }

			   //超时 站内滞留时间
			    //if(u32CurrentTimeT>u32EntryTimeT+(JourneyTimeLimit*60)&&(g_BRContext.TicktPara0301.OverTimeCheck[0]=='1'))
			   if(!Check_Exit_Timeout_AccCpuCard(APIParam,JourneyTimeLimit,stAccCpuCardInfo))
				{
				   pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;//"付费区超时",
				   stAnalysis->wError=RW_EC_EXIT_TIMOUT_PAID_AREA;
				   //stAnalysis->dwOperationStauts|=0x02;//可更新
				   m_stOperationStauts.bAllowUpdate=TRUE;
				   stAnalysis->lPenalty=TimeoutsFines;////更新金额,
				   PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard 超时 lPenalty[%d] ",__FILE__,__LINE__,stAnalysis->lPenalty);
				}

				if(stAnalysis->wError==RW_EC_EXIT_TIMOUT_PAID_AREA&&stAnalysis->wError1==RW_EC_EXIT_OUTRANGE_PAID_AREA)
				{
					pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_AND_TIMEOUT;
				}
		   }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:  //超时更新(BOM/pca 付费区)
		   {
			   iRet=Get_Price_InDegrade(cardType,szEntryStation,u8EntryTime,APIParam.ucTimeStamp,
			   						&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);
				 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard lPrice[%d],JourneyTimeLimit[%d],TimeoutsFines[%d]",__FILE__,__LINE__,lPrice,JourneyTimeLimit,TimeoutsFines);
				if(iRet!=CE_OK)
				{
					 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard GetPrice Failed",__FILE__,__LINE__);
					 pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
					 return CE_OK;
				}
				if(!Check_Exit_RemainningValue_AccCpuCard(&lPrice,stAccCpuCardInfo)) //超乘
			   {
				   pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_PAID_AREA;//"付费区超乘",
				   stAnalysis->wError=RW_EC_EXIT_OUTRANGE_PAID_AREA;
				   //stAnalysis->dwOperationStauts|=0x02;//可更新
				   m_stOperationStauts.bAllowUpdate=TRUE;
				   stAnalysis->lPenalty=lPrice-lRemainningValue;//更新金额
				   PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard 超乘 lPenalty[%d] ",__FILE__,__LINE__,stAnalysis->lPenalty);
			   }
		   }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_RANGEOUT:  //超乖更新(BOM/pca 付费区)
		   {
			   iRet=Get_Price_InDegrade(cardType,szEntryStation,u8EntryTime,APIParam.ucTimeStamp,
			   						&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);
				 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard lPrice[%d],JourneyTimeLimit[%d],TimeoutsFines[%d]",__FILE__,__LINE__,lPrice,JourneyTimeLimit,TimeoutsFines);
				if(iRet!=CE_OK)
				{
					 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard GetPrice Failed",__FILE__,__LINE__);
					 pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
					 return CE_OK;
				}
			   //超时 站内滞留时间
				//if(u32CurrentTimeT>u32EntryTimeT+(JourneyTimeLimit*60)&&(g_BRContext.TicktPara0301.OverTimeCheck[0]=='1'))
				if(!Check_Exit_Timeout_AccCpuCard(APIParam,JourneyTimeLimit,stAccCpuCardInfo))
				{
				   pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;//"付费区超时",
				   stAnalysis->wError1=RW_EC_EXIT_TIMOUT_PAID_AREA;
				   //stAnalysis->dwOperationStauts|=0x02;//可更新
				   m_stOperationStauts.bAllowUpdate=TRUE;
				   stAnalysis->lPenalty1=TimeoutsFines;////更新金额,
				   PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard 超时 lPenalty[%d] ",__FILE__,__LINE__,stAnalysis->lPenalty1);
				}
			  }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:		//免费出闸更新
			   {
			    if(memcmp(szProcessStation,(char*)g_BRContext.bCurrentStationID,2)==0)//更新站为本站
				{
				   if(u32CurrentTimeT>(u32EntryTimeT+(24*3600)))//本站24前更新
				   {
					   pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_DATE;//"非本日更新的车票",，不可更新。
				   }
				}else
				{
					 pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_SATION;//非本站更新的车票","可以建议乘客去更新的车站出站，也可以根据乘客的要求做票卡更新"
					 m_stOperationStauts.bAllowUpdate=TRUE;
					 stAnalysis->wError=RW_EC_UPDATE_OTHER_SATION;
				}
			   }
			   break;
			 case EM_TICKET_TRAVEL_STATUS_EXITED://已出站
				 {
					 if(u32CurrentTimeT<=(u32EntryTimeT+(10*60))&&(memcmp(szProcessStation,(char*)g_BRContext.bCurrentStationID,2)==0))//本站X秒内出站
					 {
					   pRetInfo->wErrCode=RW_EC_LAST_EXIT_BELOW_X_MINUTE;
					   pRetInfo->bNoticeCode=RW_SUBEC_LAST_EXIT_BELOW_X_MINUTE;////上次出站在X秒内
					 }else
					 {
					   pRetInfo->wErrCode=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;
					   m_stOperationStauts.bAllowUpdate=TRUE;//可更新
					   stAnalysis->wError=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;

					 }
				 }
			   break;
			 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:
				 pRetInfo->wErrCode=RW_EC_UNKNOWN;
				 pRetInfo->bNoticeCode=RW_SUBEC_TRAIN_FAULT;//列车故障模式出站
				 break;
	 }

	if(pRetInfo->wErrCode!=RW_EC_OK)
	{
		bRet=Allow_Exit_InFreeEntryStationCode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID,szProcessStation);
		if(bRet)
		{
			m_stOperationStauts.bAllowUpdate=FALSE;
			pRetInfo->wErrCode=RW_EC_OK;
			stAnalysis->wError=RW_EC_OK;
			stAnalysis->lPenalty=0;
			stAnalysis->wError1=RW_EC_OK;
			stAnalysis->lPenalty1=0;
		}
	}
	 memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
	 stAnalysis->dwOperationStauts=u8stOperationStauts;

	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_AccCpuCard bAllowActive[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowActive);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_AccCpuCard bAllowCharge[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowCharge);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_AccCpuCard bAllowDelay[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowDelay);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_AccCpuCard bAllowRefund[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowRefund);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_AccCpuCard bAllowSale[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowSale);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_AccCpuCard bAllowUnlock[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUnlock);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_AccCpuCard bAllowUpdate[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUpdate);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_AccCpuCard dwOperationStauts[%d]",__FILE__,__LINE__,stAnalysis->dwOperationStauts);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_AccCpuCard pRetInfo->wErrCode[0x%02X]",__FILE__,__LINE__,pRetInfo->wErrCode);

	 return TRUE;
 }

 //非付费区分析。
 BOOL UnpaidArea_Analysis_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  stAccCpuCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis)
 {
	 int iRet=-1;
	 BOOL bRet=FALSE;
	 uint8 szEntryStation[2]={0};
	 uint8 szProcessStation[2]={0};
	 uint8 u8EntryTime[7]={0};
	 uint32 u32EntryTimeT=0;
	 uint32 u32CurrentTimeT=0;
	 uint8 cardType[2]={0};
	 uint32 u32MinPrice=0;
	 unsigned char u8stOperationStauts=0;

	 uint8 cardStatus=stAccCpuCardInfo.TranRecord_02.CardStatus;
	 szEntryStation[0]=stAccCpuCardInfo.TranRecord_02.InGateLine;
	 szEntryStation[1]=stAccCpuCardInfo.TranRecord_02.InGateStation;


	 szProcessStation[0]=stAccCpuCardInfo.TranRecord_02.ProcessLine;
	 szProcessStation[1]=stAccCpuCardInfo.TranRecord_02.ProcessStation;

	 cardType[0]=stAccCpuCardInfo.IssueInfo_0005.MainType;
	 cardType[1]=stAccCpuCardInfo.IssueInfo_0005.SubType;
	 BCD_to_TimeT(stAccCpuCardInfo.TranRecord_02.ProcessTime,&u32EntryTimeT);

	 BCD_to_TimeT(APIParam.ucTimeStamp,&u32CurrentTimeT);

	 memcpy(u8EntryTime,stAccCpuCardInfo.TranRecord_02.ProcessTime,7);

	 switch(cardStatus)
	 {
	   case EM_TICKET_TRAVEL_STATUS_REFUND://已退卡
		   pRetInfo->wErrCode=RW_EC_STATUS_REFUND;
		   m_stOperationStauts.bAllowSale=TRUE;
		   m_stOperationStauts.bAllowCharge=FALSE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_INITIALIZATION://初始化
		   pRetInfo->wErrCode=RW_EC_UNSALE;
		   m_stOperationStauts.bAllowSale=TRUE;
		   m_stOperationStauts.bAllowCharge=FALSE;
		 break;
	   case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES://Ini.t II (Pre-value loaded @E/S)(预赋值)
		   m_stOperationStauts.bAllowRefund=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_ISSUED://(BOM/TVM)发售
		   m_stOperationStauts.bAllowRefund=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA://非付费区免费更新(BOM/pca 非付费区)
		   m_stOperationStauts.bAllowUpdate=FALSE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_ENTRY:  ////已进站
		   if(memcmp(szEntryStation,(char*)g_BRContext.bCurrentStationID,2)==0)//入站为本站
		   {
			   if(u32EntryTimeT+(20*60)<u32CurrentTimeT)
			   {
				   pRetInfo->wErrCode=RW_EC_ENTRY_TIMOUT_UNPAID_AREA;//非付费区进站超时
				   stAnalysis->wError=RW_EC_ENTRY_TIMOUT_UNPAID_AREA;
				   iRet=BR_GetMinPrice(cardType,szProcessStation,APIParam.ucTimeStamp,&u32MinPrice);
				   if(iRet!=0)
				   {
					   pRetInfo->wErrCode=RW_EC_UNKNOWN;
					   return CE_OK;
				   }
				   stAnalysis->lPenalty=u32MinPrice;//最小票价,
				   m_stOperationStauts.bAllowUpdate=TRUE;
			   }else
			   {
				   pRetInfo->wErrCode=RW_EC_ENTRY_ENTRYCODE_WRITTEN_UNPAID_AREA;//非付费区有进站码
				   stAnalysis->wError=RW_EC_ENTRY_ENTRYCODE_WRITTEN_UNPAID_AREA;
				   stAnalysis->lPenalty=0;
				   m_stOperationStauts.bAllowUpdate=TRUE;
			   }
		   }else//入站非本站
		   {
			   pRetInfo->wErrCode=RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA;////"非付费区非本站进站"
			   m_stOperationStauts.bAllowUpdate=TRUE;
			   stAnalysis->wError=RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA;

			   iRet=BR_GetMinPrice(cardType,szProcessStation,APIParam.ucTimeStamp,&u32MinPrice);
			   if(iRet!=0)
			   {
				   pRetInfo->wErrCode=RW_EC_UNKNOWN;
				   return CE_OK;
			   }
			   stAnalysis->lPenalty=u32MinPrice;//最小票价,
		   }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:  //无进站码更新(BOM/pca 付费区)
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:  //超时更新(BOM/pca 付费区)
		   case EM_TICKET_TRAVEL_STATUS_RANGEOUT:  //超乖更新(BOM/pca 付费区)
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:		//免费出闸更新
			   pRetInfo->wErrCode=RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA;////"非付费区非本站进站"
			   stAnalysis->wError=RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA;
			   m_stOperationStauts.bAllowUpdate=TRUE;
			   iRet=BR_GetMinPrice(cardType,szProcessStation,APIParam.ucTimeStamp,&u32MinPrice);
			   if(iRet!=0)
			   {
				   pRetInfo->wErrCode=RW_EC_UNKNOWN;
				   return CE_OK;
			   }
			   stAnalysis->lPenalty=u32MinPrice;//最小票价,
			   break;
		   case EM_TICKET_TRAVEL_STATUS_EXITED://已出站
			    pRetInfo->wErrCode=RW_EC_OK;
			   break;
		   case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:////出站票
			   pRetInfo->wErrCode=RW_EC_UNKNOWN;
			   pRetInfo->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;//回收票
			   break;
		   case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:
				 pRetInfo->wErrCode=RW_EC_UNKNOWN;
				 pRetInfo->bNoticeCode=RW_SUBEC_TRAIN_FAULT;//列车故障模式出站
				break;
	 }

	 if(pRetInfo->wErrCode==RW_EC_OK)
	 {
		m_stOperationStauts.bAllowRefund=TRUE;
	 }else
	 {
		 bRet=Allow_Entry_InDegradeMode(APIParam.ucTimeStamp,u8EntryTime,szProcessStation,cardStatus);
		 if(bRet)
		 {
			m_stOperationStauts.bAllowUpdate=FALSE;
			pRetInfo->wErrCode=RW_EC_OK;
			stAnalysis->wError=RW_EC_OK;
			stAnalysis->lPenalty=0;
			stAnalysis->wError1=RW_EC_OK;
			stAnalysis->lPenalty1=0;
		 }
	 }


	 memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
	 stAnalysis->dwOperationStauts=u8stOperationStauts;
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_AccCpuCard bAllowActive[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowActive);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_AccCpuCard bAllowCharge[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowCharge);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_AccCpuCard bAllowDelay[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowDelay);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_AccCpuCard bAllowRefund[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowRefund);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_AccCpuCard bAllowSale[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowSale);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_AccCpuCard bAllowUnlock[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUnlock);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_AccCpuCard bAllowUpdate[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUpdate);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_AccCpuCard dwOperationStauts[%d]",__FILE__,__LINE__,stAnalysis->dwOperationStauts);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_AccCpuCard pRetInfo->wErrCode[0x%02X]",__FILE__,__LINE__,pRetInfo->wErrCode);





	 return TRUE;
 }

 //检查车票状态是否正确
 BOOL Check_Ticket_Status_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
	 
	 BOOL bRet=FALSE;
	 uint8 u8CurrentCardStatus=0;
	 u8CurrentCardStatus=stAccCpuCardInfo.TranRecord_02.CardStatus;
	 PrintLog("File[%s]Line[%d]Check_Ticket_Status_AccCpuCard u8CurrentCardStatus[%d]",__FILE__,__LINE__,u8CurrentCardStatus);
	 switch(u8CurrentCardStatus)
	 {
		 case EM_TICKET_TRAVEL_STATUS_INITIALIZATION:			//e/s 初始化(init 0)
		 case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES:		//e/s 初始化(init 1)
		 case EM_TICKET_TRAVEL_STATUS_ISSUED:					// SJT发售(init 2)
		 case EM_TICKET_TRAVEL_STATUS_ENTRY:					//已进站
		 case EM_TICKET_TRAVEL_STATUS_EXITED:					//已出站
		 case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:				//出站票
		 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:		//列车故障模式出站(exit during Train-disruption)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA:	//非付费区免费更新(BOM/pca 非付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA:	//非付费区付费更新(BOM/pca 非付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
		 case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
		 case EM_TICKET_TRAVEL_STATUS_REFUND:					//已退卡
			 bRet=TRUE;
			 break;
		 default:
			 bRet=FALSE;
			 break;

	 }

	 return bRet;
 }

 //检查余额是否超出上限。
 BOOL Check_Ticket_Value_Uplimit_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
	 BOOL bRet=FALSE;
	 uint32 u32CurrentCardValue=0;
	 long u32UplimitValue=0;
	 char szUpperLimit[7]={0};

	 u32CurrentCardValue=htonl(stAccCpuCardInfo.Purse_EP_0002);
	 PrintLog("File[%s]Line[%d]Check_Ticket_Value_Uplimit_AccCpuCard u32CurrentCardValue[%d]",__FILE__,__LINE__,u32CurrentCardValue);

	 memcpy(szUpperLimit,g_BRContext.TicktPara0301.UpperLimit,6);
	 u32UplimitValue=atoi((char*)g_BRContext.TicktPara0301.UpperLimit);
	 PrintLog("File[%s]Line[%d]Check_Ticket_Value_Uplimit_AccCpuCard u32UplimitValue[%d]",__FILE__,__LINE__,u32UplimitValue);
	 if(u32CurrentCardValue>u32UplimitValue)
	 {
		 bRet=FALSE;
	 }else
	 {
		 bRet=TRUE;
	 }
	 return bRet;

 }
 //检查车票是否过期。
 BOOL Check_Ticket_Valid_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
		// 逻辑有效期开始时间(BCD)
	//m_stAccCpuCardInfo.IssueInfo_0005.CardActiveDate
	char temp[20]={0};
	BOOL bRet=FALSE;
	unsigned char szEndDate[7]={0};
    unsigned char ucParam=0;
	memset(temp,0,sizeof(temp));

    ////逻辑及物理有效期检查	CHAR	1	0：不检查逻辑及物理有效期；1：检查逻辑及物理有效期；2：检查逻辑但不检查物理有效期；3：不检查逻辑期但检查物理有效期
     temp[0]=g_BRContext.TicktPara0301.PhysicsCheck[0];
     ucParam=atoi(temp);
     if(!ucParam)
     {
    	 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  g_BRContext.TicktPara0301.PhysicsCheck= [%d]",__FILE__,__LINE__,ucParam);
    	 return TRUE;
     }

     if(ucParam==1||ucParam==3)//检查物理有效期
          {

     		memset(temp,0,sizeof(temp));
     		memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
     		int tempValidityMin=atoi(temp);
     		PrintLog("File[%s]Line[%d] Check_Ticket_Valid_AccCpuCard  tempValidityMin= [%d]",__FILE__,__LINE__,tempValidityMin);

     		BCDTimeAddSeconds(tempValidityMin*60,stAccCpuCardInfo.IssueInfo_0005.CardActiveDate,szEndDate);
     		PrintLog("File[%s]Line[%d]stAnalysis-> bEndDate",__FILE__,__LINE__);
     		PrintBuffer((const char *)szEndDate,4);


     		 if(memcmp(APIParam.ucTimeStamp,stAccCpuCardInfo.IssueInfo_0005.CardValidDate,4)>0)
     		 {
     			 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_AccCpuCard  u8BCDCurrentDate>szEndDate",__FILE__,__LINE__);
     			 return FALSE;
     		 }
          }

     if(ucParam==1||ucParam==2)//检查逻辑有效期
     {

		memset(temp,0,sizeof(temp));
		memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
		int tempValidityMin=atoi(temp);
		PrintLog("File[%s]Line[%d] Check_Ticket_Valid_AccCpuCard  tempValidityMin= [%d]",__FILE__,__LINE__,tempValidityMin);

		BCDTimeAddSeconds(tempValidityMin*60,stAccCpuCardInfo.TranRecord_11.AppActiveBeginTime,szEndDate);
		PrintLog("File[%s]Line[%d]stAnalysis-> bEndDate",__FILE__,__LINE__);
		PrintBuffer((const char *)szEndDate,7);
		 if(memcmp(APIParam.ucTimeStamp,szEndDate,7)>0||memcmp(APIParam.ucTimeStamp,stAccCpuCardInfo.TranRecord_11.AppActiveBeginTime,7)<0)
		 {
			 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_AccCpuCard  u8BCDCurrentDate>szEndDate",__FILE__,__LINE__);
			 return FALSE;
		 }
     }
	 return TRUE;
 }

 BOOL Check_Exit_DateTime_Order_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
	 if(stAccCpuCardInfo.TranRecord_02.CardStatus!=EM_TICKET_TRAVEL_STATUS_ENTRY)
	 {
		 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_AccCpuCard return true  ",__FILE__,__LINE__);
		 return TRUE;
	 }

	 if(memcmp(APIParam.ucTimeStamp,stAccCpuCardInfo.TranRecord_02.ProcessTime,7)<0)
	  {
		 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_AccCpuCard  u8BCDCurrentDate<ProcessTime",__FILE__,__LINE__);
		 return FALSE;
	  }

	 return TRUE;
 }

 //检查是否本站进站。
   BOOL Check_EntryThisStation_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
   {
 	 BOOL bRet=FALSE;
 	 uint8 szSaleStation[2]={0};

 	 szSaleStation[0]=stAccCpuCardInfo.TranRecord_02.ProcessLine;
 	 szSaleStation[1]=stAccCpuCardInfo.TranRecord_02.ProcessStation;

 	 if(memcmp(szSaleStation,(char*)g_BRContext.bCurrentStationID,2)==0)
 	 {
 		 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_AccCpuCard  u8BCDCurrentDate<ProcessTime",__FILE__,__LINE__);
 		 bRet=TRUE;
 	 }

 	 return bRet;
   }

     //检查进站超时。
   BOOL Check_Entry_Timeout_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
   {
 	  	 //未实现 ,不知如何判断
 	 return TRUE;
   }

     //进站次序检查。
   BOOL Check_Entry_Status_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
   {
 	   BOOL bRet=FALSE;

 	  char temp[20]={0};

 	  //进出站次序检查	CHAR	1	0：进出站均不检查进出站次序 1：进出站均检查进出站次序
 	  // 2：进站不检查进出站次序，出站检查进出站次序 3：进站检查进出站次序，出站不检查进出站次序
 	  temp[0]=g_BRContext.TicktPara0301.InOutOrderCheck[0];
 	  if(atoi(temp)==0||atoi(temp)==2)
 	  {
 	 	 PrintLog("File[%s]Line[%d] Check_Entry_Status_AccCpuCard  g_BRContext.TicktPara0301.InOutOrderCheck= [%d]",__FILE__,__LINE__,atoi(temp));
 	 	 return TRUE;
 	  }

 	 uint8 u8CurrentCardStatus=0;
 	 u8CurrentCardStatus=stAccCpuCardInfo.TranRecord_02.CardStatus;

 	 switch(u8CurrentCardStatus)
 	 {

 		 case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES:		//e/s 初始化(init 1)
 		 case EM_TICKET_TRAVEL_STATUS_ISSUED:					// SJT发售(init 2)
 		 case EM_TICKET_TRAVEL_STATUS_EXITED:					// SJT发售(init 2)
 		 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:		//列车故障模式出站(exit during Train-disruption)
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA:	//非付费区免费更新(BOM/pca 非付费区)
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA:	//非付费区付费更新(BOM/pca 非付费区)
 			 bRet=TRUE;
 			 break;
 		 default:
 			 bRet=FALSE;
 			 break;

 	 }

 	 return bRet;
   }

     //余额低于最小票价。
BOOL Check_MinValue_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  stAccCpuCardInfo)
{
 uint8 cardType[2]={0};
 uint32 u32MinPrice=0;
 int iRet=-1;

 char temp[20]={0};


  memset(temp,0,sizeof(temp));

 ////是否检查余额/余次	CHAR	1	0：不检查，1：检查
  temp[0]=g_BRContext.TicktPara0301.RemainCheck[0];
  if(atoi(temp)==0)
  {
 	 PrintLog("File[%s]Line[%d] Check_MinValue_AccCpuCard  g_BRContext.TicktPara0301.RemainCheck= [%d]",__FILE__,__LINE__,atoi(temp));
 	 return TRUE;
  }

 cardType[0]=stAccCpuCardInfo.IssueInfo_0005.MainType;
 cardType[1]=stAccCpuCardInfo.IssueInfo_0005.SubType;

   iRet=BR_GetMinPrice(cardType,g_BRContext.bCurrentStationID,APIParam.ucTimeStamp,&u32MinPrice);
   if(iRet!=0)
   {
	   PrintLog("File[%s]Line[%d] Check_MinValue_AccCpuCard BR_GetMinPrice iRet=[%d]",__FILE__,__LINE__,iRet);
	   return FALSE;
   }

  if( htonl(stAccCpuCardInfo.Purse_EP_0002)<u32MinPrice)
  {
	  PrintLog("File[%s]Line[%d] Check_MinValue_AccCpuCard  remainningValue[%d]<u32MinPrice[%d]",__FILE__,__LINE__,stAccCpuCardInfo.Purse_EP_0002,u32MinPrice);
	  return FALSE;
  }

 return TRUE;
}

     //出站次序检查。
   BOOL Check_Exit_Status_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
   {
 	  BOOL bRet=FALSE;

 	  char temp[20]={0};

 	  //进出站次序检查	CHAR	1	0：进出站均不检查进出站次序 1：进出站均检查进出站次序
 	  // 2：进站不检查进出站次序，出站检查进出站次序 3：进站检查进出站次序，出站不检查进出站次序
 	  temp[0]=g_BRContext.TicktPara0301.InOutOrderCheck[0];
 	  if(atoi(temp)==0||atoi(temp)==3)
 	  {
 	 	 PrintLog("File[%s]Line[%d] Check_Exit_Status_AccCpuCard  g_BRContext.TicktPara0301.InOutOrderCheck= [%d]",__FILE__,__LINE__,atoi(temp));
 	 	 return TRUE;
 	  }

 	 uint8 u8CurrentCardStatus=0;
 	 u8CurrentCardStatus=stAccCpuCardInfo.TranRecord_02.CardStatus;

 	 switch(u8CurrentCardStatus)
 	 {

 		 case EM_TICKET_TRAVEL_STATUS_ENTRY:					//已进站
 		 case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:				//出站票
 		 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:		//列车故障模式出站(exit during Train-disruption)
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
 		 case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
 			 bRet=TRUE;
 			 break;
 		 default:
 			 bRet=FALSE;
 			 break;

 	 }

 	 return bRet;
   }

   //非本站更新？
   BOOL Check_Update_ThisStation_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
   {
 	 BOOL bRet=FALSE;
 	 uint8 u8CurrentCardStatus=0;
 	 uint8 szUpdateStation[2]={0};
 	 u8CurrentCardStatus=stAccCpuCardInfo.TranRecord_02.CardStatus;

 	 szUpdateStation[0]=stAccCpuCardInfo.TranRecord_02.ProcessLine;
 	 szUpdateStation[1]=stAccCpuCardInfo.TranRecord_02.ProcessStation;

 	 char temp[20]={0};
	  memset(temp,0,sizeof(temp));
	 //PaintPlaceCheck1[1];//付费区非本站更新检查标志	CHAR	1	0：不检查，1：检查
	  temp[0]=g_BRContext.TicktPara0301.PaintPlaceCheck1[0];
	  if(atoi(temp)==0)
	  {
		 PrintLog("File[%s]Line[%d] Check_Update_ThisDay_AccCpuCard  g_BRContext.TicktPara0301.PaintPlaceCheck1= [%d]",__FILE__,__LINE__,atoi(temp));
		 return TRUE;
	  }
 	 switch(u8CurrentCardStatus)
 	 {
 		 //case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
 		 case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
 			 {
 				if(memcmp(szUpdateStation,(char*)g_BRContext.bCurrentStationID,2)==0)
 				 {
 					 bRet=TRUE;
 				 }else
 				{
 					 bRet=Check_IsTranStaton(szUpdateStation,g_BRContext.bCurrentStationID);
 					  PrintLog("File[%s]Line[%d] Check_IsTranStaton bRet=[%d]",__FILE__,__LINE__,bRet);
 				 }
 			 }
 			 break;
 		 default:
 			 bRet=TRUE;
 			 break;

 	 }

 	 return bRet;
   }

  //非本日更新
 BOOL Check_Update_ThisDay_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
 	BOOL bRet=FALSE;
 	uint8 u8CurrentCardStatus=0;
 	uint32 u32UpdateTimeT=0;
 	uint32 u32CurrentTimeT=0;

	 char temp[20]={0};
	  memset(temp,0,sizeof(temp));
	 //PaintPlaceCheck2[1];//付费区非本日更新检查标志	CHAR	1	0：不检查，1：检查
	  temp[0]=g_BRContext.TicktPara0301.PaintPlaceCheck2[0];
	  if(atoi(temp)==0)
	  {
		 PrintLog("File[%s]Line[%d] Check_Update_ThisDay_AccCpuCard  g_BRContext.TicktPara0301.PaintPlaceCheck2= [%d]",__FILE__,__LINE__,atoi(temp));
		 return TRUE;
	  }


 	u8CurrentCardStatus=stAccCpuCardInfo.TranRecord_02.CardStatus;

 	//u32UpdateTimeT=stAccCpuCardInfo.TranRecord_02.ProcessTime;

 	BCD_to_TimeT(stAccCpuCardInfo.TranRecord_02.ProcessTime,&u32UpdateTimeT);

 	BCD_to_TimeT(APIParam.ucTimeStamp,&u32CurrentTimeT);

 	switch(u8CurrentCardStatus)
 	{
 		case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
 		case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
 		case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
 		case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
 		case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
 			{
 	              if(u32CurrentTimeT<=u32UpdateTimeT+(24*3600))
 				  {
 					bRet=TRUE;
 				  }
 			}
 			break;
 		default:
 			bRet=TRUE;
 			break;

 	}

 	return bRet;
 }
   //出站超时
 BOOL Check_Exit_Timeout_AccCpuCard(StruAPIParam APIParam,uint16 u16JourneyTimeLimit,ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
	 BOOL bRet=TRUE;

	 uint8 szEntryTime[7]={0};
	 uint8 szStayTime[8]={0};

	if(g_BRContext.ucCurrentStationMode==EM_MODE_FREE_DATE)
	{
		PrintLog("File[%s]Line[%d] Check_Exit_Timeout_AccCpuCard ucCurrentStationMode==EM_MODE_FREE_DATE",__FILE__,__LINE__);
		return TRUE;
	}

	 ////是否检查超时	CHAR	1	0：不检查，1：检查
	 if(g_BRContext.TicktPara0301.OverTimeCheck[0]=='0')
	 {
		 bRet=TRUE;
		 return bRet;
	 }

	 memcpy(szEntryTime,stAccCpuCardInfo.TranRecord_02.ProcessTime,7);

	 BCDTimeAddSeconds(u16JourneyTimeLimit*60,szEntryTime,szStayTime);

	 PrintLog("File[%s]Line[%d] Exit_AccCpuCard  Check_Exit_Timeout_AccCpuCard szEntryTime",__FILE__,__LINE__);
	 PrintBuffer(szEntryTime,7);

	 PrintLog("File[%s]Line[%d] Exit_AccCpuCard  Check_Exit_Timeout_AccCpuCard szStayTime",__FILE__,__LINE__);
	 PrintBuffer(szStayTime,7);

	if(memcmp(APIParam.ucTimeStamp,szStayTime,7)>0)
	{
		PrintLog("File[%s]Line[%d] Check_Exit_Timeout_AccCpuCard  超时",__FILE__,__LINE__);
	   bRet=FALSE;
	}
	 return bRet;
 }

   //出站超程
 BOOL Check_Exit_RemainningValue_AccCpuCard(uint32 *u32Price,ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
 	 BOOL bRet=FALSE;
 	long lCardValue=0;
 	 lCardValue=htonl(stAccCpuCardInfo.Purse_EP_0002);



 	 ////是否检查余额/余次	CHAR	1	0：不检查，1：检查
 	  if(g_BRContext.TicktPara0301.RemainCheck[0]=='0')
 	  {
 	 	 PrintLog("File[%s]Line[%d] Check_Exit_RemainningValue_AccCpuCard  g_BRContext.TicktPara0301.RemainCheck= [%d]",__FILE__,__LINE__,g_BRContext.TicktPara0301.RemainCheck[0]);
 	 	 return TRUE;
 	  }

 	 //是否检查超乘	CHAR	1	0：不检查，1：检查
	 if(g_BRContext.TicktPara0301.OverTaken[0]=='0')
	 {
		 bRet=TRUE;
		 return bRet;
	 }

 	 if(stAccCpuCardInfo.TranRecord_02.CardStatus==EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION)
 	 {

 		 if(lCardValue<=(*u32Price))
 		 {
 			*u32Price=lCardValue;
 		 }


 		bRet=TRUE;
 		return bRet;
 	 }



 	if(lCardValue>=(*u32Price))
 	{
 	   bRet=TRUE;
 	}

 	 return bRet;
 }




 //Limited station code
 BOOL Check_Limited_ENTRY_STATION_CODE_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
 	  //是否限制进出站点	CHAR	1	0：否，1：是。具体限制的进出站信息制票时写在票卡上。
 	 if(g_BRContext.TicktPara0301.StationCheck[0]=='0')
 	  {
 	 	 PrintLog("File[%s]Line[%d] Check_Limited_ENTRY_STATION_CODE_AccCpuCard  g_BRContext.TicktPara0301.StationCheck= [%d]",__FILE__,__LINE__,g_BRContext.TicktPara0301.StationCheck[0]);
 	 	 return TRUE;
 	  }

 	  /*00  指示终端不进行出入控制判断；
		01  指示终端只进行入口判断，判断控制条件由可入线路、可入站点指明；
		02  指示终端只进行出口判断，判断控制条件由可出线路、可出站点指明；
		03  指示终端只进行出入判断，判断控制条件由可入线路、可入站点、可出线路、可出站点*/
 	 if(stAccCpuCardInfo.AssistInfo_0011.EntryExitMode==0x00||stAccCpuCardInfo.AssistInfo_0011.EntryExitMode==0x02)
 	 {
 		PrintLog("File[%s]Line[%d] Check_Limited_ENTRY_STATION_CODE_AccCpuCard  EntryExitMode= [%d]",__FILE__,__LINE__,stAccCpuCardInfo.AssistInfo_0011.EntryExitMode);
 		return TRUE;
 	 }

 	 if(g_BRContext.bCurrentLineID==stAccCpuCardInfo.AssistInfo_0011.AllowEntryLineCode
 			 &&g_BRContext.bCurrentStationID[1]==stAccCpuCardInfo.AssistInfo_0011.AllowEntryStationCode)
 	 {

 		return TRUE;
 	 }
 	PrintLog("File[%s]Line[%d] Check_Limited_ENTRY_STATION_CODE_AccCpuCard  bCurrentLineID[%d]!= AllowExitLineCode[%d]",__FILE__,__LINE__,g_BRContext.bCurrentLineID,stAccCpuCardInfo.AssistInfo_0011.AllowEntryLineCode);
 	return FALSE;
 }


 BOOL Check_Limited_Exit_STATION_CODE_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
	 //是否限制进出站点	CHAR	1	0：否，1：是。具体限制的进出站信息制票时写在票卡上。
	 if(g_BRContext.TicktPara0301.StationCheck[0]=='0')
	  {
		 PrintLog("File[%s]Line[%d] Check_Limited_Exit_STATION_CODE_AccCpuCard  g_BRContext.TicktPara0301.StationCheck= [%d]",__FILE__,__LINE__,g_BRContext.TicktPara0301.StationCheck[0]);
		 return TRUE;
	  }

	  /*00  指示终端不进行出入控制判断；
		01  指示终端只进行入口判断，判断控制条件由可入线路、可入站点指明；
		02  指示终端只进行出口判断，判断控制条件由可出线路、可出站点指明；
		03  指示终端只进行出入判断，判断控制条件由可入线路、可入站点、可出线路、可出站点*/
	 if(stAccCpuCardInfo.AssistInfo_0011.EntryExitMode==0x00||stAccCpuCardInfo.AssistInfo_0011.EntryExitMode==0x01)
	 {
		PrintLog("File[%s]Line[%d] Check_Limited_Exit_STATION_CODE_AccCpuCard  EntryExitMode= [%d]",__FILE__,__LINE__,stAccCpuCardInfo.AssistInfo_0011.EntryExitMode);
		return TRUE;
	 }

	 if(g_BRContext.bCurrentLineID==stAccCpuCardInfo.AssistInfo_0011.AllowExitLineCode
			 &&g_BRContext.bCurrentStationID[1]==stAccCpuCardInfo.AssistInfo_0011.AllowExitStationCode)
	 {
		return TRUE;
	 }
	 PrintLog("File[%s]Line[%d] Check_Limited_Exit_STATION_CODE_AccCpuCard  bCurrentLineID[%d]!= AllowExitLineCode[%d]",__FILE__,__LINE__,g_BRContext.bCurrentLineID,stAccCpuCardInfo.AssistInfo_0011.AllowExitLineCode);
	 return FALSE;

 }

int Analysis_AccCpuCard(StruAPIParam APIParam,uint8 u8IsDegradeMode,uint8 u8WorkArea,RetInfo * pRetInfo,BOMANALYZE * stAnalysis,TICKETLOCK * stTicketLock)
{
	
	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;
	BOOL bCardHasLocked=FALSE;

	memset(&m_stOperationStauts,0,sizeof(m_stOperationStauts));
	unsigned char u8stOperationStauts=0;

	char temp[32]={0};

	if(NULL==pRetInfo||NULL==stAnalysis||NULL==stTicketLock)
	{
		PrintLog("File[%s]Line[%d]Analysis_AccCpuCard RW_EC_INVALID_INPUT_PARAM",__FILE__,__LINE__);

		return RW_EC_INVALID_INPUT_PARAM;
	}

	if(u8WorkArea!=EM_CS_AREA_TYPE_PAID_AREA&&u8WorkArea!=EM_CS_AREA_TYPE_UNPAID_AREA)
	{
		PrintLog("File[%s]Line[%d]Analysis_AccCpuCard u8WorkArea[%d]",__FILE__,__LINE__,u8WorkArea);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	memset(&m_stAccCpuCardInfo,0,sizeof(m_stAccCpuCardInfo));

	iRet=Inner_Read_AccCpuCard(APIParam,&m_stAccCpuCardInfo,TRUE);
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	iRet= BR_GetParaTicketsTypeTable_h(m_stAccCpuCardInfo.IssueInfo_0005.MainType, m_stAccCpuCardInfo.IssueInfo_0005.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}

	// 物理卡号,
	memset(temp,0,sizeof(temp));

	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(stAnalysis->cPhysicalID,temp,20);

	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cPhysicalID[%s]",__FILE__,__LINE__,stAnalysis->cPhysicalID);

	// 逻辑卡号
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			m_stAccCpuCardInfo.IssueInfo_0005.AppSn[0],
			m_stAccCpuCardInfo.IssueInfo_0005.AppSn[1],
			m_stAccCpuCardInfo.IssueInfo_0005.AppSn[2],
			m_stAccCpuCardInfo.IssueInfo_0005.AppSn[3],
			m_stAccCpuCardInfo.IssueInfo_0005.AppSn[4],
			m_stAccCpuCardInfo.IssueInfo_0005.AppSn[5],
			m_stAccCpuCardInfo.IssueInfo_0005.AppSn[6],
			m_stAccCpuCardInfo.IssueInfo_0005.AppSn[7]);
	strncpy(stAnalysis->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cLogicalID[%s]",__FILE__,__LINE__,stAnalysis->cLogicalID);

	// 车票类型(主类型+子类型)
	stAnalysis->bTicketType[0]=m_stAccCpuCardInfo.IssueInfo_0005.MainType;
	stAnalysis->bTicketType[1]=m_stAccCpuCardInfo.IssueInfo_0005.SubType;
	PrintLog("File[%s]Line[%d]stAnalysis-> bTicketType[%02X%02X]",__FILE__,__LINE__,stAnalysis->bTicketType[0],stAnalysis->bTicketType[1]);
	// 余值
	 
	stAnalysis->lBalance=htonl(m_stAccCpuCardInfo.Purse_EP_0002);
	PrintLog("File[%s]Line[%d]stAnalysis-> lBalance[%02X]",__FILE__,__LINE__,stAnalysis->lBalance);

	// 押金
	//memset(temp,0,sizeof(temp));
	//memcpy(temp,( char*)g_BRContext.TicktPara0301.Deposit,6);
	//stAnalysis->lDepositorCost=atoi(temp);
	stAnalysis->lDepositorCost=(m_stAccCpuCardInfo.AssistInfo_0011.Reserved3[0])*100;
	PrintLog("File[%s]Line[%d]stAnalysis-> lDepositorCost[%02X]",__FILE__,__LINE__,stAnalysis->lDepositorCost);
	// 车票最高上限值
	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.UpperLimit,6);
	stAnalysis->lLimitedBalance=atoi(temp);
	PrintLog("File[%s]Line[%d]stAnalysis-> lLimitedBalance[%02X]",__FILE__,__LINE__,stAnalysis->lLimitedBalance);
	// 发行时间
	memcpy(stAnalysis->bIssueData,m_stAccCpuCardInfo.IssueInfo_0005.IssueDate,4);
	PrintLog("File[%s]Line[%d]stAnalysis-> bIssueData",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->bIssueData,4);
	// 物理有效期截止时间(BCD)(无)
	memcpy(stAnalysis->bExpiry,m_stAccCpuCardInfo.IssueInfo_0005.CardValidDate,4);
	PrintLog("File[%s]Line[%d]stAnalysis-> bExpiry",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->bExpiry,4);

	// 逻辑有效期开始时间(BCD)
	memcpy(stAnalysis->bStartDate,m_stAccCpuCardInfo.TranRecord_11.AppActiveBeginTime,4);
	PrintLog("File[%s]Line[%d]stAnalysis-> bStartDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->bStartDate,7);

	//stAnalysis->bEndDate[7];					// 逻辑有效期结束时间(BCD)
	//memcpy(stAnalysis->bEndDate,m_stAccCpuCardInfo.TranRecord_11.CardValidDate,7);
	memset(temp,0,sizeof(temp));

	memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
	int tempValidityMin=atoi(temp);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  tempValidityMin= [%d]",__FILE__,__LINE__,tempValidityMin);

	BCDTimeAddSeconds(tempValidityMin*60,stAnalysis->bStartDate,stAnalysis->bEndDate);
	PrintLog("File[%s]Line[%d]stAnalysis-> bEndDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->bEndDate,7);

	// 交易状态 m_stAccCpuCardInfo.TranRecord_02.CardStatus;//
	stAnalysis->bStatus=ConvertAccCPUCardStatus(m_stAccCpuCardInfo.TranRecord_02.CardStatus);//todo:
	PrintLog("File[%s]Line[%d]stAnalysis-> bStatus[%02X]",__FILE__,__LINE__,stAnalysis->bStatus);

	// 上次交易线路站点(BCD)
	//memcpy(&stAnalysis->bLastStationID[0],&m_stAccCpuCardInfo.TranRecord_02.ProcessLine,1);//todo:
	//memcpy(&stAnalysis->bLastStationID[1],&m_stAccCpuCardInfo.TranRecord_02.ProcessStation,1);//todo:
	stAnalysis->bLastStationID[0]=Byte_Decimal_to_BCD(m_stAccCpuCardInfo.TranRecord_02.ProcessLine);
	stAnalysis->bLastStationID[1]=Byte_Decimal_to_BCD(m_stAccCpuCardInfo.TranRecord_02.ProcessStation);
	PrintLog("File[%s]Line[%d]stAnalysis-> bLastStationID[%02X%02X]",__FILE__,__LINE__,stAnalysis->bLastStationID[0],stAnalysis->bLastStationID[1]);

	// 上次交易设备编号(BCD),第0字节仅低4bit有效

	memcpy(stAnalysis->bLastDeviceID,&m_stAccCpuCardInfo.TranRecord_02.ProcessEquCode,2);//todo:
	//stAnalysis->bLastDeviceID[0]=stAnalysis->bLastDeviceID[0]&0x0F;
	stAnalysis->bLastDeviceID[0]=Byte_Decimal_to_BCD(stAnalysis->bLastDeviceID[0]&0x0F);
	PrintLog("File[%s]Line[%d]stAnalysis-> bLastDeviceID[%02X%02X]",__FILE__,__LINE__,stAnalysis->bLastDeviceID[0],stAnalysis->bLastDeviceID[1]);


	// 上次交易设备类型
	stAnalysis->bLastDeviceType=(m_stAccCpuCardInfo.TranRecord_02.ProcessEquCode&0x00F0)>>4; //todo:
	PrintLog("File[%s]Line[%d]stAnalysis-> bLastDeviceType[%02X]",__FILE__,__LINE__,stAnalysis->bLastDeviceType);

	// 上次交易时间
	memcpy(stAnalysis->dtLastDate,m_stAccCpuCardInfo.TranRecord_02.ProcessTime,7);
	PrintLog("File[%s]Line[%d]stAnalysis-> dtLastDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->dtLastDate,7);

	// 上次进站站点
	stAnalysis->bEntrySationID[0]=Byte_Decimal_to_BCD(m_stAccCpuCardInfo.TranRecord_02.InGateLine);
	stAnalysis->bEntrySationID[1]=Byte_Decimal_to_BCD(m_stAccCpuCardInfo.TranRecord_02.InGateStation);
	PrintLog("File[%s]Line[%d]stAnalysis-> bEntrySationID[%02X%02X]",__FILE__,__LINE__,stAnalysis->bEntrySationID[0],stAnalysis->bEntrySationID[1]);

	//上次进站时间
	memcpy(stAnalysis->dtEntryDate,m_stAccCpuCardInfo.TranRecord_02.InGateTime,7);
	PrintLog("File[%s]Line[%d]stAnalysis-> dtEntryDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->dtEntryDate,7);


	stAnalysis->cTestFlag=m_stAccCpuCardInfo.IssueInfo_0005.TestFlag+'0';		// 卡应用标识
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cTestFlag= [0x%02X]",__FILE__,__LINE__,stAnalysis->cTestFlag);

	// 城市代码
	sprintf(stAnalysis->cCityCode,"%02X%02X",m_stAccCpuCardInfo.IssueInfo_0005.CityCode[0],m_stAccCpuCardInfo.IssueInfo_0005.CityCode[1]);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cCityCode= [0x%02X%02X]",__FILE__,__LINE__,m_stAccCpuCardInfo.IssueInfo_0005.CityCode[0],m_stAccCpuCardInfo.IssueInfo_0005.CityCode[1]);

	// 发行商代码
	sprintf(stAnalysis->cSellerCode,"%02X%02X",m_stAccCpuCardInfo.IssueInfo_0005.IssuerCode[0],m_stAccCpuCardInfo.IssueInfo_0005.IssuerCode[1]);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cSellerCode= [0x%02X%02X]",__FILE__,__LINE__,m_stAccCpuCardInfo.IssueInfo_0005.IssuerCode[0],m_stAccCpuCardInfo.IssueInfo_0005.IssuerCode[1]);

	// 消费计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,m_stAccCpuCardInfo.LocalTradeRecord_0018[0],2);
	stAnalysis->lTradeCount=htons(usTempTradeCount);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  lTradeCount= [0x%02X]",__FILE__,__LINE__,stAnalysis->lTradeCount);

	// 充值计数
	unsigned short usTempChargeCount=0;
	memcpy(&usTempChargeCount,m_stAccCpuCardInfo.TopupTradeRecord_001A[0],2);
	stAnalysis->lChargeCount=htons(usTempChargeCount);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  lChargeCount= [0x%02X]",__FILE__,__LINE__,stAnalysis->lChargeCount);

	//// 证件类型
	stAnalysis->bCertificateType=m_stAccCpuCardInfo.PersonInfo_0016.CustomType;

	//证件代码
	memcpy(stAnalysis->cCertificateCode,m_stAccCpuCardInfo.PersonInfo_0016.CustomIDCode,32);

	//证件持有人姓名
	memcpy(stAnalysis->cCertificateName,m_stAccCpuCardInfo.PersonInfo_0016.CustomName,20);

	//卡应用模式
	stAnalysis->cTkAppMode='1';


	// 充值上限，可充值标志位非0时有效
	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.TopUplimit,6);
	stAnalysis->lChargeUpper=atoi(temp);
	PrintLog("File[%s]Line[%d]stAnalysis-> lChargeUpper[%02X]",__FILE__,__LINE__,stAnalysis->lChargeUpper);

	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.TopUp,1);
	int iAllowTopup=atoi(temp);
	PrintLog("File[%s]Line[%d]iAllowTopup[%02X]",__FILE__,__LINE__,iAllowTopup);

	if((iAllowTopup==1)&&(htonl(m_stAccCpuCardInfo.Purse_EP_0002)<stAnalysis->lChargeUpper))
	{
		PrintLog("File[%s]Line[%d]m_stOperationStauts.bAllowCharge[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowCharge);
		m_stOperationStauts.bAllowCharge=TRUE;
	}

	//检查卡是否在黑名单参数中
	bRet=Verify_Blacklist_AccCpuCard(m_stAccCpuCardInfo);
	PrintLog("File[%s]Line[%d]Verify_Blacklist_AccCpuCard bRet[%d]",__FILE__,__LINE__,bRet);

	//检查卡是否已锁。
	bCardHasLocked=Verify_IsLocked_AccCpuCard(m_stAccCpuCardInfo);
	PrintLog("File[%s]Line[%d]Verify_IsLocked_AccCpuCard bCardHasLocked[%d]",__FILE__,__LINE__,bCardHasLocked);


	if(bRet==TRUE)
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==FALSE)
		{
		   iRet=Inner_Lock_AccCpuCard( APIParam, pRetInfo,stTicketLock);
		   PrintLog("File[%s]Line[%d]Inner_Lock_AccCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
		   if(iRet!=CE_OK)
		   {
			   pRetInfo->wErrCode=RW_EC_WRITE_FAILED;
			   return CE_OK;
		   }
		}
		//是否可解锁
		m_stOperationStauts.bAllowUnlock=FALSE;

		pRetInfo->wErrCode=RW_EC_BLACKLIST;
		return CE_OK;

	}else
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==TRUE)
		{
			memset(&m_stOperationStauts,0,sizeof(m_stOperationStauts));
			m_stOperationStauts.bAllowUnlock=TRUE;
			memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
			stAnalysis->dwOperationStauts=u8stOperationStauts;
			PrintLog("File[%s]Line[%d] stAnalysis.dwOperationStauts = [0x%02x]",__FILE__,__LINE__,stAnalysis->dwOperationStauts);
			pRetInfo->wErrCode=RW_EC_BLACKLIST;
			return CE_OK;
		}

	}

	//检查车票状态是否正确。
	bRet=Check_Ticket_Status_AccCpuCard(m_stAccCpuCardInfo);
	PrintLog("File[%s]Line[%d]Check_Ticket_Status_AccCpuCard bRet[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_STATUS_CODE;
		return CE_OK;
	}
	//检查余额是否超出上限。
	bRet=Check_Ticket_Value_Uplimit_AccCpuCard(m_stAccCpuCardInfo);
	PrintLog("File[%s]Line[%d]Check_Ticket_Value_Uplimit_AccCpuCard bRet[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return CE_OK;
	}
	//检查车票是否过期。
	bRet=Check_Ticket_Valid_AccCpuCard(APIParam,m_stAccCpuCardInfo);
	PrintLog("File[%s]Line[%d]Check_Ticket_Valid_AccCpuCard bRet[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		m_stOperationStauts.bAllowDelay=TRUE;
		memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
		stAnalysis->dwOperationStauts=u8stOperationStauts;
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		return CE_OK;
	}
	PrintLog("File[%s]Line[%d]Check_Ticket_Valid_AccCpuCard u8WorkArea[%d]",__FILE__,__LINE__,u8WorkArea);
	switch(u8WorkArea)
	{
	  case EM_CS_AREA_TYPE_PAID_AREA:
	  	bRet=Check_Exit_DateTime_Order_AccCpuCard( APIParam,m_stAccCpuCardInfo);
		  PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  Check_Exit_DateTime_Order_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
		  if(!bRet)
			{
				pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
				return CE_OK;
			}

		  PaidArea_Analysis_AccCpuCard(APIParam,m_stAccCpuCardInfo, pRetInfo,stAnalysis);
		break;
	  case EM_CS_AREA_TYPE_UNPAID_AREA:
		  UnpaidArea_Analysis_AccCpuCard(APIParam,m_stAccCpuCardInfo, pRetInfo,stAnalysis);
		  break;
	}

	//判断是否退卡
	if(g_BRContext.TicktPara0301.Refund[0]=='0')
	{
		m_stOperationStauts.bAllowRefund=FALSE;
	}

	//判断是否延期
	if(g_BRContext.TicktPara0301.Delay[0]=='1')
	{
		char temp[21]={0};
		unsigned char szEndDate[7]={0};
		memset(temp,0,sizeof(temp));
		memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
		int tempValidityMin=atoi(temp);
		PrintLog("File[%s]Line[%d] Check_Ticket_Valid_AccCpuCard  tempValidityMin= [%d]",__FILE__,__LINE__,tempValidityMin);

		tempValidityMin=(tempValidityMin-(15*24*60));

		BCDTimeAddSeconds(tempValidityMin*60,m_stAccCpuCardInfo.TranRecord_11.AppActiveBeginTime,szEndDate);
		PrintLog("File[%s]Line[%d]stAnalysis-> bEndDate",__FILE__,__LINE__);
		PrintBuffer((const char *)szEndDate,7);
		 if(memcmp(APIParam.ucTimeStamp,szEndDate,7)>0)
		 {
			 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_AccCpuCard  u8BCDCurrentDate>szEndDate",__FILE__,__LINE__);
			 m_stOperationStauts.bAllowDelay=TRUE;
		 }

	}

	//是否可退押金
	if(g_BRContext.TicktPara0301.IsRefundDeposit[0]=='1')
	{
		m_stOperationStauts.bAllowRefundDeposit=TRUE;
	}
	PrintLog("File[%s]Line[%d] stAnalysis.bAllowRefundDeposit = [%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowRefundDeposit);
	memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
	stAnalysis->dwOperationStauts=u8stOperationStauts;
	PrintLog("File[%s]Line[%d] stAnalysis.dwOperationStauts = [0x%02x]",__FILE__,__LINE__,stAnalysis->dwOperationStauts);
	return CE_OK;
}

  int Sale_AccCpuCard(StruAPIParam APIParam,uint16 u16TranValue,uint8 u8PaymentType,uint8 u8MoneyType,RetInfo * pRetInfo, OTHERSALE * pUD)
 {
	 //PaymentType 1=现金，2=储值卡，3=一卡通

	//入参检查.Description	Resource	Path	Location	Type



	int iRet=-1;
	BOOL bRet=FALSE;

	char temp[32]={0};
	int  tempDeposit=0;

	int iRemainningValue=0;
	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;
	//ST_CARD_ACC_CPU cardProcessInfo;
	//memset(&cardProcessInfo,0,sizeof(ST_CARD_ACC_CPU));

	if(NULL==pRetInfo||NULL==pUD)
	{
		PrintError("File[%s]Line[%d] Sale_AccCpuCard RW_EC_INVALID_INPUT_PARAM",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	if(u8PaymentType!=EM_TOKEN_PAYMENT_TYPE_CASH&&u8PaymentType!=EM_TOKEN_PAYMENT_TYPE_SVC&&u8PaymentType!=EM_TOKEN_PAYMENT_TYPE_YKT)
	{
		PrintError("File[%s]Line[%d] Sale_AccCpuCard u8PaymentType[%d]",__FILE__,__LINE__,u8PaymentType);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	if(u8MoneyType!=0)
	{
		PrintError("File[%s]Line[%d] Sale_AccCpuCard u8MoneyType!=0[%d]",__FILE__,__LINE__,u8MoneyType);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	if(!m_stOperationStauts.bAllowSale)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_API_CALL;
		return RW_EC_INVALID_INPUT_PARAM;
	}


	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.Deposit,6);
	tempDeposit=atoi(temp);
	PrintLog("File[%s]Line[%d]Sale_AccCpuCard tempDeposit [%d]",__FILE__,__LINE__,tempDeposit);
//	if(tempDeposit!=u16TranValue)
//	{
//		PrintError("File[%s]Line[%d] Sale_AccCpuCard tempDeposit[%d]!=u16TranValue[%d]",__FILE__,__LINE__,tempDeposit,u16TranValue);
//		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
//		return RW_EC_INVALID_INPUT_PARAM;
//	}


	bRet=Verify_Issue_Device_AccCpuCard(g_BRContext.emCurrentDeviceType);
	PrintLog("File[%s]Line[%d] Sale_AccCpuCard Verify_Issue_Device_AccCpuCard[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		// 参数不允许当前设备发售车票。
		pRetInfo->wErrCode=RW_EC_INVALID_API_CALL;
		return pRetInfo->wErrCode;
	}

	//车票状态
	if(m_stAccCpuCardInfo.TranRecord_02.CardStatus!=EM_TICKET_TRAVEL_STATUS_INITIALIZATION&&m_stAccCpuCardInfo.TranRecord_02.CardStatus!=EM_TICKET_TRAVEL_STATUS_REFUND)//e/s 初始化(init 0)
	//if(m_stAccCpuCardInfo.TranRecord_02.CardStatus!=EM_TICKET_TRAVEL_STATUS_INITIALIZATION)//e/s 初始化(init 0)
	{
		PrintLog("File[%s]Line[%d] Sale_AccCpuCard CardStatus!=EM_TICKET_TRAVEL_STATUS_INITIALIZATION",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
		return RW_EC_INVALID_TICKET;
	}
//
	//特殊标记
	if(m_stAccCpuCardInfo.TranRecord_02.CardSpecialFlag!=EM_CS_SPEC_FLAG_NORMAL)//正常
	{
		PrintLog("File[%s]Line[%d] Sale_AccCpuCard CardSpecialFlag!=EM_CS_SPEC_FLAG_NORMAL",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
		return RW_EC_INVALID_TICKET;
	}

	//钱包非0，报错
	iRemainningValue=htonl(m_stAccCpuCardInfo.Purse_EP_0002);
	PrintLog("File[%s]Line[%d] Sale_AccCpuCard iRemainningValue[%d]",__FILE__,__LINE__,iRemainningValue);
	if(iRemainningValue!=0)
	{
		PrintLog("File[%s]Line[%d] Sale_AccCpuCard iRemainningValue!=0",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
		return RW_EC_INVALID_TICKET;
	}


	//票卡应用有效期判断，过期报错（读0015公共应用基本数据文件，"应用启用日期"和"应用有效日期"判断）
	bRet=Check_Ticket_Valid_AccCpuCard(APIParam,m_stAccCpuCardInfo);
	PrintLog("File[%s]Line[%d]Sale_AccCpuCard Check_Ticket_Valid_AccCpuCard bRet[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		return RW_EC_INVALID_TICKET;
	}

	//准备写卡信息
	m_stAccCpuCardInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_ISSUED;// SJT发售(init 2)
	m_stAccCpuCardInfo.TranRecord_02.CardSpecialFlag=EM_CS_SPEC_FLAG_NORMAL;//正常
	m_stAccCpuCardInfo.Info_0011[0]=0x01;
	m_stAccCpuCardInfo.Info_0011[5]=(tempDeposit/100);//0x11;//实际值需要调整，从参数中获取
	m_stAccCpuCardInfo.Info_0017[6][2]=0x01;//激活后，本记录文件的应用锁定标志位改为锁定状态
	memcpy(&m_stAccCpuCardInfo.Info_0017[6][4],APIParam.ucTimeStamp,7);//激活启用日期


	iRet=Write_AccCpuCard_Sail_Info(&m_stAccCpuCardInfo,0x00);//SailFlag 00:11应用控制记录   01:辅助信息文件
	PrintLog("File[%s]Line[%d]Sale_AccCpuCard Write_AccCpuCard_Sail_Info [%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}
	iRet=Write_AccCpuCard_Sail_Info(&m_stAccCpuCardInfo,0x01);//SailFlag 00:11应用控制记录   01:辅助信息文件
	PrintLog("File[%s]Line[%d]Sale_AccCpuCard Write_AccCpuCard_Sail_Info [%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}
	iRet=Inner_Write_AccCpuCard(APIParam,0x00,m_stAccCpuCardInfo,u8TAC,&u32TerminalTradeNum);//u16TranValue
	PrintLog("File[%s]Line[%d]Sale_AccCpuCard Inner_Write_AccCpuCard [%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}


	//组UD
	//BYTE		bStatus;					// 交易状态代码
	pUD->bStatus=RW_LIFECODE_SALE_BOM_OR_TVM;
	//long		lSAMTrSeqNo;				// SAM卡脱机交易流水号（单程票）
	pUD->lSAMTrSeqNo=u32TerminalTradeNum;
	//	char		cBusinessseqno[12];			// 脱机业务流水号

	//BYTE		bAmountType;				// 金额类型
	pUD->bAmountType  =u8MoneyType;
	//short		nAmount;					// 押金
	pUD->nAmount=tempDeposit;
	//long		lBrokerage;					// 手续费
	pUD->lBrokerage=0;
	Fill_Sale_AccCpuCard_UD(APIParam,m_stAccCpuCardInfo,pUD);
	
	pRetInfo->wErrCode=0;

	return CE_OK;
 }

 int Recharge_AccCpuCard(StruAPIParam APIParam,uint8 u8RechargeType,uint32 u32RechargeValue,RetInfo * pRetInfo,PURSETRADE *stPurseInfo)
 {
	 return CE_OK;
 }

 int Decrease_AccCpuCard(StruAPIParam APIParam,uint32 u32DecreaseValue,RetInfo * pRetInfo,PURSETRADE *stPurseInfo)
 {
	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;

	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;

	//ST_CARD_ACC_CPU cardProcessInfo;
	//memset(&cardProcessInfo,0,sizeof(ST_CARD_ACC_CPU));

	if(NULL==pRetInfo||NULL==stPurseInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	bRet=Verify_Issue_Device_AccCpuCard(g_BRContext.emCurrentDeviceType);
	if(!bRet)
	{
		// 参数不允许当前设备发售车票。
		pRetInfo->wErrCode=RW_EC_INVALID_API_CALL;
		return pRetInfo->wErrCode;
	}
	
	 uint8 u8CurrentCardStatus=0;
	 u8CurrentCardStatus=m_stAccCpuCardInfo.TranRecord_02.CardStatus;

	 // 参数不允许当前设备发售车票。
	 if(u8CurrentCardStatus==EM_TICKET_TRAVEL_STATUS_INITIALIZATION||u8CurrentCardStatus==EM_TICKET_TRAVEL_STATUS_REFUND)
	{
		pRetInfo->wErrCode=RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT;
		return pRetInfo->wErrCode;
	}


	//钱包非0，报错
	 uint32 iRemainningValue=0;
	iRemainningValue=htonl(m_stAccCpuCardInfo.Purse_EP_0002);
	PrintLog("File[%s]Line[%d] Sale_AccCpuCard iRemainningValue[%d]",__FILE__,__LINE__,iRemainningValue);
	if(iRemainningValue<u32DecreaseValue)
	{
		PrintLog("File[%s]Line[%d] Decrease_AccCpuCard iRemainningValue<u32DecreaseValue[%d]",__FILE__,__LINE__,iRemainningValue,u32DecreaseValue);
		pRetInfo->wErrCode=RW_EC_ILLEGAL_INPUT_PARAM;
		return RW_EC_ILLEGAL_INPUT_PARAM;
	}

	iRet=Inner_Write6_AccCpuCard(APIParam,u32DecreaseValue,m_stAccCpuCardInfo,u8TAC,&u32TerminalTradeNum);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD
	

	// SAM卡脱机交易流水号
	stPurseInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	//stPurseInfo
	stPurseInfo->bStatus=RW_LIFECODE_DEBIT;

	Fill_Purse_AccCpuCard_UD(APIParam,m_stAccCpuCardInfo,stPurseInfo);

	stPurseInfo->lTradeAmount=u32DecreaseValue;
	stPurseInfo->lBalance=(htonl(m_stAccCpuCardInfo.Purse_EP_0002)-u32DecreaseValue);

	if(g_BRContext.emCurrentDeviceType==EM_DEVICE_TYPE_TVM)
	{
		stPurseInfo->cPaymentType[0]='1';
		stPurseInfo->cPaymentType[1]='9';
	}else
	{
		stPurseInfo->cPaymentType[0]='1';
		stPurseInfo->cPaymentType[1]='A';
	}
	stPurseInfo->cClassicType[0]='0';//
	stPurseInfo->cClassicType[1]='6';//

	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  cMACorTAC [%02X%02X%02X%02X]",__FILE__,__LINE__,u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);
	// SAM生成的交易检查代码

	char u8tempTac[16]={0};
	sprintf(u8tempTac,"%02X%02X%02X%02X  ",u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);
	memcpy(stPurseInfo->cMACorTAC,u8tempTac,10);

	pRetInfo->wErrCode=RW_EC_OK;


	return CE_OK;
 }

 int Query_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETINFO * stTicketInfo)
 {
	 
	int iRet=-1;
	//BOOL bRet=FALSE;
	char temp[32]={0};
	ST_CARD_ACC_CPU stCardInfo;
	memset(&stCardInfo,0,sizeof(ST_CARD_ACC_CPU));

	if(NULL==pRetInfo||NULL==stTicketInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	iRet=Inner_Read_AccCpuCard(APIParam,&stCardInfo,TRUE);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}
	iRet= BR_GetParaTicketsTypeTable_h(stCardInfo.IssueInfo_0005.MainType, stCardInfo.IssueInfo_0005.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}
//	//根据卡信息 判断卡的发行有效性。
//	iRet=Verify_Issue_AccCpuCard(stCardInfo);
//	if(CE_OK!=iRet)
//	{
//		// 有效性不通过，返回 无效卡。
//		pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
//		return pRetInfo->wErrCode;
//	}

	// 物理卡号,
	memset(temp,0,sizeof(temp));

	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(stTicketInfo->cPhysicalID,temp,14);

	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cPhysicalID[%s]",__FILE__,__LINE__,stTicketInfo->cPhysicalID);

	// 逻辑卡号
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stCardInfo.IssueInfo_0005.AppSn[0],
			stCardInfo.IssueInfo_0005.AppSn[1],
			stCardInfo.IssueInfo_0005.AppSn[2],
			stCardInfo.IssueInfo_0005.AppSn[3],
			stCardInfo.IssueInfo_0005.AppSn[4],
			stCardInfo.IssueInfo_0005.AppSn[5],
			stCardInfo.IssueInfo_0005.AppSn[6],
			stCardInfo.IssueInfo_0005.AppSn[7]);
	strncpy(stTicketInfo->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cLogicalID[%s]",__FILE__,__LINE__,stTicketInfo->cLogicalID);

	// 车票类型(主类型+子类型)
	stTicketInfo->bTicketType[0]=stCardInfo.IssueInfo_0005.MainType;
	stTicketInfo->bTicketType[1]=stCardInfo.IssueInfo_0005.SubType;
	PrintLog("File[%s]Line[%d]stTicketInfo-> bTicketType[%02X%02X]",__FILE__,__LINE__,stTicketInfo->bTicketType[0],stTicketInfo->bTicketType[1]);
	// 余值

	stTicketInfo->lBalance=htonl(stCardInfo.Purse_EP_0002);
	PrintLog("File[%s]Line[%d]stTicketInfo-> lBalance[%02X]",__FILE__,__LINE__,stTicketInfo->lBalance);

	// 押金
	//memset(temp,0,sizeof(temp));
	//memcpy(temp,( char*)g_BRContext.TicktPara0301.Deposit,6);
	//stTicketInfo->lDepositorCost=atoi(temp);
	stTicketInfo->lDepositorCost=(stCardInfo.AssistInfo_0011.Reserved3[0])*100;
	PrintLog("File[%s]Line[%d]stTicketInfo-> lDepositorCost[%02X]",__FILE__,__LINE__,stTicketInfo->lDepositorCost);
	// 车票最高上限值
	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.UpperLimit,6);
	stTicketInfo->lLimitedBalance=atoi(temp);
	PrintLog("File[%s]Line[%d]stTicketInfo-> lLimitedBalance[%02X]",__FILE__,__LINE__,stTicketInfo->lLimitedBalance);
	// 发行时间
	memcpy(stTicketInfo->bIssueData,stCardInfo.IssueInfo_0005.IssueDate,4);
	PrintLog("File[%s]Line[%d]stTicketInfo-> bIssueData",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->bIssueData,4);
	// 物理有效期截止时间(BCD)(无)
	memcpy(stTicketInfo->bExpiry,stCardInfo.IssueInfo_0005.CardValidDate,4);
	PrintLog("File[%s]Line[%d]stTicketInfo-> bExpiry",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->bExpiry,4);

	// 逻辑有效期开始时间(BCD)
	memcpy(stTicketInfo->bStartDate,stCardInfo.IssueInfo_0005.CardActiveDate,4);
	PrintLog("File[%s]Line[%d]stTicketInfo-> bStartDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->bStartDate,7);

	//stTicketInfo->bEndDate[7];					// 逻辑有效期结束时间(BCD)
	//memcpy(stTicketInfo->bEndDate,stCardInfo.TranRecord_11.AppActiveEndTime,7);
	memset(temp,0,sizeof(temp));

	memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
	int tempValidityMin=atoi(temp);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  tempValidityMin= [%d]",__FILE__,__LINE__,tempValidityMin);

	BCDTimeAddSeconds(tempValidityMin*60,stTicketInfo->bStartDate,stTicketInfo->bEndDate);
	PrintLog("File[%s]Line[%d]stTicketInfo-> bEndDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->bEndDate,7);

	// 交易状态
	stTicketInfo->bStatus=ConvertAccCPUCardStatus(stCardInfo.TranRecord_02.CardStatus);//todo:
	PrintLog("File[%s]Line[%d]stTicketInfo-> bStatus[%02X]",__FILE__,__LINE__,stTicketInfo->bStatus);

	// 上次交易线路站点(BCD)
	memcpy(&stTicketInfo->bLastStationID[0],&stCardInfo.TranRecord_02.ProcessLine,1);//todo:
	memcpy(&stTicketInfo->bLastStationID[1],&stCardInfo.TranRecord_02.ProcessStation,1);//todo:
	PrintLog("File[%s]Line[%d]stTicketInfo-> bLastStationID[%02X%02X]",__FILE__,__LINE__,stTicketInfo->bLastStationID[0],stTicketInfo->bLastStationID[1]);

	// 上次交易设备编号(BCD),第0字节仅低4bit有效

	memcpy(stTicketInfo->bLastDeviceID,&stCardInfo.TranRecord_02.ProcessEquCode,2);//todo:
	stTicketInfo->bLastDeviceID[0]=stTicketInfo->bLastDeviceID[0]&0x0F;
	PrintLog("File[%s]Line[%d]stTicketInfo-> bLastDeviceID[%02X%02X]",__FILE__,__LINE__,stTicketInfo->bLastDeviceID[0],stTicketInfo->bLastDeviceID[1]);


	// 上次交易设备类型
	stTicketInfo->bLastDeviceType=stCardInfo.TranRecord_02.ProcessEquCode&0x0FFF; //todo:
	PrintLog("File[%s]Line[%d]stTicketInfo-> bLastDeviceType[%02X]",__FILE__,__LINE__,stTicketInfo->bLastDeviceType);

	// 上次交易时间
	memcpy(stTicketInfo->dtLastDate,stCardInfo.TranRecord_02.ProcessTime,7);
	PrintLog("File[%s]Line[%d]stTicketInfo-> dtLastDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->dtLastDate,7);

	// 上次进站站点
	stTicketInfo->bEntrySationID[0]=stCardInfo.TranRecord_02.InGateLine;
	stTicketInfo->bEntrySationID[1]=stCardInfo.TranRecord_02.InGateStation;
	PrintLog("File[%s]Line[%d]stTicketInfo-> bEntrySationID[%02X%02X]",__FILE__,__LINE__,stTicketInfo->bEntrySationID[0],stTicketInfo->bEntrySationID[1]);

	//上次进站时间
	memcpy(stTicketInfo->dtEntryDate,stCardInfo.TranRecord_02.InGateTime,7);
	PrintLog("File[%s]Line[%d]stTicketInfo-> dtEntryDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->dtEntryDate,7);


	stTicketInfo->cTestFlag=stCardInfo.IssueInfo_0005.TestFlag+'0';		// 卡应用标识
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cTestFlag= [0x%02X]",__FILE__,__LINE__,stTicketInfo->cTestFlag);

	// 城市代码
	sprintf(stTicketInfo->cCityCode,"%02X%02X",stCardInfo.IssueInfo_0005.CityCode[0],stCardInfo.IssueInfo_0005.CityCode[1]);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cCityCode= [0x%02X%02X]",__FILE__,__LINE__,stCardInfo.IssueInfo_0005.CityCode[0],stCardInfo.IssueInfo_0005.CityCode[1]);

	// 发行商代码
	sprintf(stTicketInfo->cSellerCode,"%02X%02X",stCardInfo.IssueInfo_0005.IssuerCode[0],stCardInfo.IssueInfo_0005.IssuerCode[1]);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cSellerCode= [0x%02X%02X]",__FILE__,__LINE__,stCardInfo.IssueInfo_0005.IssuerCode[0],stCardInfo.IssueInfo_0005.IssuerCode[1]);

	// 消费计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,stCardInfo.LocalTradeRecord_0018[0],2);
	stTicketInfo->lTradeCount=htons(usTempTradeCount);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  lTradeCount= [0x%02X]",__FILE__,__LINE__,stTicketInfo->lTradeCount);

	// 充值计数
	unsigned short usTempChargeCount=0;
	memcpy(&usTempChargeCount,stCardInfo.TopupTradeRecord_001A[0],2);
	stTicketInfo->lChargeCount=htons(usTempChargeCount);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  lChargeCount= [0x%02X]",__FILE__,__LINE__,stTicketInfo->lChargeCount);


	//// 证件类型
	stTicketInfo->bCertificateType=stCardInfo.PersonInfo_0016.CustomType;

	//证件代码
	memcpy(stTicketInfo->cCertificateCode,stCardInfo.PersonInfo_0016.CustomIDCode,32);

	//证件持有人姓名
	memcpy(stTicketInfo->cCertificateName,stCardInfo.PersonInfo_0016.CustomName,20);

	//卡应用模式
	stTicketInfo->cTkAppMode='1';

	stTicketInfo->bUsefulCount=0x11;

	ST_ACC_CPU_CARD_ADF_HISTORY stHistory1;
	memset(&stHistory1,0,sizeof(ST_ACC_CPU_CARD_ADF_HISTORY));

	ST_ACC_CPU_CARD_ADF_HISTORY stTempHistory[20];

	memset(stTempHistory,0,sizeof(stTempHistory));


	//memcpy(stTempHistory,stCardInfo.LocalTradeRecord_0018,sizeof(stCardInfo.LocalTradeRecord_0018));

	//memcpy(stTempHistory+10,stCardInfo.TopupTradeRecord_001A,sizeof(stCardInfo.TopupTradeRecord_001A));


	int i=0;
	int j=0;
	int icount=0;
	for(i=0;i<10;i++)
	{
		if(memcmp(&stCardInfo.LocalTradeRecord_0018[i][16],stTicketInfo->bEndDate,7)<0
				&&memcmp(&stCardInfo.LocalTradeRecord_0018[i][16],stTicketInfo->bStartDate,7)>0)
		{
		   memcpy(&stTempHistory[icount],&stCardInfo.LocalTradeRecord_0018[i],sizeof(ST_ACC_CPU_CARD_ADF_HISTORY));
		   icount++;
		}
	}
	for(i=0;i<10;i++)
	{
		if(memcmp(&stCardInfo.TopupTradeRecord_001A[i][16],stTicketInfo->bEndDate,7)<0
				&&memcmp(&stCardInfo.TopupTradeRecord_001A[i][16],stTicketInfo->bStartDate,7)>0)
		{
		   memcpy(&stTempHistory[icount],&stCardInfo.TopupTradeRecord_001A[i],sizeof(ST_ACC_CPU_CARD_ADF_HISTORY));
		   icount++;
		}
	}

	stTicketInfo->bUsefulCount=icount>17?17:icount;
	//排序
	for(i=stTicketInfo->bUsefulCount; i>0;--i)
	{
		for(j = 0; j < i; ++j)
		{

			if(memcmp(stTempHistory[j+1].TranTime,stTempHistory[j].TranTime,7)>0)
			{
				memcpy(&stHistory1,&stTempHistory[j],sizeof(ST_ACC_CPU_CARD_ADF_HISTORY));
				memcpy(&stTempHistory[j],&stTempHistory[j+1],sizeof(ST_ACC_CPU_CARD_ADF_HISTORY));
				memcpy(&stTempHistory[j+1],&stHistory1,sizeof(ST_ACC_CPU_CARD_ADF_HISTORY));
			}
		}

	}

	//转换
	ST_ACC_CPU_CARD_ADF_HISTORY stHistory;
	for(i=0;i<stTicketInfo->bUsefulCount;i++)
	{
		memset(&stHistory,0,sizeof(ST_ACC_CPU_CARD_ADF_HISTORY));
		memcpy(&stHistory,&stTempHistory[i],23);
		stHistory.TranValue=htonl(stHistory.TranValue);
		memcpy(stTicketInfo->bhs[i].dtDate,stHistory.TranTime,7);

		if(stHistory.TranType==6)
		{
			stTicketInfo->bhs[i].bStatus=RW_LIFECODE_COMMON_CONSUMPTION;
		}else if(stHistory.TranType==9)
		{
			stTicketInfo->bhs[i].bStatus=RW_LIFECODE_COMPLEX_CONSUMPTION;
		}else
		{
			stTicketInfo->bhs[i].bStatus=RW_LIFECODE_REVALUATE;
		}

		stTicketInfo->bhs[i].lTradeAmount=stHistory.TranValue;

		sprintf(stTicketInfo->bhs[i].cSAMID,"%02X%02X%02X%02X%02X%02X"
				,stHistory.TranDeviceCode[0]
				,stHistory.TranDeviceCode[1]
				,stHistory.TranDeviceCode[2]
				,stHistory.TranDeviceCode[3]
				,stHistory.TranDeviceCode[4]
				,stHistory.TranDeviceCode[5]);
	}

	pRetInfo->wErrCode=0;

	return CE_OK;
 }

 int Update_AccCpuCard(StruAPIParam APIParam,uint8 u8UpdateCode,uint16 u16EntryStationCode,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRetInfo,TICKETUPDATE * stUpdateInfo)
 {
	 
	int iRet=-1;
	//BOOL bRet=FALSE;
    unsigned int uiTranValue=0;
	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;
	uint8 updateArea=0;
	uint8 u8TranStatus=0;

	if(NULL==pRetInfo||NULL==stUpdateInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	PrintLog("File[%s]Line[%d] Update_ULCard  m_stOperationStauts.bAllowUpdate= [0x%02X]",__FILE__,__LINE__,m_stOperationStauts.bAllowUpdate);
	PrintLog("File[%s]Line[%d] Update_ULCard  u16EntryStationCode [0x%02X]",__FILE__,__LINE__,u16EntryStationCode);
	PrintLog("File[%s]Line[%d] Update_ULCard  m_stOperationStauts.bAllowUpdate= [0x%02X]",__FILE__,__LINE__,m_stOperationStauts.bAllowUpdate);

	if(!m_stOperationStauts.bAllowUpdate)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	char szEntryStationCode[10]={0};

	uint8 InGateLine=u16EntryStationCode&0x00FF;
	uint8 InGateStation=(u16EntryStationCode&0xFF00)>>8;

	sprintf(szEntryStationCode,"%02d%02d",InGateLine,InGateStation);


	//车票状态
	/*1：付费区出站超时
	2：付费区超乘
	3：付费区无进站码
	10：非付费区有进站码
	11：非付费区非本站进站
	12：非付费区进站超时；
	*/
	switch(u8UpdateCode)
	{
		case 1:
			m_stAccCpuCardInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT;
			updateArea='1';
			u8TranStatus=RW_LIFECODE_UPDATE_TIMEOUT;
			break;
		case 2:
			m_stAccCpuCardInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_RANGEOUT;
			updateArea='1';
			u8TranStatus=RW_LIFECODE_UPDATE_RANGEOUT;
			break;
		case 3:
		{
			iRet=BR_IsExsitStationCode(szEntryStationCode);
			if(iRet!=CE_OK)
			{
				pRetInfo->wErrCode = RW_EC_INVALID_STATION_CODE;// 错误码,非法的输入参数
				return pRetInfo->wErrCode;
			}
			m_stAccCpuCardInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION;
			m_stAccCpuCardInfo.TranRecord_02.InGateLine=InGateLine;//u16EntryStationCode&0x00FF;
			m_stAccCpuCardInfo.TranRecord_02.InGateStation=InGateStation;//(u16EntryStationCode&0xFF00)>>8;
			memcpy(m_stAccCpuCardInfo.TranRecord_02.InGateTime,APIParam.ucTimeStamp,7);
			updateArea='1';
			u8TranStatus=RW_LIFECODE_UPDATE_NO_ENTRY_STATION;
		}
			break;
		case 10:
		case 11:
		case 12:
			if(u16TranValue>0)
			{
			   m_stAccCpuCardInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA;
			   u8TranStatus=RW_LIFECODE_UPDATE_PAYED_UNPAYAREA;
			}else
			{
				m_stAccCpuCardInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA;
				u8TranStatus=RW_LIFECODE_UPDATE_FREE_UNPAYAREA;
			}
			updateArea='2';
			break;
//		case 11:
//			m_stAccCpuCardInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA;
//			updateArea='2';
//			u8TranStatus=RW_LIFECODE_UPDATE_PAYED_UNPAYAREA;
//			break;
//		case 12:
//			m_stAccCpuCardInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA;
//			updateArea='2';
//			u8TranStatus=RW_LIFECODE_UPDATE_PAYED_UNPAYAREA;
//			break;
		default:
			pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
			return iRet;
	}

	if(u8PaymentType==2)//卡内支付
	{
		uiTranValue=u16TranValue;
	}



	iRet=Inner_Write_AccCpuCard(APIParam,0,m_stAccCpuCardInfo,u8TAC,&u32TerminalTradeNum);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD
	// SAM卡脱机交易流水号
	stUpdateInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	// 罚金支付方式  //01：现金，02：票卡
	stUpdateInfo->bPaymentMode=u8PaymentType;

	stUpdateInfo->nForfeiture=u16TranValue;

	//// 更新区域 1：付费区，2：非付费区
	stUpdateInfo->cUpdateZone=updateArea;
	stUpdateInfo->bUpdateReasonCode=Byte_Decimal_to_BCD(u8UpdateCode);

	stUpdateInfo->bStatus=u8TranStatus;

	Fill_Update_AccCpuCard_UD(APIParam,m_stAccCpuCardInfo,stUpdateInfo);


	pRetInfo->wErrCode=0;

	return CE_OK;
 }
 int Refund_AccCpuCard(StruAPIParam APIParam,uint8 u8RefundOption,uint8 u8RefundCode,uint16 u16TranValue,RetInfo * pRetInfo,DIRECTREFUND * stRefundInfo)
 {
	
	int iRet=-1;

	BOOL bRet=FALSE;

	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;
	uint32 u32TranValue=0;

	if(NULL==pRetInfo||NULL==stRefundInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	if(u8RefundOption<1||u8RefundOption>3)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}



	 if(g_BRContext.TicktPara0301.Refund[0]=='0')
	 {
		 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  g_BRContext.TicktPara0301.Refund= [%d]",__FILE__,__LINE__,g_BRContext.TicktPara0301.Refund[0]);
		 return TRUE;
	 }

	PrintLog("File[%s]Line[%d] Refund_AccCpuCard  m_stOperationStauts.bAllowRefund= [0x%02X]",__FILE__,__LINE__,m_stOperationStauts.bAllowRefund);

	if(!m_stOperationStauts.bAllowRefund)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_API_CALL;
		return RW_EC_INVALID_INPUT_PARAM;
	}



	if(m_stAccCpuCardInfo.TranRecord_02.CardStatus==EM_TICKET_TRAVEL_STATUS_INITIALIZATION||m_stAccCpuCardInfo.TranRecord_02.CardStatus==EM_TICKET_TRAVEL_STATUS_REFUND)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
		return RW_EC_INVALID_TICKET;
	}


	char temp[10]={0};
    memset(temp,0,sizeof(temp));
    memcpy(temp,g_BRContext.TicktPara0301.RefundMoneyLimit,6);

    if(atoi(temp)<htonl(m_stAccCpuCardInfo.Purse_EP_0002))
    {
    	PrintLog("File[%s]Line[%d] Refund_ULCard  RW_EC_AMOUNT_EXCEED_MAX_AMOUNT ",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return pRetInfo->wErrCode;
    }




	//特殊标记
	if(m_stAccCpuCardInfo.TranRecord_02.CardSpecialFlag!=EM_CS_SPEC_FLAG_NORMAL)//正常
	{
		PrintLog("File[%s]Line[%d] Refund_AccCpuCard CardSpecialFlag!=EM_CS_SPEC_FLAG_NORMAL",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
		return RW_EC_INVALID_TICKET;
	}


	//票卡应用有效期判断，过期报错（读0015公共应用基本数据文件，"应用启用日期"和"应用有效日期"判断）
	bRet=Check_Ticket_Valid_AccCpuCard(APIParam,m_stAccCpuCardInfo);
	PrintLog("File[%s]Line[%d]Refund_AccCpuCard Check_Ticket_Valid_AccCpuCard bRet[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		return RW_EC_INVALID_TICKET;
	}


	if(m_stOperationStauts.bAllowRefundDeposit!=TRUE&&(u8RefundOption==2||u8RefundOption==3))
	{
		PrintLog("File[%s]Line[%d]Refund_AccCpuCard bAllowRefundDeposit bRet[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowRefundDeposit);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_TICKET;
	}

	//准备写卡信息
	m_stAccCpuCardInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_REFUND;//车票状态
	//m_stAccCpuCardInfo.TranRecord_02.CardSpecialFlag=EM_CS_SPEC_FLAG_NORMAL;//特殊标记
	m_stAccCpuCardInfo.Info_0011[0]=0x02;
	if(u8RefundOption==2||u8RefundOption==3)
	{
	  m_stAccCpuCardInfo.Info_0011[5]=0x00;//清空押金
	}

	iRet=Write_AccCpuCard_Sail_Info(&m_stAccCpuCardInfo,0x01);//SailFlag 00:11应用控制记录   01:辅助信息文件
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	if(u8RefundOption==1||u8RefundOption==3)
	{
		u32TranValue=htonl(m_stAccCpuCardInfo.Purse_EP_0002);
	}
	iRet=Inner_Write_AccCpuCard(APIParam,u32TranValue,m_stAccCpuCardInfo,u8TAC,&u32TerminalTradeNum);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD
	Fill_Refund_AccCpuCard_UD(APIParam,m_stAccCpuCardInfo,stRefundInfo);

	stRefundInfo->bStatus=RW_LIFECODE_REBACK_CARD;

	//long		lBalanceReturned;				// 退还钱包金额, 单位为分
	//short		nDepositReturned;				// 退还押金, 单位为分

	stRefundInfo->lBalanceReturned=u32TranValue;//htonl(m_stAccCpuCardInfo.Purse_EP_0002);

	if(m_stOperationStauts.bAllowRefundDeposit==TRUE)
	{

	if(u8RefundOption==2||u8RefundOption==3)
		{
		  stRefundInfo->nDepositReturned=(m_stAccCpuCardInfo.AssistInfo_0011.Reserved3[0]*100);
		}
	}
	stRefundInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  cMACorTAC [%02X%02X%02X%02X]",__FILE__,__LINE__,u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);
	// SAM生成的交易检查代码
	sprintf(stRefundInfo->cMACOrTAC,"%02X%02X%02X%02X",u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);

	pRetInfo->wErrCode=0;

	return CE_OK;
 }
 int Defer_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETDEFER * stDeferInfo)
 {


	int iRet=-1;

	char  szDelayDay[5]={0};
    int   iDelayDay=0;

	if(NULL==pRetInfo||NULL==stDeferInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	 if(g_BRContext.TicktPara0301.Delay[0]=='0')
	 {
		 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  g_BRContext.TicktPara0301.Delay= [%d]",__FILE__,__LINE__,g_BRContext.TicktPara0301.Delay[0]);
		 return TRUE;
	 }

	PrintLog("File[%s]Line[%d] Update_ULCard  m_stOperationStauts.bAllowDelay= [0x%02X]",__FILE__,__LINE__,m_stOperationStauts.bAllowDelay);

	if(!m_stOperationStauts.bAllowDelay)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	memcpy(szDelayDay,g_BRContext.TicktPara0301.DelayDayTime,4);

	iDelayDay=atoi(szDelayDay);

	PrintLog("File[%s]Line[%d] Defer_AccCpuCard  iDelayDay= [%d]",__FILE__,__LINE__,iDelayDay);

	BCDTimeAddSeconds(iDelayDay*24*3600,m_stAccCpuCardInfo.TranRecord_11.AppActiveBeginTime,&m_stAccCpuCardInfo.Info_0017[6][4]);//启用日期 后延
	PrintLog("File[%s]Line[%d]m_stAccCpuCardInfo-> bStartDate",__FILE__,__LINE__);
	PrintBuffer((const char *)&m_stAccCpuCardInfo.Info_0017[6][4],7);

	//memcpy(&m_stAccCpuCardInfo.Info_0017[6][4],APIParam.ucTimeStamp,7);//启用日期 后延
	iRet=Write_AccCpuCard_Sail_Info(&m_stAccCpuCardInfo,0x00);//SailFlag 00:11应用控制记录   01:辅助信息文件
	PrintLog("File[%s]Line[%d]Sale_AccCpuCard Write_AccCpuCard_Sail_Info [%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD
	Fill_Deffer_AccCpuCard_UD(APIParam,m_stAccCpuCardInfo,stDeferInfo);

	//BYTE		bStatus;						// 交易状态代码
	//BYTE		dtOldExpiryDate[7];			// 原有效时间
	//BYTE		dtNewExpiryDate[7];			// 现有效时间

	stDeferInfo->bStatus=RW_LIFECODE_DEFER;

	memcpy(stDeferInfo->dtOldExpiryDate,m_stAccCpuCardInfo.TranRecord_11.AppActiveBeginTime,7);

	memcpy(stDeferInfo->dtNewExpiryDate,APIParam.ucTimeStamp,7);

	pRetInfo->wErrCode=0;

	return CE_OK;

 }

 int Unlock_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETLOCK * stLockInfo)
 {
	int iRet=-1;
	uint32 TranSn=0;

	//入参检查.
	if(NULL==pRetInfo||NULL==stLockInfo)
	{
		return CE_CHECKERROR;
	}
	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;

	if(!m_stOperationStauts.bAllowUnlock)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_API_CALL;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	//特殊标记
	m_stAccCpuCardInfo.TranRecord_01.AppLockFlag=0x00;//黑名单
	memcpy(&m_stAccCpuCardInfo.Info_0017[0],&m_stAccCpuCardInfo.TranRecord_01,48);
	iRet=Unlock_AccCpuCard_Info(&m_stAccCpuCardInfo);
	PrintLog("File[%s]Line[%d] Unlock_AccCpuCard Unlock_AccCpuCard_Info iRet[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	iRet=Inner_Write6_AccCpuCard(APIParam,0,m_stAccCpuCardInfo,u8TAC,&u32TerminalTradeNum);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD
	Fill_Lock_AccCpuCard_UD(APIParam,m_stAccCpuCardInfo,stLockInfo);


	stLockInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	//BYTE		bStatus;					// 交易状态代码
	//char		cLockFlag;					// 加解锁标志

	//1：加锁；2：解锁
	stLockInfo->cLockFlag='2';

	stLockInfo->bStatus=RW_LIFECODE_UNLOCK;

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;
 }

 int Check_Aisel_Type(ST_CARD_ACC_CPU  stAccCpuCardInfo)
 {
	int iRet=-1;
	Para0302 stPara0302;
	memset(&stPara0302,0,sizeof(Para0302));
	iRet= BR_GetAgTicketPara(stAccCpuCardInfo.IssueInfo_0005.MainType, stAccCpuCardInfo.IssueInfo_0005.SubType,&stPara0302);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Check_Aisel_Type  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		return RW_EC_UNKNOW_TICKETTYPE;
	}
	//通道类型
	//1	0	byte	1：普通通道（不接受优惠票）
	//2：专用通道（只接受优惠票）
	//3：正常通道（接受所有票票种）

	//是否优惠票	CHAR	1	0：普通票 1：优惠票

	switch(g_BRContext.AGMAisleType)
	{
	   case EM_AG_AISLE_TYPE_NORMAL://1：普通通道（不接受优惠票）
		   if(stPara0302.PreferentialCard[0]!='0')
		   {
			   return RW_EC_AISLE_FOR_COMMON_TICKET;
		   }
		break;
	   case EM_AG_AISLE_TYPE_SEC://2：专用通道（只接受优惠票）
		   if(stPara0302.PreferentialCard[0]!='1')
		   {
			   return RW_EC_AISLE_FOR_SPECIAL_TICKET;
		   }
		break;
	   case EM_AG_AISLE_TYPE_ALL://3：正常通道（接受所有票票种）
		break;
	}

	return RW_EC_OK;
 }

 int Entry_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,ENTRYGATE *stEntryInfo,TICKETLOCK * stLockInfo)
 {

	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;
    BOOL bCardHasLocked=FALSE;
	BOOL bAllowEntryInMode=FALSE;
	 unsigned char DeviceID[2]={0};
	 unsigned short usDeviceID=0;
	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;
	ST_CARD_ACC_CPU cardProcessInfo;
	memset(&cardProcessInfo,0,sizeof(ST_CARD_ACC_CPU));

	uint8 szLastProcessStation[2]={0};
	uint8 szLastProcessTime[7]={0};
	uint8 u8CardStatus=0;

	if(NULL==pRetInfo||NULL==stEntryInfo||NULL==stLockInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	g_BRContext.ucCurrentStationMode=GetLocalStationMode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID);

	PrintLog("File[%s]Line[%d]Entry_ULCard   CurrentStationMode=[%d]",__FILE__,__LINE__,g_BRContext.ucCurrentStationMode);

	if(g_BRContext.ucCurrentStationMode==EM_MODE_EMERGENCY
	  ||g_BRContext.ucCurrentStationMode==EM_MODE_TRAIN_FAULT
	  ||g_BRContext.ucCurrentStationMode==EM_MODE_FREE_ENTRY)
	{
		PrintLog("File[%s]Line[%d]Entry_ULCard   StationMode=EM_MODE_EMERGENCY",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}


	iRet=Inner_Read_AccCpuCard(APIParam,&cardProcessInfo,FALSE);
	PrintLog("File[%s]Line[%d] Entry_AccCpuCard  Inner_Read_AccCpuCard iRet= [%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}
	iRet= BR_GetParaTicketsTypeTable_h(cardProcessInfo.IssueInfo_0005.MainType, cardProcessInfo.IssueInfo_0005.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Entry_AccCpuCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}

	szLastProcessStation[0]=cardProcessInfo.TranRecord_02.ProcessLine;
	szLastProcessStation[1]=cardProcessInfo.TranRecord_02.ProcessStation;
	memcpy(szLastProcessTime,cardProcessInfo.TranRecord_02.ProcessTime,7);
	u8CardStatus=cardProcessInfo.TranRecord_02.CardStatus;;

	iRet= Check_Aisel_Type(cardProcessInfo);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Entry_AccCpuCard  Check_Aisel_Type iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=iRet;
		return pRetInfo->wErrCode;
	}

	//检查卡是否在黑名单参数中
	bRet=Verify_Blacklist_AccCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d]Verify_Blacklist_AccCpuCard bRet[%d]",__FILE__,__LINE__,bRet);

	//检查卡是否已锁。
	bCardHasLocked=Verify_IsLocked_AccCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d]Verify_IsLocked_AccCpuCard bCardHasLocked[%d]",__FILE__,__LINE__,bCardHasLocked);


	if(bRet==TRUE)
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==FALSE)
		{
		   iRet=Inner_Lock_AccCpuCard( APIParam, pRetInfo,stLockInfo);
		   PrintLog("File[%s]Line[%d]Inner_Lock_AccCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
		   if(iRet!=CE_OK)
		   {
			   pRetInfo->wErrCode=RW_EC_WRITE_FAILED;
			   return pRetInfo->wErrCode;
		   }
		}
		pRetInfo->wErrCode=RW_EC_BLACKLIST;
		return pRetInfo->wErrCode;

	}else
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==TRUE)
		{
			pRetInfo->wErrCode=RW_EC_BLACKLIST;
			return pRetInfo->wErrCode;
		}

	}

	//检查车票状态是否正确。
	bRet=Check_Ticket_Status_AccCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Entry_AccCpuCard  Check_Ticket_Status_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_STATUS_CODE;
		return pRetInfo->wErrCode;
	}
	//检查余额是否超出上限。
	bRet=Check_Ticket_Value_Uplimit_AccCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Entry_AccCpuCard  Check_Ticket_Value_Uplimit_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return pRetInfo->wErrCode;
	}
	//检查车票是否过期。
	bRet=Check_Ticket_Valid_AccCpuCard(APIParam,cardProcessInfo);
	PrintLog("File[%s]Line[%d] Entry_AccCpuCard  Check_Ticket_Valid_AccCpuCard  bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		return pRetInfo->wErrCode;
	}
	//进站次序检查。
	bRet=Check_Entry_Status_AccCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Entry_AccCpuCard  Check_Entry_Status_AccCpuCard  bRet= [%d]",__FILE__,__LINE__,bRet);
	if((!bRet)&&(!bAllowEntryInMode))
	{
		bAllowEntryInMode=Allow_Entry_InDegradeMode(APIParam.ucTimeStamp,szLastProcessTime,szLastProcessStation,u8CardStatus);
		PrintLog("File[%s]Line[%d]Entry_AccCpuCard  Allow_Entry_InDegradeMode bAllowEntryInMode=[%d]",__FILE__,__LINE__,bAllowEntryInMode);
		if(!bAllowEntryInMode)
		{
		  pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
		  return pRetInfo->wErrCode;
		}
	}

	//余额低于最小票价。
	bRet=Check_MinValue_AccCpuCard(APIParam,cardProcessInfo);
	PrintLog("File[%s]Line[%d] Entry_AccCpuCard  Check_MinValue_AccCpuCard  bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_INSUFFICIENT;
		return pRetInfo->wErrCode;
	}

	//写卡准备
	//车票状态
	cardProcessInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_ENTRY;//:已进站
	cardProcessInfo.TranRecord_02.InGateLine=g_BRContext.bCurrentLineID;
	cardProcessInfo.TranRecord_02.InGateStation=g_BRContext.bCurrentStationID[1];
	memcpy(cardProcessInfo.TranRecord_02.InGateTime,APIParam.ucTimeStamp,7);


	 BitstreamInitMasks();
	//设备类型设备编码
	memcpy(&usDeviceID,g_BRContext.bCurrentDeviceID,2);
	unsigned int uiDeviceID=htons(usDeviceID);


	BitStreamPack(g_BRContext.bCurrentDeviceTypeCode,DeviceID,0, 4);

	BitStreamPack(uiDeviceID,DeviceID,4, 12);

	PrintLog("File[%s]Line[%d]Entry_AccCpuCard uiDeviceID[%d],g_BRContext.bCurrentDeviceTypeCode[%d]",__FILE__,__LINE__,uiDeviceID,g_BRContext.bCurrentDeviceTypeCode);

	PrintLog("File[%s]Line[%d]Entry_AccCpuCard DeviceID[0x%02X%02X]",__FILE__,__LINE__,DeviceID[0],DeviceID[1]);

	memcpy(&cardProcessInfo.TranRecord_02.InGateDeviceCode,DeviceID,2);

	iRet=Inner_Write_AccCpuCard(APIParam,0,cardProcessInfo,u8TAC,&u32TerminalTradeNum);
	PrintLog("File[%s]Line[%d] Entry_AccCpuCard  Inner_Write_AccCpuCard  iRet= [%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD
	// SAM卡脱机交易流水号
	stEntryInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	//stEntryInfo
	stEntryInfo->bStatus=RW_LIFECODE_ENTRY_STATION;

	Fill_Entry_AccCpuCard_UD(APIParam,cardProcessInfo,stEntryInfo);

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;

 }

int Exit_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,PURSETRADE *stPurseInfo,TICKETLOCK * stLockInfo)
{

	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;
	BOOL bCardHasLocked=FALSE;
	BOOL bHasFreeMode=FALSE;
	uint32 u32Price=0;
	 uint16 FareZone=0;
	 uint16 JourneyTimeLimit=0;
	 uint16 TimeoutsFines=0;
	 uint8  RidingTime=0;
	 uint8  TrainTicketTableID=0;
	 uint8 u8CardType[2]={0};
	 uint8 szProcessStation[2]={0};
	 uint8 u8EntryTime[7]={0};

	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;

	ST_CARD_ACC_CPU cardProcessInfo;
	memset(&cardProcessInfo,0,sizeof(ST_CARD_ACC_CPU));

	if(NULL==pRetInfo||NULL==stPurseInfo||NULL==stLockInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	g_BRContext.ucCurrentStationMode=GetLocalStationMode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID);

	if(g_BRContext.ucCurrentStationMode==EM_MODE_EMERGENCY)
	{
		PrintLog("File[%s]Line[%d]Exit_AccCpuCard   StationMode=EM_MODE_EMERGENCY",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	iRet=Inner_Read_AccCpuCard(APIParam,&cardProcessInfo,FALSE);
	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  Inner_Read_AccCpuCard iRet= [%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}
	iRet= BR_GetParaTicketsTypeTable_h(cardProcessInfo.IssueInfo_0005.MainType, cardProcessInfo.IssueInfo_0005.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Exit_AccCpuCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}

	u8CardType[0]=cardProcessInfo.IssueInfo_0005.MainType;
	u8CardType[1]=cardProcessInfo.IssueInfo_0005.SubType;
	szProcessStation[0]=cardProcessInfo.TranRecord_02.InGateLine;
	szProcessStation[1]=cardProcessInfo.TranRecord_02.InGateStation;

	memcpy(u8EntryTime,cardProcessInfo.TranRecord_02.InGateTime,7);

	iRet= Check_Aisel_Type(cardProcessInfo);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Entry_AccCpuCard  Check_Aisel_Type iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=iRet;
		return pRetInfo->wErrCode;
	}
	//检查卡是否在黑名单参数中
	bRet=Verify_Blacklist_AccCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d]Verify_Blacklist_AccCpuCard bRet[%d]",__FILE__,__LINE__,bRet);

	//检查卡是否已锁。
	bCardHasLocked=Verify_IsLocked_AccCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d]Verify_IsLocked_AccCpuCard bCardHasLocked[%d]",__FILE__,__LINE__,bCardHasLocked);


	if(bRet==TRUE)
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==FALSE)
		{
		   iRet=Inner_Lock_AccCpuCard( APIParam, pRetInfo,stLockInfo);
		   PrintLog("File[%s]Line[%d]Inner_Lock_AccCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
		   if(iRet!=CE_OK)
		   {
			   pRetInfo->wErrCode=RW_EC_WRITE_FAILED;
			   return pRetInfo->wErrCode;
		   }
		}
		pRetInfo->wErrCode=RW_EC_BLACKLIST;
		return pRetInfo->wErrCode;

	}else
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==TRUE)
		{
			pRetInfo->wErrCode=RW_EC_BLACKLIST;
			return pRetInfo->wErrCode;
		}

	}

	//检查车票状态是否正确。
	bRet=Check_Ticket_Status_AccCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  Check_Ticket_Status_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_STATUS_CODE;
		return pRetInfo->wErrCode;
	}
	//检查余额是否超出上限。
	bRet=Check_Ticket_Value_Uplimit_AccCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  Check_Ticket_Value_Uplimit_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return pRetInfo->wErrCode;
	}
	//检查车票是否过期。
	bRet=Check_Ticket_Valid_AccCpuCard(APIParam,cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  Check_Ticket_Valid_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		return pRetInfo->wErrCode;
	}
	//出站次序检查。
	bRet=Check_Exit_Status_AccCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  Check_Exit_Status_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if((!bRet)&&(!bHasFreeMode))
	{
		bHasFreeMode=Allow_Exit_InFreeEntryStationCode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID,szProcessStation);
		if(!bHasFreeMode)
		{
			pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
			return pRetInfo->wErrCode;
		}
	}
	bRet=Check_Exit_DateTime_Order_AccCpuCard( APIParam,cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  Check_Exit_DateTime_Order_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		return pRetInfo->wErrCode;
	}
	//非本站更新
	bRet=Check_Update_ThisStation_AccCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  Check_Update_ThisStation_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_SATION;
		return pRetInfo->wErrCode;
	}
	//非本日更新
	bRet=Check_Update_ThisDay_AccCpuCard( APIParam,cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  Check_Update_ThisDay_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_DATE;
		return pRetInfo->wErrCode;
	}
	//出站超时

	iRet=Get_Price_InDegrade(u8CardType,szProcessStation,u8EntryTime,APIParam.ucTimeStamp,
			&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&u32Price);
	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  BR_CalcPrice JourneyTimeLimit= [%d] u32Price[%d]",__FILE__,__LINE__,JourneyTimeLimit,u32Price);
	if(iRet!=CE_OK)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return pRetInfo->wErrCode;
	}
	bRet=Check_Exit_Timeout_AccCpuCard(APIParam,JourneyTimeLimit,cardProcessInfo);//判断错误，要根据获取票价返回的参数。
	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  Check_Exit_Timeout_AccCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;
		return pRetInfo->wErrCode;
	}
	//出站超程
	bRet=Check_Exit_RemainningValue_AccCpuCard(&u32Price,cardProcessInfo);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_PAID_AREA;
		return pRetInfo->wErrCode;
	}


	//车票状态
	if(g_BRContext.ucCurrentStationMode==EM_MODE_TRAIN_FAULT)
	{
		stPurseInfo->bStatus=RW_LIFECODE_EXIT_TRAINFAULT;
		cardProcessInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE;//列车故障模式出站(
		u32Price=0;//列车故障模式出站 不扣车费
	}else
	{
		cardProcessInfo.TranRecord_02.CardStatus=EM_TICKET_TRAVEL_STATUS_EXITED;//:已出站
		stPurseInfo->bStatus=RW_LIFECODE_EXIT_STAION;
	}


	iRet=Inner_Write_AccCpuCard(APIParam,u32Price,cardProcessInfo,u8TAC,&u32TerminalTradeNum);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD

	// SAM卡脱机交易流水号
	stPurseInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	Fill_Purse_AccCpuCard_UD(APIParam,cardProcessInfo,stPurseInfo);

	stPurseInfo->lTradeAmount=u32Price;
	stPurseInfo->lBalance=(htonl(cardProcessInfo.Purse_EP_0002)-u32Price);

	PrintLog("File[%s]Line[%d] Exit_AccCpuCard  cMACorTAC [%02X%02X%02X%02X]",__FILE__,__LINE__,u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);
	// SAM生成的交易检查代码
	char u8tempTac[16]={0};
	sprintf(u8tempTac,"%02X%02X%02X%02X  ",u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);
	memcpy(stPurseInfo->cMACorTAC,u8tempTac,10);

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;

}

int Bom_AccCPU_TopupInit(StruAPIParam APIParam,uint8 TopupType,uint32 TopupValue,uint8 *NetPoint,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;
	int i=0;
	char charBuff[20]={0};
	char temp[32]={0};

	int ChargeUpper=0;
	int RemainningUpper=0;

	uint8 u8InitPurseBuff[18];//Cpu卡圈存初始化返回数据（4旧金额+2联机交易序号+1秘钥版本+1算法标识+4伪随机数+4MAC1）+2脱机交易序号
	TopupRequestReader st_TopupRequestReader;
	memset(&st_TopupRequestReader,0x30,sizeof(st_TopupRequestReader));
	memset(u8InitPurseBuff,0x00,sizeof(u8InitPurseBuff));

	if(!m_stOperationStauts.bAllowCharge)
	{
		PrintLog("File[%s]Line[%d] Bom_AccCPU_TopupInit  m_stOperationStauts.bAllowCharge [%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowCharge);

		pRi->wErrCode=RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT;
		return pRi->wErrCode;
	}

	// 充值上限，可充值标志位非0时有效
	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.TopUplimit,6);
	ChargeUpper=atoi(temp);
	PrintLog("File[%s]Line[%d]Bom_AccCPU_TopupInit ChargeUpper[%d]",__FILE__,__LINE__,ChargeUpper);

	if(TopupValue>ChargeUpper)
	{
		PrintLog("File[%s]Line[%d]Bom_AccCPU_TopupInit TopupValue[%d]>ChargeUpper[%d]",__FILE__,__LINE__,TopupValue,ChargeUpper);
		pRi->wErrCode=RW_EC_ILLEGAL_INPUT_PARAM;
		return pRi->wErrCode;
	}

	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.UpperLimit,6);
	RemainningUpper=atoi(temp);

	if((TopupValue+htonl(m_stAccCpuCardInfo.Purse_EP_0002))>RemainningUpper)
	{
		PrintLog("File[%s]Line[%d]Bom_AccCPU_TopupInit (TopupValue+m_stAccCpuCardInfo.Purse_EP_0002)>RemainningUpper[%d]",__FILE__,__LINE__,RemainningUpper);
		pRi->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return pRi->wErrCode;
	}


	iRet = PopupInit_AccCpuCard(TopupValue,u8InitPurseBuff);
	if(iRet!=CE_OK)
	{pRi->wErrCode=RW_ERR_SAM_RESPONSE;}

	st_TopupRequestReader.MessageType[0] = '5';
	st_TopupRequestReader.MessageType[1] = '1';

	memcpy(st_TopupRequestReader.MessageTime,APIParam.ucTimeStamp,7);

	st_TopupRequestReader.TerminalID[0]=g_BRContext.bCurrentStationID[0]/10+'0';
	st_TopupRequestReader.TerminalID[1]=g_BRContext.bCurrentStationID[0]%10+'0';
	st_TopupRequestReader.TerminalID[2]=g_BRContext.bCurrentStationID[1]/10+'0';
	st_TopupRequestReader.TerminalID[3]=g_BRContext.bCurrentStationID[1]%10+'0';
	st_TopupRequestReader.TerminalID[4]=g_BRContext.bCurrentDeviceTypeCode/10+'0';
	st_TopupRequestReader.TerminalID[5]=g_BRContext.bCurrentDeviceTypeCode%10+'0';
	st_TopupRequestReader.TerminalID[6]=g_BRContext.bCurrentDeviceID[0]%10+'0';
	st_TopupRequestReader.TerminalID[7]=g_BRContext.bCurrentDeviceID[1]/10+'0';
	st_TopupRequestReader.TerminalID[8]=g_BRContext.bCurrentDeviceID[1]%10+'0';

	memcpy(st_TopupRequestReader.SamLogicID,g_BRContext.stSamInfo[0].cSAMID,16);
	memcpy(st_TopupRequestReader.WebsiteCode,NetPoint,16);

	st_TopupRequestReader.SendcardMaincode[0]=(m_stAccCpuCardInfo.Info_0005[0]/0x10)+'0';
	st_TopupRequestReader.SendcardMaincode[1]=(m_stAccCpuCardInfo.Info_0005[0]%0x10)+'0';
	st_TopupRequestReader.SendcardMaincode[2]=(m_stAccCpuCardInfo.Info_0005[1]/0x10)+'0';
	st_TopupRequestReader.SendcardMaincode[3]=(m_stAccCpuCardInfo.Info_0005[1]%0x10)+'0';

	st_TopupRequestReader.CardCode[0]=m_stAccCpuCardInfo.Info_0005[16];
	st_TopupRequestReader.CardCode[1]=m_stAccCpuCardInfo.Info_0005[17];

	for(i=0;i<8;i++)
	{
		st_TopupRequestReader.CardLogicNo[4+2*i]=(m_stAccCpuCardInfo.Info_0005[8+i]/0x10)+'0';
		st_TopupRequestReader.CardLogicNo[4+2*i+1]=(m_stAccCpuCardInfo.Info_0005[8+i]%0x10)+'0';
	}

	memset(charBuff,0x00,sizeof(charBuff));
	BcdToString(g_BRContext.szCardPhID,4,charBuff);
	memcpy(st_TopupRequestReader.CardPhysicsNo,charBuff,8);
	memset(&st_TopupRequestReader.CardPhysicsNo[14],' ',6);

	for(i=0;i<4;i++)
	{
		st_TopupRequestReader.CardLogicNo[4+2*i]=(m_stAccCpuCardInfo.Info_0005[8+i]/0x10)+'0';
		st_TopupRequestReader.CardLogicNo[4+2*i+1]=(m_stAccCpuCardInfo.Info_0005[8+i]%0x10)+'0';
	}

	st_TopupRequestReader.TsetFlag[0]=m_stAccCpuCardInfo.Info_0005[6]+'0';

	// 消费计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,m_stAccCpuCardInfo.LocalTradeRecord_0018[0],2);
	usTempTradeCount=htons(usTempTradeCount);
	PrintLog("File[%s]Line[%d] Bom_ACCCPU_ChargeBackInit  lTradeCount= [0x%02X]",__FILE__,__LINE__,usTempTradeCount);

	// 充值计数
	unsigned short usTempChargeCount=0;
	memcpy(&usTempChargeCount,m_stAccCpuCardInfo.TopupTradeRecord_001A[0],2);
	usTempChargeCount=htons(usTempChargeCount);
	PrintLog("File[%s]Line[%d] Bom_ACCCPU_ChargeBackInit  lChargeCount= [0x%02X]",__FILE__,__LINE__,usTempChargeCount);

	unsigned short uiTreminalTranNo=usTempChargeCount+1;

	PrintLog("File[%s]Line[%d] Bom_ACCCPU_ChargeBackInit  uiTreminalTranNo= [0x%02X]",__FILE__,__LINE__,uiTreminalTranNo);

	memset(st_TopupRequestReader.CardOnlineNo,0x00,4);
	memcpy(st_TopupRequestReader.CardOnlineNo,&usTempChargeCount,2);

	memset(st_TopupRequestReader.CardOutlineNo,0x00,4);
	memcpy(st_TopupRequestReader.CardOutlineNo,&usTempTradeCount,2);

	memset(st_TopupRequestReader.TerminalTransNo,0x00,4);
	memcpy(st_TopupRequestReader.TerminalTransNo,&uiTreminalTranNo,2);


//	st_TopupRequestReader.CardOnlineNo[0] = u8InitPurseBuff[5];
//	st_TopupRequestReader.CardOnlineNo[1] = u8InitPurseBuff[4];
//	st_TopupRequestReader.CardOnlineNo[2] = 0;
//	st_TopupRequestReader.CardOnlineNo[3] = 0;
//	st_TopupRequestReader.TerminalTransNo[0]=0x99;//此值需要后期添加
//	st_TopupRequestReader.TerminalTransNo[1]=0x00;
//	st_TopupRequestReader.TerminalTransNo[2]=0x00;
//	st_TopupRequestReader.TerminalTransNo[3]=0x00;
//
//	memset(st_TopupRequestReader.CardOutlineNo,0x00,4);
//	st_TopupRequestReader.CardOutlineNo[0] = u8InitPurseBuff[17];
//	st_TopupRequestReader.CardOutlineNo[1] = u8InitPurseBuff[16];

	st_TopupRequestReader.BusinessType[0] = 1+'0';
	st_TopupRequestReader.BusinessType[1] = 4+'0';
	st_TopupRequestReader.ValueType[0] = TopupType+'0';

	st_TopupRequestReader.TopupMoney[0] = (TopupValue%0x100);
	st_TopupRequestReader.TopupMoney[1] = ((TopupValue/0x100)%0x100);
	st_TopupRequestReader.TopupMoney[2] = ((TopupValue/0x10000)%0x100);
	st_TopupRequestReader.TopupMoney[3] = (TopupValue/0x1000000);

	st_TopupRequestReader.CardRemainMoney[0] = m_stAccCpuCardInfo.Info_0002[3];
	st_TopupRequestReader.CardRemainMoney[1] = m_stAccCpuCardInfo.Info_0002[2];
	st_TopupRequestReader.CardRemainMoney[2] = m_stAccCpuCardInfo.Info_0002[1];
	st_TopupRequestReader.CardRemainMoney[3] = m_stAccCpuCardInfo.Info_0002[0];

	memset(charBuff,0x00,sizeof(charBuff));
	BcdToString(&u8InitPurseBuff[8],4,charBuff);
	memcpy(st_TopupRequestReader.Random,charBuff,8);
	PrintBuffer(charBuff,8);
	memset(charBuff,0x00,sizeof(charBuff));
	BcdToString(&u8InitPurseBuff[12],4,charBuff);
	memcpy(st_TopupRequestReader.MAC1,charBuff,8);
	PrintBuffer(charBuff,8);


	memcpy(st_TopupRequestReader.LasttimeTerinalNo,st_TopupRequestReader.SamLogicID,16);//此值需要后期添加
	memcpy(st_TopupRequestReader.LasttimeTerinalTime,st_TopupRequestReader.MessageTime,7);//此值需要后期添加
	memcpy(st_TopupRequestReader.OperatorNo,g_BRContext.CurrentUserID,6);


	*pLen1=sizeof(st_TopupRequestReader);
	memcpy(pMsg1,&st_TopupRequestReader,sizeof(st_TopupRequestReader));
	*pLen2=0;

	return iRet;
}



int Bom_AccCPU_TopupOperate(StruAPIParam APIParam,TopupRequestServer st_TopupRequestServer,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;
	PURSETRADE stPurseTrade;
	ST_CARD_ACC_CPU  stAccCpuCardInfo;
	int i=0;
	uint8 MAC2[8];
	uint8 u8TAC[4];
	memset(MAC2,0x00,sizeof(MAC2));
	memset(u8TAC,0x00,sizeof(u8TAC));
	memset(&stPurseTrade,0x00,sizeof(stPurseTrade));
    memset(&stAccCpuCardInfo,0,sizeof(stAccCpuCardInfo));
	for(i=0;i<4;i++)
	{
		if(st_TopupRequestServer.MAC2[2*i]>='0'&&st_TopupRequestServer.MAC2[2*i]<='9')
		{
			if(st_TopupRequestServer.MAC2[2*i+1]>='0'&&st_TopupRequestServer.MAC2[2*i+1]<='9')
			{
				MAC2[i] = (st_TopupRequestServer.MAC2[2*i]-'0')*0x10+st_TopupRequestServer.MAC2[2*i+1]-'0';
			}
			else
			{
				MAC2[i] = (st_TopupRequestServer.MAC2[2*i]-'0')*0x10+st_TopupRequestServer.MAC2[2*i+1]-'A'+10;
			}
		}
		else
		{
			if(st_TopupRequestServer.MAC2[2*i+1]>='0'&&st_TopupRequestServer.MAC2[2*i+1]<='9')
			{
				MAC2[i] = (st_TopupRequestServer.MAC2[2*i]-'A'+10)*0x10+st_TopupRequestServer.MAC2[2*i+1]-'0';
			}
			else
			{
				MAC2[i] = (st_TopupRequestServer.MAC2[2*i]-'A'+10)*0x10+st_TopupRequestServer.MAC2[2*i+1]-'A'+10;
			}
		}
	}

	iRet = Popup_AccCpuCard(st_TopupRequestServer.SystemTime,MAC2,u8TAC);//输入时间和MAC2  输出TAC
	if(iRet!=CE_OK)
	{
		pRi->wErrCode=RW_ERR_SAM_RESPONSE;
	}

	//回读卡

	iRet=Inner_Read_AccCpuCard(APIParam,&stAccCpuCardInfo,TRUE);
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRi->wErrCode=RW_EC_UNKNOWN;
		pRi->bNoticeCode=RW_SUBEC_NEED_CONFIRM_TRANSACTION;
		return iRet;
	}

	//组UD
	Fill_Purse_AccCpuCard_UD(APIParam,stAccCpuCardInfo,&stPurseTrade);
	memcpy(stPurseTrade.dtDate,st_TopupRequestServer.SystemTime,7);

	// TAC交易分类
	stPurseTrade.cClassicType[0]='0';
	stPurseTrade.cClassicType[1]='2';
	//
	stPurseTrade.cPaymentType[0]='1';
	stPurseTrade.cPaymentType[1]='4';
	// 票卡充值计数
	unsigned short usTempChargeCount=0;
	memcpy(&usTempChargeCount,m_stAccCpuCardInfo.TopupTradeRecord_001A[0],2);
	stPurseTrade.lChargeCount=htons(usTempChargeCount);
	memcpy(&stPurseTrade.lSAMTrSeqNo,st_TopupRequestServer.TerminalTransNo,4);

	stPurseTrade.bStatus=RW_LIFECODE_REVALUATE;
	stPurseTrade.lTradeAmount=(htonl(stAccCpuCardInfo.Purse_EP_0002)-htonl(m_stAccCpuCardInfo.Purse_EP_0002));
	stPurseTrade.lBalance=htonl(stAccCpuCardInfo.Purse_EP_0002);
	sprintf(stPurseTrade.cMACorTAC,"%02X%02X%02X%02X",u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);
	*pLen1=sizeof(stPurseTrade);
	memcpy(pMsg1,&stPurseTrade,sizeof(stPurseTrade));


	return iRet;
}




int Bom_ACCCPU_ChargeBackInit(StruAPIParam APIParam,uint8 Type,uint32 Value,uint32 remainningValue,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;
	int i=0;
	char charBuff[20]={0};
	//char temp[32]={0};

	char NetPoint[17]={0};
	memset(NetPoint,'0',16);
	//int ChargeUpper=0;
	int lastValue=0;


	ST_CARD_ACC_CPU  stAccCpuCardInfo;
	memset(&stAccCpuCardInfo,0,sizeof(stAccCpuCardInfo));

	ST_ACC_CPU_CARD_ADF_HISTORY stHistory;
	memset(&stHistory,0,sizeof(stHistory));
	memcpy(&stHistory,m_stAccCpuCardInfo.TopupTradeRecord_001A[0],23);
	lastValue=htonl(stHistory.TranValue);
	PrintLog("File[%s]Line[%d]Bom_ACCCPU_ChargeBackInit (Value[%d]  last topup value[%d]",__FILE__,__LINE__,Value,lastValue);
	if(Value!=lastValue)
	{
		pRi->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	uint8 u8InitPurseBuff[18];//Cpu卡圈存初始化返回数据（4旧金额+2联机交易序号+1秘钥版本+1算法标识+4伪随机数+4MAC1）+2脱机交易序号
	TopupRepealReader st_TopupRequestReader;
	memset(&st_TopupRequestReader,0x30,sizeof(st_TopupRequestReader));
	memset(u8InitPurseBuff,0x00,sizeof(u8InitPurseBuff));

	/*char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	TerminalTransNo[4];		//终端交易序列号
	char	WebsiteCode[16];		//网点编码
	char	SendcardMaincode[4];	//发行者主编码
	char	SendcardSecondcode[4];	//发行者子编码
	char	CardCode[2];			//票卡类型(主类型代码＋子类型代码)
	char	CardLogicNo[20];		//票卡逻辑卡号(不足20位时左对齐，右补空格，缺省值：全0)
	char	CardPhysicsNo[20];		//票卡物理卡号(不足20位时左对齐，右补空格。默认值：全为0)
	char	TsetFlag[1];			//是否测试卡(0：正式票卡  1：测试票卡)
	char	CardOnlineNo[4];		//票卡联机交易计数
	char	CardOutlineNo[4];		//票卡脱机交易计数
	char	BusinessType[2];		//业务类型(固定填写‘18’)
	char	ValueType[1];			//值类型(0：无值类型；1：金额；2：次数；3：天数；)
	char	RepealMoney[4];			//撤销金额(为金额时单位为”分”)
	char	CardRemainMoney[4];		//票卡余额(为金额时单位为”分”)
	char	LasttimeTerinalNo[16];	//上次交易终端编号(如果上次无交易，为当前交易终端终端编号。)
	char	LasttimeTerinalTime[7];	//上次交易时间(如果上次无交易，为终端当前时间)
	char	OperatorNo[6];			//操作员编码(默认值：全为0)*/

	st_TopupRequestReader.MessageType[0] = '5';
	st_TopupRequestReader.MessageType[1] = '3';

	memcpy(st_TopupRequestReader.MessageTime,APIParam.ucTimeStamp,7);

	st_TopupRequestReader.TerminalID[0]=g_BRContext.bCurrentStationID[0]/10+'0';
	st_TopupRequestReader.TerminalID[1]=g_BRContext.bCurrentStationID[0]%10+'0';
	st_TopupRequestReader.TerminalID[2]=g_BRContext.bCurrentStationID[1]/10+'0';
	st_TopupRequestReader.TerminalID[3]=g_BRContext.bCurrentStationID[1]%10+'0';
	st_TopupRequestReader.TerminalID[4]=g_BRContext.bCurrentDeviceTypeCode/10+'0';
	st_TopupRequestReader.TerminalID[5]=g_BRContext.bCurrentDeviceTypeCode%10+'0';
	st_TopupRequestReader.TerminalID[6]=g_BRContext.bCurrentDeviceID[0]%10+'0';
	st_TopupRequestReader.TerminalID[7]=g_BRContext.bCurrentDeviceID[1]/10+'0';
	st_TopupRequestReader.TerminalID[8]=g_BRContext.bCurrentDeviceID[1]%10+'0';

	memcpy(st_TopupRequestReader.SamLogicID,g_BRContext.stSamInfo[0].cSAMID,16);
	memcpy(st_TopupRequestReader.WebsiteCode,NetPoint,16);

	st_TopupRequestReader.SendcardMaincode[0]=(m_stAccCpuCardInfo.Info_0005[0]/0x10)+'0';
	st_TopupRequestReader.SendcardMaincode[1]=(m_stAccCpuCardInfo.Info_0005[0]%0x10)+'0';
	st_TopupRequestReader.SendcardMaincode[2]=(m_stAccCpuCardInfo.Info_0005[1]/0x10)+'0';
	st_TopupRequestReader.SendcardMaincode[3]=(m_stAccCpuCardInfo.Info_0005[1]%0x10)+'0';

	st_TopupRequestReader.CardCode[0]=m_stAccCpuCardInfo.Info_0005[16];
	st_TopupRequestReader.CardCode[1]=m_stAccCpuCardInfo.Info_0005[17];

	for(i=0;i<8;i++)
	{
		st_TopupRequestReader.CardLogicNo[4+2*i]=(m_stAccCpuCardInfo.Info_0005[8+i]/0x10)+'0';
		st_TopupRequestReader.CardLogicNo[4+2*i+1]=(m_stAccCpuCardInfo.Info_0005[8+i]%0x10)+'0';
	}

	memset(charBuff,0x00,sizeof(charBuff));
	BcdToString(g_BRContext.szCardPhID,4,charBuff);
	memcpy(st_TopupRequestReader.CardPhysicsNo,charBuff,8);
	memset(&st_TopupRequestReader.CardPhysicsNo[14],' ',6);

	for(i=0;i<4;i++)
	{
		st_TopupRequestReader.CardLogicNo[4+2*i]=(m_stAccCpuCardInfo.Info_0005[8+i]/0x10)+'0';
		st_TopupRequestReader.CardLogicNo[4+2*i+1]=(m_stAccCpuCardInfo.Info_0005[8+i]%0x10)+'0';
	}

	st_TopupRequestReader.TsetFlag[0]=m_stAccCpuCardInfo.Info_0005[6]+'0';

	// 消费计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,m_stAccCpuCardInfo.LocalTradeRecord_0018[0],2);
	usTempTradeCount=htons(usTempTradeCount);
	PrintLog("File[%s]Line[%d] Bom_ACCCPU_ChargeBackInit  lTradeCount= [0x%02X]",__FILE__,__LINE__,usTempTradeCount);

	// 充值计数
	unsigned short usTempChargeCount=0;
	memcpy(&usTempChargeCount,m_stAccCpuCardInfo.TopupTradeRecord_001A[0],2);
	usTempChargeCount=htons(usTempChargeCount);
	PrintLog("File[%s]Line[%d] Bom_ACCCPU_ChargeBackInit  lChargeCount= [0x%02X]",__FILE__,__LINE__,usTempChargeCount);

	unsigned short uiTreminalTranNo=usTempChargeCount;
	PrintLog("File[%s]Line[%d] Bom_ACCCPU_ChargeBackInit  uiTreminalTranNo= [0x%02X]",__FILE__,__LINE__,uiTreminalTranNo);

	memset(st_TopupRequestReader.CardOnlineNo,0x00,4);
	memcpy(st_TopupRequestReader.CardOnlineNo,&usTempChargeCount,2);

	memset(st_TopupRequestReader.CardOutlineNo,0x00,4);
	memcpy(st_TopupRequestReader.CardOutlineNo,&usTempTradeCount,2);

	memset(st_TopupRequestReader.TerminalTransNo,0x00,4);
	memcpy(st_TopupRequestReader.TerminalTransNo,&uiTreminalTranNo,2);


	//st_TopupRequestReader.CardOnlineNo[0] = m_stAccCpuCardInfo.TopupTradeRecord_001A[0][1];
	//st_TopupRequestReader.CardOnlineNo[1] = m_stAccCpuCardInfo.TopupTradeRecord_001A[0][0];
	//st_TopupRequestReader.CardOnlineNo[2] = 0;
	//st_TopupRequestReader.CardOnlineNo[3] = 0;
	//st_TopupRequestReader.TerminalTransNo[0]=0x99;//此值需要后期添加
	//st_TopupRequestReader.TerminalTransNo[1]=0x00;
	//st_TopupRequestReader.TerminalTransNo[2]=0x00;
	//st_TopupRequestReader.TerminalTransNo[3]=0x00;

	//memset(st_TopupRequestReader.CardOutlineNo,0x00,4);
	//st_TopupRequestReader.CardOutlineNo[0] = m_stAccCpuCardInfo.LocalTradeRecord_0018[0][1];
	//st_TopupRequestReader.CardOutlineNo[1] =m_stAccCpuCardInfo.LocalTradeRecord_0018[0][0];

	st_TopupRequestReader.BusinessType[0] = 1+'0';
	st_TopupRequestReader.BusinessType[1] = 8+'0';
	st_TopupRequestReader.ValueType[0] = Type+'0';

	st_TopupRequestReader.RepealMoney[0] = (Value%0x100);
	st_TopupRequestReader.RepealMoney[1] = ((Value/0x100)%0x100);
	st_TopupRequestReader.RepealMoney[2] = ((Value/0x10000)%0x100);
	st_TopupRequestReader.RepealMoney[3] = (Value/0x1000000);

	st_TopupRequestReader.CardRemainMoney[0] = m_stAccCpuCardInfo.Info_0002[3];
	st_TopupRequestReader.CardRemainMoney[1] = m_stAccCpuCardInfo.Info_0002[2];
	st_TopupRequestReader.CardRemainMoney[2] = m_stAccCpuCardInfo.Info_0002[1];
	st_TopupRequestReader.CardRemainMoney[3] = m_stAccCpuCardInfo.Info_0002[0];


	//memcpy(st_TopupRequestReader.LasttimeTerinalNo,st_TopupRequestReader.SamLogicID,16);//此值需要后期添加
	//memcpy(st_TopupRequestReader.LasttimeTerinalTime,st_TopupRequestReader.MessageTime,7);//此值需要后期添加
	memcpy(st_TopupRequestReader.LasttimeTerinalNo,st_TopupRequestReader.SamLogicID,16);//此值需要后期添加
	memcpy(st_TopupRequestReader.LasttimeTerinalTime,stHistory.TranTime,7);//此值需要后期添加
	memcpy(st_TopupRequestReader.OperatorNo,g_BRContext.CurrentUserID,6);


	*pLen1=sizeof(st_TopupRequestReader);
	memcpy(pMsg1,&st_TopupRequestReader,sizeof(st_TopupRequestReader));
	*pLen2=0;

	return iRet;
}

int Bom_ACCCPU_ChargeBackOperate(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;
	PURSETRADE stPurseTrade;
	memset(&stPurseTrade,0,sizeof(stPurseTrade));
	unsigned int uiLastValue=0;

	uint8  u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;

	ST_CARD_ACC_CPU stAccCpuCardInfo;
	memset(&stAccCpuCardInfo,0,sizeof(ST_CARD_ACC_CPU));

	ST_ACC_CPU_CARD_ADF_HISTORY stHistory;
	memset(&stHistory,0,sizeof(stHistory));
	memcpy(&stHistory,m_stAccCpuCardInfo.TopupTradeRecord_001A[0],23);

	uiLastValue=htonl(stHistory.TranValue);
	//写卡准备
	PrintLog("File[%s]Line[%d]Bom_ACCCPU_ChargeBackOperate (last topup value[%d]",__FILE__,__LINE__,uiLastValue);

	iRet=Inner_Write6_AccCpuCard(APIParam,uiLastValue,m_stAccCpuCardInfo,u8TAC,&u32TerminalTradeNum);
	PrintLog("File[%s]Line[%d] Bom_ACCCPU_ChargeBackOperate  Inner_Write_AccCpuCard  iRet= [%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRi->wErrCode=iRet;
	}

	//回读卡

	iRet=Inner_Read_AccCpuCard(APIParam,&stAccCpuCardInfo,TRUE);
	PrintLog("File[%s]Line[%d]Inner_Read_AccCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRi->wErrCode=RW_EC_UNKNOWN;
		pRi->bNoticeCode=RW_SUBEC_NEED_CONFIRM_TRANSACTION;
		return iRet;
	}

	//组UD
	Fill_Purse_AccCpuCard_UD(APIParam,m_stAccCpuCardInfo,&stPurseTrade);
	stPurseTrade.cPaymentType[0]='1';
	stPurseTrade.cPaymentType[1]='8';

	// TAC交易分类
	stPurseTrade.cClassicType[0]='0';
	stPurseTrade.cClassicType[1]='6';

	// 票卡充值计数
	unsigned short usTempChargeCount=0;
	memcpy(&usTempChargeCount,stAccCpuCardInfo.TopupTradeRecord_001A[0],2);
	stPurseTrade.lSAMTrSeqNo=u32TerminalTradeNum;

	stPurseTrade.bStatus=RW_LIFECODE_COMMON_CONSUMPTION;
	stPurseTrade.lTradeAmount=(htonl(m_stAccCpuCardInfo.Purse_EP_0002)-htonl(stAccCpuCardInfo.Purse_EP_0002));
	stPurseTrade.lBalance=htonl(stAccCpuCardInfo.Purse_EP_0002);
	sprintf(stPurseTrade.cMACorTAC,"%02X%02X%02X%02X",u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);
	*pLen1=sizeof(stPurseTrade);
	memcpy(pMsg1,&stPurseTrade,sizeof(stPurseTrade));



	return iRet;
}


int ConvertAccCPUCardStatus(unsigned char ucTicketStatus)
{
	/*EM_TICKET_TRAVEL_STATUS_INITIALIZATION			=1,	//e/s 初始化(init 0)
	EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES		=2,	//e/s 预赋值(init 1)
	EM_TICKET_TRAVEL_STATUS_ISSUED					=3,	// SJT发售(init 2)
	EM_TICKET_TRAVEL_STATUS_ENTRY					=4,	//已进站
	EM_TICKET_TRAVEL_STATUS_EXITED					=5,	//已出站
	EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE				=6,	//出站票
	EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE		=7,	//列车故障模式出站(exit during Train-disruption)
	EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA	=8,	//非付费区免费更新(BOM/pca 非付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA	=9,	//非付费区付费更新(BOM/pca 非付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION	=10,//无进站码更新(BOM/pca 付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT				=11,//出站码更新
	EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT			=12,//超时更新
	EM_TICKET_TRAVEL_STATUS_RANGEOUT				=13,//超乖更新
	EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT		=14,//免费出闸更新
	EM_TICKET_TRAVEL_STATUS_REFUND					=15,//已退卡*/
	unsigned char ucStatus=RW_STATUSCODE_UNKNOWN;
    switch(ucTicketStatus)
    {
        case EM_TICKET_TRAVEL_STATUS_INITIALIZATION:
        	ucStatus=RW_STATUSCODE_INITIALIZATION;
    	 break;
        case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES:
               	ucStatus=RW_STATUSCODE_PREVALUE_LOADED_ES;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_ISSUED:
               	ucStatus=RW_STATUSCODE_SALE_BOM_OR_TVM;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_ENTRY:
               	ucStatus=RW_STATUSCODE_ENTRY_STATION;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_EXITED:
               	ucStatus=RW_STATUSCODE_EXIT_STAION;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:
               	ucStatus=RW_STATUSCODE_ET_FOR_EXIT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:
               	ucStatus=RW_STATUSCODE_EXIT_TRAINFAULT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA:
               	ucStatus=RW_STATUSCODE_UPDATE_FREE_UNPAYAREA;
           	 break;

        case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA:
               	ucStatus=RW_STATUSCODE_UPDATE_PAYED_UNPAYAREA;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:
               	ucStatus=RW_STATUSCODE_UPDATE_NO_ENTRY_STATION;
           	 break;

        case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:
               	ucStatus=RW_STATUSCODE_UPDATE_EXIT_ATBOM;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:
               	ucStatus=RW_STATUSCODE_UPDATE_TIMEOUT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_RANGEOUT:
               	ucStatus=RW_STATUSCODE_UPDATE_RANGEOUT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:
               	ucStatus=RW_STATUSCODE_UPDATE_ENTRY_ATBOM;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_REFUND:
               	ucStatus=RW_STATUSCODE_REBACK_CARD;
           	 break;
    }

    return ucStatus;
}
