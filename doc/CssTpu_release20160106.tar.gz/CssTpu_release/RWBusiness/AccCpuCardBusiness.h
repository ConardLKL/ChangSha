#ifndef __ACCCPUCARDBUSINESS_H__
#define __ACCCPUCARDBUSINESS_H__

#include "../Globle.h"
#include "../TicketEntity/AccCpuCardEntity.h"
#include "../XPublic/XTime.h"
#include "../XPublic/Log.h"
#include "../RWParam/RWParameter.h"
#include "DegradeModeBusinuess.h"

//  验证卡发行有效性
// int Verify_Issue_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);

//验证卡是否在黑名单参数中。0 : not blacklist ,1 : blacklist
 BOOL Verify_Blacklist_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);

//验证卡是否已锁。
 BOOL Verify_IsLocked_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);

//验证是否允许该设备发售。
 BOOL Verify_Issue_Device_AccCpuCard(EM_DEVICE_TYPE emCurrentDeivceType);

//内部用读卡
 int Inner_Read_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  *stAccCpuCardInfo,BOOL bReadHistory);

//内部写卡复合消费
 int Inner_Write_AccCpuCard(StruAPIParam APIParam,uint32 u32ConsumeMoney,ST_CARD_ACC_CPU cardProcessInfo,uint8 *TAC,uint32 *u8TerminalTradeNum);

 //内部写卡普通消费
 int Inner_Write6_AccCpuCard(StruAPIParam APIParam,uint32 u32ConsumeMoney,ST_CARD_ACC_CPU cardProcessInfo,uint8 *TAC,uint32 *u8TerminalTradeNum);

 int Inner_Lock_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETLOCK * stLockInfo);

 //UD处理
 void Fill_Sale_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,OTHERSALE * pUD);

  void Fill_Entry_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,ENTRYGATE * pUD);

  void Fill_Purse_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,PURSETRADE * pUD);

 void Fill_Lock_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,TICKETLOCK * pUD);

 void Fill_Refund_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,DIRECTREFUND * pUD);

 void Fill_Update_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,TICKETUPDATE  * pUD);

 void Fill_Deffer_AccCpuCard_UD(StruAPIParam APIParam,ST_CARD_ACC_CPU stAccCpuCardInfo,TICKETDEFER  * pUD);

  //付费区分析。
 BOOL PaidArea_Analysis_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  stAccCpuCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis);

 //非付费区分析。
 BOOL UnpaidArea_Analysis_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  stAccCpuCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis);

 //检查车票状态是否正确
 BOOL Check_Ticket_Status_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);

 //检查余额是否超出上限。
 BOOL Check_Ticket_Value_Uplimit_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);

 //检查车票是否过期。
 BOOL Check_Ticket_Valid_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  stAccCpuCardInfo);

//检查是否本站进站。
BOOL Check_EntryThisStation_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);

//检查进站超时。
BOOL Check_Entry_Timeout_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);

//进站次序检查。
BOOL Check_Entry_Status_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);

//余额低于最小票价。
BOOL Check_MinValue_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  stAccCpuCardInfo);

//出站次序检查。
BOOL Check_Exit_Status_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);

//非本站更新
BOOL Check_Update_ThisStation_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);

//非本日更新
BOOL Check_Update_ThisDay_AccCpuCard(StruAPIParam APIParam,ST_CARD_ACC_CPU  stAccCpuCardInfo);

//出站超时
BOOL Check_Exit_Timeout_AccCpuCard(StruAPIParam APIParam,uint16 u16JourneyTimeLimit,ST_CARD_ACC_CPU  stAccCpuCardInfo);

//出站超程
BOOL Check_Exit_RemainningValue_AccCpuCard(uint32 *u32Price,ST_CARD_ACC_CPU  stAccCpuCardInfo);

//Limited station code
BOOL Check_Limited_Entry_STATION_CODE_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);

BOOL Check_Limited_Exit_STATION_CODE_AccCpuCard(ST_CARD_ACC_CPU  stAccCpuCardInfo);


int  Check_Aisel_Type(ST_CARD_ACC_CPU  stAccCpuCardInfo);

//
int Analysis_AccCpuCard(StruAPIParam APIParam,uint8 u8IsDegradeMode,uint8 u8WorkArea,RetInfo * pRetInfo,BOMANALYZE * stAnalysis,TICKETLOCK * stTicketLock);

int Sale_AccCpuCard(StruAPIParam APIParam,uint16 u16TranValue,uint8 u8PaymentType,uint8 u8MoneyType,RetInfo * pRetInfo, OTHERSALE * pUD);

int Recharge_AccCpuCard(StruAPIParam APIParam,uint8 u8RechargeType,uint32 u32RechargeValue,RetInfo * pRetInfo,PURSETRADE *stPurseInfo);

int Decrease_AccCpuCard(StruAPIParam APIParam,uint32 u32DecreaseValue,RetInfo * pRetInfo,PURSETRADE *stPurseInfo);

int Query_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETINFO * stTicketInfo);

int Update_AccCpuCard(StruAPIParam APIParam,uint8 u8UpdateCode,uint16 u16EntryStationCode,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRetInfo,TICKETUPDATE * stUpdateInfo);

int Refund_AccCpuCard(StruAPIParam APIParam,uint8 u8RefundOption,uint8 u8RefundCode,uint16 u16TranValue,RetInfo * pRetInfo,DIRECTREFUND * stRefundInfo);

int Defer_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETDEFER * stDeferInfo);

int Unlock_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETLOCK * stLockInfo);

int Entry_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,ENTRYGATE *stEntryInfo,TICKETLOCK * stLockInfo);

int Exit_AccCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,PURSETRADE *stPurseInfo,TICKETLOCK * stLockInfo);

int Bom_AccCPU_TopupOperate(StruAPIParam APIParam,TopupRequestServer st_TopupRequestServer,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_AccCPU_TopupInit(StruAPIParam APIParam,uint8 TopupType,uint32 TopupValue,uint8 *NetPoint,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_ACCCPU_ChargeBackInit(StruAPIParam APIParam,uint8 Type,uint32 Value,uint32 remainningValue,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_ACCCPU_ChargeBackOperate(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);


int ConvertAccCPUCardStatus(unsigned char ucTicketStatus);

#endif
