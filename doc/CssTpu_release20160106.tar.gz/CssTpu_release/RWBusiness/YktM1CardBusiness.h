#ifndef __YKTM1CARDBUSINESS_H__
#define __YKTM1CARDBUSINESS_H__


#include "../Globle.h"
#include "../TicketEntity/YktM1CardEntity.h"
#include "../XPublic/XTime.h"
#include "../XPublic/Log.h"
#include "../RWParam/RWParameter.h"
#include "DegradeModeBusinuess.h"

//  验证卡发行有效性
// int Verify_Issue_YktM1Card(ST_CARD_YKT_M1  stYktM1CardInfo);

//验证卡是否在黑名单参数中。0 : not blacklist ,1 : blacklist
 BOOL Verify_Blacklist_YktM1Card(ST_CARD_YKT_M1  stYktM1CardInfo);

//验证卡是否已锁。
 BOOL Verify_IsLocked_YktM1Card(ST_CARD_YKT_M1  stYktM1CardInfo);

//验证是否允许该设备发售。
 BOOL Verify_Issue_Device_YktM1Card(EM_DEVICE_TYPE emCurrentDeivceType);

//内部用读卡
 int Inner_Read_YktM1Card(StruAPIParam APIParam,ST_CARD_YKT_M1  *stYktM1CardInfo,BOOL bReadHistory);

//内部写卡复合消费
 int Inner_Write_YktM1Card(StruAPIParam APIParam,uint32 u32ConsumeMoney,ST_CARD_YKT_M1 cardProcessInfo,uint32 *u8TerminalTradeNum);

 //内部写卡普通消费
 int Inner_Write6_YktM1Card(StruAPIParam APIParam,uint32 u32ConsumeMoney,ST_CARD_YKT_M1 cardProcessInfo,uint32 *u8TerminalTradeNum);



 int Inner_Lock_YktM1Card(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETLOCK * stLockInfo);

 //UD处理
 void Fill_Sale_YktM1Card_UD(StruAPIParam APIParam,ST_CARD_YKT_M1 stYktM1CardInfo,SJTSALE * pUD);

  void Fill_Entry_YktM1Card_UD(StruAPIParam APIParam,ST_CARD_YKT_M1 stYktM1CardInfo,ENTRYGATE * pUD);

  void Fill_Purse_YktM1Card_UD(StruAPIParam APIParam,ST_CARD_YKT_M1 stYktM1CardInfo,PURSETRADE * pUD);

 void Fill_Lock_YktM1Card_UD(StruAPIParam APIParam,ST_CARD_YKT_M1 stYktM1CardInfo,TICKETLOCK * pUD);


 void Fill_Update_YktM1Card_UD(StruAPIParam APIParam,ST_CARD_YKT_M1 stYktM1CardInfo,TICKETUPDATE  * pUD);

  //付费区分析。
 BOOL PaidArea_Analysis_YktM1Card(StruAPIParam APIParam,ST_CARD_YKT_M1  stYktM1CardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis);

 //非付费区分析。
 BOOL UnpaidArea_Analysis_YktM1Card(StruAPIParam APIParam,ST_CARD_YKT_M1  stYktM1CardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis);

 //检查车票状态是否正确
 BOOL Check_Ticket_Status_YktM1Card(ST_CARD_YKT_M1  stYktM1CardInfo);

 //检查余额是否超出上限。
 BOOL Check_Ticket_Value_Uplimit_YktM1Card(ST_CARD_YKT_M1  stYktM1CardInfo);

 //检查车票是否过期。
 BOOL Check_Ticket_Valid_YktM1Card(StruAPIParam APIParam,ST_CARD_YKT_M1  *stYktM1CardInfo);

//检查是否本站进站。
BOOL Check_EntryThisStation_YktM1Card(ST_CARD_YKT_M1  stYktM1CardInfo);

//检查进站超时。
BOOL Check_Entry_Timeout_YktM1Card(ST_CARD_YKT_M1  stYktM1CardInfo);

//进站次序检查。
BOOL Check_Entry_Status_YktM1Card(ST_CARD_YKT_M1  stYktM1CardInfo);

//余额低于最小票价。
BOOL Check_MinValue_YktM1Card(StruAPIParam APIParam,ST_CARD_YKT_M1  stYktM1CardInfo);

//出站次序检查。
BOOL Check_Exit_Status_YktM1Card(ST_CARD_YKT_M1  stYktM1CardInfo);

//非本站更新
BOOL Check_Update_ThisStation_YktM1Card(ST_CARD_YKT_M1  stYktM1CardInfo);

//非本日更新
BOOL Check_Update_ThisDay_YktM1Card(StruAPIParam APIParam,ST_CARD_YKT_M1  stYktM1CardInfo);

//出站超时
BOOL Check_Exit_Timeout_YktM1Card(StruAPIParam APIParam,uint16 u16JourneyTimeLimit,ST_CARD_YKT_M1  stYktM1CardInfo);

//出站超程
BOOL Check_Exit_RemainningValue_YktM1Card(uint32 *u32Price,ST_CARD_YKT_M1  stYktM1CardInfo);

//
int Analysis_YktM1Card(StruAPIParam APIParam,uint8 u8IsDegradeMode,uint8 u8WorkArea,RetInfo * pRetInfo,BOMANALYZE * stAnalysis,TICKETLOCK * stTicketLock);


int Decrease_YktM1Card(StruAPIParam APIParam,uint32 u32DecreaseValue,RetInfo * pRetInfo,PURSETRADE *stPurseInfo);

int Query_YktM1Card(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETINFO * stTicketInfo);

int Update_YktM1Card(StruAPIParam APIParam,uint8 u8UpdateCode,uint16 u16EntryStationCode,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRetInfo,TICKETUPDATE * stUpdateInfo);

int Entry_YktM1Card(StruAPIParam APIParam,RetInfo * pRetInfo,ENTRYGATE *stEntryInfo,TICKETLOCK * stLockInfo);

int Exit_YktM1Card(StruAPIParam APIParam,RetInfo * pRetInfo,PURSETRADE *stPurseInfo,TICKETLOCK * stLockInfo);

int Unlock_YktM1Card(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETLOCK * stLockInfo);


int ConvertYktM1CardStatus(unsigned char ucTicketStatus);



#endif

