#include "YktCpuCardBusiness.h"

/*内部变量申明；*/
static ST_CARD_YKT_CPU m_stYktCpuCardInfo;

static ST_BOM_OperationStauts m_stOperationStauts;
////  验证卡发行有效性
// int Verify_Issue_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo)
// {
//	//根据卡信息 判断卡的有效性。
//
//	// 有效性不通过，返回 无效卡。
//
//	return CE_OK;
// }

//验证卡是否在黑名单参数中。0 : not blacklist ,1 : blacklist
 BOOL Verify_Blacklist_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo)
 {
	 //todo :
	int iRet=-1;
	char  LogicID[32]={0};
	uint8  BlackListControl=0;
	char  CheckBlackList=0;
	CheckBlackList=g_BRContext.TicktPara0301.CheckBlackList[0];
	char temp[32]={0};

	PrintLog("File[%s]Line[%d]Verify_Blacklist_YktCpuCard TicktPara0301.CheckBlackList[%02X]",__FILE__,__LINE__,CheckBlackList);
	if(CheckBlackList=='0')
	{
		return FALSE;//不检查黑名单，返回 0 ：not blacklist
	}

	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stYktCpuCardInfo.EF05.AppSn[0],
			stYktCpuCardInfo.EF05.AppSn[1],
			stYktCpuCardInfo.EF05.AppSn[2],
			stYktCpuCardInfo.EF05.AppSn[3],
			stYktCpuCardInfo.EF05.AppSn[4],
			stYktCpuCardInfo.EF05.AppSn[5],
			stYktCpuCardInfo.EF05.AppSn[6],
			stYktCpuCardInfo.EF05.AppSn[7]);
	strncpy(LogicID,temp,20);
	PrintLog("File[%s]Line[%d] Verify_Blacklist_YktCpuCard  cLogicalID[%s]",__FILE__,__LINE__,LogicID);

	//根据卡逻辑编号，查询黑名单参数。
	iRet=BR_CheckBlacklistCardYKT_h((uint8 *)LogicID,&BlackListControl);
	PrintLog("File[%s]Line[%d]Verify_Blacklist_YktCpuCard BR_CheckBlacklistCardACC_h iRet[%d]",__FILE__,__LINE__,iRet);
	if(iRet!=0)
	{
		return FALSE;
	}

	return TRUE;
 }

//验证卡是否已锁。
 BOOL Verify_IsLocked_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo)
 {
	BOOL bRet=FALSE;
	bRet=(stYktCpuCardInfo.sz3F00_1A[0]==0x53&&stYktCpuCardInfo.sz3F00_1A[1]==0x4B);
	PrintLog("File[%s]Line[%d]stYktCpuCardInfo.sz3F00_1A[%02X%02X]",__FILE__,__LINE__,stYktCpuCardInfo.sz3F00_1A[0],stYktCpuCardInfo.sz3F00_1A[1]);
	return bRet;
 }

//验证是否允许该设备发售。
 BOOL Verify_Issue_Device_YktCpuCard(EM_DEVICE_TYPE emCurrentDeivceType)
 {
	 	/*1、	设备字符信息代码定义：
字符	描述
字符1	TVM
字符2	BOM
字符3	进站闸机
字符4	出站闸机
字符5	双向闸机
字符6	TCM
字符7	PCA
字符8	ES
字符9~16	预留
如参数使用设备为TVM、BOM、进站闸机、出站闸机、双向闸机、TCM、PCA、ES则取值“1111111100000000”
*/
	BOOL bRet=FALSE;
	switch(emCurrentDeivceType)
	{
		case EM_DEVICE_TYPE_TVM:
			  bRet= g_BRContext.TicktPara0301.SaleDevice[0];
		break;
		case EM_DEVICE_TYPE_BOM:
			 bRet= g_BRContext.TicktPara0301.SaleDevice[1];
		break;
		default:
			bRet=FALSE;
			break;

	}
	return bRet;
 }

int Inner_Read_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  *stYktCpuCardInfo,BOOL bReadHistory)
 {
	int iRet=-1;

	iRet=Read_YKTCpuCard_All_Info(APIParam.AntennaMode,stYktCpuCardInfo, bReadHistory);

	if(CE_OK!=iRet)
	{
		return RW_EC_READ_FAILED;
	}

	// 发卡基本信息文件0005

	PrintLog("File[%s]Line[%d]Inner_Read_YktCpuCard 发卡基本信息文件0005 Info_0005",__FILE__,__LINE__);
	PrintBuffer((const char *)&stYktCpuCardInfo->EF05,sizeof(YKT_CPU_EF_05));

	if(stYktCpuCardInfo->EF05.MainType==0x80&&stYktCpuCardInfo->EF05.SubType==0x01) //成人卡
	{
		stYktCpuCardInfo->EF05.MainType=0x06;
		stYktCpuCardInfo->EF05.SubType=0x00;

	}else if(stYktCpuCardInfo->EF05.MainType==0x80&&stYktCpuCardInfo->EF05.SubType==0xA4) //学生卡
	{
		stYktCpuCardInfo->EF05.MainType=0x06;
		stYktCpuCardInfo->EF05.SubType=0x01;

	}else if(stYktCpuCardInfo->EF05.MainType==0x80&&stYktCpuCardInfo->EF05.SubType==0xA5) //老人卡
	{
		stYktCpuCardInfo->EF05.MainType=0x06;
		stYktCpuCardInfo->EF05.SubType=0x02;
	}else
	{
		return RW_EC_OTHER_SYSTEM_CARD;
	}

	memcpy(&stYktCpuCardInfo->EF05_BAK,&stYktCpuCardInfo->EF05,sizeof(YKT_CPU_EF_05));
	// 公共应用基本数据文件0015
	//memcpy(&stYktCpuCardInfo->PublicInfo_0015,stYktCpuCardInfo->Info_0015,sizeof(ST_YKT_CPU_CARD_ADF_EF15));
	PrintLog("File[%s]Line[%d]Inner_Read_YktCpuCard 公共应用基本数据文件0015 Info_0015",__FILE__,__LINE__);
	PrintBuffer((const char *)&stYktCpuCardInfo->EF15,sizeof(YKT_CPU_EF_15));

	// 持卡人基本信息文件0016
	//memcpy(&stYktCpuCardInfo->EF16,stYktCpuCardInfo->Info_0016,sizeof(ST_YKT_CPU_CARD_ADF_EF16));
	PrintLog("File[%s]Line[%d]Inner_Read_YktCpuCard  持卡人基本信息文件0016 Info_0016",__FILE__,__LINE__);
	PrintBuffer((const char *)&stYktCpuCardInfo->EF16,sizeof(YKT_CPU_EF_16));

	//公共电子钱包0002
	//memcpy(&stYktCpuCardInfo->Purse,stYktCpuCardInfo->Info_0002,4);
	PrintLog("File[%s]Line[%d]Inner_Read_YktCpuCard 公共电子钱包0002 Info_0002",__FILE__,__LINE__);
	PrintBuffer((const char *)&stYktCpuCardInfo->Purse,4);



	//本地消费明细文件0018
	PrintLog("File[%s]Line[%d]Inner_Read_YktCpuCard  本地消费明细文件0018 Info_0018",__FILE__,__LINE__);
	PrintBuffer((const char *)stYktCpuCardInfo->LocalHistory,sizeof(stYktCpuCardInfo->LocalHistory));

	// 充值明细文件001A
	PrintLog("File[%s]Line[%d]Inner_Read_YktCpuCard   充值明细文件001A Info_001A",__FILE__,__LINE__);
	PrintBuffer((const char *)stYktCpuCardInfo->RechargeHistory,sizeof(stYktCpuCardInfo->RechargeHistory));


	// 复合交易记录文件0017 03 轨道交通
	PrintLog("File[%s]Line[%d]Inner_Read_YktCpuCard  复合交易记录文件0017 02 轨道交通 Info_0017",__FILE__,__LINE__);
	PrintBuffer((const char *)&stYktCpuCardInfo->EF_17_03,48);

	stYktCpuCardInfo->EF_17_03.CardStatus=stYktCpuCardInfo->EF_17_03.CardStatus0>>3;
	PrintLog("File[%s]Line[%d]Inner_Read_YktCpuCard  CardStatus [0x%02X]",__FILE__,__LINE__,stYktCpuCardInfo->EF_17_03.CardStatus);

	stYktCpuCardInfo->EF_17_03.CardSpecialFlag=stYktCpuCardInfo->EF_17_03.CardStatus0&0x07;
	PrintLog("File[%s]Line[%d]Inner_Read_YktCpuCard  CardSpecialFlag [0x%02X]",__FILE__,__LINE__,stYktCpuCardInfo->EF_17_03.CardSpecialFlag);

	//
	return CE_OK;
 }

int Inner_Write6_YktCpuCard(StruAPIParam APIParam,uint32 u32ConsumeMoney,ST_CARD_YKT_CPU cardProcessInfo,uint8 *TAC,uint32 *u8TerminalTradeNum)
{

	int TranSn=0;
	int iRet=-1;
	PrintLog("File[%s]Line[%d]Inner_Write6_YktCpuCard  u32ConsumeMoney[0x%02X]",__FILE__,__LINE__,u32ConsumeMoney);
	iRet=Write_YKTCpuCard_Recombine_Info(u32ConsumeMoney,APIParam.ucTimeStamp,&cardProcessInfo,0x00,TAC,&TranSn);
	PrintLog("File[%s]Line[%d]Write_YktCpuCard_Recombine_Info  iRet[0x%02X]",__FILE__,__LINE__,iRet);
	if(0!=iRet)
	{
		return RW_EC_WRITE_FAILED;
	}
	*u8TerminalTradeNum=htonl(TranSn);
	return CE_OK;
}

 int Inner_Write_YktCpuCard(StruAPIParam APIParam,uint32 u32ConsumeMoney,ST_CARD_YKT_CPU cardProcessInfo,uint8 *TAC,uint32 *u8TerminalTradeNum)
 {

	 int iRet=-1;
	 uint32 TranSn=0;
	 unsigned char DeviceID[2]={0};
	 unsigned short usDeviceID=0;
	 unsigned short usCrc16=0;
	 unsigned char ptr1[19]="CS-METRO-2013@GDMH";
	 unsigned char szTempData[128]={0};
	 BitstreamInitMasks();
	//处理时间
	memcpy(cardProcessInfo.EF_17_03.ProcessTime,APIParam.ucTimeStamp,7);
	//当前线路
	cardProcessInfo.EF_17_03.ProcessLine=g_BRContext.bCurrentLineID;
	//当前车站
	cardProcessInfo.EF_17_03.ProcessStation=g_BRContext.bCurrentStationID[1];
	//设备类型设备编码
	memcpy(&usDeviceID,g_BRContext.bCurrentDeviceID,2);
	usDeviceID=htons(usDeviceID);


	BitStreamPack(g_BRContext.bCurrentDeviceTypeCode,DeviceID,0, 4);

	BitStreamPack(usDeviceID,DeviceID,4, 12);

	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard usDeviceID[%d],g_BRContext.bCurrentDeviceTypeCode[%d]",__FILE__,__LINE__,usDeviceID,g_BRContext.bCurrentDeviceTypeCode);

	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard DeviceID[0x%02X%02X]",__FILE__,__LINE__,DeviceID[0],DeviceID[1]);

	memcpy(&cardProcessInfo.EF_17_03.ProcessEquCode,DeviceID,2);

	cardProcessInfo.EF_17_03.CardStatus0=(cardProcessInfo.EF_17_03.CardStatus<<3)+(cardProcessInfo.EF_17_03.CardSpecialFlag&0x07);

	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard cardProcessInfo.ProcessLine[%d]",__FILE__,__LINE__,cardProcessInfo.EF_17_03.ProcessLine);
	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard cardProcessInfo.ProcessStation[%d]",__FILE__,__LINE__,cardProcessInfo.EF_17_03.ProcessStation);
	//PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard cardProcessInfo.ProcessEquType[%d]",__FILE__,__LINE__,cardProcessInfo.EF_17_03.ProcessEquType);
	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard cardProcessInfo.ProcessEquCode[0x%02X]",__FILE__,__LINE__,cardProcessInfo.EF_17_03.ProcessEquCode);
	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard cardProcessInfo.CardStatus[%d]",__FILE__,__LINE__,cardProcessInfo.EF_17_03.CardStatus);
	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard cardProcessInfo.CardSpecialFlag[%d]",__FILE__,__LINE__,cardProcessInfo.EF_17_03.CardSpecialFlag);
	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard cardProcessInfo.CardStatus0[%d]",__FILE__,__LINE__,cardProcessInfo.EF_17_03.CardStatus0);
	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard cardProcessInfo.InGateLine[%d]",__FILE__,__LINE__,cardProcessInfo.EF_17_03.InGateLine);
	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard cardProcessInfo.InGateStation[%d]",__FILE__,__LINE__,cardProcessInfo.EF_17_03.InGateStation);

	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard cardProcessInfo.InGateTime",__FILE__,__LINE__);
    PrintBuffer(cardProcessInfo.EF_17_03.InGateTime,7);

    memcpy(szTempData,ptr1,18);
    memcpy(szTempData+18,&cardProcessInfo.EF_17_03,30);
    usCrc16=crc16(szTempData,18+30);
    PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard  复合交易记录文件0017 02 轨道交通 Info_0017 usCrc16[%02X]",__FILE__,__LINE__,usCrc16);
    //memset(cardProcessInfo.EF_17_03.Reserved3,0,sizeof(cardProcessInfo.EF_17_03.Reserved3));
    memcpy(&cardProcessInfo.EF_17_03.Reserved3[2],&usCrc16,2);

	// 复合交易记录文件0017 02 轨道交通
	//memcpy(&cardProcessInfo.Info_0017[1],&cardProcessInfo.EF_17_03,48);
	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard  复合交易记录文件0017 02 轨道交通 Info_0017",__FILE__,__LINE__);
	PrintBuffer((const char *)&cardProcessInfo.EF_17_03,32);
	PrintLog("File[%s]Line[%d]Inner_Write_YktCpuCard  u32ConsumeMoney[0x%02X]",__FILE__,__LINE__,u32ConsumeMoney);

	iRet=Write_YKTCpuCard_Recombine_Info(u32ConsumeMoney,APIParam.ucTimeStamp,&cardProcessInfo,0x01,TAC,&TranSn);
	PrintLog("File[%s]Line[%d]Write_YktCpuCard_Recombine_Info  iRet[0x%02X]",__FILE__,__LINE__,iRet);
	if(0!=iRet)
	{
		return RW_EC_WRITE_FAILED;
	}
	*u8TerminalTradeNum=htonl(TranSn);
	return CE_OK;
 }



 void Fill_Lock_YktCpuCard_UD(StruAPIParam APIParam,ST_CARD_YKT_CPU stYktCpuCardInfo,TICKETLOCK * pUD)
{
	 /*	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		bStatus;					// 交易状态代码
	char		cLockFlag;					// 加解锁标志
	BYTE		dtDate[7];					// 时间YYYYMMDDHHMMSS
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShfitID;				// BOM班次序号每个BOM每天重置	(BCD)
   char		cTestFlag;						// 卡应用标识
   char		cTkAppMode;						//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	 char temp[128]={0};
	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_LOCK);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[1].cSAMID,16);
	//未实现
	//pUD->lSAMTrSeqNo=
	// 单程票卡类型
	pUD->bTicketType[0]=stYktCpuCardInfo.EF05_BAK.MainType;
	pUD->bTicketType[1]=stYktCpuCardInfo.EF05_BAK.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stYktCpuCardInfo.EF05.AppSn[0],
			stYktCpuCardInfo.EF05.AppSn[1],
			stYktCpuCardInfo.EF05.AppSn[2],
			stYktCpuCardInfo.EF05.AppSn[3],
			stYktCpuCardInfo.EF05.AppSn[4],
			stYktCpuCardInfo.EF05.AppSn[5],
			stYktCpuCardInfo.EF05.AppSn[6],
			stYktCpuCardInfo.EF05.AppSn[7]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Sale_ULCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);
	// 进站时间
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	// 交易状态  ---外边赋值

	// 操作员代码(Login)
	memcpy(pUD->cOperatorID,g_BRContext.CurrentUserID,6);

	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShfitID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);;

	// 卡应用标识
	pUD->cTestFlag='1';
	//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	pUD->cTkAppMode='1';
}




void Fill_Update_YktCpuCard_UD(StruAPIParam APIParam,ST_CARD_YKT_CPU stYktCpuCardInfo,TICKETUPDATE  * pUD)
 {
	/*char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;				// 更新设备SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	long		lTradeCount;				// 票卡扣款交易计数
	BYTE		bStatus;					// 交易状态代码
	char		cUpdateZone;				// 更新区域
	BYTE		bUpdateReasonCode;			// 更新原因
											// 更新原因代码表
											// 原因代码	描述（Description）
											// 付费区：01－出站超时，02-超乘，03-无进站码
											// 非付费区：10－有进站码，
											// 11：非付费区非本站进站
											// 12：进站超时
	BYTE		dtUpdateDate[7];			// 更新日期时间YYYYMMDDHHMMSS
	BYTE		bPaymentMode;				// 罚金支付方式
											// 	1-现金，2-储值卡， 3-一卡通
											//	4-Credit， 5- civil charge '默认值''
	short		nForfeiture;				// 罚金, 需缴纳的罚款金额（现金支付），单位分
	char		cReceiptID[4];				// 支付凭证码
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bEntryStationID[2];			// 进站线路站点代码
	BYTE		bBOMShfitID;				// BOM班次序号每个BOM每天重置	（BCD）
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				// 限制使用模式
	BYTE		bLimitEntryID[2];			// 限制进站代码
	BYTE		bLimitExitID[2];			// 限制出站代码
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	char temp[128]={0};
	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_UPDATE);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[1].cSAMID,16);

	// 单程票卡类型
	pUD->bTicketType[0]=stYktCpuCardInfo.EF05_BAK.MainType;
	pUD->bTicketType[1]=stYktCpuCardInfo.EF05_BAK.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stYktCpuCardInfo.EF05.AppSn[0],
			stYktCpuCardInfo.EF05.AppSn[1],
			stYktCpuCardInfo.EF05.AppSn[2],
			stYktCpuCardInfo.EF05.AppSn[3],
			stYktCpuCardInfo.EF05.AppSn[4],
			stYktCpuCardInfo.EF05.AppSn[5],
			stYktCpuCardInfo.EF05.AppSn[6],
			stYktCpuCardInfo.EF05.AppSn[7]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Sale_ULCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);

	// 单程票扣款计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,stYktCpuCardInfo.LocalHistory[0],2);
	pUD->lTradeCount=htons(usTempTradeCount);

	// 交易状态  ---外边赋值

	// 更新区域  ---外边赋值

	// 更新原因  ---外边赋值

	// 更新日期时间YYYYMMDDHHMMSS
	memcpy(pUD->dtUpdateDate,APIParam.ucTimeStamp,7);

	// 罚金支付方式  ---外边赋值

	// 罚金, 需缴纳的罚款金额（现金支付），单位分  ---外边赋值

	//cReceiptID[4];				// 支付凭证码
    memcpy(pUD->cReceiptID,szTempZero,4);
	// 操作员代码(Login)
	memcpy(pUD->cOperatorID,g_BRContext.CurrentUserID,6);
	// 入口站点代码(BCD)
	pUD->bEntryStationID[0]=Byte_Decimal_to_BCD(stYktCpuCardInfo.EF_17_03.InGateLine);
	pUD->bEntryStationID[1]=Byte_Decimal_to_BCD(stYktCpuCardInfo.EF_17_03.InGateStation);

	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShfitID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);

	// 卡应用标识
	pUD->cTestFlag='1';

	// 限制使用模式
    memcpy(pUD->cLimitMode,szTempZero,3);
    pUD->bLimitEntryID[0]=0;			// 限制进站代码
	pUD->bLimitEntryID[1]=0;
	pUD->bLimitExitID[0]=0;			// 限制出站代码
	pUD->bLimitEntryID[1]=0;

	//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	pUD->cTkAppMode='1';



 }

  void Fill_Entry_YktCpuCard_UD(StruAPIParam APIParam,ST_CARD_YKT_CPU stYktCpuCardInfo,ENTRYGATE * pUD)
 {

	  /*
	 char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];				// 设备类型
	char		cDeviceID[3];					// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		dtDate[7];					// 进站日期时间如;20060211160903
	BYTE		bStatus;						// 交易状态代码
	long		lBalance;						// 余额
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				//限制使用模式
	BYTE		bLimitEntryID[2];				//限制进站代码
	BYTE		bLimitExitID[2];				//限制出站代码
	char 		cEntryMode;					//进闸工作模式
	long		lTradeCount;					//扣款计数
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	char temp[128]={0};
	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_ENTRY);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[1].cSAMID,16);
	//未实现
	//pUD->lSAMTrSeqNo=
	// 单程票卡类型
	pUD->bTicketType[0]=stYktCpuCardInfo.EF05_BAK.MainType;
	pUD->bTicketType[1]=stYktCpuCardInfo.EF05_BAK.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stYktCpuCardInfo.EF05.AppSn[0],
			stYktCpuCardInfo.EF05.AppSn[1],
			stYktCpuCardInfo.EF05.AppSn[2],
			stYktCpuCardInfo.EF05.AppSn[3],
			stYktCpuCardInfo.EF05.AppSn[4],
			stYktCpuCardInfo.EF05.AppSn[5],
			stYktCpuCardInfo.EF05.AppSn[6],
			stYktCpuCardInfo.EF05.AppSn[7]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Sale_ULCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);
	// 进站时间
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	// 交易状态  ---外边赋值

	// 余额
	pUD->lBalance=htonl(stYktCpuCardInfo.Purse);

	// 卡应用标识
	pUD->cTestFlag='1';

	//限制使用模式
    memcpy(pUD->cLimitMode,szTempZero,3);
	//限制进站代码
	pUD->bLimitEntryID[0]=0;;
	pUD->bLimitEntryID[1]=0;;
	//限制出站代码
	pUD->bLimitExitID[0]=0;
	pUD->bLimitExitID[1]=0;
	//进闸工作模式
	//pUD->cEntryMode;
	memcpy(&pUD->cEntryMode,szTempZero,1);

	// 单程票扣款计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,stYktCpuCardInfo.LocalHistory[0],2);
	pUD->lTradeCount=htons(usTempTradeCount);
	//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	pUD->cTkAppMode='1';


 }

  void Fill_Purse_YktCpuCard_UD(StruAPIParam APIParam,ST_CARD_YKT_CPU stYktCpuCardInfo,PURSETRADE * pUD)
 {

	  /*	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// 本次交易SAM逻辑卡号
	long		lSAMTrSeqNo;				// 本次交易SAM卡脱机交易流水号
	BYTE		dtDate[7];					// 日期时间(BCD)
	BYTE		bTicketType[2];				// 票卡类型(BCD)
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		bStatus;					// 交易状态代码
	long		lTradeAmount;				// 交易金额, 单位为分
	long		lBalance;					// 余额, 单位为分
	long		lChargeCount;				// 票卡充值计数
	long		lTradeCount;				// 票卡扣款交易计数
	char		cPaymentType[2];			// 支付类型
	char		cReceiptID[4];				// 支付凭证码
	char		cMACorTAC[10];				// 交易认证码
	BYTE		bEntryStationID[2];			// 入口站点代码(BCD)
	char		cEntrySAMID[16];			// 入口SAM逻辑卡号
	BYTE		dtEntryDate[7];				// 进站日期时间(BCD)
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShiftID;				// BOM班次序号
	char		cSamLast[16];				// 上次交易的SAM卡号
	BYTE		dtLast[7];					// 上次交易日期时间
	long		lTradeWallet;				// 钱包交易额，卡片实际需要变动的钱包值
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				// 限制使用模式
	BYTE		bLimitEntryID[2];			// 限制进站代码
	BYTE		bLimitExitID[2];			// 限制出站代码
	char		cExitMode;					//出闸工作模式
	char		cCityCode[4];				// 城市代码
	char		cIndustryCode[4];			// 行业代码
	char		cClassicType[2];			// TAC交易分类
	char		cSamPosId[12];				// SAM卡终端编码
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	char temp[128]={0};
	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_PURSE);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[1].cSAMID,16);

	// 时间
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	// 单程票卡类型
	pUD->bTicketType[0]=stYktCpuCardInfo.EF05_BAK.MainType;
	pUD->bTicketType[1]=stYktCpuCardInfo.EF05_BAK.SubType;


	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stYktCpuCardInfo.EF05.AppSn[0],
			stYktCpuCardInfo.EF05.AppSn[1],
			stYktCpuCardInfo.EF05.AppSn[2],
			stYktCpuCardInfo.EF05.AppSn[3],
			stYktCpuCardInfo.EF05.AppSn[4],
			stYktCpuCardInfo.EF05.AppSn[5],
			stYktCpuCardInfo.EF05.AppSn[6],
			stYktCpuCardInfo.EF05.AppSn[7]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Sale_ULCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02X%02X%02X%02X000000      ",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);


	// 交易状态  ---外边赋值

	// 交易金额, 单位为分   ---外边赋值

	// 余额, 单位为分  ---外边赋值

	// 票卡充值计数
	unsigned short usTempChargeCount=0;
	memcpy(&usTempChargeCount,stYktCpuCardInfo.RechargeHistory[0],2);
	pUD->lChargeCount=htons(usTempChargeCount);

	// 单程票扣款计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,stYktCpuCardInfo.LocalHistory[0],2);
	pUD->lTradeCount=htons(usTempTradeCount);

	// 支付类型
	pUD->cPaymentType[0]='4';
	pUD->cPaymentType[1]='2';
	// 支付凭证码
	memcpy(pUD->cReceiptID,szTempZero,4);

	// 入口站点代码(BCD)
	pUD->bEntryStationID[0]=Byte_Decimal_to_BCD(stYktCpuCardInfo.EF_17_03.InGateLine);
	pUD->bEntryStationID[1]=Byte_Decimal_to_BCD(stYktCpuCardInfo.EF_17_03.InGateStation);

	// 入口SAM逻辑卡号
	memcpy(pUD->cEntrySAMID,szTempZero,16);

	// 进站日期时间(BCD)
	memcpy(pUD->dtEntryDate,stYktCpuCardInfo.EF_17_03.InGateTime,7);

	// 操作员代码(Login)
	sprintf(pUD->cOperatorID,"%s",g_BRContext.CurrentUserID);

	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShiftID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);

	// 上次交易的SAM卡号pUD->cSamLast[16];
	memcpy(pUD->cSamLast,szTempZero,16);

	// 上次交易日期时间pUD->dtLast[7];
	memcpy(pUD->dtLast,stYktCpuCardInfo.EF_17_03.ProcessTime,7);

	// 卡应用标识
	pUD->cTestFlag='1';

	// 限制使用模式
	memcpy(pUD->cLimitMode,szTempZero,3);
	// 限制进站代码

	// 限制出站代码

	//出闸工作模式
	sprintf(&pUD->cExitMode,"0");

	// 城市代码
	sprintf(pUD->cCityCode,"4100");

	//行业代码
	memcpy(pUD->cIndustryCode,szTempZero,4);
	// TAC交易分类
	sprintf(pUD->cClassicType,"09");//
	/*TAC交易分类
	储值类CPU卡片（地铁卡，公交CPU卡）：
	02：充值
	09：复合消费 （出闸 扣费、出闸更新、退款）
	06：单次消费（支付罚金、冲正）
	单程票、公交M1卡：所有交易（钱包交易、退款）与二号线保持一致，填写00*/

	// SAM卡终端编码
	strncpy(pUD->cSamPosId,g_BRContext.stSamInfo[0].cSAMID,5);
	strncpy(pUD->cSamPosId+5,g_BRContext.stSamInfo[0].cSAMID+9,7);

	//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	pUD->cTkAppMode='1';


 }

    //付费区分析。
 BOOL PaidArea_Analysis_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  stYktCpuCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis)
 {
	 int iRet=-1;
	 BOOL bRet=FALSE;
	 uint8 szEntryStation[2]={0};
	 uint8 szProcessStation[2]={0};
	 long  lRemainningValue=0;
	 uint8 u8EntryTime[7]={0};

	 unsigned char cardType[2]={0};

	 unsigned char u8stOperationStauts=0;
	 uint32 u32EntryTimeT=0;
	 uint32 u32CurrentTimeT=0;
	 uint32  lPrice=0;
	 uint16 FareZone=0;
	 uint16 JourneyTimeLimit=0;
	 uint16 TimeoutsFines=0;
	 uint8  RidingTime=0;
	 uint8  TrainTicketTableID=0;

	 uint8 cardStatus=stYktCpuCardInfo.EF_17_03.CardStatus;
	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard cardStatus[%d]",__FILE__,__LINE__,cardStatus);

	 szEntryStation[0]=stYktCpuCardInfo.EF_17_03.InGateLine;
	 szEntryStation[1]=stYktCpuCardInfo.EF_17_03.InGateStation;
	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard szEntryStation[%02X%02X]",__FILE__,__LINE__,szEntryStation[0],szEntryStation[1]);


	 cardType[0]=stYktCpuCardInfo.EF05.MainType;
	 cardType[1]=stYktCpuCardInfo.EF05.SubType;

	 BCD_to_TimeT(stYktCpuCardInfo.EF_17_03.ProcessTime,&u32EntryTimeT);

	 lRemainningValue=htonl(stYktCpuCardInfo.Purse);
	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard lRemainningValue[%d]",__FILE__,__LINE__,lRemainningValue);

	 szProcessStation[0]=stYktCpuCardInfo.EF_17_03.ProcessLine;
	 szProcessStation[1]=stYktCpuCardInfo.EF_17_03.ProcessStation;

	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard szProcessStation[%02X%02X]",__FILE__,__LINE__,szProcessStation[0],szProcessStation[1]);

	 memcpy(u8EntryTime,stYktCpuCardInfo.EF_17_03.InGateTime,7);

	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard InGateTime[%d]",__FILE__,__LINE__,u32EntryTimeT);

	 BCD_to_TimeT(APIParam.ucTimeStamp,&u32CurrentTimeT);

	 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard u32CurrentTimeT[%d]",__FILE__,__LINE__,u32CurrentTimeT);

	  bRet=Check_Update_ThisDay_YktCpuCard(APIParam,stYktCpuCardInfo);
	  PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  Check_Update_ThisDay_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	  if(!bRet)
		{
		   pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_DATE;
//		   stAnalysis->wError=RW_EC_UPDATE_OTHER_DATE;
//		   m_stOperationStauts.bAllowUpdate=TRUE;
//			iRet=Get_Price_InDegrade(cardType,szEntryStation,u8EntryTime,APIParam.ucTimeStamp,
//								&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);
//			 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard lPrice[%d],JourneyTimeLimit[%d],TimeoutsFines[%d]",__FILE__,__LINE__,lPrice,JourneyTimeLimit,TimeoutsFines);
//			if(iRet!=CE_OK)
//			{
//				 PrintLog("File[%s]Line[%d]PaidArea_Analysis_AccCpuCard GetPrice Failed",__FILE__,__LINE__);
//				 pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
//			}
//			stAnalysis->lPenalty=TimeoutsFines;
			 memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
			 stAnalysis->dwOperationStauts=u8stOperationStauts;
			return CE_OK;
		}
	  bRet=Check_Update_ThisStation_YktCpuCard(stYktCpuCardInfo);
	  PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  Check_Update_ThisStation_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	  if(!bRet)
		{
		   pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_SATION;
//		   stAnalysis->wError=RW_EC_UPDATE_OTHER_SATION;
//		   m_stOperationStauts.bAllowUpdate=TRUE;
//		   iRet=BR_GetMinPrice(cardType,szProcessStation,APIParam.ucTimeStamp,&lPrice);
//		   if(iRet!=0)
//		   {
//			   pRetInfo->wErrCode=RW_EC_UNKNOWN;
//		   }
//		   stAnalysis->lPenalty=lPrice;//最小票价,
//		   memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
		   stAnalysis->dwOperationStauts=u8stOperationStauts;
		   return CE_OK;
		}

	 switch(cardStatus)
	 {
	   case EM_TICKET_TRAVEL_STATUS_REFUND://已退卡
		   pRetInfo->wErrCode=RW_EC_STATUS_REFUND;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_INITIALIZATION://初始化
		   pRetInfo->wErrCode=RW_EC_UNSALE;
			break;
	   case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES://Init II (Pre-value loaded @E/S)(预赋值)
		   pRetInfo->wErrCode=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;//"付费区无进站码","需要更新"
		   stAnalysis->wError=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;
		   m_stOperationStauts.bAllowUpdate=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_ISSUED://(BOM/TVM)发售
		   pRetInfo->wErrCode=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;//"付费区无进站码","需要更新"
		   stAnalysis->wError=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;
		   m_stOperationStauts.bAllowUpdate=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA://非付费区免费更新(BOM/pca 非付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA://非付费区付费更新(BOM/pca 非付费区)
		   pRetInfo->wErrCode=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;//"付费区无进站码","需要更新"
		   stAnalysis->wError=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;
		   m_stOperationStauts.bAllowUpdate=TRUE;
		   break;
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:  //无进站码更新(BOM/pca 付费区)
				iRet=Get_Price_InDegrade(cardType,szEntryStation,u8EntryTime,APIParam.ucTimeStamp,
									&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);
				if(iRet!=CE_OK)
				{
					 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard Get_Price_InDegrade Failed[%d]",__FILE__,__LINE__,iRet);
					 pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
					 return CE_OK;
				}
			   //超时 站内滞留时间
			    //if(u32CurrentTimeT>u32EntryTimeT+(JourneyTimeLimit*60)&&(g_BRContext.TicktPara0301.OverTimeCheck[0]=='1'))
				if(!Check_Exit_Timeout_YktCpuCard(APIParam,JourneyTimeLimit,stYktCpuCardInfo))
				{
				   pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;//"付费区超时",
				   stAnalysis->wError=RW_EC_EXIT_TIMOUT_PAID_AREA;
				   //stAnalysis->dwOperationStauts|=0x02;//可更新
				   m_stOperationStauts.bAllowUpdate=TRUE;
				   stAnalysis->lPenalty=TimeoutsFines;////更新金额,
				   PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard 超时 lPenalty[%d] ",__FILE__,__LINE__,stAnalysis->lPenalty);
				}
			    break;
		case EM_TICKET_TRAVEL_STATUS_ENTRY: ////已进站；
		  //if(memcmp(szEntryStation,(char*)g_BRContext.bCurrentStationID,2)!=0)////入站非本站
		   {
				iRet=Get_Price_InDegrade(cardType,szEntryStation,u8EntryTime,APIParam.ucTimeStamp,
						&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);
				 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard lPrice[%d],JourneyTimeLimit[%d],TimeoutsFines[%d]",__FILE__,__LINE__,lPrice,JourneyTimeLimit,TimeoutsFines);
				if(iRet!=CE_OK)
				{
					 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard GetPrice Failed",__FILE__,__LINE__);
					 pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
					 return CE_OK;
				}
			   //if(lRemainningValue<lPrice&&(g_BRContext.TicktPara0301.OverTaken[0]=='1')) //超乘
				if(!Check_Exit_RemainningValue_YktCpuCard(&lPrice,stYktCpuCardInfo))
			   {
				   pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_PAID_AREA;//"付费区超乘",
				   stAnalysis->wError1=RW_EC_EXIT_OUTRANGE_PAID_AREA;
				   //stAnalysis->dwOperationStauts|=0x02;//可更新
				   m_stOperationStauts.bAllowUpdate=TRUE;
				   stAnalysis->lPenalty1=lPrice-lRemainningValue;//更新金额
				   PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard 超乘 lPenalty1[%d] ",__FILE__,__LINE__,stAnalysis->lPenalty1);
			   }

			   //超时 站内滞留时间
			    //if(u32CurrentTimeT>u32EntryTimeT+(JourneyTimeLimit*60)&&(g_BRContext.TicktPara0301.OverTimeCheck[0]=='1'))
			   if(!Check_Exit_Timeout_YktCpuCard(APIParam,JourneyTimeLimit,stYktCpuCardInfo))
				{
				   pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;//"付费区超时",
				   stAnalysis->wError=RW_EC_EXIT_TIMOUT_PAID_AREA;
				   //stAnalysis->dwOperationStauts|=0x02;//可更新
				   m_stOperationStauts.bAllowUpdate=TRUE;
				   stAnalysis->lPenalty=TimeoutsFines;////更新金额,
				   PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard 超时 lPenalty[%d] ",__FILE__,__LINE__,stAnalysis->lPenalty);
				}

				if(stAnalysis->wError==RW_EC_EXIT_TIMOUT_PAID_AREA&&stAnalysis->wError1==RW_EC_EXIT_OUTRANGE_PAID_AREA)
				{
					pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_AND_TIMEOUT;
				}
		   }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:  //超时更新(BOM/pca 付费区)
		   {
			   iRet=Get_Price_InDegrade(cardType,szEntryStation,u8EntryTime,APIParam.ucTimeStamp,
			   						&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);
				 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard lPrice[%d],JourneyTimeLimit[%d],TimeoutsFines[%d]",__FILE__,__LINE__,lPrice,JourneyTimeLimit,TimeoutsFines);
				if(iRet!=CE_OK)
				{
					 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard GetPrice Failed",__FILE__,__LINE__);
					 pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
					 return CE_OK;
				}
			   //if(lRemainningValue<lPrice&&(g_BRContext.TicktPara0301.OverTaken[0]=='1')) //超乘
				if(!Check_Exit_RemainningValue_YktCpuCard(&lPrice,stYktCpuCardInfo))
			   {
				   pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_PAID_AREA;//"付费区超乘",
				   stAnalysis->wError=RW_EC_EXIT_OUTRANGE_PAID_AREA;
				   //stAnalysis->dwOperationStauts|=0x02;//可更新
				   m_stOperationStauts.bAllowUpdate=TRUE;
				   stAnalysis->lPenalty=lPrice-lRemainningValue;//更新金额
				   PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard 超乘 lPenalty[%d] ",__FILE__,__LINE__,stAnalysis->lPenalty);
			   }
		   }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_RANGEOUT:  //超乖更新(BOM/pca 付费区)
		   {
			   iRet=Get_Price_InDegrade(cardType,szEntryStation,u8EntryTime,APIParam.ucTimeStamp,
			   						&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);
				 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard lPrice[%d],JourneyTimeLimit[%d],TimeoutsFines[%d]",__FILE__,__LINE__,lPrice,JourneyTimeLimit,TimeoutsFines);
				if(iRet!=CE_OK)
				{
					 PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard GetPrice Failed",__FILE__,__LINE__);
					 pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
					 return CE_OK;
				}
			   //超时 站内滞留时间
				//if(u32CurrentTimeT>u32EntryTimeT+(JourneyTimeLimit*60)&&(g_BRContext.TicktPara0301.OverTimeCheck[0]=='1'))
				if(!Check_Exit_Timeout_YktCpuCard(APIParam,JourneyTimeLimit,stYktCpuCardInfo))
				{
				   pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;//"付费区超时",
				   stAnalysis->wError1=RW_EC_EXIT_TIMOUT_PAID_AREA;
				   //stAnalysis->dwOperationStauts|=0x02;//可更新
				   m_stOperationStauts.bAllowUpdate=TRUE;
				   stAnalysis->lPenalty1=TimeoutsFines;////更新金额,
				   PrintLog("File[%s]Line[%d]PaidArea_Analysis_YktCpuCard 超时 lPenalty[%d] ",__FILE__,__LINE__,stAnalysis->lPenalty1);
				}
			  }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:		//免费出闸更新
			   {
			    if(memcmp(szProcessStation,(char*)g_BRContext.bCurrentStationID,2)==0)//更新站为本站
				{
				   if(u32CurrentTimeT>(u32EntryTimeT+(24*3600)))//本站24前更新
				   {
					   pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_DATE;//"非本日更新的车票",，不可更新。
				   }
				}else
				{
					 pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_SATION;//非本站更新的车票","可以建议乘客去更新的车站出站，也可以根据乘客的要求做票卡更新"
					 m_stOperationStauts.bAllowUpdate=TRUE;
					 stAnalysis->wError=RW_EC_UPDATE_OTHER_SATION;
				}
			   }
			   break;
			 case EM_TICKET_TRAVEL_STATUS_EXITED://已出站
				 {
					 if(u32CurrentTimeT<=(u32EntryTimeT+(10*60))&&(memcmp(szProcessStation,(char*)g_BRContext.bCurrentStationID,2)==0))//本站X秒内出站
					 {
					   pRetInfo->wErrCode=RW_EC_LAST_EXIT_BELOW_X_MINUTE;
					   pRetInfo->bNoticeCode=RW_SUBEC_LAST_EXIT_BELOW_X_MINUTE;////上次出站在X秒内
					 }else
					 {
					   pRetInfo->wErrCode=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;
					   m_stOperationStauts.bAllowUpdate=TRUE;//可更新
					   stAnalysis->wError=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;

					 }
				 }
			   break;
			 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:
				 pRetInfo->wErrCode=RW_EC_UNKNOWN;
				 pRetInfo->bNoticeCode=RW_SUBEC_TRAIN_FAULT;//列车故障模式出站
				 break;
	 }
	 if(pRetInfo->wErrCode!=RW_EC_OK)
	 	{
			bRet=Allow_Exit_InFreeEntryStationCode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID,szProcessStation);
			if(bRet)
			{
				m_stOperationStauts.bAllowUpdate=FALSE;
				pRetInfo->wErrCode=RW_EC_OK;
				stAnalysis->wError=RW_EC_OK;
				stAnalysis->lPenalty=0;
				stAnalysis->wError1=RW_EC_OK;
				stAnalysis->lPenalty1=0;
			}
	 	}
	 memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
	 stAnalysis->dwOperationStauts=u8stOperationStauts;
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_YktCpuCard bAllowActive[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowActive);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_YktCpuCard bAllowCharge[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowCharge);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_YktCpuCard bAllowDelay[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowDelay);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_YktCpuCard bAllowRefund[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowRefund);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_YktCpuCard bAllowSale[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowSale);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_YktCpuCard bAllowUnlock[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUnlock);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_YktCpuCard bAllowUpdate[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUpdate);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_YktCpuCard dwOperationStauts[%d]",__FILE__,__LINE__,stAnalysis->dwOperationStauts);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_YktCpuCard pRetInfo->wErrCode[0x%02X]",__FILE__,__LINE__,pRetInfo->wErrCode);

	 return FALSE;
 }

 //非付费区分析。
 BOOL UnpaidArea_Analysis_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  stYktCpuCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis)
 {
	 int iRet=-1;
	 BOOL bRet=FALSE;
	 uint8 szEntryStation[2]={0};
	 uint8 szProcessStation[2]={0};
	 uint32 u32EntryTimeT=0;
	 uint8 u8EntryTime[7]={0};
	 uint32 u32CurrentTimeT=0;
	 uint8 cardType[2]={0};
	 uint32 u32MinPrice=0;
	 unsigned char u8stOperationStauts=0;

	 uint8 cardStatus=stYktCpuCardInfo.EF_17_03.CardStatus;
	 szEntryStation[0]=stYktCpuCardInfo.EF_17_03.InGateLine;
	 szEntryStation[1]=stYktCpuCardInfo.EF_17_03.InGateStation;

	 szProcessStation[0]=stYktCpuCardInfo.EF_17_03.ProcessLine;
	 szProcessStation[1]=stYktCpuCardInfo.EF_17_03.ProcessStation;

	 cardType[0]=stYktCpuCardInfo.EF05.MainType;
	 cardType[1]=stYktCpuCardInfo.EF05.SubType;
	 BCD_to_TimeT(stYktCpuCardInfo.EF_17_03.ProcessTime,&u32EntryTimeT);
	 BCD_to_TimeT(APIParam.ucTimeStamp,&u32CurrentTimeT);

	 memcpy(u8EntryTime,stYktCpuCardInfo.EF_17_03.ProcessTime,7);
	 switch(cardStatus)
	 {
	   case EM_TICKET_TRAVEL_STATUS_REFUND://已退卡
		   pRetInfo->wErrCode=RW_EC_STATUS_REFUND;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_INITIALIZATION://初始化
		   pRetInfo->wErrCode=RW_EC_UNSALE;
		   //stAnalysis->dwOperationStauts|=0x04;//可发售
		   m_stOperationStauts.bAllowSale=TRUE;
		 break;
	   case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES://Ini.t II (Pre-value loaded @E/S)(预赋值)
		   //stAnalysis->dwOperationStauts|=0x20;//可退款
		   m_stOperationStauts.bAllowRefund=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_ISSUED://(BOM/TVM)发售
		   //stAnalysis->dwOperationStauts|=0x20;//可退款
		   m_stOperationStauts.bAllowRefund=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA://非付费区免费更新(BOM/pca 非付费区)
		   //stAnalysis->dwOperationStauts|=0x20;//可退款
		   m_stOperationStauts.bAllowRefund=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_ENTRY:  ////已进站
		   if(memcmp(szEntryStation,(char*)g_BRContext.bCurrentStationID,2)==0)//入站为本站
		   {
			   if(u32EntryTimeT+(20*60)<u32CurrentTimeT)
			   {
				   pRetInfo->wErrCode=RW_EC_ENTRY_TIMOUT_UNPAID_AREA;//非付费区进站超时
				   stAnalysis->wError=RW_EC_ENTRY_TIMOUT_UNPAID_AREA;
				   iRet=BR_GetMinPrice(cardType,g_BRContext.bCurrentStationID,APIParam.ucTimeStamp,&u32MinPrice);
				   if(iRet!=0)
				   {
					   pRetInfo->wErrCode=RW_EC_UNKNOWN;
					   return CE_OK;
				   }
				   stAnalysis->lPenalty=u32MinPrice;//最小票价,
				   m_stOperationStauts.bAllowUpdate=TRUE;
			   }else
			   {
				   pRetInfo->wErrCode=RW_EC_ENTRY_ENTRYCODE_WRITTEN_UNPAID_AREA;//非付费区有进站码
				   stAnalysis->wError=RW_EC_ENTRY_ENTRYCODE_WRITTEN_UNPAID_AREA;
				   stAnalysis->lPenalty=0;
				   m_stOperationStauts.bAllowUpdate=TRUE;
			   }
		   }else//入站非本站
		   {
			   pRetInfo->wErrCode=RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA;////"非付费区非本站进站"
			   m_stOperationStauts.bAllowUpdate=TRUE;
			   stAnalysis->wError=RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA;

			   iRet=BR_GetMinPrice(cardType,g_BRContext.bCurrentStationID,APIParam.ucTimeStamp,&u32MinPrice);
			   if(iRet!=0)
			   {
				   pRetInfo->wErrCode=RW_EC_UNKNOWN;
				   return CE_OK;
			   }
			   stAnalysis->lPenalty=u32MinPrice;//最小票价,
		   }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:  //无进站码更新(BOM/pca 付费区)
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:  //超时更新(BOM/pca 付费区)
		   case EM_TICKET_TRAVEL_STATUS_RANGEOUT:  //超乖更新(BOM/pca 付费区)
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:		//免费出闸更新
			   pRetInfo->wErrCode=RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA;////"非付费区非本站进站"
			   stAnalysis->wError=RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA;
			   m_stOperationStauts.bAllowUpdate=TRUE;
			   iRet=BR_GetMinPrice(cardType,g_BRContext.bCurrentStationID,APIParam.ucTimeStamp,&u32MinPrice);
			   if(iRet!=0)
			   {
				   pRetInfo->wErrCode=RW_EC_UNKNOWN;
				   return CE_OK;
			   }
			   stAnalysis->lPenalty=u32MinPrice;//最小票价,
			   break;
		   case EM_TICKET_TRAVEL_STATUS_EXITED://已出站
			    pRetInfo->wErrCode=RW_EC_OK;
			   break;
		   case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:////出站票
			   pRetInfo->wErrCode=RW_EC_UNKNOWN;
			   pRetInfo->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;//回收票
			   break;
		   case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:
				 pRetInfo->wErrCode=RW_EC_UNKNOWN;
				 pRetInfo->bNoticeCode=RW_SUBEC_TRAIN_FAULT;//列车故障模式出站
				break;
	 }
	 if(pRetInfo->wErrCode!=RW_EC_OK)
	 {
		 bRet=Allow_Entry_InDegradeMode(APIParam.ucTimeStamp,u8EntryTime,szProcessStation,cardStatus);
		 if(bRet)
		 {
			m_stOperationStauts.bAllowUpdate=FALSE;
			pRetInfo->wErrCode=RW_EC_OK;
			stAnalysis->wError=RW_EC_OK;
			stAnalysis->lPenalty=0;
			stAnalysis->wError1=RW_EC_OK;
			stAnalysis->lPenalty1=0;
		 }
	 }

	 memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
	 stAnalysis->dwOperationStauts=u8stOperationStauts;
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_YktCpuCard bAllowActive[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowActive);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_YktCpuCard bAllowCharge[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowCharge);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_YktCpuCard bAllowDelay[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowDelay);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_YktCpuCard bAllowRefund[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowRefund);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_YktCpuCard bAllowSale[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowSale);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_YktCpuCard bAllowUnlock[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUnlock);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_YktCpuCard bAllowUpdate[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUpdate);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_YktCpuCard dwOperationStauts[%d]",__FILE__,__LINE__,stAnalysis->dwOperationStauts);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_YktCpuCard pRetInfo->wErrCode[0x%02X]",__FILE__,__LINE__,pRetInfo->wErrCode);
	  return FALSE;
 }

 //检查车票状态是否正确
 BOOL Check_Ticket_Status_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo)
 {

	 BOOL bRet=FALSE;
	 uint8 u8CurrentCardStatus=0;
	 u8CurrentCardStatus=stYktCpuCardInfo.EF_17_03.CardStatus;
	 PrintLog("File[%s]Line[%d]Check_Ticket_Status_YktCpuCard u8CurrentCardStatus[%d]",__FILE__,__LINE__,u8CurrentCardStatus);
	 switch(u8CurrentCardStatus)
	 {
	     case 0:
		 case EM_TICKET_TRAVEL_STATUS_INITIALIZATION:			//e/s 初始化(init 0)
		 case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES:		//e/s 初始化(init 1)
		 case EM_TICKET_TRAVEL_STATUS_ISSUED:					// SJT发售(init 2)
		 case EM_TICKET_TRAVEL_STATUS_ENTRY:					//已进站
		 case EM_TICKET_TRAVEL_STATUS_EXITED:					//已出站
		 case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:				//出站票
		 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:		//列车故障模式出站(exit during Train-disruption)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA:	//非付费区免费更新(BOM/pca 非付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA:	//非付费区付费更新(BOM/pca 非付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
		 case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
		 case EM_TICKET_TRAVEL_STATUS_REFUND:					//已退卡
			 bRet=TRUE;
			 break;
		 default:
			 bRet=FALSE;
			 break;

	 }

	 return bRet;
 }

 //检查余额是否超出上限。
 BOOL Check_Ticket_Value_Uplimit_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo)
 {
	 BOOL bRet=FALSE;
	 uint32 u32CurrentCardValue=0;
	 long u32UplimitValue=0;
	 char szUpperLimit[7]={0};

	 u32CurrentCardValue=htonl(stYktCpuCardInfo.Purse);
	 PrintLog("File[%s]Line[%d]Check_Ticket_Value_Uplimit_YktCpuCard u32CurrentCardValue[%d]",__FILE__,__LINE__,u32CurrentCardValue);

	 memcpy(szUpperLimit,g_BRContext.TicktPara0301.UpperLimit,6);
	 u32UplimitValue=atoi((char*)g_BRContext.TicktPara0301.UpperLimit);
	 PrintLog("File[%s]Line[%d]Check_Ticket_Value_Uplimit_YktCpuCard u32UplimitValue[%d]",__FILE__,__LINE__,u32UplimitValue);
	 if(u32CurrentCardValue>u32UplimitValue)
	 {
		 bRet=FALSE;
	 }else
	 {
		 bRet=TRUE;
	 }
	 return bRet;

 }
 //检查车票是否过期。
 BOOL Check_Ticket_Valid_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  *stYktCpuCardInfo)
 {
		// 逻辑有效期开始时间(BCD)
	//m_stYktCpuCardInfo.EF05.CardActiveDate
	char temp[20]={0};
    unsigned char ucParam=0;
	memset(temp,0,sizeof(temp));

    ////逻辑及物理有效期检查	CHAR	1	0：不检查逻辑及物理有效期；1：检查逻辑及物理有效期；2：检查逻辑但不检查物理有效期；3：不检查逻辑期但检查物理有效期
     temp[0]=g_BRContext.TicktPara0301.PhysicsCheck[0];
     ucParam=atoi(temp);
     if(!ucParam)
     {
    	 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  g_BRContext.TicktPara0301.PhysicsCheck= [%d]",__FILE__,__LINE__,ucParam);
    	 return TRUE;
     }

     if(ucParam==1||ucParam==3)//检查物理有效期
	 {

		PrintLog("File[%s]Line[%d]stAnalysis-> bEndDate",__FILE__,__LINE__);
		PrintBuffer((const char *)stYktCpuCardInfo->EF15.CardValidDate,4);
		 if(memcmp(APIParam.ucTimeStamp,stYktCpuCardInfo->EF05.CardValidDate,4)>0)
		 {
			 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_YktCpuCard  u8BCDCurrentDate>CardValidDate",__FILE__,__LINE__);
			 return FALSE;
		 }
	 }


     if(ucParam==1||ucParam==2)//检查逻辑有效期
     {

		PrintLog("File[%s]Line[%d]stAnalysis-> bEndDate",__FILE__,__LINE__);
		PrintBuffer((const char *)stYktCpuCardInfo->EF15.CardValidDate,4);

		 if(memcmp(APIParam.ucTimeStamp,stYktCpuCardInfo->EF15.CardValidDate,4)>0||memcmp(APIParam.ucTimeStamp,stYktCpuCardInfo->EF15.CardStartDate,4)<0)
		 {
			 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_YktCpuCard  u8BCDCurrentDate>szEndDate",__FILE__,__LINE__);
			 return FALSE;
		 }
     }

     if(stYktCpuCardInfo->EF06.AuditDate[0]!=0)
     {
    	 PrintLog("File[%s]Line[%d]stAnalysis-> AuditDate",__FILE__,__LINE__);
		 PrintBuffer((const char *)stYktCpuCardInfo->EF06.AuditDate,3);

		 if(memcmp(APIParam.ucTimeStamp+1,stYktCpuCardInfo->EF06.AuditDate,3)>0)
		 {
			 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_YktCpuCard  u8BCDCurrentDate>AuditDate",__FILE__,__LINE__);
			 stYktCpuCardInfo->EF05.MainType=0x06;//过期后当成人票处理
			 stYktCpuCardInfo->EF05.SubType=0x00;
			 return TRUE;
		 }

     }
	 return TRUE;
 }

 BOOL Check_Exit_DateTime_Order_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  stYktCpuCardInfo)
 {
	 if(stYktCpuCardInfo.EF_17_03.CardStatus!=EM_TICKET_TRAVEL_STATUS_ENTRY)
	 {
		 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_YktCpuCard return true  ",__FILE__,__LINE__);
		 return TRUE;
	 }

	 if(memcmp(APIParam.ucTimeStamp,stYktCpuCardInfo.EF_17_03.ProcessTime,7)<0)
	  {
		 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_YktCpuCard  u8BCDCurrentDate<ProcessTime",__FILE__,__LINE__);
		 return FALSE;
	  }

	 return TRUE;
 }

 //检查是否本站进站。
   BOOL Check_EntryThisStation_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo)
   {
 	 BOOL bRet=FALSE;
 	 uint8 szSaleStation[2]={0};

 	 szSaleStation[0]=stYktCpuCardInfo.EF_17_03.ProcessLine;
 	 szSaleStation[1]=stYktCpuCardInfo.EF_17_03.ProcessStation;

 	 if(memcmp(szSaleStation,(char*)g_BRContext.bCurrentStationID,2)==0)
 	 {
 		 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_YktCpuCard  u8BCDCurrentDate<ProcessTime",__FILE__,__LINE__);
 		 bRet=TRUE;
 	 }

 	 return bRet;
   }

     //检查进站超时。
   BOOL Check_Entry_Timeout_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo)
   {
 	  	 //未实现 ,不知如何判断
 	 return TRUE;
   }

     //进站次序检查。
   BOOL Check_Entry_Status_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo)
   {
 	   BOOL bRet=FALSE;

  	  char temp[20]={0};

  	  //进出站次序检查	CHAR	1	0：进出站均不检查进出站次序 1：进出站均检查进出站次序
  	  // 2：进站不检查进出站次序，出站检查进出站次序 3：进站检查进出站次序，出站不检查进出站次序
  	  temp[0]=g_BRContext.TicktPara0301.InOutOrderCheck[0];
  	  if(atoi(temp)==0||atoi(temp)==2)
  	  {
  	 	 PrintLog("File[%s]Line[%d] Check_Entry_Status_YktCpuCard  g_BRContext.TicktPara0301.InOutOrderCheck= [%d]",__FILE__,__LINE__,atoi(temp));
  	 	 return TRUE;
  	  }
 	 uint8 u8CurrentCardStatus=0;
 	 u8CurrentCardStatus=stYktCpuCardInfo.EF_17_03.CardStatus;

 	 switch(u8CurrentCardStatus)
 	 {

 	     case 0:
 		 case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES:		//e/s 初始化(init 1)
 		 case EM_TICKET_TRAVEL_STATUS_ISSUED:					// SJT发售(init 2)
 		 case EM_TICKET_TRAVEL_STATUS_EXITED:					// SJT发售(init 2)
 		 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:		//列车故障模式出站(exit during Train-disruption)
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA:	//非付费区免费更新(BOM/pca 非付费区)
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA:	//非付费区付费更新(BOM/pca 非付费区)
 			 bRet=TRUE;
 			 break;
 		 default:
 			 bRet=FALSE;
 			 break;

 	 }

 	 return bRet;
   }

     //余额低于最小票价。
BOOL Check_MinValue_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  stYktCpuCardInfo)
{
 uint8 cardType[2]={0};
 uint32 u32MinPrice=0;
 int iRet=-1;

 char temp[20]={0};


  memset(temp,0,sizeof(temp));

 ////是否检查余额/余次	CHAR	1	0：不检查，1：检查
  temp[0]=g_BRContext.TicktPara0301.RemainCheck[0];
  if(atoi(temp)==0)
  {
 	 PrintLog("File[%s]Line[%d] Check_MinValue_YktCpuCard  g_BRContext.TicktPara0301.RemainCheck= [%d]",__FILE__,__LINE__,atoi(temp));
 	 return TRUE;
  }

 cardType[0]=stYktCpuCardInfo.EF05.MainType;
 cardType[1]=stYktCpuCardInfo.EF05.SubType;

   iRet=BR_GetMinPrice(cardType,g_BRContext.bCurrentStationID,APIParam.ucTimeStamp,&u32MinPrice);
   if(iRet!=0)
   {
	   PrintLog("File[%s]Line[%d] Check_MinValue_YktCpuCard BR_GetMinPrice iRet=[%d]",__FILE__,__LINE__,iRet);
	   return FALSE;
   }

  if( htonl(stYktCpuCardInfo.Purse)<u32MinPrice)
  {
	  PrintLog("File[%s]Line[%d] Check_MinValue_YktCpuCard  remainningValue[%d]<u32MinPrice[%d]",__FILE__,__LINE__,stYktCpuCardInfo.Purse,u32MinPrice);
	  return FALSE;
  }

 return TRUE;
}

     //出站次序检查。
   BOOL Check_Exit_Status_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo)
   {
 	  BOOL bRet=FALSE;

 	  char temp[20]={0};

 	  //进出站次序检查	CHAR	1	0：进出站均不检查进出站次序 1：进出站均检查进出站次序
 	  // 2：进站不检查进出站次序，出站检查进出站次序 3：进站检查进出站次序，出站不检查进出站次序
 	  temp[0]=g_BRContext.TicktPara0301.InOutOrderCheck[0];
 	  if(atoi(temp)==0||atoi(temp)==3)
 	  {
 	 	 PrintLog("File[%s]Line[%d] Check_Exit_Status_YktCpuCard  g_BRContext.TicktPara0301.InOutOrderCheck= [%d]",__FILE__,__LINE__,atoi(temp));
 	 	 return TRUE;
 	  }
 	 uint8 u8CurrentCardStatus=0;
 	 u8CurrentCardStatus=stYktCpuCardInfo.EF_17_03.CardStatus;

 	 switch(u8CurrentCardStatus)
 	 {

 		 case EM_TICKET_TRAVEL_STATUS_ENTRY:					//已进站
 		 case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:				//出站票
 		 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:		//列车故障模式出站(exit during Train-disruption)
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
 		 case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
 			 bRet=TRUE;
 			 break;
 		 default:
 			 bRet=FALSE;
 			 break;

 	 }

 	 return bRet;
   }

   //非本站更新？
   BOOL Check_Update_ThisStation_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo)
   {
 	 BOOL bRet=FALSE;
 	 uint8 u8CurrentCardStatus=0;
 	 uint8 szUpdateStation[2]={0};
 	 u8CurrentCardStatus=stYktCpuCardInfo.EF_17_03.CardStatus;

 	 szUpdateStation[0]=stYktCpuCardInfo.EF_17_03.ProcessLine;
 	 szUpdateStation[1]=stYktCpuCardInfo.EF_17_03.ProcessStation;

 	 char temp[20]={0};
	  memset(temp,0,sizeof(temp));
	 //PaintPlaceCheck1[1];//付费区非本站更新检查标志	CHAR	1	0：不检查，1：检查
	  temp[0]=g_BRContext.TicktPara0301.PaintPlaceCheck1[0];
	  if(atoi(temp)==0)
	  {
		 PrintLog("File[%s]Line[%d] Check_Update_ThisDay_YktCpuCard  g_BRContext.TicktPara0301.PaintPlaceCheck1= [%d]",__FILE__,__LINE__,atoi(temp));
		 return TRUE;
	  }
 	 switch(u8CurrentCardStatus)
 	 {
 		 //case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
 		 case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
 		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
 			 {
 				if(memcmp(szUpdateStation,(char*)g_BRContext.bCurrentStationID,2)==0)
 				 {
 					 bRet=TRUE;
 				 }else
 				{
 					 bRet=Check_IsTranStaton(szUpdateStation,g_BRContext.bCurrentStationID);
 					 PrintLog("File[%s]Line[%d] Check_IsTranStaton bRet=[%d]",__FILE__,__LINE__,bRet);
 				 }
 			 }
 			 break;
 		 default:
 			 bRet=TRUE;
 			 break;

 	 }

 	 return bRet;
   }

  //非本日更新
 BOOL Check_Update_ThisDay_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  stYktCpuCardInfo)
 {
 	BOOL bRet=FALSE;
 	uint8 u8CurrentCardStatus=0;
 	uint32 u32UpdateTimeT=0;
 	uint32 u32CurrentTimeT=0;

	 char temp[20]={0};
	  memset(temp,0,sizeof(temp));
	 //PaintPlaceCheck2[1];//付费区非本日更新检查标志	CHAR	1	0：不检查，1：检查
	  temp[0]=g_BRContext.TicktPara0301.PaintPlaceCheck2[0];
	  if(atoi(temp)==0)
	  {
		 PrintLog("File[%s]Line[%d] Check_Update_ThisDay_YktCpuCard  g_BRContext.TicktPara0301.PaintPlaceCheck2= [%d]",__FILE__,__LINE__,atoi(temp));
		 return TRUE;
	  }


 	u8CurrentCardStatus=stYktCpuCardInfo.EF_17_03.CardStatus;

 	//u32UpdateTimeT=stYktCpuCardInfo.EF_17_03.ProcessTime;

 	BCD_to_TimeT(stYktCpuCardInfo.EF_17_03.ProcessTime,&u32UpdateTimeT);

 	BCD_to_TimeT(APIParam.ucTimeStamp,&u32CurrentTimeT);

 	switch(u8CurrentCardStatus)
 	{
 		case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
 		case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
 		case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
 		case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
 		case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
 			{
 	              if(u32CurrentTimeT<=u32UpdateTimeT+(24*3600))
 				  {
 					bRet=TRUE;
 				  }
 			}
 			break;
 		default:
 			bRet=TRUE;
 			break;

 	}

 	return bRet;
 }
   //出站超时
 BOOL Check_Exit_Timeout_YktCpuCard(StruAPIParam APIParam,uint16 u16JourneyTimeLimit,ST_CARD_YKT_CPU  stYktCpuCardInfo)
 {
	 BOOL bRet=TRUE;

	 uint8 szEntryTime[7]={0};
	 uint8 szStayTime[8]={0};

	if(g_BRContext.ucCurrentStationMode==EM_MODE_FREE_DATE)
	{
		PrintLog("File[%s]Line[%d] Check_Exit_Timeout_YktCpuCard ucCurrentStationMode==EM_MODE_FREE_DATE",__FILE__,__LINE__);
		return TRUE;
	}

	 ////是否检查超时	CHAR	1	0：不检查，1：检查
	 if(g_BRContext.TicktPara0301.OverTimeCheck[0]=='0')
	 {
		 bRet=TRUE;
		 return bRet;
	 }

	 memcpy(szEntryTime,stYktCpuCardInfo.EF_17_03.ProcessTime,7);

	 BCDTimeAddSeconds(u16JourneyTimeLimit*60,szEntryTime,szStayTime);

	 PrintLog("File[%s]Line[%d] Exit_YktCpuCard  Check_Exit_Timeout_YktCpuCard szEntryTime",__FILE__,__LINE__);
	 PrintBuffer(szEntryTime,7);

	 PrintLog("File[%s]Line[%d] Exit_YktCpuCard  Check_Exit_Timeout_YktCpuCard szStayTime",__FILE__,__LINE__);
	 PrintBuffer(szStayTime,7);

	if(memcmp(APIParam.ucTimeStamp,szStayTime,7)>0)
	{
		PrintLog("File[%s]Line[%d] Check_Exit_Timeout_YktCpuCard  超时",__FILE__,__LINE__);
	   bRet=FALSE;
	}
	 return bRet;
 }

   //出站超程
 BOOL Check_Exit_RemainningValue_YktCpuCard(uint32 *u32Price,ST_CARD_YKT_CPU  stYktCpuCardInfo)
 {
 	 BOOL bRet=FALSE;
 	long lCardValue=0;
 	 lCardValue=htonl(stYktCpuCardInfo.Purse);



 	 ////是否检查余额/余次	CHAR	1	0：不检查，1：检查
 	  if(g_BRContext.TicktPara0301.RemainCheck[0]=='0')
 	  {
 	 	 PrintLog("File[%s]Line[%d] Check_Exit_RemainningValue_YktCpuCard  g_BRContext.TicktPara0301.RemainCheck= [%d]",__FILE__,__LINE__,g_BRContext.TicktPara0301.RemainCheck[0]);
 	 	 return TRUE;
 	  }

 	 //是否检查超乘	CHAR	1	0：不检查，1：检查
	 if(g_BRContext.TicktPara0301.OverTaken[0]=='0')
	 {
		 bRet=TRUE;
		 return bRet;
	 }

 	 if(stYktCpuCardInfo.EF_17_03.CardStatus==EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION)
 	 {

 		 if(lCardValue<=(*u32Price))
 		 {
 			*u32Price=lCardValue;
 		 }


 		bRet=TRUE;
 		return bRet;
 	 }



 	if(lCardValue>=(*u32Price))
 	{
 	   bRet=TRUE;
 	}

 	 return bRet;
 }

int Analysis_YktCpuCard(StruAPIParam APIParam,uint8 u8IsDegradeMode,uint8 u8WorkArea,RetInfo * pRetInfo,BOMANALYZE * stAnalysis,TICKETLOCK * stTicketLock)
{

	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;
	BOOL bCardHasLocked=FALSE;

	memset(&m_stOperationStauts,0,sizeof(m_stOperationStauts));
	unsigned char u8stOperationStauts=0;

	char temp[32]={0};

	if(NULL==pRetInfo||NULL==stAnalysis||NULL==stTicketLock)
	{
		PrintLog("File[%s]Line[%d]Analysis_YktCpuCard RW_EC_INVALID_INPUT_PARAM",__FILE__,__LINE__);

		return RW_EC_INVALID_INPUT_PARAM;
	}

	if(u8WorkArea!=EM_CS_AREA_TYPE_PAID_AREA&&u8WorkArea!=EM_CS_AREA_TYPE_UNPAID_AREA)
	{
		PrintLog("File[%s]Line[%d]Analysis_YktCpuCard u8WorkArea[%d]",__FILE__,__LINE__,u8WorkArea);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	memset(&m_stYktCpuCardInfo,0,sizeof(m_stYktCpuCardInfo));

	iRet=Inner_Read_YktCpuCard(APIParam,&m_stYktCpuCardInfo,TRUE);
	PrintLog("File[%s]Line[%d]Inner_Read_YktCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	iRet= BR_GetParaTicketsTypeTable_h(m_stYktCpuCardInfo.EF05.MainType, m_stYktCpuCardInfo.EF05.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}

	// 物理卡号,
	memset(temp,0,sizeof(temp));

	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(stAnalysis->cPhysicalID,temp,20);

	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  cPhysicalID[%s]",__FILE__,__LINE__,stAnalysis->cPhysicalID);

	// 逻辑卡号
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			m_stYktCpuCardInfo.EF05.AppSn[0],
			m_stYktCpuCardInfo.EF05.AppSn[1],
			m_stYktCpuCardInfo.EF05.AppSn[2],
			m_stYktCpuCardInfo.EF05.AppSn[3],
			m_stYktCpuCardInfo.EF05.AppSn[4],
			m_stYktCpuCardInfo.EF05.AppSn[5],
			m_stYktCpuCardInfo.EF05.AppSn[6],
			m_stYktCpuCardInfo.EF05.AppSn[7]);
	strncpy(stAnalysis->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  cLogicalID[%s]",__FILE__,__LINE__,stAnalysis->cLogicalID);

	// 车票类型(主类型+子类型)
	stAnalysis->bTicketType[0]=m_stYktCpuCardInfo.EF05.MainType;
	stAnalysis->bTicketType[1]=m_stYktCpuCardInfo.EF05.SubType;
	PrintLog("File[%s]Line[%d]stAnalysis-> bTicketType[%02X%02X]",__FILE__,__LINE__,stAnalysis->bTicketType[0],stAnalysis->bTicketType[1]);
	// 余值

	stAnalysis->lBalance=htonl(m_stYktCpuCardInfo.Purse);
	PrintLog("File[%s]Line[%d]stAnalysis-> lBalance[%02X]",__FILE__,__LINE__,stAnalysis->lBalance);

	// 押金
	//memset(temp,0,sizeof(temp));
	//memcpy(temp,( char*)g_BRContext.TicktPara0301.Deposit,6);
	//stAnalysis->lDepositorCost=atoi(temp);
	stAnalysis->lDepositorCost=(m_stYktCpuCardInfo.EF05.SaleCardDeposit)*100;
	PrintLog("File[%s]Line[%d]stAnalysis-> lDepositorCost[%02X]",__FILE__,__LINE__,stAnalysis->lDepositorCost);
	// 车票最高上限值
	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.UpperLimit,6);
	stAnalysis->lLimitedBalance=atoi(temp);
	PrintLog("File[%s]Line[%d]stAnalysis-> lLimitedBalance[%02X]",__FILE__,__LINE__,stAnalysis->lLimitedBalance);
	// 发行时间
	memcpy(stAnalysis->bIssueData,m_stYktCpuCardInfo.EF05.IssueDate,4);
	PrintLog("File[%s]Line[%d]stAnalysis-> bIssueData",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->bIssueData,4);
	// 物理有效期截止时间(BCD)(无)
	memcpy(stAnalysis->bExpiry,m_stYktCpuCardInfo.EF05.CardValidDate,4);
	PrintLog("File[%s]Line[%d]stAnalysis-> bExpiry",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->bExpiry,4);

	// 逻辑有效期开始时间(BCD)
	memcpy(stAnalysis->bStartDate,m_stYktCpuCardInfo.EF15.CardStartDate,4);
	PrintLog("File[%s]Line[%d]stAnalysis-> bStartDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->bStartDate,7);

	//stAnalysis->bEndDate[7];					// 逻辑有效期结束时间(BCD)
	memcpy(stAnalysis->bEndDate,m_stYktCpuCardInfo.EF15.CardValidDate,4);
	stAnalysis->bEndDate[4]=0x23;
	stAnalysis->bEndDate[5]=0x59;
	stAnalysis->bEndDate[6]=0x59;

	PrintLog("File[%s]Line[%d]stAnalysis-> bEndDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->bEndDate,7);

	// 交易状态 m_stYktCpuCardInfo.EF_17_03.CardStatus;//
	stAnalysis->bStatus=ConvertYktCPUCardStatus(m_stYktCpuCardInfo.EF_17_03.CardStatus);//todo:
	PrintLog("File[%s]Line[%d]stAnalysis-> bStatus[%02X]",__FILE__,__LINE__,stAnalysis->bStatus);

	// 上次交易线路站点(BCD)
	//memcpy(&stAnalysis->bLastStationID[0],&m_stYktCpuCardInfo.EF_17_03.ProcessLine,1);//todo:
	//memcpy(&stAnalysis->bLastStationID[1],&m_stYktCpuCardInfo.EF_17_03.ProcessStation,1);//todo:
	stAnalysis->bLastStationID[0]=Byte_Decimal_to_BCD(m_stYktCpuCardInfo.EF_17_03.ProcessLine);
	stAnalysis->bLastStationID[1]=Byte_Decimal_to_BCD(m_stYktCpuCardInfo.EF_17_03.ProcessStation);
	PrintLog("File[%s]Line[%d]stAnalysis-> bLastStationID[%02X%02X]",__FILE__,__LINE__,stAnalysis->bLastStationID[0],stAnalysis->bLastStationID[1]);

	// 上次交易设备编号(BCD),第0字节仅低4bit有效

	memcpy(stAnalysis->bLastDeviceID,&m_stYktCpuCardInfo.EF_17_03.ProcessEquCode,2);//todo:
	//stAnalysis->bLastDeviceID[0]=stAnalysis->bLastDeviceID[0]&0x0F;
	stAnalysis->bLastDeviceID[0]=Byte_Decimal_to_BCD(stAnalysis->bLastDeviceID[0]&0x0F);
	PrintLog("File[%s]Line[%d]stAnalysis-> bLastDeviceID[%02X%02X]",__FILE__,__LINE__,stAnalysis->bLastDeviceID[0],stAnalysis->bLastDeviceID[1]);


	// 上次交易设备类型
	stAnalysis->bLastDeviceType=(m_stYktCpuCardInfo.EF_17_03.ProcessEquCode&0x00F0)>>4; //todo:
	PrintLog("File[%s]Line[%d]stAnalysis-> bLastDeviceType[%02X][%d]",__FILE__,__LINE__,stAnalysis->bLastDeviceType,m_stYktCpuCardInfo.EF_17_03.ProcessEquCode);

	// 上次交易时间
	memcpy(stAnalysis->dtLastDate,m_stYktCpuCardInfo.EF_17_03.ProcessTime,7);
	PrintLog("File[%s]Line[%d]stAnalysis-> dtLastDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->dtLastDate,7);

	// 上次进站站点
	stAnalysis->bEntrySationID[0]=Byte_Decimal_to_BCD(m_stYktCpuCardInfo.EF_17_03.InGateLine);
	stAnalysis->bEntrySationID[1]=Byte_Decimal_to_BCD(m_stYktCpuCardInfo.EF_17_03.InGateStation);
	PrintLog("File[%s]Line[%d]stAnalysis-> bEntrySationID[%02X%02X]",__FILE__,__LINE__,stAnalysis->bEntrySationID[0],stAnalysis->bEntrySationID[1]);

	//上次进站时间
	memcpy(stAnalysis->dtEntryDate,m_stYktCpuCardInfo.EF_17_03.InGateTime,7);
	PrintLog("File[%s]Line[%d]stAnalysis-> dtEntryDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->dtEntryDate,7);

	// 消费计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,m_stYktCpuCardInfo.LocalHistory[0],2);
	stAnalysis->lTradeCount=htons(usTempTradeCount);
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  lTradeCount= [0x%02X]",__FILE__,__LINE__,stAnalysis->lTradeCount);

	// 充值计数
	unsigned short usTempChargeCount=0;
	memcpy(&usTempChargeCount,m_stYktCpuCardInfo.RechargeHistory[0],2);
	stAnalysis->lChargeCount=htons(usTempChargeCount);
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  lChargeCount= [0x%02X]",__FILE__,__LINE__,stAnalysis->lChargeCount);

	stAnalysis->cTestFlag='1';		// 卡应用标识
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  cTestFlag= [0x%02X]",__FILE__,__LINE__,stAnalysis->cTestFlag);

	// 城市代码
	sprintf(stAnalysis->cCityCode,"%02X%02X",m_stYktCpuCardInfo.EF05.CityCode[0],m_stYktCpuCardInfo.EF05.CityCode[1]);
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  cCityCode= [0x%02X%02X]",__FILE__,__LINE__,m_stYktCpuCardInfo.EF05.CityCode[0],m_stYktCpuCardInfo.EF05.CityCode[1]);

	// 发行商代码
	sprintf(stAnalysis->cSellerCode,"%02X%02X",m_stYktCpuCardInfo.EF05.IssuerCode[0],m_stYktCpuCardInfo.EF05.IssuerCode[1]);
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  cSellerCode= [0x%02X%02X]",__FILE__,__LINE__,m_stYktCpuCardInfo.EF05.IssuerCode[0],m_stYktCpuCardInfo.EF05.IssuerCode[1]);

	//// 证件类型
	stAnalysis->bCertificateType=m_stYktCpuCardInfo.EF16.PersonIDType==0xff?0:m_stYktCpuCardInfo.EF16.PersonIDType;

	//证件代码
	unsigned char szTempFF[10]={0xFF,0xFF,0xFF,0xFF,0xFF};

	if(memcmp(m_stYktCpuCardInfo.EF16.PersonID,szTempFF,4)==0)
	{
		memset(temp,0x20,sizeof(temp));
		memcpy(stAnalysis->cCertificateCode,temp,20);
	}else
	{
	  memcpy(stAnalysis->cCertificateCode,m_stYktCpuCardInfo.EF16.PersonID,20);
	}
	//证件持有人姓名
	if(memcmp(m_stYktCpuCardInfo.EF16.PersonName,szTempFF,4)==0)
	{
		memset(temp,0x20,sizeof(temp));
		memcpy(stAnalysis->cCertificateName,temp,20);
	}else
	{
		memcpy(stAnalysis->cCertificateName,m_stYktCpuCardInfo.EF16.PersonName,10);
	}




	//证件有效期
	if(m_stYktCpuCardInfo.EF06.AuditDate[0]!=0)
	{
	 stAnalysis->bCertExpire[0]=0x20;
	}
	memcpy(stAnalysis->bCertExpire+1,m_stYktCpuCardInfo.EF06.AuditDate,3);

	//卡应用模式
	stAnalysis->cTkAppMode='1';


	// 充值上限，可充值标志位非0时有效
	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.TopUplimit,6);
	stAnalysis->lChargeUpper=atoi(temp);
	PrintLog("File[%s]Line[%d]stAnalysis-> lChargeUpper[%02X]",__FILE__,__LINE__,stAnalysis->lChargeUpper);

	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.TopUp,1);
	int iAllowTopup=atoi(temp);
	PrintLog("File[%s]Line[%d]iAllowTopup[%02X]",__FILE__,__LINE__,iAllowTopup);

	//检查卡是否在黑名单参数中
	bRet=Verify_Blacklist_YktCpuCard(m_stYktCpuCardInfo);
	PrintLog("File[%s]Line[%d]Verify_Blacklist_YktCpuCard bRet[%d]",__FILE__,__LINE__,bRet);

	//检查卡是否已锁。
	bCardHasLocked=Verify_IsLocked_YktCpuCard(m_stYktCpuCardInfo);
	PrintLog("File[%s]Line[%d]Verify_IsLocked_YktCpuCard bCardHasLocked[%d]",__FILE__,__LINE__,bCardHasLocked);


	if(bRet==TRUE)
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==FALSE)
		{
		   iRet=Inner_Lock_YktCpuCard( APIParam, pRetInfo,stTicketLock);
		   PrintLog("File[%s]Line[%d]Inner_Lock_YktCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
		   if(iRet!=CE_OK)
		   {
			   pRetInfo->wErrCode=RW_EC_WRITE_FAILED;
			   return CE_OK;
		   }
		}
		//是否可解锁
		m_stOperationStauts.bAllowUnlock=FALSE;

		pRetInfo->wErrCode=RW_EC_BLACKLIST;
		return CE_OK;

	}else
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==TRUE)
		{
			//是否可解锁
			m_stOperationStauts.bAllowUnlock=TRUE;
			memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
			stAnalysis->dwOperationStauts=u8stOperationStauts;
			PrintLog("File[%s]Line[%d] stAnalysis.dwOperationStauts = [0x%02x]",__FILE__,__LINE__,stAnalysis->dwOperationStauts);
			pRetInfo->wErrCode=RW_EC_BLACKLIST;
			return CE_OK;
		}

	}
	//检查车票状态是否正确。
	bRet=Check_Ticket_Status_YktCpuCard(m_stYktCpuCardInfo);
	PrintLog("File[%s]Line[%d]Check_Ticket_Status_YktCpuCard bRet[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_STATUS_CODE;
		return CE_OK;
	}
	//检查余额是否超出上限。
	bRet=Check_Ticket_Value_Uplimit_YktCpuCard(m_stYktCpuCardInfo);
	PrintLog("File[%s]Line[%d]Check_Ticket_Value_Uplimit_YktCpuCard bRet[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return CE_OK;
	}
	//检查车票是否过期。
	bRet=Check_Ticket_Valid_YktCpuCard(APIParam,&m_stYktCpuCardInfo);
	PrintLog("File[%s]Line[%d]Check_Ticket_Valid_YktCpuCard bRet[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		return CE_OK;
	}
	PrintLog("File[%s]Line[%d]Check_Ticket_Valid_YktCpuCard u8WorkArea[%d]",__FILE__,__LINE__,u8WorkArea);
	switch(u8WorkArea)
	{
	  case EM_CS_AREA_TYPE_PAID_AREA:
	  	bRet=Check_Exit_DateTime_Order_YktCpuCard( APIParam,m_stYktCpuCardInfo);
		  PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  Check_Exit_DateTime_Order_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
		  if(!bRet)
			{
				pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
				return CE_OK;
			}
		  PaidArea_Analysis_YktCpuCard(APIParam,m_stYktCpuCardInfo, pRetInfo,stAnalysis);
		break;
	  case EM_CS_AREA_TYPE_UNPAID_AREA:
		  UnpaidArea_Analysis_YktCpuCard(APIParam,m_stYktCpuCardInfo, pRetInfo,stAnalysis);
		  break;
	}

	if(g_BRContext.TicktPara0301.Refund[0]=='0')
	{
		m_stOperationStauts.bAllowRefund=FALSE;
	}

	if(g_BRContext.TicktPara0301.Delay[0]=='0')
	{
		m_stOperationStauts.bAllowDelay=FALSE;
	}




	memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
	stAnalysis->dwOperationStauts=u8stOperationStauts;
	PrintLog("File[%s]Line[%d] stAnalysis.dwOperationStauts = [0x%02x]",__FILE__,__LINE__,stAnalysis->dwOperationStauts);
	return CE_OK;
}

 int Inner_Lock_YktCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETLOCK * stLockInfo)
 {
	int iRet=-1;
	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;
	//入参检查.
	if(NULL==pRetInfo||NULL==stLockInfo)
	{
		return CE_CHECKERROR;
	}

	//特殊标记
	m_stYktCpuCardInfo.sz3F00_1A[0]=0x53;//黑名单
	m_stYktCpuCardInfo.sz3F00_1A[1]=0x4B;


	iRet=Inner_Write6_YktCpuCard(APIParam,0,m_stYktCpuCardInfo,u8TAC,&u32TerminalTradeNum);
	PrintLog("File[%s]Line[%d] Inner_Lock_YktCpuCard Inner_Write_YktCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}
	iRet=Write_Blacklist(&m_stYktCpuCardInfo);
	PrintLog("File[%s]Line[%d] Inner_Lock_YktCpuCard Write_Blacklist iRet[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	stLockInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	//组UD
	Fill_Lock_YktCpuCard_UD(APIParam,m_stYktCpuCardInfo,stLockInfo);

	//1：加锁；2：解锁
	stLockInfo->cLockFlag='1';

	stLockInfo->bStatus=RW_LIFECODE_LOCK;

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;
 }


 int Decrease_YktCpuCard(StruAPIParam APIParam,uint32 u32DecreaseValue,RetInfo * pRetInfo,PURSETRADE *stPurseInfo)
 {
	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;

	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;
	if(NULL==pRetInfo||NULL==stPurseInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	bRet=Verify_Issue_Device_YktCpuCard(g_BRContext.emCurrentDeviceType);
	if(!bRet)
	{
		// 参数不允许当前设备发售车票。
		pRetInfo->wErrCode=RW_EC_INVALID_API_CALL;
		return pRetInfo->wErrCode;
	}

	iRet=Inner_Write6_YktCpuCard(APIParam,u32DecreaseValue,m_stYktCpuCardInfo,u8TAC,&u32TerminalTradeNum);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD

	// SAM卡脱机交易流水号
	stPurseInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	//stPurseInfo
	stPurseInfo->bStatus=RW_LIFECODE_DEBIT;

	Fill_Purse_YktCpuCard_UD(APIParam,m_stYktCpuCardInfo,stPurseInfo);

	stPurseInfo->lTradeAmount=u32DecreaseValue;
	stPurseInfo->lBalance=(htonl(m_stYktCpuCardInfo.Purse)-u32DecreaseValue);

	stPurseInfo->cClassicType[0]='0';
	stPurseInfo->cClassicType[1]='6';

	if(g_BRContext.emCurrentDeviceType==EM_DEVICE_TYPE_TVM)
	{
		stPurseInfo->cPaymentType[0]='4';
		stPurseInfo->cPaymentType[1]='9';
	}else
	{
		stPurseInfo->cPaymentType[0]='4';
		stPurseInfo->cPaymentType[1]='A';
	}

	PrintLog("File[%s]Line[%d] Exit_YktCpuCard  cMACorTAC [%02X%02X%02X%02X]",__FILE__,__LINE__,u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);
	// SAM生成的交易检查代码
	sprintf(stPurseInfo->cMACorTAC,"%02X%02X%02X%02X",u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);

	pRetInfo->wErrCode=0;

	return CE_OK;
 }

 int Query_YktCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETINFO * stTicketInfo)
 {

	int iRet=-1;
	//BOOL bRet=FALSE;
	char temp[32]={0};
	ST_CARD_YKT_CPU stCardInfo;
	memset(&stCardInfo,0,sizeof(ST_CARD_YKT_CPU));

	if(NULL==pRetInfo||NULL==stTicketInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	iRet=Inner_Read_YktCpuCard(APIParam,&stCardInfo,TRUE);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}
	iRet= BR_GetParaTicketsTypeTable_h(stCardInfo.EF05.MainType, stCardInfo.EF05.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}
//	//根据卡信息 判断卡的发行有效性。
//	iRet=Verify_Issue_YktCpuCard(stCardInfo);
//	if(CE_OK!=iRet)
//	{
//		// 有效性不通过，返回 无效卡。
//		pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
//		return pRetInfo->wErrCode;
//	}

	// 物理卡号,
	memset(temp,0,sizeof(temp));

	sprintf(temp,"%02X%02X%02X%02X000000",g_BRContext.szCardPhID[0],
			g_BRContext.szCardPhID[1],
			g_BRContext.szCardPhID[2],
			g_BRContext.szCardPhID[3]);
	strncpy(stTicketInfo->cPhysicalID,temp,20);

	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  cPhysicalID[%s]",__FILE__,__LINE__,stTicketInfo->cPhysicalID);

	// 逻辑卡号
	memset(temp,0,sizeof(temp));
	sprintf(temp,"0000%02X%02X%02X%02X%02X%02X%02X%02X",
			stCardInfo.EF05.AppSn[0],
			stCardInfo.EF05.AppSn[1],
			stCardInfo.EF05.AppSn[2],
			stCardInfo.EF05.AppSn[3],
			stCardInfo.EF05.AppSn[4],
			stCardInfo.EF05.AppSn[5],
			stCardInfo.EF05.AppSn[6],
			stCardInfo.EF05.AppSn[7]);
	strncpy(stTicketInfo->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  cLogicalID[%s]",__FILE__,__LINE__,stTicketInfo->cLogicalID);

	// 车票类型(主类型+子类型)
	stTicketInfo->bTicketType[0]=stCardInfo.EF05.MainType;
	stTicketInfo->bTicketType[1]=stCardInfo.EF05.SubType;
	PrintLog("File[%s]Line[%d]stTicketInfo-> bTicketType[%02X%02X]",__FILE__,__LINE__,stTicketInfo->bTicketType[0],stTicketInfo->bTicketType[1]);
	// 余值

	stTicketInfo->lBalance=htonl(stCardInfo.Purse);
	PrintLog("File[%s]Line[%d]stTicketInfo-> lBalance[%02X]",__FILE__,__LINE__,stTicketInfo->lBalance);

	// 押金
	//memset(temp,0,sizeof(temp));
	//memcpy(temp,( char*)g_BRContext.TicktPara0301.Deposit,6);
	//stTicketInfo->lDepositorCost=atoi(temp);
	stTicketInfo->lDepositorCost=(stCardInfo.EF05.SaleCardDeposit)*100;
	PrintLog("File[%s]Line[%d]stTicketInfo-> lDepositorCost[%02X]",__FILE__,__LINE__,stTicketInfo->lDepositorCost);
	// 车票最高上限值
	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.UpperLimit,6);
	stTicketInfo->lLimitedBalance=atoi(temp);
	PrintLog("File[%s]Line[%d]stTicketInfo-> lLimitedBalance[%02X]",__FILE__,__LINE__,stTicketInfo->lLimitedBalance);
	// 发行时间
	memcpy(stTicketInfo->bIssueData,stCardInfo.EF05.IssueDate,4);
	PrintLog("File[%s]Line[%d]stTicketInfo-> bIssueData",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->bIssueData,4);
	// 物理有效期截止时间(BCD)(无)
	memcpy(stTicketInfo->bExpiry,stCardInfo.EF05.CardValidDate,4);
	PrintLog("File[%s]Line[%d]stTicketInfo-> bExpiry",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->bExpiry,4);

	// 逻辑有效期开始时间(BCD)
	memcpy(stTicketInfo->bStartDate,stCardInfo.EF15.CardStartDate,4);
	PrintLog("File[%s]Line[%d]stTicketInfo-> bStartDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->bStartDate,7);

	//stTicketInfo->bEndDate[7];					// 逻辑有效期结束时间(BCD)
	memcpy(stTicketInfo->bEndDate,stCardInfo.EF15.CardValidDate,4);
	stTicketInfo->bEndDate[4]=0x23;
	stTicketInfo->bEndDate[5]=0x59;
	stTicketInfo->bEndDate[6]=0x59;

	PrintLog("File[%s]Line[%d]stTicketInfo-> bEndDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->bEndDate,7);

	// 交易状态 stCardInfo.EF_17_03.CardStatus;//
	stTicketInfo->bStatus=ConvertYktCPUCardStatus(stCardInfo.EF_17_03.CardStatus);//todo:
	PrintLog("File[%s]Line[%d]stTicketInfo-> bStatus[%02X]",__FILE__,__LINE__,stTicketInfo->bStatus);

	// 上次交易线路站点(BCD)
	memcpy(&stTicketInfo->bLastStationID[0],&stCardInfo.EF_17_03.ProcessLine,1);//todo:
	memcpy(&stTicketInfo->bLastStationID[1],&stCardInfo.EF_17_03.ProcessStation,1);//todo:
	PrintLog("File[%s]Line[%d]stTicketInfo-> bLastStationID[%02X%02X]",__FILE__,__LINE__,stTicketInfo->bLastStationID[0],stTicketInfo->bLastStationID[1]);

	// 上次交易设备编号(BCD),第0字节仅低4bit有效

	memcpy(stTicketInfo->bLastDeviceID,&stCardInfo.EF_17_03.ProcessEquCode,2);//todo:
	stTicketInfo->bLastDeviceID[0]=stTicketInfo->bLastDeviceID[0]&0x0F;
	PrintLog("File[%s]Line[%d]stTicketInfo-> bLastDeviceID[%02X%02X]",__FILE__,__LINE__,stTicketInfo->bLastDeviceID[0],stTicketInfo->bLastDeviceID[1]);


	// 上次交易设备类型
	stTicketInfo->bLastDeviceType=(stCardInfo.EF_17_03.ProcessEquCode&0x00F0)>>4; //todo:
	PrintLog("File[%s]Line[%d]stTicketInfo-> bLastDeviceType[%02X][%d]",__FILE__,__LINE__,stTicketInfo->bLastDeviceType,stCardInfo.EF_17_03.ProcessEquCode);

	// 上次交易时间
	memcpy(stTicketInfo->dtLastDate,stCardInfo.EF_17_03.ProcessTime,7);
	PrintLog("File[%s]Line[%d]stTicketInfo-> dtLastDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->dtLastDate,7);

	// 上次进站站点
	stTicketInfo->bEntrySationID[0]=stCardInfo.EF_17_03.InGateLine;
	stTicketInfo->bEntrySationID[1]=stCardInfo.EF_17_03.InGateStation;
	PrintLog("File[%s]Line[%d]stTicketInfo-> bEntrySationID[%02X%02X]",__FILE__,__LINE__,stTicketInfo->bEntrySationID[0],stTicketInfo->bEntrySationID[1]);

	//上次进站时间
	memcpy(stTicketInfo->dtEntryDate,stCardInfo.EF_17_03.InGateTime,7);
	PrintLog("File[%s]Line[%d]stTicketInfo-> dtEntryDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stTicketInfo->dtEntryDate,7);

	// 消费计数
	unsigned short usTempTradeCount=0;
	memcpy(&usTempTradeCount,stCardInfo.LocalHistory[0],2);
	stTicketInfo->lTradeCount=htons(usTempTradeCount);
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  lTradeCount= [0x%02X]",__FILE__,__LINE__,stTicketInfo->lTradeCount);

	// 充值计数
	unsigned short usTempChargeCount=0;
	memcpy(&usTempChargeCount,stCardInfo.RechargeHistory[0],2);
	stTicketInfo->lChargeCount=htons(usTempChargeCount);
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  lChargeCount= [0x%02X]",__FILE__,__LINE__,stTicketInfo->lChargeCount);

	stTicketInfo->cTestFlag='1';		// 卡应用标识
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  cTestFlag= [0x%02X]",__FILE__,__LINE__,stTicketInfo->cTestFlag);

	// 城市代码
	sprintf(stTicketInfo->cCityCode,"%02X%02X",stCardInfo.EF05.CityCode[0],stCardInfo.EF05.CityCode[1]);
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  cCityCode= [0x%02X%02X]",__FILE__,__LINE__,stCardInfo.EF05.CityCode[0],stCardInfo.EF05.CityCode[1]);

	// 发行商代码
	sprintf(stTicketInfo->cSellerCode,"%02X%02X",stCardInfo.EF05.IssuerCode[0],stCardInfo.EF05.IssuerCode[1]);
	PrintLog("File[%s]Line[%d] Analysis_YktCpuCard  cSellerCode= [0x%02X%02X]",__FILE__,__LINE__,stCardInfo.EF05.IssuerCode[0],stCardInfo.EF05.IssuerCode[1]);

	//// 证件类型
	stTicketInfo->bCertificateType=stCardInfo.EF16.PersonIDType;

	//证件代码
	memcpy(stTicketInfo->cCertificateCode,stCardInfo.EF16.PersonID,20);

	//证件持有人姓名
	memcpy(stTicketInfo->cCertificateName,stCardInfo.EF16.PersonName,10);

	//证件有效期
	if(stCardInfo.EF06.AuditDate[0]!=0)
	{
		stTicketInfo->bCertExpire[0]=0x20;
	}
	memcpy(stTicketInfo->bCertExpire+1,stCardInfo.EF06.AuditDate,3);

	//卡应用模式
	stTicketInfo->cTkAppMode='1';


	ST_YKT_CPU_CARD_HISTORY stHistory1;
	memset(&stHistory1,0,sizeof(ST_YKT_CPU_CARD_HISTORY));


	ST_YKT_CPU_CARD_HISTORY stTempHistory[20];

	memset(stTempHistory,0,sizeof(stTempHistory));

	int i=0;
	int j=0;
	int icount=0;
	for(i=0;i<10;i++)
	{
		if(memcmp(&stCardInfo.LocalHistory[i][16],stTicketInfo->bEndDate,7)<0)
		{
		   memcpy(&stTempHistory[icount],&stCardInfo.LocalHistory[i],sizeof(ST_YKT_CPU_CARD_HISTORY));
		   icount++;
		}
	}
	for(i=0;i<10;i++)
	{
		if(memcmp(&stCardInfo.RechargeHistory[i][16],stTicketInfo->bEndDate,7)<0)
		{
		   memcpy(&stTempHistory[icount],&stCardInfo.RechargeHistory[i],sizeof(ST_YKT_CPU_CARD_HISTORY));
		   icount++;
		}
	}

	stTicketInfo->bUsefulCount=icount>17?17:icount;

	//memcpy(stTempHistory,stCardInfo.LocalHistory,sizeof(stCardInfo.LocalHistory));

	//memcpy(stTempHistory+10,stCardInfo.RechargeHistory,sizeof(stCardInfo.RechargeHistory));


	//排序

	for(i=stTicketInfo->bUsefulCount; i>0;--i)
	{
		for(j = 0; j < i; ++j)
		{

			if(memcmp(stTempHistory[j+1].TranTime,stTempHistory[j].TranTime,7)>0)
			{
				memcpy(&stHistory1,&stTempHistory[j],sizeof(ST_YKT_CPU_CARD_HISTORY));
				memcpy(&stTempHistory[j],&stTempHistory[j+1],sizeof(ST_YKT_CPU_CARD_HISTORY));
				memcpy(&stTempHistory[j+1],&stHistory1,sizeof(ST_YKT_CPU_CARD_HISTORY));
			}
		}

	}

	//转换
	ST_YKT_CPU_CARD_HISTORY stHistory;
	for(i=0;i<stTicketInfo->bUsefulCount;i++)
	{
		memset(&stHistory,0,sizeof(ST_YKT_CPU_CARD_HISTORY));
		memcpy(&stHistory,&stTempHistory[i],23);
		stHistory.TranValue=htonl(stHistory.TranValue);
		memcpy(stTicketInfo->bhs[i].dtDate,stHistory.TranTime,7);

		if(stHistory.TranType==6)
		{
			stTicketInfo->bhs[i].bStatus=RW_LIFECODE_COMMON_CONSUMPTION;
		}else if(stHistory.TranType==9)
		{
			stTicketInfo->bhs[i].bStatus=RW_LIFECODE_COMPLEX_CONSUMPTION;
		}else
		{
			stTicketInfo->bhs[i].bStatus=RW_LIFECODE_REVALUATE;
		}

		stTicketInfo->bhs[i].lTradeAmount=stHistory.TranValue;
	}

	pRetInfo->wErrCode=0;

	return CE_OK;
 }

 int Update_YktCpuCard(StruAPIParam APIParam,uint8 u8UpdateCode,uint16 u16EntryStationCode,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRetInfo,TICKETUPDATE * stUpdateInfo)
 {

	int iRet=-1;
	//BOOL bRet=FALSE;
    unsigned int uiTranValue=0;
	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;
	uint8 updateArea=0;
	uint8 u8TranStatus=0;

	if(NULL==pRetInfo||NULL==stUpdateInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	PrintLog("File[%s]Line[%d] Update_ULCard  m_stOperationStauts.bAllowUpdate= [0x%02X]",__FILE__,__LINE__,m_stOperationStauts.bAllowUpdate);
	PrintLog("File[%s]Line[%d] Update_ULCard  u16EntryStationCode [0x%02X]",__FILE__,__LINE__,u16EntryStationCode);
	PrintLog("File[%s]Line[%d] Update_ULCard  m_stOperationStauts.bAllowUpdate= [0x%02X]",__FILE__,__LINE__,m_stOperationStauts.bAllowUpdate);

	if(!m_stOperationStauts.bAllowUpdate)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	char szEntryStationCode[10]={0};

	uint8 InGateLine=u16EntryStationCode&0x00FF;
	uint8 InGateStation=(u16EntryStationCode&0xFF00)>>8;

	sprintf(szEntryStationCode,"%02d%02d",InGateLine,InGateStation);

	//车票状态
	/*1：付费区出站超时
	2：付费区超乘
	3：付费区无进站码
	10：非付费区有进站码
	11：非付费区非本站进站
	12：非付费区进站超时；
	*/
	switch(u8UpdateCode)
	{
		case 1:
			m_stYktCpuCardInfo.EF_17_03.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT;
			updateArea='1';
			u8TranStatus=RW_LIFECODE_UPDATE_TIMEOUT;
			break;
		case 2:
			m_stYktCpuCardInfo.EF_17_03.CardStatus=EM_TICKET_TRAVEL_STATUS_RANGEOUT;
			updateArea='1';
			u8TranStatus=RW_LIFECODE_UPDATE_RANGEOUT;
			break;
		case 3:
		{
			iRet=BR_IsExsitStationCode(szEntryStationCode);
				if(iRet!=CE_OK)
				{
					pRetInfo->wErrCode = RW_EC_INVALID_STATION_CODE;// 错误码,非法的输入参数
					return pRetInfo->wErrCode;
				}

			m_stYktCpuCardInfo.EF_17_03.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION;
			m_stYktCpuCardInfo.EF_17_03.InGateLine=InGateLine;//u16EntryStationCode&0x00FF;
			m_stYktCpuCardInfo.EF_17_03.InGateStation=InGateStation;//(u16EntryStationCode&0xFF00)>>8;
			memcpy(m_stYktCpuCardInfo.EF_17_03.InGateTime,APIParam.ucTimeStamp,7);
			updateArea='1';
			u8TranStatus=RW_LIFECODE_UPDATE_NO_ENTRY_STATION;
		}
			break;
		case 10:
		case 11:
		case 12:
			if(u16TranValue>0)
			{
			    m_stYktCpuCardInfo.EF_17_03.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA;
			    u8TranStatus=RW_LIFECODE_UPDATE_PAYED_UNPAYAREA;
			}else
			{
				m_stYktCpuCardInfo.EF_17_03.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA;
				u8TranStatus=RW_LIFECODE_UPDATE_FREE_UNPAYAREA;
			}
			updateArea='2';
			break;
//		case 11:
//			m_stYktCpuCardInfo.EF_17_03.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA;
//			updateArea='2';
//			u8TranStatus=RW_LIFECODE_UPDATE_PAYED_UNPAYAREA;
//			break;
//		case 12:
//			m_stYktCpuCardInfo.EF_17_03.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA;
//			updateArea='2';
//			u8TranStatus=RW_LIFECODE_UPDATE_PAYED_UNPAYAREA;
//			break;
		default:
			pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
			return iRet;
	}

	if(u8PaymentType==2)//卡内支付
	{
		uiTranValue=u16TranValue;
	}

	iRet=Inner_Write_YktCpuCard(APIParam,0,m_stYktCpuCardInfo,u8TAC,&u32TerminalTradeNum);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD
	// SAM卡脱机交易流水号
	stUpdateInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	// 罚金支付方式  //01：现金，02：票卡
	stUpdateInfo->bPaymentMode=u8PaymentType;

	stUpdateInfo->nForfeiture=u16TranValue;

	//// 更新区域 1：付费区，2：非付费区
	stUpdateInfo->cUpdateZone=updateArea;
	stUpdateInfo->bUpdateReasonCode=Byte_Decimal_to_BCD(u8UpdateCode);
;

	stUpdateInfo->bStatus=u8TranStatus;

	Fill_Update_YktCpuCard_UD(APIParam,m_stYktCpuCardInfo,stUpdateInfo);

	pRetInfo->wErrCode=0;

	return CE_OK;
 }


 int Entry_YktCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,ENTRYGATE *stEntryInfo,TICKETLOCK * stLockInfo)
 {

	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;
	BOOL bCardHasLocked=FALSE;
	BOOL bAllowEntryInMode=FALSE;
	unsigned char DeviceID[2]={0};
	unsigned short usDeviceID=0;
	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;

	ST_CARD_YKT_CPU cardProcessInfo;
	memset(&cardProcessInfo,0,sizeof(ST_CARD_YKT_CPU));

	uint8 szLastProcessStation[2]={0};
	uint8 szLastProcessTime[7]={0};
	uint8 u8CardStatus=0;

	if(NULL==pRetInfo||NULL==stEntryInfo||NULL==stLockInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	g_BRContext.ucCurrentStationMode=GetLocalStationMode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID);

	PrintLog("File[%s]Line[%d]Entry_ULCard   CurrentStationMode=[%d]",__FILE__,__LINE__,g_BRContext.ucCurrentStationMode);

	if(g_BRContext.ucCurrentStationMode==EM_MODE_EMERGENCY
	  ||g_BRContext.ucCurrentStationMode==EM_MODE_TRAIN_FAULT
	  ||g_BRContext.ucCurrentStationMode==EM_MODE_FREE_ENTRY)
	{
		PrintLog("File[%s]Line[%d]Entry_ULCard   StationMode=EM_MODE_EMERGENCY",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}


	iRet=Inner_Read_YktCpuCard(APIParam,&cardProcessInfo,FALSE);
	PrintLog("File[%s]Line[%d] Entry_YktCpuCard  Inner_Read_YktCpuCard iRet= [%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		 pRetInfo->wErrCode=iRet;
		return iRet;
	}
	iRet= BR_GetParaTicketsTypeTable_h(cardProcessInfo.EF05.MainType, cardProcessInfo.EF05.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Entry_YktCpuCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}

	szLastProcessStation[0]=cardProcessInfo.EF_17_03.ProcessLine;
	szLastProcessStation[1]=cardProcessInfo.EF_17_03.ProcessStation;
	memcpy(szLastProcessTime,cardProcessInfo.EF_17_03.ProcessTime,7);
	u8CardStatus=cardProcessInfo.EF_17_03.CardStatus;

	//检查卡是否在黑名单参数中
	bRet=Verify_Blacklist_YktCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d]Verify_Blacklist_YktCpuCard bRet[%d]",__FILE__,__LINE__,bRet);

	//检查卡是否已锁。
	bCardHasLocked=Verify_IsLocked_YktCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d]Verify_IsLocked_YktCpuCard bCardHasLocked[%d]",__FILE__,__LINE__,bCardHasLocked);


	if(bRet==TRUE)
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==FALSE)
		{
		   iRet=Inner_Lock_YktCpuCard( APIParam, pRetInfo,stLockInfo);
		   PrintLog("File[%s]Line[%d]Inner_Lock_YktCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
		   if(iRet!=CE_OK)
		   {
			   pRetInfo->wErrCode=RW_EC_WRITE_FAILED;
			   return pRetInfo->wErrCode;
		   }
		}
		pRetInfo->wErrCode=RW_EC_BLACKLIST;
		return pRetInfo->wErrCode;

	}else
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==TRUE)
		{
			pRetInfo->wErrCode=RW_EC_BLACKLIST;
			return pRetInfo->wErrCode;
		}

	}

	//检查车票状态是否正确。
	bRet=Check_Ticket_Status_YktCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Entry_YktCpuCard  Check_Ticket_Status_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_STATUS_CODE;
		return pRetInfo->wErrCode;
	}
	//检查余额是否超出上限。
	bRet=Check_Ticket_Value_Uplimit_YktCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Entry_YktCpuCard  Check_Ticket_Value_Uplimit_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return pRetInfo->wErrCode;
	}
	//检查车票是否过期。
	bRet=Check_Ticket_Valid_YktCpuCard(APIParam,&cardProcessInfo);
	PrintLog("File[%s]Line[%d] Entry_YktCpuCard  Check_Ticket_Valid_YktCpuCard  bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		return pRetInfo->wErrCode;
	}
	//进站次序检查。
	bRet=Check_Entry_Status_YktCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Entry_YktCpuCard  Check_Entry_Status_YktCpuCard  bRet= [%d]",__FILE__,__LINE__,bRet);
	if((!bRet)&&(!bAllowEntryInMode))
	{
		bAllowEntryInMode=Allow_Entry_InDegradeMode(APIParam.ucTimeStamp,szLastProcessTime,szLastProcessStation,u8CardStatus);
		PrintLog("File[%s]Line[%d]Entry_YktCpuCard  Allow_Entry_InDegradeMode bAllowEntryInMode=[%d]",__FILE__,__LINE__,bAllowEntryInMode);
		if(!bAllowEntryInMode)
		{
		  pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
		  return pRetInfo->wErrCode;
		}
	}

	//余额低于最小票价。
	bRet=Check_MinValue_YktCpuCard(APIParam,cardProcessInfo);
	PrintLog("File[%s]Line[%d] Entry_YktCpuCard  Check_MinValue_YktCpuCard  bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_INSUFFICIENT;
		return pRetInfo->wErrCode;
	}

	//写卡准备
	//车票状态
	cardProcessInfo.EF_17_03.CardStatus=EM_TICKET_TRAVEL_STATUS_ENTRY;//:已进站
	cardProcessInfo.EF_17_03.InGateLine=g_BRContext.bCurrentLineID;
	cardProcessInfo.EF_17_03.InGateStation=g_BRContext.bCurrentStationID[1];
	memcpy(cardProcessInfo.EF_17_03.InGateTime,APIParam.ucTimeStamp,7);


	 BitstreamInitMasks();
	//设备类型设备编码
	memcpy(&usDeviceID,g_BRContext.bCurrentDeviceID,2);
	unsigned int uiDeviceID=htons(usDeviceID);


	BitStreamPack(g_BRContext.bCurrentDeviceTypeCode,DeviceID,0, 4);

	BitStreamPack(uiDeviceID,DeviceID,4, 12);

	PrintLog("File[%s]Line[%d]Entry_YktCpuCard uiDeviceID[%d],g_BRContext.bCurrentDeviceTypeCode[%d]",__FILE__,__LINE__,uiDeviceID,g_BRContext.bCurrentDeviceTypeCode);

	PrintLog("File[%s]Line[%d]Entry_YktCpuCard DeviceID[0x%02X%02X]",__FILE__,__LINE__,DeviceID[0],DeviceID[1]);

	memcpy(&cardProcessInfo.EF_17_03.InGateDeviceCode,DeviceID,2);



	iRet=Inner_Write_YktCpuCard(APIParam,0,cardProcessInfo,u8TAC,&u32TerminalTradeNum);
	PrintLog("File[%s]Line[%d] Entry_YktCpuCard  Inner_Write_YktCpuCard  iRet= [%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD
	// SAM卡脱机交易流水号
	stEntryInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	//stEntryInfo
	stEntryInfo->bStatus=RW_LIFECODE_ENTRY_STATION;

	Fill_Entry_YktCpuCard_UD(APIParam,cardProcessInfo,stEntryInfo);

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;

 }

 int Unlock_YktCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETLOCK * stLockInfo)
 {
	int iRet=-1;

	//入参检查.
	if(NULL==pRetInfo||NULL==stLockInfo)
	{
		return CE_CHECKERROR;
	}
	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;

	//特殊标记
	m_stYktCpuCardInfo.sz3F00_1A[0]=0x00;//黑名单
	m_stYktCpuCardInfo.sz3F00_1A[1]=0x00;


	iRet=Inner_Write6_YktCpuCard(APIParam,0,m_stYktCpuCardInfo,u8TAC,&u32TerminalTradeNum);
	PrintLog("File[%s]Line[%d] Inner_Lock_YktCpuCard Inner_Write_YktCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}
	iRet=Write_Blacklist(&m_stYktCpuCardInfo);
	PrintLog("File[%s]Line[%d] Inner_Lock_YktCpuCard Write_Blacklist iRet[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	stLockInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	//组UD
	Fill_Lock_YktCpuCard_UD(APIParam,m_stYktCpuCardInfo,stLockInfo);

	//BYTE		bStatus;					// 交易状态代码
	//char		cLockFlag;					// 加解锁标志

	//1：加锁；2：解锁
	stLockInfo->cLockFlag='2';

	stLockInfo->bStatus=RW_LIFECODE_UNLOCK;

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;
}


int Exit_YktCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,PURSETRADE *stPurseInfo,TICKETLOCK * stLockInfo)
{

	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;
	BOOL bCardHasLocked=FALSE;
	BOOL bHasFreeMode=FALSE;
	uint32 u32Price=0;
	 uint16 FareZone=0;
	 uint16 JourneyTimeLimit=0;
	 uint16 TimeoutsFines=0;
	 uint8  RidingTime=0;
	 uint8  TrainTicketTableID=0;
	 uint8 u8CardType[2]={0};
	 uint8 szProcessStation[2]={0};
	 uint8 u8EntryTime[7]={0};
	uint8 u8TAC[10]={0};
	uint32 u32TerminalTradeNum=0;

	ST_CARD_YKT_CPU cardProcessInfo;
	memset(&cardProcessInfo,0,sizeof(ST_CARD_YKT_CPU));

	if(NULL==pRetInfo||NULL==stPurseInfo||NULL==stLockInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	g_BRContext.ucCurrentStationMode=GetLocalStationMode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID);

	if(g_BRContext.ucCurrentStationMode==EM_MODE_EMERGENCY)
	{
		PrintLog("File[%s]Line[%d]Exit_YktCpuCard   StationMode=EM_MODE_EMERGENCY",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	iRet=Inner_Read_YktCpuCard(APIParam,&cardProcessInfo,FALSE);
	PrintLog("File[%s]Line[%d] Exit_YktCpuCard  Inner_Read_YktCpuCard iRet= [%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		 pRetInfo->wErrCode=iRet;
		return iRet;
	}
	iRet= BR_GetParaTicketsTypeTable_h(cardProcessInfo.EF05.MainType, cardProcessInfo.EF05.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Exit_YktCpuCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}

	u8CardType[0]=cardProcessInfo.EF05.MainType;
	u8CardType[1]=cardProcessInfo.EF05.SubType;
	szProcessStation[0]=cardProcessInfo.EF_17_03.InGateLine;
	szProcessStation[1]=cardProcessInfo.EF_17_03.InGateStation;

	memcpy(u8EntryTime,cardProcessInfo.EF_17_03.InGateTime,7);


	//检查卡是否在黑名单参数中
	bRet=Verify_Blacklist_YktCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d]Verify_Blacklist_YktCpuCard bRet[%d]",__FILE__,__LINE__,bRet);

	//检查卡是否已锁。
	bCardHasLocked=Verify_IsLocked_YktCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d]Verify_IsLocked_YktCpuCard bCardHasLocked[%d]",__FILE__,__LINE__,bCardHasLocked);


	if(bRet==TRUE)
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==FALSE)
		{
		   iRet=Inner_Lock_YktCpuCard( APIParam, pRetInfo,stLockInfo);
		   PrintLog("File[%s]Line[%d]Inner_Lock_YktCpuCard iRet[%d]",__FILE__,__LINE__,iRet);
		   if(iRet!=CE_OK)
		   {
			   pRetInfo->wErrCode=RW_EC_WRITE_FAILED;
			   return pRetInfo->wErrCode;
		   }
		}
		pRetInfo->wErrCode=RW_EC_BLACKLIST;
		return pRetInfo->wErrCode;

	}else
	{
		// todo:黑名单卡，锁卡;
		if(bCardHasLocked==TRUE)
		{
			pRetInfo->wErrCode=RW_EC_BLACKLIST;
			return pRetInfo->wErrCode;
		}

	}

	//检查车票状态是否正确。
	bRet=Check_Ticket_Status_YktCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_YktCpuCard  Check_Ticket_Status_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_STATUS_CODE;
		return pRetInfo->wErrCode;
	}
	//检查余额是否超出上限。
	bRet=Check_Ticket_Value_Uplimit_YktCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_YktCpuCard  Check_Ticket_Value_Uplimit_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return pRetInfo->wErrCode;
	}
	//检查车票是否过期。
	bRet=Check_Ticket_Valid_YktCpuCard(APIParam,&cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_YktCpuCard  Check_Ticket_Valid_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		return pRetInfo->wErrCode;
	}
	//出站次序检查。
	bRet=Check_Exit_Status_YktCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_YktCpuCard  Check_Exit_Status_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if((!bRet)&&(!bHasFreeMode))
	{
		bHasFreeMode=Allow_Exit_InFreeEntryStationCode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID,szProcessStation);
		if(!bHasFreeMode)
		{
			pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
			return pRetInfo->wErrCode;
		}
	}
	bRet=Check_Exit_DateTime_Order_YktCpuCard( APIParam,cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_YktCpuCard  Check_Exit_DateTime_Order_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		return pRetInfo->wErrCode;
	}
	//非本站更新
	bRet=Check_Update_ThisStation_YktCpuCard(cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_YktCpuCard  Check_Update_ThisStation_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_SATION;
		return pRetInfo->wErrCode;
	}
	//非本日更新
	bRet=Check_Update_ThisDay_YktCpuCard( APIParam,cardProcessInfo);
	PrintLog("File[%s]Line[%d] Exit_YktCpuCard  Check_Update_ThisDay_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_DATE;
		return pRetInfo->wErrCode;
	}
	//出站超时
	iRet=Get_Price_InDegrade(u8CardType,szProcessStation,u8EntryTime,APIParam.ucTimeStamp,
				&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&u32Price);
	 PrintLog("File[%s]Line[%d] Exit_YktCpuCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
	 PrintLog("File[%s]Line[%d] Exit_YktCpuCard  BR_CalcPrice JourneyTimeLimit= [%d] u32Price[%d]",__FILE__,__LINE__,JourneyTimeLimit,u32Price);
	if(iRet!=CE_OK)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return pRetInfo->wErrCode;
	}
	bRet=Check_Exit_Timeout_YktCpuCard(APIParam,JourneyTimeLimit,cardProcessInfo);//判断错误，要根据获取票价返回的参数。
	PrintLog("File[%s]Line[%d] Exit_YktCpuCard  Check_Exit_Timeout_YktCpuCard bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;
		return pRetInfo->wErrCode;
	}
	//出站超程
	bRet=Check_Exit_RemainningValue_YktCpuCard(&u32Price,cardProcessInfo);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_PAID_AREA;
		return pRetInfo->wErrCode;
	}

	//车票状态
	if(g_BRContext.ucCurrentStationMode==EM_MODE_TRAIN_FAULT)
	{
		stPurseInfo->bStatus=RW_LIFECODE_EXIT_TRAINFAULT;
		cardProcessInfo.EF_17_03.CardStatus=EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE;//列车故障模式出站(
		u32Price=0;//列车故障模式出站 不扣车费
	}else
	{
		cardProcessInfo.EF_17_03.CardStatus=EM_TICKET_TRAVEL_STATUS_EXITED;//:已出站
		stPurseInfo->bStatus=RW_LIFECODE_EXIT_STAION;
	}

	iRet=Inner_Write_YktCpuCard(APIParam,u32Price,cardProcessInfo,u8TAC,&u32TerminalTradeNum);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD
	// SAM卡脱机交易流水号
	stPurseInfo->lSAMTrSeqNo=u32TerminalTradeNum;

	Fill_Purse_YktCpuCard_UD(APIParam,cardProcessInfo,stPurseInfo);

	stPurseInfo->lTradeAmount=u32Price;
	stPurseInfo->lBalance=(htonl(cardProcessInfo.Purse)-u32Price);

	PrintLog("File[%s]Line[%d] Exit_YktCpuCard  cMACorTAC [%02X%02X%02X%02X]",__FILE__,__LINE__,u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);
	// SAM生成的交易检查代码
	sprintf(stPurseInfo->cMACorTAC,"%02X%02X%02X%02X",u8TAC[0],u8TAC[1],u8TAC[2],u8TAC[3]);

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;

}


int ConvertYktCPUCardStatus(unsigned char ucTicketStatus)
{
	/*EM_TICKET_TRAVEL_STATUS_INITIALIZATION			=1,	//e/s 初始化(init 0)
	EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES		=2,	//e/s 预赋值(init 1)
	EM_TICKET_TRAVEL_STATUS_ISSUED					=3,	// SJT发售(init 2)
	EM_TICKET_TRAVEL_STATUS_ENTRY					=4,	//已进站
	EM_TICKET_TRAVEL_STATUS_EXITED					=5,	//已出站
	EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE				=6,	//出站票
	EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE		=7,	//列车故障模式出站(exit during Train-disruption)
	EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA	=8,	//非付费区免费更新(BOM/pca 非付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA	=9,	//非付费区付费更新(BOM/pca 非付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION	=10,//无进站码更新(BOM/pca 付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT				=11,//出站码更新
	EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT			=12,//超时更新
	EM_TICKET_TRAVEL_STATUS_RANGEOUT				=13,//超乖更新
	EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT		=14,//免费出闸更新
	EM_TICKET_TRAVEL_STATUS_REFUND					=15,//已退卡*/
	unsigned char ucStatus=RW_STATUSCODE_UNKNOWN;
    switch(ucTicketStatus)
    {
        case EM_TICKET_TRAVEL_STATUS_INITIALIZATION:
        	ucStatus=RW_STATUSCODE_INITIALIZATION;
    	 break;
        case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES:
               	ucStatus=RW_STATUSCODE_PREVALUE_LOADED_ES;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_ISSUED:
               	ucStatus=RW_STATUSCODE_SALE_BOM_OR_TVM;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_ENTRY:
               	ucStatus=RW_STATUSCODE_ENTRY_STATION;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_EXITED:
               	ucStatus=RW_STATUSCODE_EXIT_STAION;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:
               	ucStatus=RW_STATUSCODE_ET_FOR_EXIT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:
               	ucStatus=RW_STATUSCODE_EXIT_TRAINFAULT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA:
               	ucStatus=RW_STATUSCODE_UPDATE_FREE_UNPAYAREA;
           	 break;

        case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA:
               	ucStatus=RW_STATUSCODE_UPDATE_PAYED_UNPAYAREA;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:
               	ucStatus=RW_STATUSCODE_UPDATE_NO_ENTRY_STATION;
           	 break;

        case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:
               	ucStatus=RW_STATUSCODE_UPDATE_EXIT_ATBOM;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:
               	ucStatus=RW_STATUSCODE_UPDATE_TIMEOUT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_RANGEOUT:
               	ucStatus=RW_STATUSCODE_UPDATE_RANGEOUT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:
               	ucStatus=RW_STATUSCODE_UPDATE_ENTRY_ATBOM;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_REFUND:
               	ucStatus=RW_STATUSCODE_REBACK_CARD;
           	 break;
    }

    return ucStatus;
}
