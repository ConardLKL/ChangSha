/*
 * DegradeModeBusinuess.c
 *
 *  Created on: Nov 29, 2015
 *      Author: root
 */

#include "DegradeModeBusinuess.h"



static HashDictionary  m_ModeNotifyList;

static DEGRADECMD m_stCurrentDegrade;


int InitModeList()
{

    Initialize(&m_ModeNotifyList,3);

    memset(&m_stCurrentDegrade,0,sizeof(m_stCurrentDegrade));

    return RW_EC_OK;
}

/*EM_MODE_NORMAL 				= 0x00,     //0 正常模式
	EM_MODE_TRAIN_FAULT 		= 0x01,		//1	列车故障模式（000000000000001B）
	EM_MODE_FREE_ENTRY			= 0x02,		//2	进站免检模式（000000000100000B）
	EM_MODE_FREE_DATE			= 0x03,		//3	日期免检模式（000000000000100B）
	EM_MODE_FREE_FARE			= 0x05,		//5	车费免检模式（000000000001000B））
	EM_MODE_EMERGENCY			= 0x06,		//6	紧急放行模式（000000010000000B）*/

BOOL CheckModeCode(uint8 ModeCode)
{
     switch(ModeCode)
     {
     case EM_MODE_NORMAL:
     case EM_MODE_TRAIN_FAULT:
     case EM_MODE_FREE_ENTRY:
     case EM_MODE_FREE_DATE:
     case EM_MODE_FREE_FARE:
     case EM_MODE_EMERGENCY:
    	 return TRUE;
     default:
    	 return FALSE;
     }
}

int SyncModeHistory(unsigned char *ucTime)
{


	BOOL bRet=FALSE;
	int iRet=-1;
	uint32 FileLen=0;
	uint8 * tmp_pFiledata=NULL;
	Para0501  stTmpPara;

	int iDegradeValidSeconds=0;

	char szKey[6]={0};
	char szMode[5]={0};
	char szTemp[20]={0};
	unsigned char szModeEndTime[8]={0};

	ST_RW_DEGRADECMD stTempDegradeCmd;
	memset(&stTempDegradeCmd,0,sizeof(ST_RW_DEGRADECMD));



	uint8 *pFile=NULL;
	//取得FileID对应的内存地址
	bRet=GetCDFilePointer(FILE_ACC_CHANGSHA_DEGRADE_HISTORY,&FileLen, &tmp_pFiledata);
	if(bRet==FALSE)return CE_CHECKERROR;//详细错误代码以后添加
	pFile=tmp_pFiledata;

	iRet=BR_GetDegradeValidDate(szTemp);
	if(iRet!=CE_OK)
	{
		PrintLog("File[%s]Line[%d]BR_GetDegradeValidDate   Failed",__FILE__,__LINE__);

		return -1;
	}

	iDegradeValidSeconds=atoi(szTemp)*24*60*60;


	uint32 pos=0;//偏移量

	uint32 k=0;


	for(k=0;k<(FileLen/sizeof(Para0501));k++)
	{
		memset(szModeEndTime,0,sizeof(szModeEndTime));
		memset(&stTmpPara,0,sizeof(Para0501));
		memcpy(&stTmpPara,  pFile+pos, sizeof(Para0501));

		//stationCode(2) + DegradeCode(1)
		memcpy(szKey,stTmpPara.StationCode,4);
		memcpy(szKey+4,&stTmpPara.ModeType[2],1);
		memcpy(szMode,stTmpPara.ModeType,3);

		stTempDegradeCmd.bDegradeType=atoi(szMode);



		stTempDegradeCmd.bFlag=0x01;
		memset(szTemp,0,sizeof(szTemp));
		memcpy(szTemp,stTmpPara.StationCode,4);
		StringToBcd(szTemp,stTempDegradeCmd.bStationID);

		stTempDegradeCmd.bStationID[0]=BCD_to_Decimal(stTempDegradeCmd.bStationID[0]);
		stTempDegradeCmd.bStationID[1]=BCD_to_Decimal(stTempDegradeCmd.bStationID[1]);
		memset(szTemp,0,sizeof(szTemp));
		memcpy(szTemp,stTmpPara.BeginDateTime,14);
		StringToBcd(szTemp,stTempDegradeCmd.bStartTime);

		memset(szTemp,0,sizeof(szTemp));
		memcpy(szTemp,stTmpPara.EndDateTime,14);
		StringToBcd(szTemp,stTempDegradeCmd.bEndTime);

		PrintLog("File[%s]Line[%d] SyncModeHistory  szKey[%s]",__FILE__,__LINE__,szKey);
		PrintLog("File[%s]Line[%d] SyncModeHistory  bDegradeType[%02d]",__FILE__,__LINE__,stTempDegradeCmd.bDegradeType);
		PrintLog("File[%s]Line[%d] SyncModeHistory  StationCode[%02d%02d]",__FILE__,__LINE__,stTempDegradeCmd.bStationID[0],stTempDegradeCmd.bStationID[1]);
		PrintLog("File[%s]Line[%d] SyncModeHistory  BeginDateTime",__FILE__,__LINE__);
		PrintBuffer(stTempDegradeCmd.bStartTime,7);
		PrintLog("File[%s]Line[%d] SyncModeHistory  bEndTime",__FILE__,__LINE__);
		PrintBuffer(stTempDegradeCmd.bEndTime,7);

		pos += sizeof(Para0501);

		if(!CheckModeCode(stTempDegradeCmd.bDegradeType))continue;

		if(BR_IsExsitStationCode((char *)stTmpPara.StationCode)!=0) continue;

		BCDTimeAddSeconds(iDegradeValidSeconds,stTempDegradeCmd.bStartTime,szModeEndTime);

		if(memcmp(ucTime,szModeEndTime,4)>0)continue;

		if(memcmp(stTempDegradeCmd.bStartTime,stTempDegradeCmd.bEndTime,7)<0)
		{
			stTempDegradeCmd.bFlag=0x02;
		}else
		{
			stTempDegradeCmd.bFlag=0x01;
		}

		Insert(&m_ModeNotifyList,szKey,&stTempDegradeCmd,FALSE);

		PrintLog("File[%s]Line[%d] SyncModeHistory  Inserted",__FILE__,__LINE__);


	}

	return CE_CHECKERROR;

}


BOOL ClearModeList(unsigned char *ucTime)
{

	ST_RW_DEGRADECMD stTempDegrade;

	int iRet=-1;
	char szTemp[5]={0};
	unsigned char szModeEndTime[7]={0};
	int iDegradeValidSeconds=0;
	if(NULL==ucTime)
	{
		 return FALSE;
	}

	iRet=BR_GetDegradeValidDate(szTemp);
	if(iRet!=CE_OK)
	{
		return FALSE;
	}

	iDegradeValidSeconds=atoi(szTemp)*24*60*60;

    int i = 0;
    for (; i >= 0; i = m_ModeNotifyList.entrys[i].next)
    {
    	memset(&stTempDegrade,0,sizeof(ST_RW_DEGRADECMD));

    	memcpy(&stTempDegrade,m_ModeNotifyList.entrys[i].value,sizeof(ST_RW_DEGRADECMD));

    	BCDTimeAddSeconds(iDegradeValidSeconds,stTempDegrade.bStartTime,szModeEndTime);

		if(memcmp(ucTime,szModeEndTime,4)>0)
		{
			Remove(&m_ModeNotifyList,m_ModeNotifyList.entrys[i].key);
		}

    }

    return FALSE;


}


int GetLocalStationMode(unsigned char * ucTime,unsigned char *pStationCode)
{

	unsigned char ucCurrentDegradeCode=EM_MODE_NORMAL;

	PrintLog("File[%s]Line[%d] GetLocalStationMode m_CurrentDegrade.bFlag[%d]",__FILE__,__LINE__,m_stCurrentDegrade.bFlag);
	//0x01 - 生效,0x02 - 取消
	if(m_stCurrentDegrade.bFlag==0x01)
	{
		ucCurrentDegradeCode=m_stCurrentDegrade.bDegradeType;
	}

	PrintLog("File[%s]Line[%d] GetLocalStationMode  ucCurrentDegradeCode[%d]",__FILE__,__LINE__,ucCurrentDegradeCode);

	return  ucCurrentDegradeCode;
}


int SetLocalStationMode(DEGRADECMD stDegradeCmd)
{

    BOOL bRet=FALSE;


    bRet=CheckStationMode(m_stCurrentDegrade,stDegradeCmd);

    if(!bRet)
    {
    	 return RW_EC_ILLEGAL_INPUT_PARAM;
    }

    memcpy(&m_stCurrentDegrade,&stDegradeCmd,sizeof(DEGRADECMD));


	return RW_EC_OK;

}


int SetStationModeNotifyList(unsigned char *ucTime,DEGRADECMD stDegradeCmd)
{
    int iRet=-1;

    char szKey[6]={0};

    ST_RW_DEGRADECMD stTempDegradeCmd;
    memset(&stTempDegradeCmd,0,sizeof(ST_RW_DEGRADECMD));

    //stationCode(2) + DegradeCode(1)
    sprintf(szKey,"%02d%02d%d",stDegradeCmd.bStationID[0],stDegradeCmd.bStationID[1],stDegradeCmd.bDegradeType);

    PrintLog("File[%s]Line[%d] SetStationModeNotifyList  ucCurrentDegradeCode[%d]",__FILE__,__LINE__,stDegradeCmd.bDegradeType);
    // clear invalid mode list

    Entry *pEntry=NULL;
    pEntry= FindEntry(&m_ModeNotifyList,szKey);

    PrintLog("File[%s]Line[%d] SetStationModeNotifyList  m_ModeNotifyList. count[%d]",__FILE__,__LINE__,m_ModeNotifyList.count);

    if(NULL!=pEntry)
	{
    	 PrintLog("File[%s]Line[%d] SetStationModeNotifyList  update key[%s]",__FILE__,__LINE__,szKey);
    	 memcpy(&stTempDegradeCmd,pEntry->value,sizeof(ST_RW_DEGRADECMD));
    	 if(stDegradeCmd.bFlag==0x01)
    	 {
    		 memcpy(stTempDegradeCmd.bStartTime,stDegradeCmd.bTime,7);
    		 PrintLog("File[%s]Line[%d] SetStationModeNotifyList  update bStartTime",__FILE__,__LINE__);
    		 PrintBuffer(stTempDegradeCmd.bStartTime,7);
    	 }else
    	 {
    		 stTempDegradeCmd.bFlag=stDegradeCmd.bFlag;
    		 memcpy(stTempDegradeCmd.bEndTime,stDegradeCmd.bTime,7);
    		 PrintLog("File[%s]Line[%d] SetStationModeNotifyList  update bEndTime",__FILE__,__LINE__);
    		 PrintBuffer(stTempDegradeCmd.bEndTime,7);
    	 }

    	 Insert(&m_ModeNotifyList,szKey,&stTempDegradeCmd,FALSE);

	}else
	{
		PrintLog("File[%s]Line[%d] SetStationModeNotifyList  Insert key[%s]",__FILE__,__LINE__,szKey);
		//插入新值
		stTempDegradeCmd.bDegradeType=stDegradeCmd.bDegradeType;
		memcpy(stTempDegradeCmd.bStationID,stDegradeCmd.bStationID,2);
		stTempDegradeCmd.bFlag=stDegradeCmd.bFlag;
		memcpy(stTempDegradeCmd.bStartTime,stDegradeCmd.bTime,7);
		iRet=Insert(&m_ModeNotifyList,szKey,&stTempDegradeCmd,FALSE);
		if(iRet==-1)
		{
			 return CE_FAIL;
		}
	}




	return RW_EC_OK;
}

int GetStationModeNotify(unsigned char * ucSysTime,unsigned char * ucTime,unsigned char *pStationCode,int iDegradeMode,ST_RW_DEGRADECMD *stDegradeCmd)
{
	char szKey[6]={0};

	Entry *pEntry=NULL;

	ST_RW_DEGRADECMD stTempDegrade;

	int iRet=-1;
	char szTemp[5]={0};
	unsigned char szModeStartTime[7]={0};
	unsigned char szModeEndTime[7]={0};
	int iDegradeValidSeconds=0;

	if(NULL==pStationCode||NULL==ucTime)
	{
		 return EM_MODE_NORMAL;
	}

	PrintLog("File[%s]Line[%d]GetStationModeNotify   iDegradeMode=[%d]",__FILE__,__LINE__,iDegradeMode);
	PrintLog("File[%s]Line[%d]GetStationModeNotify   ucTime",__FILE__,__LINE__);
	PrintBuffer(ucTime,7);
	PrintLog("File[%s]Line[%d]GetStationModeNotify   ucSysTime",__FILE__,__LINE__);
	PrintBuffer(ucSysTime,7);
	PrintLog("File[%s]Line[%d]GetStationModeNotify   pStationCode=[%02d%02d]",__FILE__,__LINE__,pStationCode[0],pStationCode[1]);


	iRet=BR_GetDegradeValidDate(szTemp);
	if(iRet!=CE_OK)
	{
		PrintLog("File[%s]Line[%d]BR_GetDegradeValidDate   Failed",__FILE__,__LINE__);

		return EM_MODE_NORMAL;
	}

	iDegradeValidSeconds=atoi(szTemp)*24*60*60;

	sprintf(szKey,"%02d%02d%d",pStationCode[0],pStationCode[1],iDegradeMode);

	pEntry= FindEntry(&m_ModeNotifyList,szKey);

	PrintLog("File[%s]Line[%d] GetStationModeNotify  szKey[%s]",__FILE__,__LINE__,szKey);


	if(NULL!=pEntry)
	{

		memcpy(&stTempDegrade,pEntry->value,sizeof(ST_RW_DEGRADECMD));

		if(stTempDegrade.bFlag==0x02)
		{
           memcpy(szModeStartTime,stTempDegrade.bEndTime,7);
		}else
		{
		   memcpy(szModeStartTime,stTempDegrade.bStartTime,7);
		}

		BCDTimeAddSeconds(iDegradeValidSeconds,szModeStartTime,szModeEndTime);

		PrintLog("File[%s]Line[%d] GetStationModeNotify  stTempDegrade.bStartTime",__FILE__,__LINE__);
		PrintBuffer(stTempDegrade.bStartTime,7);
		PrintLog("File[%s]Line[%d] GetStationModeNotify  stTempDegrade.bEndTime",__FILE__,__LINE__);
		PrintBuffer(stTempDegrade.bEndTime,7);


		PrintLog("File[%s]Line[%d] GetStationModeNotify  szModeStartTime",__FILE__,__LINE__);
		PrintBuffer(szModeStartTime,7);
		PrintLog("File[%s]Line[%d] GetStationModeNotify  szModeEndTime",__FILE__,__LINE__);
		PrintBuffer(szModeEndTime,7);

		//作用期
		if(stTempDegrade.bFlag==0x02&&((memcmp(ucTime,stTempDegrade.bStartTime,4)<0||memcmp(ucTime,stTempDegrade.bEndTime,4)>0)))
		{
			PrintLog("File[%s]Line[%d] GetStationModeNotify bFlag=0x02  Not in  zuoyongqi",__FILE__,__LINE__);
			return EM_MODE_NORMAL;
		}else if(stTempDegrade.bFlag==0x01&&(memcmp(ucTime,stTempDegrade.bStartTime,4)<0))
		{
			PrintLog("File[%s]Line[%d] GetStationModeNotify bFlag=0x01 Not in  zuoyongqi",__FILE__,__LINE__);
			return EM_MODE_NORMAL;
		}
		//敏感期
		if((memcmp(ucSysTime,szModeStartTime,4)>=0&&memcmp(ucSysTime,szModeEndTime,4)<=0))
		{
		   if(NULL!=stDegradeCmd)
		   {
              memcpy(stDegradeCmd,pEntry->value,sizeof(ST_RW_DEGRADECMD));
		   }
		   PrintLog("File[%s]Line[%d] GetStationModeNotify  stTempDegrade.bDegradeType[%d]",__FILE__,__LINE__,stTempDegrade.bDegradeType);
           return stTempDegrade.bDegradeType;
		}

	}

	if(NULL!=stDegradeCmd)
	{
	  stDegradeCmd->bDegradeType=EM_MODE_NORMAL;
	}

	return EM_MODE_NORMAL;

}

BOOL HasEmergencyModeInModeNotifyList(unsigned char * ucSysTime,unsigned char * ucTime)
{
	ST_RW_DEGRADECMD stTempDegrade;

	int iRet=-1;
	char szTemp[5]={0};
	unsigned char szModeStartTime[7]={0};
	unsigned char szModeEndTime[7]={0};
	int iDegradeValidSeconds=0;

	BOOL bRet=FALSE;

	if(NULL==ucTime)
	{
		 return FALSE;
	}
	PrintLog("File[%s]Line[%d]HasEmergencyModeInModeNotifyList   ucTime",__FILE__,__LINE__);
	PrintBuffer(ucTime,7);

	iRet=BR_GetDegradeValidDate(szTemp);
	if(iRet!=CE_OK)
	{
		PrintLog("File[%s]Line[%d]BR_GetDegradeValidDate   Failed",__FILE__,__LINE__);
		return FALSE;
	}

	PrintLog("File[%s]Line[%d] HasEmergencyModeInModeNotifyList  m_ModeNotifyList. count[%d]",__FILE__,__LINE__,m_ModeNotifyList.count);

	iDegradeValidSeconds=atoi(szTemp)*24*60*60;

    int i = 0;
    for (; i < m_ModeNotifyList.count; i ++)
    {

    	PrintLog("File[%s]Line[%d] HasEmergencyModeInModeNotifyList  m_ModeNotifyList. i[%d]",__FILE__,__LINE__,i);

    	memset(&stTempDegrade,0,sizeof(ST_RW_DEGRADECMD));

    	memcpy(&stTempDegrade,m_ModeNotifyList.entrys[i].value,sizeof(ST_RW_DEGRADECMD));

    	if(stTempDegrade.bDegradeType!=EM_MODE_EMERGENCY)
		{
			PrintLog("File[%s]Line[%d] HasEmergencyModeInModeNotifyList continue",__FILE__,__LINE__);
			continue;
		}

		if(stTempDegrade.bFlag==0x02)
		{
           memcpy(szModeStartTime,stTempDegrade.bEndTime,7);
		}else
		{
		   memcpy(szModeStartTime,stTempDegrade.bStartTime,7);
		}

    	BCDTimeAddSeconds(iDegradeValidSeconds,szModeStartTime,szModeEndTime);
    	PrintLog("File[%s]Line[%d] HasEmergencyModeInModeNotifyList szModeStartTime",__FILE__,__LINE__);
		PrintBuffer(szModeStartTime,7);
		PrintLog("File[%s]Line[%d] HasEmergencyModeInModeNotifyList szModeEndTime",__FILE__,__LINE__);
		PrintBuffer(szModeEndTime,7);

		//作用期
		if(stTempDegrade.bFlag==0x02&&((memcmp(ucTime,stTempDegrade.bStartTime,4)>=0&&memcmp(ucTime,stTempDegrade.bEndTime,4)<=0)))
		{
			PrintLog("File[%s]Line[%d] HasEmergencyModeInModeNotifyList bFlag=0x02   in  zuoyongqi",__FILE__,__LINE__);
			bRet= TRUE;
		}else if(stTempDegrade.bFlag==0x01&&(memcmp(ucTime,stTempDegrade.bStartTime,4)>=0))
		{
			PrintLog("File[%s]Line[%d] HasEmergencyModeInModeNotifyList bFlag=0x01  in  zuoyongqi",__FILE__,__LINE__);
			bRet= TRUE;
		}

		if(bRet)
		{
			//敏感期
			if((memcmp(ucSysTime,szModeStartTime,4)>=0&&memcmp(ucSysTime,szModeEndTime,4)<=0))
			{
			   PrintLog("File[%s]Line[%d] HasEmergencyModeInModeNotifyList return TRUE ",__FILE__,__LINE__);
			   return TRUE;
			}
			return FALSE;
		}
		PrintLog("File[%s]Line[%d] HasEmergencyModeInModeNotifyList continue",__FILE__,__LINE__);

    }

    return FALSE;
}


BOOL HasTrainFaultModeInModeNotifyList(unsigned char * ucSysTime,unsigned char * ucTime,unsigned char *pStationCode)
{
	int iRet=EM_MODE_NORMAL;

	iRet=GetStationModeNotify(ucSysTime,ucTime,pStationCode,EM_MODE_TRAIN_FAULT,NULL);

	if(iRet==EM_MODE_TRAIN_FAULT)
	{
		return TRUE;
	}

	return FALSE;
}

BOOL HasEmergencyModeInModeNotifyListByKey(unsigned char * ucSysTime,unsigned char * ucTime,unsigned char *pStationCode)
{
	int iRet=EM_MODE_NORMAL;

	iRet=GetStationModeNotify(ucSysTime,ucTime,pStationCode,EM_MODE_EMERGENCY,NULL);

	if(iRet==EM_MODE_EMERGENCY)
	{
		return TRUE;
	}

	return FALSE;
}


BOOL CheckStationMode(DEGRADECMD stCurrentDegradeCmd,DEGRADECMD stNewDegradeCmd)
{


	BOOL bRet=FALSE;

	unsigned char ucCurrentDegradeCode=EM_MODE_NORMAL;
	unsigned char ucNewDegradeCode=EM_MODE_NORMAL;

	ucCurrentDegradeCode=stCurrentDegradeCmd.bDegradeType;
	ucNewDegradeCode=stNewDegradeCmd.bDegradeType;

	if(stCurrentDegradeCmd.bFlag!=0x01)
	{
		bRet=TRUE;
		return bRet;
	}

	PrintLog("File[%s]Line[%d] CheckStationMode  ucCurrentDegradeCode[%d],ucNewDegradeCode[%d]",__FILE__,__LINE__,ucCurrentDegradeCode,ucNewDegradeCode);

	switch(ucCurrentDegradeCode)
	{
		case EM_MODE_EMERGENCY:
			{
				if(ucNewDegradeCode==EM_MODE_EMERGENCY)
				{
					bRet=TRUE;
				}
			}
			break;
		case EM_MODE_TRAIN_FAULT:
			{
				if(ucNewDegradeCode==EM_MODE_EMERGENCY||ucNewDegradeCode==EM_MODE_TRAIN_FAULT)
				{
					bRet=TRUE;
				}
			}
			break;
		case EM_MODE_FREE_ENTRY:
		case EM_MODE_FREE_DATE:
		case EM_MODE_FREE_FARE:
		case EM_MODE_NORMAL:
			bRet=TRUE;
			break;
		default:
			bRet=FALSE;
			break;

	}

	return bRet;


}

BOOL Allow_Entry_InDegradeMode(unsigned char * ucSysTime,unsigned char * ucTime,unsigned char *pStationCode,unsigned char ucCardStatus)
{
	BOOL bRet=FALSE;
	BOOL bHasTrainFaultMode=FALSE;
	BOOL bHasEmergencyMode=FALSE;

	PrintLog("File[%s]Line[%d]Allow_Entry_InDegradeMode   u8CardStatus=[%d]",__FILE__,__LINE__,ucCardStatus);
	PrintLog("File[%s]Line[%d]Allow_Entry_InDegradeMode   szLastProcessTime",__FILE__,__LINE__);
	PrintBuffer(ucTime,7);
	PrintLog("File[%s]Line[%d]Allow_Entry_InDegradeMode   szLastProcessStation=[%02d%02d]",__FILE__,__LINE__,pStationCode[0],pStationCode[1]);

	switch(ucCardStatus)
	 {
		 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:		//列车故障模式出站(exit during Train-disruption)
		 {
			 return HasTrainFaultModeInModeNotifyList(ucSysTime,ucTime,pStationCode);
		 }
		 case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES:
		 case EM_TICKET_TRAVEL_STATUS_ISSUED://SJT发售(init 2)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA:	//非付费区免费更新(BOM/pca 非付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA:	//非付费区付费更新(BOM/pca 非付费区)
		 {
			 bHasTrainFaultMode=HasTrainFaultModeInModeNotifyList(ucSysTime,ucTime,pStationCode);
			 bHasEmergencyMode=HasEmergencyModeInModeNotifyListByKey(ucSysTime,ucTime,pStationCode);

			 return (bHasTrainFaultMode||bHasEmergencyMode);
		 }
		 case EM_TICKET_TRAVEL_STATUS_ENTRY:					//已进站
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
		 case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
		 {
			 return HasEmergencyModeInModeNotifyList(ucSysTime,ucTime);
		 }
		 default:
			 break;
	 }
	return bRet;
}
//ucTime -> current system time
//pStationCode [out] FreeEntryStationCode
BOOL Allow_Exit_InFreeEntryStationCode(unsigned char * ucTime,unsigned char * szCurrentStationCode,unsigned char *pStationCode)
{
	ST_RW_DEGRADECMD stTempDegrade;

	BOOL bRet=FALSE;
	int iRet=-1;
	unsigned char szModeStartTime[7]={0};
	unsigned char szModeEndTime[7]={0};
	int iDegradeValidSeconds=0;

	uint32	u32MinPrice=0xFFFFFFFF;

	 uint32 u32Price=0;
	 uint16 FareZone=0;
	 uint16 JourneyTimeLimit=0;
	 uint16 TimeoutsFines=0;
	 uint8  RidingTime=0;
	 uint8  TrainTicketTableID=0;
	 uint8 u8CardType[2]={0};


	if(NULL==ucTime||NULL==pStationCode)
	{
		 return FALSE;
	}

	iDegradeValidSeconds=3*60*60;

    int i = 0;
    for (; i < m_ModeNotifyList.count; i ++)
    {
    	memset(&stTempDegrade,0,sizeof(ST_RW_DEGRADECMD));

    	memcpy(&stTempDegrade,m_ModeNotifyList.entrys[i].value,sizeof(ST_RW_DEGRADECMD));

		if(stTempDegrade.bDegradeType!=EM_MODE_FREE_ENTRY)
		{
			PrintLog("File[%s]Line[%d] Allow_Exit_InFreeEntryStationCode continue",__FILE__,__LINE__);
			continue;
		}

		if(stTempDegrade.bFlag==0x02)
		{
           memcpy(szModeStartTime,stTempDegrade.bEndTime,7);
		}else
		{
		   memcpy(szModeStartTime,stTempDegrade.bStartTime,7);
		}

    	BCDTimeAddSeconds(iDegradeValidSeconds,szModeStartTime,szModeEndTime);
    	PrintLog("File[%s]Line[%d] Allow_Exit_InFreeEntryStationCode szModeStartTime",__FILE__,__LINE__);
		PrintBuffer(szModeStartTime,7);
		PrintLog("File[%s]Line[%d] Allow_Exit_InFreeEntryStationCode szModeEndTime",__FILE__,__LINE__);
		PrintBuffer(szModeEndTime,7);

		//敏感期
		if((memcmp(ucTime,szModeStartTime,4)>=0&&memcmp(ucTime,szModeEndTime,4)<=0))
		{
			iRet=BR_CalcPrice(u8CardType,szCurrentStationCode,stTempDegrade.bStationID,ucTime,ucTime,
								&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&u32Price);

            if(iRet==CE_OK)
            {
				if(u32Price<u32MinPrice)
				{
					u32MinPrice=u32Price;
					memcpy(pStationCode,stTempDegrade.bStationID,2);
					bRet=TRUE;
				}
            }
		}

    }

    return bRet;
}

int Get_Price_InDegrade(uint8 *u8CardType,uint8 *u8InGateStation,uint8* u8BCDInGateTime,uint8* u8BCDOutGateTime,
		uint16* FareZone,uint16*JourneyTimeLimit,uint16*TimeoutsFines,uint8 *RidingTime,uint8 *TrainTicketTableID,uint32* Fare)
{
	int iRet=-1;

	if(g_BRContext.ucCurrentStationMode==EM_MODE_FREE_FARE)
	{
		iRet=BR_CalcPrice(u8CardType,g_BRContext.bCurrentStationID,g_BRContext.bCurrentStationID,u8BCDInGateTime,u8BCDOutGateTime,
							FareZone,JourneyTimeLimit,TimeoutsFines,RidingTime,TrainTicketTableID,Fare);
	}else
	{

	    iRet=BR_CalcPrice(u8CardType,u8InGateStation,g_BRContext.bCurrentStationID,u8BCDInGateTime,u8BCDOutGateTime,
					FareZone,JourneyTimeLimit,TimeoutsFines,RidingTime,TrainTicketTableID,Fare);
	}
	PrintLog("File[%s]Line[%d] Get_Price_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
	PrintLog("File[%s]Line[%d] Get_Price_ULCard  BR_CalcPrice JourneyTimeLimit= [%d] u32Price[%d]",__FILE__,__LINE__,*JourneyTimeLimit,*Fare);
	if(iRet!=CE_OK)
	{
		PrintLog("File[%s]Line[%d] Get_Price_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
		return RW_EC_INVALID_INPUT_PARAM;
	}

	return CE_OK;


}
