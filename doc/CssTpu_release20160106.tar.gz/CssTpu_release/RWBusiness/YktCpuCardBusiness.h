#ifndef __ACCCPUCARDBUSINESS_H__
#define __ACCCPUCARDBUSINESS_H__

#include "../Globle.h"
#include "../TicketEntity/YktCpuCardEntity.h"
#include "../XPublic/XTime.h"
#include "../XPublic/Log.h"
#include "../RWParam/RWParameter.h"
#include "DegradeModeBusinuess.h"

//  验证卡发行有效性
// int Verify_Issue_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo);

//验证卡是否在黑名单参数中。0 : not blacklist ,1 : blacklist
 BOOL Verify_Blacklist_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo);

//验证卡是否已锁。
 BOOL Verify_IsLocked_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo);

//验证是否允许该设备发售。
 BOOL Verify_Issue_Device_YktCpuCard(EM_DEVICE_TYPE emCurrentDeivceType);

//内部用读卡
 int Inner_Read_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  *stYktCpuCardInfo,BOOL bReadHistory);

//内部写卡复合消费
 int Inner_Write_YktCpuCard(StruAPIParam APIParam,uint32 u32ConsumeMoney,ST_CARD_YKT_CPU cardProcessInfo,uint8 *TAC,uint32 *u8TerminalTradeNum);

 //内部写卡普通消费
 int Inner_Write6_YktCpuCard(StruAPIParam APIParam,uint32 u32ConsumeMoney,ST_CARD_YKT_CPU cardProcessInfo,uint8 *TAC,uint32 *u8TerminalTradeNum);

 int Inner_Lock_YktCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETLOCK * stLockInfo);

 //UD处理
 void Fill_Sale_YktCpuCard_UD(StruAPIParam APIParam,ST_CARD_YKT_CPU stYktCpuCardInfo,SJTSALE * pUD);

  void Fill_Entry_YktCpuCard_UD(StruAPIParam APIParam,ST_CARD_YKT_CPU stYktCpuCardInfo,ENTRYGATE * pUD);

  void Fill_Purse_YktCpuCard_UD(StruAPIParam APIParam,ST_CARD_YKT_CPU stYktCpuCardInfo,PURSETRADE * pUD);

 void Fill_Lock_YktCpuCard_UD(StruAPIParam APIParam,ST_CARD_YKT_CPU stYktCpuCardInfo,TICKETLOCK * pUD);


 void Fill_Update_YktCpuCard_UD(StruAPIParam APIParam,ST_CARD_YKT_CPU stYktCpuCardInfo,TICKETUPDATE  * pUD);

  //付费区分析。
 BOOL PaidArea_Analysis_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  stYktCpuCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis);

 //非付费区分析。
 BOOL UnpaidArea_Analysis_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  stYktCpuCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis);

 //检查车票状态是否正确
 BOOL Check_Ticket_Status_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo);

 //检查余额是否超出上限。
 BOOL Check_Ticket_Value_Uplimit_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo);

 //检查车票是否过期。
 BOOL Check_Ticket_Valid_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  *stYktCpuCardInfo);

//检查是否本站进站。
BOOL Check_EntryThisStation_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo);

//检查进站超时。
BOOL Check_Entry_Timeout_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo);

//进站次序检查。
BOOL Check_Entry_Status_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo);

//余额低于最小票价。
BOOL Check_MinValue_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  stYktCpuCardInfo);

//出站次序检查。
BOOL Check_Exit_Status_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo);

//非本站更新
BOOL Check_Update_ThisStation_YktCpuCard(ST_CARD_YKT_CPU  stYktCpuCardInfo);

//非本日更新
BOOL Check_Update_ThisDay_YktCpuCard(StruAPIParam APIParam,ST_CARD_YKT_CPU  stYktCpuCardInfo);

//出站超时
BOOL Check_Exit_Timeout_YktCpuCard(StruAPIParam APIParam,uint16 u16JourneyTimeLimit,ST_CARD_YKT_CPU  stYktCpuCardInfo);

//出站超程
BOOL Check_Exit_RemainningValue_YktCpuCard(uint32 *u32Price,ST_CARD_YKT_CPU  stYktCpuCardInfo);

//
int Analysis_YktCpuCard(StruAPIParam APIParam,uint8 u8IsDegradeMode,uint8 u8WorkArea,RetInfo * pRetInfo,BOMANALYZE * stAnalysis,TICKETLOCK * stTicketLock);


int Decrease_YktCpuCard(StruAPIParam APIParam,uint32 u32DecreaseValue,RetInfo * pRetInfo,PURSETRADE *stPurseInfo);

int Query_YktCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETINFO * stTicketInfo);

int Update_YktCpuCard(StruAPIParam APIParam,uint8 u8UpdateCode,uint16 u16EntryStationCode,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRetInfo,TICKETUPDATE * stUpdateInfo);

int Entry_YktCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,ENTRYGATE *stEntryInfo,TICKETLOCK * stLockInfo);

int Exit_YktCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,PURSETRADE *stPurseInfo,TICKETLOCK * stLockInfo);

int Unlock_YktCpuCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETLOCK * stLockInfo);

int ConvertYktCPUCardStatus(unsigned char ucTicketStatus);

#endif
