/*********************************************************
*程序名称:		readprocessmg.c
*版本号:		0.1			
*功能描述:		 <<长沙轨道交通1号线读卡器接口调用API文档.docx>>文档中,
				所有的与上位机的接口处理函数都定义在本文件中,函数名称与文档中的名称一致.
*作者:			王洪峰			
*修改记录:		
				2015.01.13 创建 
*其他:						
***********************************************************/
 
#include "RWBusiness.h"


static unsigned char *m_ParamBuffer;
static uint32 m_ParamBufferLength;
static uint32 m_ParamBufferCount;
static ST_Parameter_Info m_stCurrentParameterInfo;
/*3.1.1	设备环境初始化
	函数原型:
		RetInfo Common_Initialize_Device (int nPort, StruAPIParam APIParam,BYTE bStationID[2], BYTE bDeviceType, BYTE wDeviceID[2] ,WORD * pLen1, unsigned char * pMsg1, ,WORD * pLen2, unsigned char * pMsg2);
	功能：
	根据接口传入的参数，加载设备所需参数，申请内部资源。设备要调用读写器处理票卡前必须先执行此调用。
	设备在初始化之前应先调用'Config_Parameter'配置好设备必须的参数，各种设备必须的参数详情参见附录五。
	输入参数：
	nPort - 设备通信端口编号
	APIParam -API函数公共参数
	bStationID[2] -线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
	bDeviceType - 设备类型，十进制表示。1字节BCD编码
	bDeviceID[2] -当前设备编码，"\x09\x87"表示设备号为987的设备

	输出参数：
		pLen1: 检测到的SAM卡个数(当前字段值为8)
		pMsg1:	pSAMCount个SAM卡中每个SAM卡槽的状态, 0为可用.
		pLen2: 预留信息的数据长度(目前默认为0)
		pMsg2:	预留信息的内容.(目前没有预留信息)

	返回值: 
		函数返回值结构体中错误码:
		0 - 成功，输出参数可用；
		非0值 -具体见附录"API返回值代码对照表"，输出参数无效
	注：
		本接口只在设备启动时成功调用一次即可，如果调用不成功，应根据返回码，配合参数据下载接口调用。
*/
int Common_Initialize_Device(StruAPIParam APIParam,//函数公共参数
								  RetInfo * pRi,
								  BYTE bStationID[2],	//线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
								  BYTE bDeviceType,		//设备类型，十进制表示。1字节BCD编码
								  BYTE bDeviceID[2],	//当前设备编码，"\x09\x87"表示设备号为987的设备
								  WORD * pLen1,			//检测到的SAM卡个数(当前字段值为8)
								  unsigned char * pMsg1,//pSAMCount个SAM卡中每个SAM卡槽的状态, 0为可用
								  WORD * pLen2,			//预留信息的数据长度(目前默认为0)
								  unsigned char * pMsg2)//预留信息的内容.(目前没有预留信息)
{
	//返回值

	
	/********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/
	//参数判断指针是否为空,避免程序崩溃.
	if( bStationID==NULL || bDeviceID==NULL 
		|| pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return pRi->wErrCode;
	}
	
	//初始化 参数下载 用到的 缓存
	m_ParamBuffer=NULL;
	int iRet=-1;

	//判断设备类型,车站ID,设备类型的实际定义是否合理
	char szDeviceCode[10]={0};
	sprintf(szDeviceCode,"%02d%02d%d%02d%02d",bStationID[0],bStationID[1],bDeviceID[0],bDeviceID[1],bDeviceType);
	printf("File[%s]Line[%d]Common_Initialize_Device BR_IsExsitDeviceCode iRet[%d]",__FILE__,__LINE__,iRet);
	iRet=BR_IsExsitDeviceCode(szDeviceCode);
	if(iRet!=CE_OK)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return RW_EC_OK;
	}

	memcpy(g_BRContext.szDeviceCode,szDeviceCode,9);



	/*98	LCC
		01	SC
		02	TVM
		03	BOM
		04	进站闸机
		05	出站闸机
		06	双向闸机
		07	TCM
		08	PCA
		09	ES
		99	ACC
*/


	memcpy((uint8*)g_BRContext.bCurrentDeviceID,bDeviceID,2);
	printf("File[%s]Line[%d]Common_Initialize_Device g_BRContext.bCurrentDeviceID[%02d%02d]",__FILE__,__LINE__,g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);

	memcpy((uint8*)g_BRContext.bCurrentStationID,bStationID,2);
	printf("File[%s]Line[%d]Common_Initialize_Device g_BRContext.bCurrentStationID[%02d%02d]",__FILE__,__LINE__,g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);

	g_BRContext.bCurrentLineID=bStationID[0];
	printf("File[%s]Line[%d]Common_Initialize_Device g_BRContext.bCurrentLineID[%02d]",__FILE__,__LINE__,g_BRContext.bCurrentLineID);

	g_BRContext.bCurrentDeviceTypeCode=bDeviceType;
	printf("File[%s]Line[%d]Common_Initialize_Device g_BRContext.bCurrentDeviceTypeCode[%02X]",__FILE__,__LINE__,g_BRContext.bCurrentDeviceTypeCode);


	//判断设备类型
	switch(bDeviceType)
	{
	  case 2:
		 g_BRContext.emCurrentDeviceType=EM_DEVICE_TYPE_TVM;
		 break;
	 case 3:
		 g_BRContext.emCurrentDeviceType=EM_DEVICE_TYPE_BOM;
		 break;
	  case 4:
		  g_BRContext.emCurrentDeviceType=EM_DEVICE_TYPE_AGM_ENTRY;
		 break;
	  case 5:
		 g_BRContext.emCurrentDeviceType=EM_DEVICE_TYPE_AGM_EXIT;
		 break;
	  case 6:
		 g_BRContext.emCurrentDeviceType=EM_DEVICE_TYPE_AGM_DOUBLE;
		 break;
	  case 7:
		 g_BRContext.emCurrentDeviceType=EM_DEVICE_TYPE_TCM;
		 break;
	  case 10:
		  g_BRContext.emCurrentDeviceType=EM_DEVICE_TYPE_AVM;
		  break;
	  default:
		  pRi->wErrCode=RW_EC_ILLEGAL_INPUT_PARAM;
		  return RW_EC_OK;
	}
	

	//检查参数是否齐全可用
	iRet=CheckAllParamInfo(g_BRContext.emCurrentDeviceType);
	printf("File[%s]Line[%d]Common_Initialize_Device CheckAllParamInfo iRet[%d]",__FILE__,__LINE__,iRet);
	//puts();
	if(iRet!=CE_OK)
	{
		pRi->wErrCode = RW_EC_PARAMETER_FILE_NOT_EXIST;
		return RW_EC_OK;
	}

	//todo:获取SAM卡信息。

	InitBiz();

	*pLen1 = 8;

	//DeviceCode  0201 + 001 +03  车站 + 设备序列号 + 设备类型
	iRet=BR_IsExsitSAMLogicCode((char*)g_BRContext.stSamInfo[0].cSAMID,'1', g_BRContext.szDeviceCode);
	if(iRet==CE_OK)
	{
		g_BRContext.stSamInfo[0].bSAMStatus=0x00;
	}
	iRet=BR_IsExsitSAMLogicCode((char*)g_BRContext.stSamInfo[1].cSAMID,'2', g_BRContext.szDeviceCode);
	if(iRet==CE_OK)
	{
		g_BRContext.stSamInfo[1].bSAMStatus=0x00;
	}
	iRet=BR_IsExsitSAMLogicCode((char*)g_BRContext.stSamInfo[2].cSAMID,'3', g_BRContext.szDeviceCode);
	if(iRet==CE_OK)
	{
		g_BRContext.stSamInfo[2].bSAMStatus=0x00;
	}
	//固定设计为8个SAM卡
	//内容8BYTE,分别对应8个SAM卡槽的状态，0为可用
	//假设单数SAM卡为正常,偶数序号SAM卡为
	pMsg1[0]=g_BRContext.stSamInfo[0].bSAMStatus;	
	pMsg1[1]=g_BRContext.stSamInfo[1].bSAMStatus;
	pMsg1[2]=g_BRContext.stSamInfo[2].bSAMStatus;
	pMsg1[3]=g_BRContext.stSamInfo[3].bSAMStatus;
	pMsg1[4]=g_BRContext.stSamInfo[4].bSAMStatus;
	pMsg1[5]=g_BRContext.stSamInfo[5].bSAMStatus;
	pMsg1[6]=g_BRContext.stSamInfo[6].bSAMStatus;
	pMsg1[7]=g_BRContext.stSamInfo[7].bSAMStatus;

	*pLen2 = 0;
	//因为长度为0 ,所以pMsg2无需填写
	pRi->wErrCode=RW_EC_OK;



	g_BRContext.AGMAisleType=EM_AG_AISLE_TYPE_ALL;

	g_BRContext.ucCurrentStationMode=EM_MODE_NORMAL;

	g_BRContext.ucTicketLastProcessStationMode=EM_MODE_NORMAL;

	//模式履历加载
	SyncModeHistory(APIParam.ucTimeStamp);

	Beep(100);

	//设置系统时间
	SetDateTime(APIParam.ucTimeStamp);

	return RW_EC_OK;

}



/*3.1.2	获取版本信息
函数原型:
RetInfo Common_GetVersion (int iPort, StruAPIParam APIParam, WORD * pLen1, unsigned char * pMsg1, ,WORD * pLen2, unsigned char * pMsg2);
功能：	
读取读写器对应的版本信息。
输入参数：
iPort - 设备通信端口编号
APIParam -API函数公共参数

输出参数：
pLen1: 有效时为sizeof(READERVERSION)
pMsg1: 设备版本信息(参见READERVERSION结构体)
pLen2: 预留信息的数据长度(目前默认为0)
pMsg2:	预留信息的内容.(目前没有预留信息)

 返回值: 
 函数返回值结构体中错误码:
 0 - 成功，输出参数可用；
 非0值 -具体见附录"API返回值代码对照表"，输出参数无效COMMON_GETVERSION
*/
int Common_GetVersion(StruAPIParam APIParam,RetInfo * pRi, WORD * pLen1, unsigned char * pMsg1 ,WORD * pLen2, unsigned char * pMsg2)
{
	//返回值
	PREADERVERSION pRv=	(PREADERVERSION)pMsg1;
	/********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/
	//参数判断指针是否为空,避免程序崩溃.
	if( pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return pRi->wErrCode;
	}
	*pLen1 =sizeof(READERVERSION);

	pRv->verApi[0]= 0x00; // API识别版本
	pRv->verApi[1]= 0x10;	// API识别版本
	
	pRv->verApiFile[0]=0x20;// AP文件版本号日期
	pRv->verApiFile[1]=0x16;// AP文件版本号日期
	pRv->verApiFile[2]=0x01;// AP文件版本号日期
	pRv->verApiFile[3]=0x02;// AP文件版本号日期
	pRv->verApiFile[4]=0x02;// AP文件版本号日期
	pRv->verApiFile[5]=0x00;// AP文件版本号日期
	pRv->verApiFile[6]=0x00;// AP文件版本号日期
	pRv->verApiFile[7]=0x00;// AP文件版本号序号
	pRv->verApiFile[8]=0x00;// AP文件版本号序号
	pRv->verApiFile[9]=0x00;// AP文件版本号序号


	pRv->verRfDev= 0x03; // Rf识别版本

	//Rf驱动识别版本
	pRv->verRfFile[0]=0x20;
	pRv->verRfFile[1]=0x15;
	pRv->verRfFile[2]=0x11;
	pRv->verRfFile[3]=0x05;
	pRv->verRfFile[4]=0x00;
	pRv->verRfFile[5]=0x01;
	pRv->verRfFile[6]=0x00;
	pRv->verRfFile[7]=0x00;
	pRv->verRfFile[8]=0x00;
	pRv->verRfFile[9]=0x00;

	pRv->verSamFile[0]=0x20;// Sam文件版本号日期
	pRv->verSamFile[1]=0x15;// Sam文件版本号日期
	pRv->verSamFile[2]=0x11;// Sam文件版本号日期
	pRv->verSamFile[3]=0x05;// Sam文件版本号日期
	pRv->verSamFile[4]=0x00;// Sam文件版本号日期
	pRv->verSamFile[5]=0x01;// Sam文件版本号日期
	pRv->verSamFile[6]=0x00;// Sam文件版本号日期
	pRv->verSamFile[7]=0x00;// Sam文件版本号序号
	pRv->verSamFile[8]=0x00;// Sam文件版本号序号
	pRv->verSamFile[9]=0x00;// Sam文件版本号序号

	
	*pLen2 = 0;
	//因为长度为0 ,所以pMsg2无需填写

	pRi->wErrCode=RW_EC_OK;

	return pRi->wErrCode;	
}


/*3.1.3	获取SAM卡信息
功能：
读取读写器对应类型的SAM卡相关信息。
输入参数：
nPort - 设备通信端口编号
APIParam -API函数公共参数

  输出参数：
  ri	: 函数返回值结构体中错误信息
  pLen1: 有效时长度即N1＝8*sizeof(SAMSTATUS)
  pMsg1: SAM卡状态信息PSAMSTATUS
  pLen2: 预留信息的数据长度(目前默认为0)
  pMsg2:	预留信息的内容.(目前没有预留信息)
  
	返回值: 
	函数返回值结构体中错误码:
	0 - 成功，输出参数可用；
	非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Common_GetSamInfo (StruAPIParam APIParam, RetInfo * pRi,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	//返回值
	//PREADERVERSION pRv=	(PREADERVERSION)pMsg1;
	//PSAMSTATUS pSamStatus =NULL;
	uint8 CardRandom[17]={0};
	int iDatalen=0;
	int iRet=-1;
	/********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return 0;
	}
	

	iRet=SamGetRandom(SAM_SLOT_ACC,CardRandom);
	if(iRet!=CE_OK)
	{
		g_BRContext.stSamInfo[0].bSAMStatus=0xFF;
		memset(g_BRContext.stSamInfo[0].cSAMID,0,sizeof(g_BRContext.stSamInfo[0].cSAMID));
	}
	iRet=YktCpuSamGetRandom(SAM_SLOT_YKT_CPU,CardRandom);
	if(iRet!=CE_OK)
	{
		g_BRContext.stSamInfo[1].bSAMStatus=0xFF;
		memset(g_BRContext.stSamInfo[1].cSAMID,0,sizeof(g_BRContext.stSamInfo[1].cSAMID));
	}
	iRet=YktM1SamGetRandom(SAM_SLOT_YKT_M1,CardRandom);
	if(iRet!=CE_OK)
	{
		g_BRContext.stSamInfo[2].bSAMStatus=0xFF;
		memset(g_BRContext.stSamInfo[2].cSAMID,0,sizeof(g_BRContext.stSamInfo[2].cSAMID));
	}

	//默认返回8个SAM卡信息
	iDatalen=sizeof(SAMSTATUS) *8;

	memcpy(pMsg1,(char*)g_BRContext.stSamInfo,iDatalen);
	
	*pLen1=iDatalen;

	*pLen2 = 0;
	//因为长度为0 ,所以pMsg2无需填写
	pRi->wErrCode=RW_EC_OK;

	return pRi->wErrCode;	
}


/*3.1.4	设备降级模式
功能：
当SLE接收到SC下发的降级模式通知或降级模式控制命令后，SLE将通知或控制命令的内容填入结构pDegradeCmd后调用本接口，本接口被调用后，API不对pDegradeCmd信息做永久记录，API从内存释放后pDegradeCmd信息丢失，API被再次载入内存时，上次载入时的pDegradeCmd信息被忽略，除非ECU再次调用本接口。
ECU应永久记录pDegradeCmd相关信息直至该信息失效（当前时间超出该降级消息的敏感期），并在每次调用完初始化接口后调用本接口。
当有新的降级模式参数后，API将以降级模式参数为准，忽略之前所有调用本接口所产生的降级。
输入参数：
iPort - 设备通信端口编号
APIParam -API函数公共参数
PDegradeCMD 降级模式结构体,参见(2.1.5降级模式命令结构体)
输出参数：
ri	: 函数返回值结构体中错误信息
pLen1: 预留信息的数据长度(目前默认为0)
pMsg1: 预留信息的内,容.(目前没有预留信息)
pLen2: 预留信息的数据长度(目前默认为0)
pMsg2:	预留信息的内容.(目前没有预留信息)

		  返回值: 
		  函数返回值结构体中错误码:
		  0 - 成功，输出参数可用；
		  非0值 -具体见附录"API返回值代码对照表"，输出参数无效COMMON_SETDEGRADEMODE
*/
int Common_SetDegradeMode (StruAPIParam APIParam, DEGRADECMD DegradeCMD, RetInfo * pRi, WORD * pLen1, unsigned char * pMsg1,WORD * pLen2, unsigned char * pMsg2)
{

	int iRet=-1;

	/********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return 0;
	}
	
	if(DegradeCMD.bDegradeType<0&&DegradeCMD.bDegradeType>6)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return 0;
	}

	//check param


	PrintLog("File[%s]Line[%d] Common_SetDegradeMode  DegradeCMD.bStartTime ",__FILE__,__LINE__);
	PrintBuffer(DegradeCMD.bTime,7);

	PrintLog("File[%s]Line[%d] Common_SetDegradeMode  DegradeCMD.bStationID [%02d%02d]",__FILE__,__LINE__,DegradeCMD.bStationID[0],DegradeCMD.bStationID[1]);

	PrintLog("File[%s]Line[%d] Common_SetDegradeMode  DegradeCMD.bDegradeType [%02d]",__FILE__,__LINE__,DegradeCMD.bDegradeType);

    //设置本站模式
	if(memcmp(DegradeCMD.bStationID,g_BRContext.bCurrentStationID,2)==0)
	{
		iRet= SetLocalStationMode(DegradeCMD);
		if(iRet!=RW_EC_OK)
		{
			pRi->wErrCode=iRet;
			return pRi->wErrCode;
		}
	}


	//模式清理
	//ClearModeList(APIParam.ucTimeStamp);

	//设置本站或他站模式通知
	iRet= SetStationModeNotifyList(APIParam.ucTimeStamp,DegradeCMD);

	if(iRet!=RW_EC_OK)
	{
		pRi->wErrCode=iRet;
	}




	//无任何返回数据
	*pLen1 = 0;
	*pLen2 = 0;

	return pRi->wErrCode;
}



/*3.1.5	获取到本站的票价
函数原型:
功能：
获取当前时间其它站到本站的票价，做付费区无进站码更新时可能需要额外补款，可以通过本接口配合。

  输入参数：
  nPort - 设备通信端口编号
  APIParam -API函数公共参数
  bTicketType - 2字节BCD编码
  bStationID - 2字节车站ID,BCD编码如"\x03\x01"，表示3号线第1个站点
  输出参数：
  ri	: 函数返回值结构体中错误信息
  pLen1: 票价数据长度(目前默认为4,因为信息内容为long)
  pMsg1: long数据内容,单位是票价(分为单位)
  pLen2: 预留信息的数据长度(目前默认为0)
  pMsg2:	预留信息的内容.(目前没有预留信息)
		
		  返回值: 
		  函数返回值结构体中错误码:
		  0 - 成功，输出参数可用；
		  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Comm_GetFare(StruAPIParam APIParam, BYTE bTicketType[2], BYTE bStationID[2], RetInfo * pRi, WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	/***********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/

	int iRet=-1;
	int iWeekDay=0;
	//参数判断指针是否为空,避免程序崩溃.
	uint8 szTicketType[5]={0};
	uint8 szStationID[5]={0};
	uint8 szCurrentStationID[5]={0};
	uint8 szInGateTime[15]={0};
	uint8 szInweekday[3]={0};

	uint8 szFareZone[2]={0};//收费区段	CHAR	2
	uint8 szJourneyTimeLimit[5]={0};//乘车时间限制 (单位：分钟)	CHAR	5	单位：分钟
	uint8 szTimeoutsFines[4]={0};//超时罚金	CHAR	4
	uint8 szRidingTime[1]={0};//乘车时间代码	CHAR	1
	uint8 szTrainTicketTableID[3]={0};//票价表ID	CHAR	3
	uint8 szFare[10]={0};//收费 (单位：分或次)	CHAR	10

	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return 0;
	}
	
	sprintf((char*)szTicketType,"%02x%02x",bTicketType[0],bTicketType[1]);
	sprintf((char*)szStationID,"%02d%02d",bStationID[0],bStationID[1]);
	sprintf((char*)szCurrentStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	sprintf((char*)szInGateTime,"%02x%02x%02x%02x%02x%02x%02x",APIParam.ucTimeStamp[0],APIParam.ucTimeStamp[1],APIParam.ucTimeStamp[2],
			APIParam.ucTimeStamp[3],APIParam.ucTimeStamp[4],APIParam.ucTimeStamp[5],APIParam.ucTimeStamp[6]);

//    tm *tmInGateTime;
//
//	tmInGateTime.
//
//	size_t strftime( char *str, size_t maxsize, const char *fmt, struct tm *time );

	iWeekDay=GetWeekDayOf7BCDTime(APIParam.ucTimeStamp);
	sprintf((char*)szInweekday,"%d",iWeekDay);

	PrintLog("File[%s]Line[%d] Comm_GetFare  szTicketType [%s]",__FILE__,__LINE__,szTicketType);
	PrintLog("File[%s]Line[%d] Comm_GetFare  szStationID [%s]",__FILE__,__LINE__,szStationID);
	PrintLog("File[%s]Line[%d] Comm_GetFare  szCurrentStationID [%s]",__FILE__,__LINE__,szCurrentStationID);
	PrintLog("File[%s]Line[%d] Comm_GetFare  szInGateTime [%s]",__FILE__,__LINE__,szInGateTime);
	PrintLog("File[%s]Line[%d] Comm_GetFare  iWeekDay [%d]",__FILE__,__LINE__,iWeekDay);


	iRet=BR_CalcAmountConsumption_h(szTicketType, szStationID, szCurrentStationID,szInGateTime,szInGateTime,szInweekday,szInweekday,
		   szFareZone, szJourneyTimeLimit, szTimeoutsFines, szRidingTime, szTrainTicketTableID, szFare);

	if(iRet!=RW_EC_OK)
	{
		pRi->wErrCode = RW_EC_INVALID_INPUT_PARAM;//
		return 0;
	}

	*pLen1 =sizeof(long); //long数据类型
	PrintLog("File[%s]Line[%d] Comm_GetFare  Fare [0x%02X]",__FILE__,__LINE__,atoi((char*)szFare));

	int fare=atoi((char*)szFare);
	memcpy(pMsg1,&fare,sizeof(long)) ;//票价300分
	
	*pLen2 = 0;
	return 0;
}


/*3.1.6	获取参数信息
函数原型:
功能：
读取指定参数类型对应的参数文件名称

  输入参数：
  nPort - 设备通信端口编号
  APIParam -API函数公共参数
  wParamType- 2字节HEX,参数类型如票价表，当前字段值为0x0400
  
	输出参数：
	pRi	: 函数返回值结构体中错误信息
	pLen1: 参数文件字节数
	pMsg1: 参数文件名称内容
	pLen2: 预留信息的数据长度(目前默认为0)
	pMsg2:	预留信息的内容.(目前没有预留信息)
	
	  返回值: 
	  函数返回值结构体中错误码:
	  0 - 成功，输出参数可用；
	  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Comm_GetParamInfo (StruAPIParam APIParam,WORD wParamType, RetInfo * pRi,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	/***********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*

	*********************************************************************/

	uint8 iRet=-1;

	char szFileName[256]={0};

	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return 0;
	}

	iRet=GetParamInfo(wParamType,szFileName);

	 if(iRet!=-1)
	{
		*pLen1 =strlen(szFileName);
		memcpy(pMsg1,szFileName,*pLen1);
	}else
	{
		*pLen1=0;
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;
	}
	*pLen2 = 0;
	return 0;
}


/*3.1.7	获取单个寄存器值
功能：
读取当前设备固定地址的寄存器值

  输入参数：
  nPort - 设备通信端口编号
  APIParam -API函数公共参数
  wRegID- 2字节HEX, 寄存器地址
  
	输出参数：
	ri	: 函数返回值结构体中错误信息
	pLen1: 寄存器值长度,目前固定为4
	pMsg1: 寄存器值(4字节HEX)
	pLen2: 预留信息的数据长度(目前默认为0)
	pMsg2:	预留信息的内容.(目前没有预留信息)
	
	  返回值: 
	  函数返回值结构体中错误码:
	  0 - 成功，输出参数可用；
	  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Get_Reg_Value (StruAPIParam APIParam ,WORD wRegID, RetInfo * pRi, WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	/***********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/

	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return 0;
	}

	
		
	*pLen1 = 4 ;//固定长度

	*(unsigned long *)pMsg1 = wRegID * 10; 

	*pLen2 = 0;
	return 0;
}


/*3.1.8	获取所有寄存器值
功能：
读取当前设备固定地址的寄存器值

  输入参数：
  nPort - 设备通信端口编号
  APIParam -API函数公共参数
  
	输出参数：
	ri	: 函数返回值结构体中错误信息
	pLen1: 固定为4的倍数(即寄存器个数*4)
	pMsg1: 寄存器值数组内容
	pLen2: 预留信息的数据长度(目前默认为0)
	pMsg2:	预留信息的内容.(目前没有预留信息)
	
	  返回值: 
	  函数返回值结构体中错误码:
	  0 - 成功，输出参数可用；
	  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Get_Reg_Info(StruAPIParam APIParam, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	/***********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/

	int i=0;
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return 0;
	}

	
	
	//假设有100个参数
	*pLen1 = 100*sizeof(DWORD) ;//固定长度
	for( i=0;i<*pLen1/(int)sizeof(DWORD);i++)
	{
		*((DWORD*)pMsg1+i)  =i * 10; 

	}
	*pLen2 = 0;
	return 0;
}


/*3.2.1	通道类型设置
功能：
设定读写器当前所属通道类型，此函数只适用于闸机，闸机车票处理流程中读写器根据此通道类型去处理对应类型的车票。
ECU应用软件调用完读写器初始化接口后紧接着调用此接口函数，如不调用此接口函数，在入/出闸处理中做为正常通道处理。

  输入参数：
  nPort - 设备通信端口编号
  APIParam -API函数公共参数
  AisleType - 	1：普通通道（不接受优惠票）
  2：专用通道（只接受优惠票）
  3：正常通道（接受所有票票种）
  输出参数：
  pLen1: 预留信息的数据长度(实际值为0)
  pMsg1: 预留信息的内容(目前没有预留信息)
  pLen2: 预留信息的数据长度(目前默认为0)
  pMsg2:	预留信息的内容.(目前没有预留信息)
		
		  返回值: 
		  函数返回值结构体中错误码:
		  0 - 成功，输出参数可用；
		  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Gate_AisleModel(StruAPIParam APIParam, BYTE AisleType, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
 	/********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return 0;
	}

	if(AisleType<1 || AisleType>3)
	{
		PrintLog("File[%s]Line[%d] Gate_AisleModel Error AisleType= [0x%02X]",__FILE__,__LINE__,AisleType);
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;
	}

	g_BRContext.AGMAisleType=AisleType;

	PrintLog("File[%s]Line[%d] Gate_AisleModel  g_BRContext.AGMAisleType= [0x%02X]",__FILE__,__LINE__,g_BRContext.AGMAisleType);
	//无任何返回数据
	*pLen1 =0;
	*pLen2 = 0;
	return 0;
}

int SetOperaterInfo (StruAPIParam APIParam, char * Id,uint8 u8ClassID, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	/********************************************************************
		*
		*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
		*
		*********************************************************************/
	//参数判断指针是否为空,避免程序崩溃.
	if(Id==NULL|| pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{

		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return 0;
	}

	char szTempId[7]={0};

	if(memcmp(Id,szTempId,6)==0)
	{
		printf("SetOperaterInfo id=[%s]\r\n",Id);
		strncpy((char*)g_BRContext.CurrentUserID,"000000",6);
		printf("SetOperaterInfo g_BRContext.CurrentUserID=[%s]\r\n",g_BRContext.CurrentUserID);
	}else
	{
		printf("SetOperaterInfo id=[%s]\r\n",Id);
		strncpy((char*)g_BRContext.CurrentUserID,Id,6);
		printf("SetOperaterInfo g_BRContext.CurrentUserID=[%s]\r\n",g_BRContext.CurrentUserID);
	}
	printf("SetOperaterInfo u8ClassID=[%d]\r\n",u8ClassID);
	g_BRContext.CurrentClassID=u8ClassID;
	printf("SetOperaterInfo g_BRContext.CurrentClassID=[%d]\r\n",g_BRContext.CurrentClassID);

	//无任何返回数据
	pRi->wErrCode=RW_EC_OK;

	*pLen1 =0;
	*pLen2 = 0;
	return 0;
}


/*5.7.1.1.	参数下载
参数下载开始前调用。*/
int StartToDownloadParameter(StruAPIParam APIParam,  ST_Parameter_Info pstParameterInfo, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	//memset(m_ParamBuffer,0,sizeof(m_ParamBuffer));
	char szCurrentParamFileName[256]={0};
	int iRet=-1;

	memset(&m_stCurrentParameterInfo,0,sizeof(ST_Parameter_Info));

	m_ParamBufferLength=0;

	m_ParamBufferCount=0;

	if(NULL!=m_ParamBuffer)
	{
		PrintLog("File[%s]Line[%d] StartToDownloadParameter. NULL!=m_ParamBuffer",__FILE__,__LINE__);
        free(m_ParamBuffer);
        m_ParamBuffer=NULL;
	}

	memcpy((char*)&m_stCurrentParameterInfo,&pstParameterInfo,sizeof(ST_Parameter_Info));

	if(m_stCurrentParameterInfo.u8MessageType!=0)
	{
		pRi->wErrCode=RW_EC_FILE_PROCESS_ERROR;
		return pRi->wErrCode;
	}


	sprintf(szCurrentParamFileName,"%s/%s",UPGRADE_PATH,m_stCurrentParameterInfo.FileName) ;

	PrintLog("File[%s]Line[%d] StartToDownloadParameter. filePath[%s]",__FILE__,__LINE__,szCurrentParamFileName);

	m_ParamBuffer=malloc(pstParameterInfo.u32FileSize+1);

	memset(m_ParamBuffer,0,pstParameterInfo.u32FileSize+1);
	PrintLog("File[%s]Line[%d] StartToDownloadParameter. m_ParamBuffer[%02X] size[%d]",__FILE__,__LINE__,m_ParamBuffer,pstParameterInfo.u32FileSize+1);

	PrintLog("File[%s]Line[%d] StartToDownloadParameter. u8CRC",__FILE__,__LINE__);
	PrintBuffer(m_stCurrentParameterInfo.u8CRC,4);

	//无任何返回数据
	pRi->wErrCode=RW_EC_OK;

	*pLen1 =0;
	*pLen2 = 0;
	return 0;
}

/*5.7.1.1.	生效通知
参数下载完成后调用。*/
int EffectParameter(StruAPIParam APIParam, ST_Parameter_Info pstParameterInfo, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint16 u16ParamID=0;
	int iRet=0;
	char   szParamID[5]={0};
	char   szBakCmd[256]={0};
	char szMoveCmd[256]={0};
	char sztarCmd[256]={0};
	char szChmodeCmd[256]={0};
    char szUpgradeParamFileName[256]={0};
    char szCurrentParamFileName[256]={0};
	sprintf(szUpgradeParamFileName,"%s/%s",UPGRADE_PATH,m_stCurrentParameterInfo.FileName) ;

	PrintLog("File[%s]Line[%d] EffectParameter. filePath[%s]",__FILE__,__LINE__,szUpgradeParamFileName);

	iRet=access(szUpgradeParamFileName,0);
	if(m_stCurrentParameterInfo.u8MessageType!=1&&iRet!=0)
	{
		PrintLog("File[%s]Line[%d] EffectParameter.m_stCurrentParameterInfo.u8MessageType!=1&&iRet!=0 !",__FILE__,__LINE__);
		pRi->wErrCode=RW_EC_FILE_PROCESS_ERROR;
		return pRi->wErrCode;
	}

	memcpy(szParamID,m_stCurrentParameterInfo.FileName+4,4);

	u16ParamID=strtol(szParamID ,NULL,16);

	if(FILE_BOM_TPU==u16ParamID||FILE_TVM_TPU==u16ParamID||FILE_AG_TPU==u16ParamID||FILE_TCM_TPU==u16ParamID||FILE_PCA_TPU==u16ParamID)
	{
		iRet=GetParamInfo(u16ParamID,szCurrentParamFileName);
		if(iRet!=-1)
		{
			sprintf(szBakCmd,"rm -f  %s/%s",PARAM_PATH,szCurrentParamFileName);
			PrintLog("File[%s]Line[%d] EffectParameter szBakCmd[%s] !",__FILE__,__LINE__,szBakCmd);
			system(szBakCmd);
		}
		sprintf(szMoveCmd,"cp -f %s  %s/%s",szUpgradeParamFileName,PARAM_PATH,m_stCurrentParameterInfo.FileName);

		PrintLog("File[%s]Line[%d] EffectParameter szMoveCmd[%s] !",__FILE__,__LINE__,szMoveCmd);

		system(szMoveCmd);

		system("sync");

		sprintf(szBakCmd,"cp -f  %s/%s %s/%s.bak",RUN_PATH,RUN_PROGRAM,UPGRADE_BAK_PATH,RUN_PROGRAM);

		PrintLog("File[%s]Line[%d] EffectParameter szBakCmd[%s] !",__FILE__,__LINE__,szBakCmd);

		system(szBakCmd);

		sleep(1);

		sprintf(sztarCmd,"cd /;gtar xvfzp  %s ;rm -f %s ;sh /tpu/run/update.sh",szUpgradeParamFileName,szUpgradeParamFileName);

		PrintLog("File[%s]Line[%d] EffectParameter sztarCmd[%s] !",__FILE__,__LINE__,sztarCmd);

		system(sztarCmd);

		system("sync");

		sleep(1);

		PrintLog("File[%s]Line[%d] EffectParameter Cmd[sync] !",__FILE__,__LINE__);

		pRi->wErrCode=RW_EC_OK;
		*pLen1 =0;

		*pLen2 = 0;

		return 1;

	}else
	{
		iRet=GetParamInfo(u16ParamID,szCurrentParamFileName);

		if(iRet!=-1)
		{
			sprintf(szBakCmd,"rm -f  %s/%s",PARAM_PATH,szCurrentParamFileName);
			//sprintf(szBakCmd,"mv -f  %s/%s %s/%s",PARAM_PATH,szCurrentParamFileName,UPGRADE_BAK_PATH,szCurrentParamFileName);
			PrintLog("File[%s]Line[%d] EffectParameter szBakCmd[%s] !",__FILE__,__LINE__,szBakCmd);
			system(szBakCmd);
		}

		sprintf(szMoveCmd,"mv %s  %s/%s",szUpgradeParamFileName,PARAM_PATH,m_stCurrentParameterInfo.FileName);

		PrintLog("File[%s]Line[%d] EffectParameter szMoveCmd[%s] !",__FILE__,__LINE__,szMoveCmd);

		system(szMoveCmd);

		system("sync");

		PrintLog("File[%s]Line[%d] EffectParameter Cmd[sync] !",__FILE__,__LINE__);

		//todo:调用解析
		iRet=SetParamInfo(u16ParamID,m_stCurrentParameterInfo.FileName);
		if(iRet==-1)
		{
			AddParamInfo(u16ParamID,m_stCurrentParameterInfo.FileName);
		}

		ParseParam(u16ParamID);


	}

	pRi->wErrCode=RW_EC_OK;
	*pLen1 =0;
	*pLen2 = 0;

	return 0;
}

//将参数文件分包下发到读写器，每次下发最大数据内容为4Kbyte。
int DownloadParameter(StruAPIParam APIParam,uint32 u32BufferLength,uint32 u32RemainnigLength,char * buffer, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 uiFileCrc=0;
	char    filePath[256]={0};
	FILE    *fp ;

	PrintLog("File[%s]Line[%d] DownloadParameter.m_ParamBufferCount[%d] u32BufferLength[%d]  !",__FILE__,__LINE__,m_ParamBufferCount,u32BufferLength);

	if(m_ParamBuffer==NULL)
	{
		PrintLog("File[%s]Line[%d] DownloadParameter. RW_EC_INVALID_API_CALL !",__FILE__,__LINE__);
		pRi->wErrCode=RW_EC_INVALID_API_CALL;
		return 0;
	}

	memcpy(m_ParamBuffer+m_ParamBufferLength,buffer,u32BufferLength);


	PrintLog("File[%s]Line[%d] DownloadParameter.m_ParamBufferCount[%d] u32BufferLength[%d]  !",__FILE__,__LINE__,m_ParamBufferCount,u32BufferLength);



	m_ParamBufferLength+=u32BufferLength;

	//PrintLog("File[%s]Line[%d] DownloadParameter.m_ParamBuffer[%s]  !",__FILE__,__LINE__,m_ParamBuffer);
	//PrintBuffer(m_ParamBuffer,m_ParamBufferLength);

	m_ParamBufferCount++;

	PrintLog("File[%s]Line[%d] DownloadParameter.m_ParamBufferCount[%d] u32BufferLength[%d]  !",__FILE__,__LINE__,m_ParamBufferCount,u32BufferLength);

	if(u32RemainnigLength>0)
	{
		PrintLog("File[%s]Line[%d] DownloadParameter. u32RemainnigLength[%d]  !",__FILE__,__LINE__,u32RemainnigLength);
		pRi->wErrCode=RW_EC_OK;
		return 0;
	}

	//检验文件长度
	if(m_ParamBufferLength!=m_stCurrentParameterInfo.u32FileSize)
	{
		pRi->wErrCode=RW_EC_PARAMETER_FILE_ILLEGAL;
		return pRi->wErrCode;
	}

	//检验文件Crc32
	uiFileCrc=Crc32_MH_ParamDownload(m_ParamBuffer,m_ParamBufferLength);

	if(memcmp(&uiFileCrc,m_stCurrentParameterInfo.u8CRC,4)!=0)
	{
		PrintLog("File[%s]Line[%d] DownloadParameter. uiFileCrc!=m_stCurrentParameterInfo.u8CRC !",__FILE__,__LINE__);
		PrintLog("File[%s]Line[%d] DownloadParameter. uiFileCrc[%02X]",__FILE__,__LINE__,uiFileCrc);
		PrintLog("File[%s]Line[%d] DownloadParameter. m_stCurrentParameterInfo.u8CRC",__FILE__,__LINE__);
		PrintBuffer(m_stCurrentParameterInfo.u8CRC,4);
		pRi->wErrCode=RW_EC_PARAMETER_FILE_ILLEGAL;
		return pRi->wErrCode;
	}

	//写文件。
	sprintf(filePath,"%s/%s",UPGRADE_PATH,m_stCurrentParameterInfo.FileName) ;

	PrintLog("File[%s]Line[%d] DownloadParameter. filePath[%s]",__FILE__,__LINE__,filePath);

	fp=fopen(filePath,"w+") ;
	if(fp==(FILE *)0)
	{
		PrintLog("File[%s]Line[%d] DownloadParameter. filePath[%s] can not open !",__FILE__,__LINE__,filePath);
		fprintf(stderr,"mig_err_log():can't open the file %s !\n",filePath);
		pRi->wErrCode=RW_EC_FILE_PROCESS_ERROR;
		return pRi->wErrCode;
	}

	fwrite(m_ParamBuffer,1,m_ParamBufferLength,fp);
	fclose(fp);

	system("sync");

	PrintLog("File[%s]Line[%d] DownloadParameter Cmd[sync] !",__FILE__,__LINE__);

	pRi->wErrCode=RW_EC_OK;
	*pLen1 =0;
	*pLen2 = 0;

	return 0;
}



/*3.2.2	入闸处理
功能：
在入口闸机中调用此接口，ECU调用票卡轮询接口返回0后，调用本接口，成功进行交易后返回进闸交易数据，否则返回操作错误状态码。
输入参数：
nPort - 设备通信端口编号
APIParam -API函数公共参数
输出参数：
pLen1: 入闸信息有效时长度为sizeof(ENTRYGATE)
pMsg1: PENTRYGATE结构体
pLen2: 锁卡信息有效时长度为sizeof(TICKETLOCK)
pMsg2:	PTICKETLOCK

  返回值: 
  函数返回值结构体中错误码:
  0 - 成功，输出参数可用；
  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Gate_EntryFlow (StruAPIParam APIParam, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	ENTRYGATE EntryGate; //进站交易结构体
	TICKETLOCK TicketLock;//票卡加锁结构体
	uint32 iRet = CE_CHECKERROR;
	memset(&EntryGate,0,sizeof(ENTRYGATE));
	memset(&TicketLock,0,sizeof(TICKETLOCK));
	/********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return pRi->wErrCode;
	}

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_AGM_ENTRY&&g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_AGM_DOUBLE)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		PrintLog("File[%s]Line[%d]PollingCard emCurrentDeviceType[%d]",__FILE__,__LINE__,g_BRContext.emCurrentDeviceType);
		return pRi->wErrCode;
	}

	unsigned char ucCardPhNoLen=0;
	//寻卡（给变量赋值，可区分UL卡和CPU卡，预留区分城市通卡）g_CardType（ACC_UL_CARD。。。。）
	g_BRContext.Result = PollingCard(APIParam.AntennaMode,&g_BRContext.u8CardPhType,g_BRContext.szCardPhID,&ucCardPhNoLen);
	PrintLog("File[%s]Line[%d]PollingCard Result=[%d],CardPhType=[%d]",__FILE__,__LINE__,g_BRContext.Result,g_BRContext.u8CardPhType);
	if(g_BRContext.Result != CE_OK)
	{
		pRi->wErrCode=RW_EC_NO_CARD_FOUND;
		memset(g_BRContext.szLastEntryCardPhID,0,sizeof(g_BRContext.szLastEntryCardPhID));
		return iRet;
	}
	
	//上笔交易成功，且为同一张卡，返回无卡。

	unsigned long ulTimeSpecOfms=3000;

	if(g_BRContext.u32LastEntryResult==0
			&&memcmp(g_BRContext.szLastEntryCardPhID,g_BRContext.szCardPhID,sizeof(g_BRContext.szCardPhID))==0
			&&CheckClockTickTimeOut(&g_BRContext.szLastEntryTime)==FALSE)
	{
		pRi->wErrCode=RW_EC_NO_CARD_FOUND;
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = Entry_ULCard(APIParam,pRi,&EntryGate,&TicketLock);
			break;
		case ACC_M1_CARD:
			break;
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Entry_AccCpuCard(APIParam,pRi,&EntryGate,&TicketLock);
			break;
		case CITY_M1_CARD:
			iRet = Entry_YktM1Card(APIParam,pRi,&EntryGate,&TicketLock);
			break;
		case CITY_CPU_CARD:
			iRet = Entry_YktCpuCard(APIParam,pRi,&EntryGate,&TicketLock);
			break;
		case PBOC_CPU_CARD:
			break;
		default:
			return 1;
	}

	if(iRet==CE_OK)
	{
	  g_BRContext.u32LastEntryResult=0;
	  InitClockTickTimeOut(&g_BRContext.szLastEntryTime,ulTimeSpecOfms);
	  memcpy(g_BRContext.szLastEntryCardPhID,g_BRContext.szCardPhID,sizeof(g_BRContext.szCardPhID));

	 *pLen1 = sizeof(EntryGate);
	  memcpy(pMsg1,&EntryGate,sizeof(EntryGate));

	}
	if(RW_EC_BLACKLIST==iRet)
	{
	  g_BRContext.u32LastEntryResult=0;
	  memcpy(g_BRContext.szLastEntryCardPhID,g_BRContext.szCardPhID,sizeof(g_BRContext.szCardPhID));
	  //加锁信息区定义
	  if(TicketLock.cLockFlag=='1')
	   {
		   *pLen2=sizeof(TicketLock);
		   memcpy(pMsg2,&TicketLock,sizeof(TicketLock));
	   }
	}

	return CE_OK;
}



/*3.2.2	入闸处理
功能：
在入口闸机中调用此接口，ECU调用票卡轮询接口返回0后，调用本接口，成功进行交易后返回进闸交易数据，否则返回操作错误状态码。
输入参数：
nPort - 设备通信端口编号
APIParam -API函数公共参数
输出参数：
pLen1: 入闸信息有效时长度为sizeof(ENTRYGATE)
pMsg1: PENTRYGATE结构体
pLen2: 锁卡信息有效时长度为sizeof(TICKETLOCK)
pMsg2:	PTICKETLOCK

  返回值: 
  函数返回值结构体中错误码:
  0 - 成功，输出参数可用；
  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Gate_ExitFlow (StruAPIParam APIParam, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	PURSETRADE purseGate; //进站交易结构体
	TICKETLOCK TicketLock;//票卡加锁结构体
	uint32 iRet = CE_CHECKERROR;
	
	memset(&TicketLock,0,sizeof(TICKETLOCK));
	memset(&purseGate,0,sizeof(PURSETRADE));

	/********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return 0;
	}

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_AGM_EXIT&&g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_AGM_DOUBLE)
	{
		PrintLog("File[%s]Line[%d]PollingCard emCurrentDeviceType[%d]",__FILE__,__LINE__,g_BRContext.emCurrentDeviceType);
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return pRi->wErrCode;
	}

	unsigned char ucCardPhNoLen=0;
	//寻卡（给变量赋值，可区分UL卡和CPU卡，预留区分城市通卡）g_CardType（ACC_UL_CARD。。。。）
	g_BRContext.Result = PollingCard(APIParam.AntennaMode,&g_BRContext.u8CardPhType,g_BRContext.szCardPhID,&ucCardPhNoLen);
	if(g_BRContext.Result != CE_OK)
	{
		pRi->wErrCode=RW_EC_NO_CARD_FOUND;
		memset(g_BRContext.szLastExitCardPhID,0,sizeof(g_BRContext.szLastExitCardPhID));
		g_BRContext.u32LastExitResult=-1;
		return iRet;
	}
	
	if(APIParam.AntennaMode==0&&g_BRContext.u8CardPhType==ACC_UL_CARD)//天线模式0=主天线
	{
		pRi->wErrCode=RW_EC_UNKNOWN;
		pRi->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;
		return iRet;
	}
	unsigned long ulTimeSpecOfms=3000;
	if(g_BRContext.u32LastExitResult==0
			&&memcmp(g_BRContext.szLastExitCardPhID,g_BRContext.szCardPhID,sizeof(g_BRContext.szCardPhID))==0
			&&CheckClockTickTimeOut(&g_BRContext.szLastExitTime)==FALSE)
	{
		pRi->wErrCode=RW_EC_NO_CARD_FOUND;
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = Exit_ULCard(APIParam,pRi,&purseGate,&TicketLock);
			break;
		case ACC_M1_CARD:
			break;
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Exit_AccCpuCard(APIParam,pRi,&purseGate,&TicketLock);
			break;
		case CITY_M1_CARD:
			iRet = Exit_YktM1Card(APIParam,pRi,&purseGate,&TicketLock);
			break;
		case CITY_CPU_CARD:
			iRet = Exit_YktCpuCard(APIParam,pRi,&purseGate,&TicketLock);
			break;
		case PBOC_CPU_CARD://市民卡
			break;
		default:
			return 1;
	}

	if(iRet==0)
	{
	  g_BRContext.u32LastExitResult=0;
	  InitClockTickTimeOut(&g_BRContext.szLastExitTime,ulTimeSpecOfms);
	  memcpy(g_BRContext.szLastExitCardPhID,g_BRContext.szCardPhID,sizeof(g_BRContext.szCardPhID));
	  *pLen1 = sizeof(PURSETRADE);
	  memcpy(pMsg1,&purseGate,sizeof(PURSETRADE));
	}
	if(RW_EC_BLACKLIST==iRet)
	{
	g_BRContext.u32LastExitResult=0;
	 memcpy(g_BRContext.szLastExitCardPhID,g_BRContext.szCardPhID,sizeof(g_BRContext.szCardPhID));
	 //加锁信息区定义
	  if(TicketLock.cLockFlag=='1')
	   {
		   *pLen2=sizeof(TicketLock);
		   memcpy(pMsg2,&TicketLock,sizeof(TicketLock));
	   }
	}


	return CE_OK;
}


int Tvm_SjtSale(StruAPIParam APIParam, uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	SJTSALE stSaleSjt; //进站交易结构体

	memset(&stSaleSjt,0,sizeof(SJTSALE));
	uint32 iRet = CE_CHECKERROR;

	
	/********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		PrintLog("File[%s]Line[%d] Tvm_SjtSale pRi->wErrCode RW_EC_ILLEGAL_INPUT_PARAM",__FILE__,__LINE__);
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_TVM)
	{
		PrintLog("File[%s]Line[%d] Tvm_SjtSale g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_TVM",__FILE__,__LINE__);
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}

	unsigned char ucCardPhNoLen=0;
	//寻卡（给变量赋值，可区分UL卡和CPU卡，预留区分城市通卡）g_CardType（ACC_UL_CARD。。。。）
	g_BRContext.Result = PollingCard(APIParam.AntennaMode,&g_BRContext.u8CardPhType,g_BRContext.szCardPhID,&ucCardPhNoLen);
	if(g_BRContext.Result != CE_OK)
	{
		PrintLog("File[%s]Line[%d] Tvm_SjtSale PollingCard Result[%d]",__FILE__,__LINE__,g_BRContext.Result);
		pRi->wErrCode=RW_EC_NO_CARD_FOUND;
		return iRet;
	}
	PrintLog("File[%s]Line[%d] Tvm_SjtSale  PollingCard CardPhType= [%d] ",__FILE__,__LINE__,g_BRContext.u8CardPhType);
	PrintLog("File[%s]Line[%d] Tvm_SjtSale  PollingCard szCardPhID",__FILE__,__LINE__);
	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = TVM_Sale_ULCard(APIParam, u16TranValue, u8PaymentType,pRi, &stSaleSjt);	
			//pRi->wErrCode=iRet;
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			PrintLog("File[%s]Line[%d] Tvm_SjtSale RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE u8CardPhType[%d]",__FILE__,__LINE__,g_BRContext.u8CardPhType);
			break;
	}

	if(iRet == CE_OK)
	{
		*pLen1=sizeof(stSaleSjt);
		memcpy(pMsg1,&stSaleSjt,sizeof(stSaleSjt));

	}

	return iRet;

}
int Tvm_SjtClear(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_TVM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}

	unsigned char ucCardPhNoLen=0;
	//寻卡（给变量赋值，可区分UL卡和CPU卡，预留区分城市通卡）g_CardType（ACC_UL_CARD。。。。）
	g_BRContext.Result = PollingCard(APIParam.AntennaMode,&g_BRContext.u8CardPhType,g_BRContext.szCardPhID,&ucCardPhNoLen);
	if(g_BRContext.Result != CE_OK)
	{
		PrintLog("File[%s]Line[%d] Tvm_SjtClear PollingCard Result[%d]",__FILE__,__LINE__,g_BRContext.Result);
		pRi->wErrCode=RW_EC_NO_CARD_FOUND;
		return iRet;
	}
	PrintLog("File[%s]Line[%d] Tvm_SjtClear  PollingCard CardPhType= [%d] ",__FILE__,__LINE__,g_BRContext.u8CardPhType);
	PrintLog("File[%s]Line[%d] Tvm_SjtClear  PollingCard szCardPhID",__FILE__,__LINE__);

	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = Earse_ULCard(APIParam,pRi);
			//pRi->wErrCode=iRet;
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}


	return iRet;
}
int Tvm_SvtAnalyze(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;
	BOMANALYZE  stAnalysis;
	TICKETLOCK  stTicketLock;
	memset(&stAnalysis,0,sizeof(stAnalysis));
	memset(&stTicketLock,0,sizeof(stTicketLock));
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_TVM&&g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_AVM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}

	unsigned char ucCardPhNoLen=0;
	//寻卡（给变量赋值，可区分UL卡和CPU卡，预留区分城市通卡）g_CardType（ACC_UL_CARD。。。。）
	g_BRContext.Result = PollingCard(APIParam.AntennaMode,&g_BRContext.u8CardPhType,g_BRContext.szCardPhID,&ucCardPhNoLen);
	PrintLog("File[%s]Line[%d] Tvm_SvtAnalyze  PollingCard iRet= [%d] ",__FILE__,__LINE__,g_BRContext.Result);
	if(g_BRContext.Result != CE_OK)
	{
		pRi->wErrCode=RW_EC_NO_CARD_FOUND;
		return iRet;
	}
	PrintLog("File[%s]Line[%d] Tvm_SvtAnalyze  PollingCard CardPhType= [%d] ",__FILE__,__LINE__,g_BRContext.u8CardPhType);
	PrintLog("File[%s]Line[%d] Tvm_SvtAnalyze  PollingCard szCardPhID",__FILE__,__LINE__);
	PrintBuffer((const char *)g_BRContext.szCardPhID,10);

	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = Analysis_ULCard(APIParam,FALSE,EM_CS_AREA_TYPE_UNPAID_AREA,pRi,&stAnalysis,&stTicketLock);
			break;
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Analysis_AccCpuCard(APIParam,FALSE,EM_CS_AREA_TYPE_UNPAID_AREA,pRi,&stAnalysis,&stTicketLock);
			break;
		case CITY_M1_CARD:
			iRet = Analysis_YktM1Card(APIParam,FALSE,EM_CS_AREA_TYPE_UNPAID_AREA,pRi,&stAnalysis,&stTicketLock);
			break;
		case CITY_CPU_CARD:
			iRet = Analysis_YktCpuCard(APIParam,FALSE,EM_CS_AREA_TYPE_UNPAID_AREA,pRi,&stAnalysis,&stTicketLock);
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	*pLen1=sizeof(stAnalysis);
	memcpy(pMsg1,&stAnalysis,sizeof(stAnalysis));

	return iRet;
}

int Tvm_SvtDecrease(StruAPIParam APIParam,uint32 u32Price,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;
	PURSETRADE stPurseInfo;
	memset(&stPurseInfo,0,sizeof(stPurseInfo));
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_TVM&&g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_AVM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}

	switch(g_BRContext.u8CardPhType)
	{
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Decrease_AccCpuCard(APIParam,u32Price,pRi,&stPurseInfo);
			break;
		case CITY_M1_CARD:
			iRet = Decrease_YktM1Card(APIParam,u32Price,pRi,&stPurseInfo);
			break;
		case CITY_CPU_CARD:
			iRet = Decrease_YktCpuCard(APIParam,u32Price,pRi,&stPurseInfo);
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	if(iRet==CE_OK)
	{
		*pLen1=sizeof(stPurseInfo);
		memcpy(pMsg1,&stPurseInfo,sizeof(stPurseInfo));
	}
	return iRet;
}

int Bom_SaleTicket(StruAPIParam APIParam,uint16 u16TranValue,uint8 u8PaymentType,uint8 u8MoneyType, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{

	uint32 iRet = CE_CHECKERROR;
	SJTSALE stSale;
	memset(&stSale,0,sizeof(stSale));

	OTHERSALE stOtherSale;
	memset(&stOtherSale,0,sizeof(stOtherSale));

	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		PrintLog("File[%s]Line[%d] RW_EC_ILLEGAL_INPUT_PARAM",__FILE__,__LINE__);
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		PrintLog("File[%s]Line[%d] CurrentDeviceType[%d]!=EM_DEVICE_TYPE_BOM",__FILE__,__LINE__,g_BRContext.emCurrentDeviceType);
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}

	PrintLog("File[%s]Line[%d] g_BRContext.u8CardPhType[%d]",__FILE__,__LINE__,g_BRContext.u8CardPhType);

	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = Sale_ULCard(APIParam,u16TranValue,u8PaymentType,pRi,&stSale);
			if(iRet==CE_OK)
			{
				*pLen1=sizeof(stSale);
				memcpy(pMsg1,&stSale,sizeof(stSale));
			}
			break;
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Sale_AccCpuCard(APIParam,u16TranValue,u8PaymentType,u8MoneyType,pRi,&stOtherSale);
			if(iRet==CE_OK)
			{
				*pLen2=sizeof(stOtherSale);
				memcpy(pMsg2,&stOtherSale,sizeof(stOtherSale));
			}
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			*pLen1=0;
			*pLen2=0;
			break;
	}

	return iRet;

}



int Bom_TicketAnalyze(StruAPIParam APIParam,uint8 u8IsDegradeMode,uint8 u8WorkArea, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;
	BOMANALYZE  stAnalysis;
	TICKETLOCK  stTicketLock;
	memset(&stAnalysis,0,sizeof(stAnalysis));
	memset(&stTicketLock,0,sizeof(stTicketLock));
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		PrintLog("File[%s]Line[%d] Bom_TicketAnalyze emCurrentDeviceType[%d]",__FILE__,__LINE__,g_BRContext.emCurrentDeviceType);
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}

	unsigned char ucCardPhNoLen=0;
	//寻卡（给变量赋值，可区分UL卡和CPU卡，预留区分城市通卡）g_CardType（ACC_UL_CARD。。。。）
	PrintLog("File[%s]Line[%d] Bom_TicketAnalyze AntennaMode[%d]",__FILE__,__LINE__,APIParam.AntennaMode);
	g_BRContext.Result = PollingCard(APIParam.AntennaMode,&g_BRContext.u8CardPhType,g_BRContext.szCardPhID,&ucCardPhNoLen);
	PrintLog("File[%s]Line[%d] Bom_TicketAnalyze Result[%d] u8CardPhType[%d]",__FILE__,__LINE__,g_BRContext.Result,g_BRContext.u8CardPhType);
	if(g_BRContext.Result != CE_OK)
	{
		PrintLog("File[%s]Line[%d] Bom_TicketAnalyze pRi->wErrCode RW_EC_NO_CARD_FOUND",__FILE__,__LINE__);
		pRi->wErrCode=g_BRContext.Result;
		return iRet;
	}

	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			stAnalysis.cTkAppMode='2';
			PrintLog("File[%s]Line[%d] Bom_TicketAnalyze pRi->wErrCode RW_EC_NO_CARD_FOUND",__FILE__,__LINE__);
			iRet = Analysis_ULCard(APIParam,u8IsDegradeMode,u8WorkArea,pRi,&stAnalysis,&stTicketLock);
			break;
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Analysis_AccCpuCard(APIParam,u8IsDegradeMode,u8WorkArea,pRi,&stAnalysis,&stTicketLock);
			break;
		case CITY_M1_CARD:
			iRet = Analysis_YktM1Card(APIParam,u8IsDegradeMode,u8WorkArea,pRi,&stAnalysis,&stTicketLock);
			break;
		case CITY_CPU_CARD:
			iRet = Analysis_YktCpuCard(APIParam,u8IsDegradeMode,u8WorkArea,pRi,&stAnalysis,&stTicketLock);
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	if(iRet==CE_OK)
	{
	  *pLen1=sizeof(stAnalysis);
	   PrintLog("File[%s]Line[%d] Bom_TicketAnalyze sizeof(stAnalysis)=[%d]",__FILE__,__LINE__,sizeof(stAnalysis));
	   memcpy(pMsg1,&stAnalysis,sizeof(stAnalysis));

	   if(pRi->wErrCode==RW_EC_BLACKLIST)
	   {
		   if(stTicketLock.cLockFlag=='1')
		   {
			   *pLen2=sizeof(stTicketLock);
			   PrintLog("File[%s]Line[%d] Bom_TicketAnalyze sizeof(stAnalysis)=[%d]",__FILE__,__LINE__,sizeof(stAnalysis));
			   memcpy(pMsg2,&stTicketLock,sizeof(stTicketLock));
		   }
	   }
	}


	return iRet;
}

int Bom_GetTicketInfo(StruAPIParam APIParam, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{

	uint32 iRet = CE_CHECKERROR;
	TICKETINFO  stTicketInfo;
	memset(&stTicketInfo,0,sizeof(TICKETINFO));
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}

	unsigned char ucCardPhNoLen=0;
	//寻卡（给变量赋值，可区分UL卡和CPU卡，预留区分城市通卡）g_CardType（ACC_UL_CARD。。。。）
	g_BRContext.Result = PollingCard(APIParam.AntennaMode,&g_BRContext.u8CardPhType,g_BRContext.szCardPhID,&ucCardPhNoLen);
	PrintLog("File[%s]Line[%d] Bom_GetTicketInfo  PollingCard iRet= [%d] ",__FILE__,__LINE__,g_BRContext.Result);
	if(g_BRContext.Result != CE_OK)
	{
		pRi->wErrCode=RW_EC_NO_CARD_FOUND;
		return iRet;
	}
	PrintLog("File[%s]Line[%d] Bom_GetTicketInfo  PollingCard CardPhType= [%d] ",__FILE__,__LINE__,g_BRContext.u8CardPhType);
	PrintLog("File[%s]Line[%d] Bom_GetTicketInfo  PollingCard szCardPhID",__FILE__,__LINE__);
	PrintBuffer((const char *)g_BRContext.szCardPhID,10);

	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = Query_ULCard(APIParam,pRi,&stTicketInfo);
			break;
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Query_AccCpuCard(APIParam,pRi,&stTicketInfo);
			break;
		case CITY_M1_CARD:
			iRet = Query_YktM1Card(APIParam,pRi,&stTicketInfo);
			break;
		case CITY_CPU_CARD:
			iRet = Query_YktCpuCard(APIParam,pRi,&stTicketInfo);
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	*pLen1=sizeof(stTicketInfo);
	memcpy(pMsg1,&stTicketInfo,sizeof(stTicketInfo));

	return iRet;
}



int Bom_GetPriceDiff(StruAPIParam APIParam,BYTE *bTicketType, BYTE *bStationID,int iRemainningValue, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	/***********************************************************************
	*
	*	该部分内容需要都读卡器实际代码来替换,目前代码仅仅用于与上位机联通测试
	*
	*********************************************************************/

	int iRet=-1;
	int iWeekDay=0;
	//参数判断指针是否为空,避免程序崩溃.
	uint8 szTicketType[5]={0};
	uint8 szStationID[5]={0};
	uint8 szCurrentStationID[5]={0};
	uint8 szInGateTime[15]={0};
	uint8 szInweekday[3]={0};
	int  iPriceDiff=0;
	int iPrice=0;

	uint8 szFareZone[2]={0};//收费区段	CHAR	2
	uint8 szJourneyTimeLimit[5]={0};//乘车时间限制 (单位：分钟)	CHAR	5	单位：分钟
	uint8 szTimeoutsFines[4]={0};//超时罚金	CHAR	4
	uint8 szRidingTime[1]={0};//乘车时间代码	CHAR	1
	uint8 szTrainTicketTableID[3]={0};//票价表ID	CHAR	3
	uint8 szFare[10]={0};//收费 (单位：分或次)	CHAR	10

	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{

		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return CE_OK;
	}

	sprintf((char*)szTicketType,"%02X%02X",bTicketType[0],bTicketType[1]);
	sprintf((char*)szStationID,"%02d%02d",bStationID[0],bStationID[1]);
	sprintf((char*)szCurrentStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	sprintf((char*)szInGateTime,"%02x%02x%02x%02x%02x%02x%02x",APIParam.ucTimeStamp[0],APIParam.ucTimeStamp[1],APIParam.ucTimeStamp[2],
			APIParam.ucTimeStamp[3],APIParam.ucTimeStamp[4],APIParam.ucTimeStamp[5],APIParam.ucTimeStamp[6]);


	iWeekDay=GetWeekDayOf7BCDTime(APIParam.ucTimeStamp);
	sprintf((char*)szInweekday,"%d",iWeekDay);

	iRet=BR_CalcAmountConsumption_h(szTicketType, szStationID, szCurrentStationID,szInGateTime,szInGateTime,szInweekday,szInweekday,
		   szFareZone, szJourneyTimeLimit, szTimeoutsFines, szRidingTime, szTrainTicketTableID, szFare);

	if(iRet!=RW_EC_OK)
	{
		PrintLog("File[%s]Line[%d] Bom_GetPriceDiff BR_CalcAmountConsumption_h=[%d]",__FILE__,__LINE__,iRet);
		pRi->wErrCode = RW_EC_UNKNOWN;//
		return CE_OK;
	}

	*pLen1 =sizeof(long); //long数据类型
	 iPrice=atoi((char*)szFare);
	 iPriceDiff= iPrice>iRemainningValue?iPrice-iRemainningValue:0;
	 PrintLog("File[%s]Line[%d] Bom_GetPriceDiff iPrice[%d]  iRemainningValue[%d]iPriceDiff=[%d]",__FILE__,__LINE__,iPrice,iRemainningValue,iPriceDiff);
	 memcpy(pMsg1,&iPriceDiff,4);

	*pLen2 = 0;
	return CE_OK;
}
int Bom_GetPenalty(StruAPIParam APIParam,BYTE *bTicketType, BYTE bPenaltyCode, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;

	uint8 MainType=0;
	uint8 SubType=0;

	MainType=bTicketType[0];
	SubType=bTicketType[1];

	uint16 u16PaneltyValue=0;

	char szCurrentStation[10]={0};

	Para0301  TicktPara0301;

	iRet= BR_GetParaTicketsTypeTable_h(MainType, SubType,(uint8*)&TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Bom_GetPenalty  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRi->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRi->wErrCode;
	}

	switch(bPenaltyCode)
	{
	case 10:
	case 11:
	case 12:
	case 13:
	case 20:
	case 21:
	case 22:
	case 23:
	case 24:
	case 25:
	case 26:
	case 27:
	case 99:
		 break;
	default:
		pRi->wErrCode=RW_EC_ILLEGAL_INPUT_PARAM;
		 return pRi->wErrCode;
	}


	sprintf(szCurrentStation,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	iRet=BR_GetPaneltyValue( MainType,  SubType,szCurrentStation,bPenaltyCode,&u16PaneltyValue);
	if(iRet!=RW_EC_OK)
	{
		PrintLog("File[%s]Line[%d] Bom_GetPenalty BR_GetPaneltyValue=[%d]",__FILE__,__LINE__,iRet);
		pRi->wErrCode = RW_EC_UNKNOWN;//
		return CE_OK;
	}

	*pLen1 =sizeof(u16PaneltyValue); //long数据类型

	 PrintLog("File[%s]Line[%d] Bom_GetPenalty u16PaneltyValue[%d]",__FILE__,__LINE__,u16PaneltyValue);
	 memcpy(pMsg1,&u16PaneltyValue,2);

	*pLen2 = 0;
	return CE_OK;
}
int Bom_GetActiveInfo(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;
	int i=0;
	uint8 CardRandom[8];
	EquipmentActivateReader st_EquipmentActivateReader;
	memset(&st_EquipmentActivateReader,0x00,sizeof(st_EquipmentActivateReader));
	memset(CardRandom,0x00,sizeof(CardRandom));

	st_EquipmentActivateReader.MessageType[0] = '5';
	st_EquipmentActivateReader.MessageType[1] = '5';

	memcpy(st_EquipmentActivateReader.MessageTime,APIParam.ucTimeStamp,7);

	st_EquipmentActivateReader.TerminalID[0]=g_BRContext.bCurrentStationID[0]/10+'0';
	st_EquipmentActivateReader.TerminalID[1]=g_BRContext.bCurrentStationID[0]%10+'0';
	st_EquipmentActivateReader.TerminalID[2]=g_BRContext.bCurrentStationID[1]/10+'0';
	st_EquipmentActivateReader.TerminalID[3]=g_BRContext.bCurrentStationID[1]%10+'0';
	st_EquipmentActivateReader.TerminalID[4]=g_BRContext.bCurrentDeviceTypeCode/10+'0';
	st_EquipmentActivateReader.TerminalID[5]=g_BRContext.bCurrentDeviceTypeCode%10+'0';
	st_EquipmentActivateReader.TerminalID[6]=g_BRContext.bCurrentDeviceID[0]%10+'0';
	st_EquipmentActivateReader.TerminalID[7]=g_BRContext.bCurrentDeviceID[1]/10+'0';
	st_EquipmentActivateReader.TerminalID[8]=g_BRContext.bCurrentDeviceID[1]%10+'0';

	memcpy(st_EquipmentActivateReader.SamLogicID,g_BRContext.stSamInfo[0].cSAMID,16);

	iRet = SamGetRandom(SAM_SLOT_ACC,CardRandom);
	if(iRet!=CE_OK)
	{pRi->wErrCode=RW_ERR_SAM_RESPONSE;}

	for(i=0;i<8;i++)
	{
		if((CardRandom[i]/0x10)>=0&&(CardRandom[i]/0x10)<=9)
		{
			if((CardRandom[i]%0x10)>=0&&(CardRandom[i]%0x10)<=9)
			{
				st_EquipmentActivateReader.Random[2*i]=CardRandom[i]/0x10+'0';
				st_EquipmentActivateReader.Random[2*i+1]=CardRandom[i]%0x10+'0';
			}
			else
			{
				st_EquipmentActivateReader.Random[2*i]=CardRandom[i]/0x10+'0';
				st_EquipmentActivateReader.Random[2*i+1]=CardRandom[i]%0x10-10+'A';
			}
		}
		else
		{
			if((CardRandom[i]%0x10)>=0&&(CardRandom[i]%0x10)<=9)
			{
				st_EquipmentActivateReader.Random[2*i]=CardRandom[i]/0x10-10+'A';
				st_EquipmentActivateReader.Random[2*i+1]=CardRandom[i]%0x10+'0';
			}
			else
			{
				st_EquipmentActivateReader.Random[2*i]=CardRandom[i]/0x10-10+'A';
				st_EquipmentActivateReader.Random[2*i+1]=CardRandom[i]%0x10-10+'A';
			}
		}
	}


	*pLen1=sizeof(st_EquipmentActivateReader);
	memcpy(pMsg1,&st_EquipmentActivateReader,sizeof(st_EquipmentActivateReader));
	*pLen2=0;

	return iRet;
}

int Bom_Active(StruAPIParam APIParam,EquipmentActivateServer st_EquipmentActivateServer,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;
	int i=0;
	uint8 MAC[8];
	memset(MAC,0x00,sizeof(MAC));

	for(i=0;i<8;i++)
	{
		if(st_EquipmentActivateServer.MAC[2*i]>='0'&&st_EquipmentActivateServer.MAC[2*i]<='9')
		{
			if(st_EquipmentActivateServer.MAC[2*i+1]>='0'&&st_EquipmentActivateServer.MAC[2*i+1]<='9')
			{
				MAC[i] = (st_EquipmentActivateServer.MAC[2*i]-'0')*0x10+st_EquipmentActivateServer.MAC[2*i+1]-'0';
			}
			else
			{
				MAC[i] = (st_EquipmentActivateServer.MAC[2*i]-'0')*0x10+st_EquipmentActivateServer.MAC[2*i+1]-'A'+10;
			}
		}
		else
		{
			if(st_EquipmentActivateServer.MAC[2*i+1]>='0'&&st_EquipmentActivateServer.MAC[2*i+1]<='9')
			{
				MAC[i] = (st_EquipmentActivateServer.MAC[2*i]-'A'+10)*0x10+st_EquipmentActivateServer.MAC[2*i+1]-'0';
			}
			else
			{
				MAC[i] = (st_EquipmentActivateServer.MAC[2*i]-'A'+10)*0x10+st_EquipmentActivateServer.MAC[2*i+1]-'A'+10;
			}
		}
	}

	iRet = SamExternalAuthentication(SAM_SLOT_ACC,MAC);
	if(iRet!=CE_OK)
	{
		pRi->wErrCode=RW_ERR_SAM_RESPONSE;
	}

	return iRet;
}

int Bom_TopupInit(StruAPIParam APIParam,uint8 TopupType,uint32 TopupValue,uint8 *NetPoint,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;

	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM&&g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_TVM&&g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_AVM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{

		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Bom_AccCPU_TopupInit(APIParam,TopupType,TopupValue,NetPoint,pRi ,pLen1, pMsg1, pLen2,pMsg2);
			break;
		default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	return iRet;
}

int Bom_TopupOperate(StruAPIParam APIParam,TopupRequestServer st_TopupRequestServer,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;

	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM&&g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_TVM&&g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_AVM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{

		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Bom_AccCPU_TopupOperate(APIParam,st_TopupRequestServer,pRi ,pLen1, pMsg1, pLen2,pMsg2);
			break;
		default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	return iRet;
}

int ChargeBackInit(StruAPIParam APIParam,uint8 Type,uint32 Value,uint32 remainningValue,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;

	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{

		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Bom_ACCCPU_ChargeBackInit(APIParam,Type,Value,remainningValue,pRi ,pLen1, pMsg1, pLen2,pMsg2);
			break;
		default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	return iRet;

}

int ChargeBackOperate(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;

	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{

		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Bom_ACCCPU_ChargeBackOperate(APIParam,pRi ,pLen1, pMsg1, pLen2,pMsg2);
			break;
		default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	return iRet;

}

int Bom_Unblock(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{

	uint32 iRet = CE_CHECKERROR;
	TICKETLOCK stLockInfo;
	memset(&stLockInfo,0,sizeof(stLockInfo));
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			break;
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Unlock_AccCpuCard(APIParam,pRi,&stLockInfo);
			break;
		case CITY_M1_CARD:
			iRet = Unlock_YktM1Card(APIParam,pRi,&stLockInfo);
			break;
		case CITY_CPU_CARD:
			iRet = Unlock_YktCpuCard(APIParam,pRi,&stLockInfo);
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	if(iRet==CE_OK)
	{
	*pLen1=sizeof(stLockInfo);
	memcpy(pMsg1,&stLockInfo,sizeof(stLockInfo));
	}
	return iRet;
}

int Bom_Refund(StruAPIParam APIParam,uint8 u8RefundOption,uint8 u8RefundCode,uint16 u16TranValue,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{

	uint32 iRet = CE_CHECKERROR;
	DIRECTREFUND  stRefundInfo;
	memset(&stRefundInfo,0,sizeof(stRefundInfo));
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = Refund_ULCard(APIParam,u8RefundOption,u8RefundCode,u16TranValue,pRi,&stRefundInfo);
			break;
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Refund_AccCpuCard(APIParam,u8RefundOption,u8RefundCode,u16TranValue,pRi,&stRefundInfo);
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	if(iRet==CE_OK)
	{
	*pLen1=sizeof(stRefundInfo);
	memcpy(pMsg1,&stRefundInfo,sizeof(stRefundInfo));
	}
	return iRet;
}

int Bom_Deffer(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{

	uint32 iRet = CE_CHECKERROR;
	TICKETDEFER  stDeferInfo;
	memset(&stDeferInfo,0,sizeof(stDeferInfo));
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Defer_AccCpuCard(APIParam,pRi,&stDeferInfo);
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	if(iRet==CE_OK)
	{
	*pLen1=sizeof(stDeferInfo);
	memcpy(pMsg1,&stDeferInfo,sizeof(stDeferInfo));
	}
	return iRet;
}

int Bom_SvtDecrease(StruAPIParam APIParam,uint32 u32Price,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{

	uint32 iRet = CE_CHECKERROR;
	PURSETRADE stPurseInfo;
	memset(&stPurseInfo,0,sizeof(stPurseInfo));
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}



	switch(g_BRContext.u8CardPhType)
	{
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Decrease_AccCpuCard(APIParam,u32Price,pRi,&stPurseInfo);
			break;
		case CITY_M1_CARD:
			iRet = Decrease_YktM1Card(APIParam,u32Price,pRi,&stPurseInfo);
			break;
		case CITY_CPU_CARD:
			iRet = Decrease_YktCpuCard(APIParam,u32Price,pRi,&stPurseInfo);
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	if(iRet==CE_OK)
	{
	*pLen1=sizeof(stPurseInfo);
	memcpy(pMsg1,&stPurseInfo,sizeof(stPurseInfo));
	}
	return iRet;
}

int Bom_Update(StruAPIParam APIParam,uint8 u8UpdateCode,uint16 u16EntryStationCode,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{

	uint32 iRet = CE_CHECKERROR;
	TICKETUPDATE  stUpdateInfo;
	memset(&stUpdateInfo,0,sizeof(stUpdateInfo));
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = Update_ULCard(APIParam,u8UpdateCode,u16EntryStationCode,u16TranValue,u8PaymentType,pRi,&stUpdateInfo);
			break;
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Update_AccCpuCard(APIParam,u8UpdateCode,u16EntryStationCode,u16TranValue,u8PaymentType,pRi,&stUpdateInfo);
			break;
		case CITY_M1_CARD:
			iRet = Update_YktM1Card(APIParam,u8UpdateCode,u16EntryStationCode,u16TranValue,u8PaymentType,pRi,&stUpdateInfo);
			break;
		case CITY_CPU_CARD:
			iRet = Update_YktCpuCard(APIParam,u8UpdateCode,u16EntryStationCode,u16TranValue,u8PaymentType,pRi,&stUpdateInfo);
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	if(iRet==CE_OK)
	{
	*pLen1=sizeof(stUpdateInfo);
	memcpy(pMsg1,&stUpdateInfo,sizeof(stUpdateInfo));
	}
	return iRet;
}

int Bom_SaleExitSJT(StruAPIParam APIParam,uint16 u16Price,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{

	uint32 iRet = CE_CHECKERROR;
	SJTSALE stSjtSale;
	memset(&stSjtSale,0,sizeof(stSjtSale));
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	PrintLog("File[%s]Line[%d] u16Price=[%d]",__FILE__,__LINE__,u16Price);

	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = Sale_Exit_ULCard(APIParam,u16Price,pRi,&stSjtSale);
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	if(iRet==CE_OK)
	{
	 pRi->wErrCode=RW_EC_OK;
	*pLen1=sizeof(stSjtSale);
	 memcpy(pMsg1,&stSjtSale,sizeof(stSjtSale));
	}
	return iRet;
}

int Bom_ConfirmTran(StruAPIParam APIParam,uint8 u8Option,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;

	TRANSACTCONFIRM  stTRANSACTCONFIRM;
	memset(&stTRANSACTCONFIRM,0,sizeof(TRANSACTCONFIRM));

	unsigned char szUD[1024]={0};
	unsigned short usUDLen=0;

	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = Confirm_ULCard( APIParam,pRi,szUD,&usUDLen);
			break;
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = 0;
			break;
		case CITY_M1_CARD:
			//iRet = Confirm_YktM1Card(APIParam,pRi,szUD,&usUDLen);
			break;
		case CITY_CPU_CARD:
			iRet = 0;
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	if(iRet==CE_OK)
	{
	  stTRANSACTCONFIRM.bTradeType=1;
	  memcpy(stTRANSACTCONFIRM.bData,szUD,usUDLen);

	  *pLen1=sizeof(stTRANSACTCONFIRM);
      memcpy(pMsg1,&stTRANSACTCONFIRM,sizeof(stTRANSACTCONFIRM));

	}
	return iRet;

}


int Tcm_GetTicketInfo(StruAPIParam APIParam, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{

	uint32 iRet = CE_CHECKERROR;
	TICKETINFO  stTicketInfo;
	memset(&stTicketInfo,0,sizeof(TICKETINFO));
	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_TCM&&g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_AVM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}

	unsigned char ucCardPhNoLen=0;
	//寻卡（给变量赋值，可区分UL卡和CPU卡，预留区分城市通卡）g_CardType（ACC_UL_CARD。。。。）
	g_BRContext.Result = PollingCard(APIParam.AntennaMode,&g_BRContext.u8CardPhType,g_BRContext.szCardPhID,&ucCardPhNoLen);
	if(g_BRContext.Result != CE_OK)
	{
		pRi->wErrCode=RW_EC_NO_CARD_FOUND;
		return iRet;
	}

	switch(g_BRContext.u8CardPhType)
	{
		case ACC_UL_CARD:
			iRet = Query_ULCard(APIParam,pRi,&stTicketInfo);
			break;
		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Query_AccCpuCard(APIParam,pRi,&stTicketInfo);
			break;
		case CITY_M1_CARD:
			iRet = Query_YktM1Card(APIParam,pRi,&stTicketInfo);
			break;
		case CITY_CPU_CARD:
			iRet = Query_YktCpuCard(APIParam,pRi,&stTicketInfo);
			break;
	default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	*pLen1=sizeof(stTicketInfo);
	memcpy(pMsg1,&stTicketInfo,sizeof(stTicketInfo));

	return iRet;
}

int Test_Read_Acc_ULCard(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{

	uint32 iRet = CE_CHECKERROR;

	CARD_ACC_UL  stULCardInfo;
	memset(&stULCardInfo,0,sizeof(CARD_ACC_UL));

    *pLen1=0;
    *pLen2=0;

    unsigned char ucCardPhNoLen=0;
    	//寻卡（给变量赋值，可区分UL卡和CPU卡，预留区分城市通卡）g_CardType（ACC_UL_CARD。。。。）
	g_BRContext.Result = PollingCard(APIParam.AntennaMode,&g_BRContext.u8CardPhType,g_BRContext.szCardPhID,&ucCardPhNoLen);
	PrintLog("File[%s]Line[%d]PollingCard Result=[%d],CardPhType=[%d]",__FILE__,__LINE__,g_BRContext.Result,g_BRContext.u8CardPhType);
	if(g_BRContext.Result != CE_OK)
	{
		pRi->wErrCode=RW_EC_NO_CARD_FOUND;
		return iRet;
	}

	if(g_BRContext.u8CardPhType!=ACC_UL_CARD)
	{
		pRi->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return iRet;
	}

	iRet= Inner_Read_ULCard(APIParam,&stULCardInfo);
	PrintLog("File[%s]Line[%d]Test_Read_Acc_ULCard iRet=[%d] ",__FILE__,__LINE__,iRet);
	if(iRet!=CE_OK)
	{
		pRi->wErrCode=RW_EC_READ_FAILED;
		return iRet;
	}

	pRi->wErrCode=RW_EC_OK;

	*pLen1=64;

	 memcpy(pMsg1,stULCardInfo.CardUL,64);
	 PrintLog("File[%s]Line[%d]Test_Read_Acc_ULCard ULCard Info ",__FILE__,__LINE__);
	 PrintBuffer(pMsg1,64);

	 return iRet;
}
int Test_Write_Acc_ULCard(StruAPIParam APIParam,uint8 * u8Buffer,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;
    uint8 point=0;

    point=u8Buffer[0];
    *pLen1=0;
    *pLen2=0;

	iRet= Write_ULCard_Info(APIParam.AntennaMode,u8Buffer+1,point);
	PrintLog("File[%s]Line[%d]Test_Write_Acc_ULCard iRet=[%d] ",__FILE__,__LINE__,iRet);
	if(iRet!=CE_OK)
	{
		pRi->wErrCode=RW_EC_READ_FAILED;
		return iRet;
	}
	pRi->wErrCode=RW_EC_OK;
	return iRet;
}


int InitBiz()
{
	//初始化ACCSAM
	uint8 cardNum[9]={0};
	uint8 cardNumLen=0;
	char  szCardNumString[20]={0};
	int iRet=-1;

    g_BRContext.stSamInfo[0].bSAMStatus=0xFF;
    memset(g_BRContext.stSamInfo[0].cSAMID,'0',16);


    g_BRContext.stSamInfo[1]=g_BRContext.stSamInfo[0];
    g_BRContext.stSamInfo[2]=g_BRContext.stSamInfo[0];
    g_BRContext.stSamInfo[3]=g_BRContext.stSamInfo[0];
    g_BRContext.stSamInfo[4]=g_BRContext.stSamInfo[0];
    g_BRContext.stSamInfo[5]=g_BRContext.stSamInfo[0];
    g_BRContext.stSamInfo[6]=g_BRContext.stSamInfo[0];
    g_BRContext.stSamInfo[7]=g_BRContext.stSamInfo[0];



    //Acc psam
    memset(cardNum,0,sizeof(cardNum));
    memset(szCardNumString,0,sizeof(szCardNumString));
    printf("SamInit begin=[%d]\r\n",cardNumLen);
	iRet=SamInit(SAM_SLOT_ACC,cardNum,&cardNumLen);
	printf("SamInit cardNumLen=[%d]\r\n",cardNumLen);
	if(iRet==CE_OK)
	{
		g_BRContext.stSamInfo[0].bSAMStatus=1;//0x00－表示正常
		BcdToString(cardNum,cardNumLen,szCardNumString);
		strncpy(g_BRContext.stSamInfo[0].cSAMID,szCardNumString,16);
		printf("SamInit cardNum=[%s]\r\n",szCardNumString);
	}else
	{
		g_BRContext.stSamInfo[0].bSAMStatus=0xFF;
	}

	// ykt cpu
    memset(cardNum,0,sizeof(cardNum));
    memset(szCardNumString,0,sizeof(szCardNumString));
	iRet=YktCpuSamInit(SAM_SLOT_YKT_CPU,cardNum,&cardNumLen);
	printf("SamInit cardNumLen=[%d]\r\n",cardNumLen);
	if(iRet==CE_OK)
	{
		g_BRContext.stSamInfo[1].bSAMStatus=1;//0x00－表示正常
		BcdToString(cardNum,cardNumLen,szCardNumString);
		strncpy(g_BRContext.stSamInfo[1].cSAMID,szCardNumString,16);
		printf("SamInit cardNum=[%s]\r\n",szCardNumString);
	}else
	{
		g_BRContext.stSamInfo[1].bSAMStatus=0xFF;
	}

	// ykt m1
    memset(cardNum,0,sizeof(cardNum));
    memset(szCardNumString,0,sizeof(szCardNumString));
	iRet=YktM1SamInit(SAM_SLOT_YKT_M1,cardNum,&cardNumLen);
	printf("SamInit cardNumLen=[%d]\r\n",cardNumLen);
	if(iRet==CE_OK)
	{
		g_BRContext.stSamInfo[2].bSAMStatus=1;//0x00－表示正常
		BcdToString(cardNum,cardNumLen,szCardNumString);
		strncpy(g_BRContext.stSamInfo[2].cSAMID,szCardNumString,16);
		printf("SamInit cardNum=[%s]\r\n",szCardNumString);
	}else
	{
		g_BRContext.stSamInfo[2].bSAMStatus=0xFF;
	}

	return iRet;
}

int Bom_ChargeBackInit(StruAPIParam APIParam,uint8 Type,uint32 Value,uint32 remainningValue,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{
	uint32 iRet = CE_CHECKERROR;

	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{

		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Bom_ACCCPU_ChargeBackInit(APIParam,Type,Value,remainningValue,pRi ,pLen1, pMsg1, pLen2,pMsg2);
			break;
		default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	return iRet;


}

int Bom_ChargeBackOperate(StruAPIParam APIParam,TopupRepealServer st_TopupRepealServer,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2)
{

	uint32 iRet = CE_CHECKERROR;

	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pLen1==NULL || pMsg1==NULL || pLen2==NULL || pMsg2==NULL)
	{
		pRi->wErrCode = RW_EC_ILLEGAL_INPUT_PARAM;// 错误码,非法的输入参数
		return iRet;
	}

	*pLen1=0;
	*pLen2=0;

	//判断设备类型;
	if(g_BRContext.emCurrentDeviceType!=EM_DEVICE_TYPE_BOM)
	{
		pRi->wErrCode = RW_EC_INVALID_API_CALL;// 错误码,非法的输入参数
		return iRet;
	}


	switch(g_BRContext.u8CardPhType)
	{

		case ACC_NFC_CPU_CARD:
		case ACC_CPU_CARD:
			iRet = Bom_ACCCPU_ChargeBackOperate(APIParam,pRi ,pLen1, pMsg1, pLen2,pMsg2);
			break;
		default:
			pRi->wErrCode=RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE;
			break;
	}

	return iRet;


}
//2015.11.07 获取日志大小
int Common_GetLogFileSize(StruAPIParam APIParam,	//函数公共参数
						  RetInfo * pRi,			//返回结构体
						  BYTE LogFileType,			//日志文件类型
						  BYTE LogFileDate[4],		//日志文件时间
						  uint32 * pdwLogFileSize)  	//返回的日志文件大小
{
	char szCmd[512]; //系统命令
	BYTE Temp[100];
	char FullLogFileName[512];
	char LogFileName[64];
	long lTemp =0;

 	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || pdwLogFileSize == NULL ||LogFileDate == NULL || pdwLogFileSize ==NULL  )
	{
		PrintLog("call Common_GetLogFileSize,parameter is null\n");
		pRi->wErrCode = RW_EC_UNKNOWN;
		pRi->bNoticeCode = RW_EC_UNKNOWN;
		return 1;
	}
	memset((void *)pRi,0 ,sizeof(RetInfo));

	//2015.12.12 删除临时文件,防止临时文件过多(例如反复多次获取不同日志文件时)
	system(SHELL_CMD_DELETE_TMP);

	if(LogFileType==0) //日志文件
	{
		//步骤1.首先写入磁盘
		FlushDisk();
		usleep(1);
		//步骤2.对日志文件进行压缩
		GetCurrentTime(Temp);
		if(memcmp(Temp,LogFileDate,4)==0) //如果是当天则立即进行压缩,并压缩到临时目录中
		{
			sprintf(LogFileName,"tpu_%02X%02X%02X%02X.log",
					LogFileDate[0],LogFileDate[1],LogFileDate[2],LogFileDate[3]);
			//执行压缩
			sprintf(szCmd,"gtar zcpvf %s/%s.tar.gz  /tpu/log/%s",TPU_TEMP_PATH,LogFileName,LogFileName);
 			system(szCmd);
	 		sprintf(FullLogFileName,"%s/%s.tar.gz",TPU_TEMP_PATH,LogFileName);
		}else
		{
			sprintf(FullLogFileName,"/tpu/log/tpu_%02X%02X%02X%02X.log.tar.gz",
					LogFileDate[0],LogFileDate[1],LogFileDate[2],LogFileDate[3]);
		}
 		//获取文件大小
		lTemp = GetFileSize(FullLogFileName);

		if(lTemp>=0)
			memcpy(pdwLogFileSize,&lTemp,4);
		else
		{
			pRi->wErrCode =  RW_EC_PARAMETER_FILE_NOT_EXIST;
		}
		//又一个整数不能取地址的典型
 		// *pdwLogFileSize = g_ThreadLogTpu.GetFileSize(FullLogFileName);

	}
	else if(LogFileType==1) //交易文件(说明:交易文件的处理方式完全和日志文件一样)
	{
		//步骤1.首先写入磁盘
		FlushDisk();
		usleep(1);
		GetCurrentTime(Temp);
		if(memcmp(Temp,LogFileDate,4)==0) //如果是当天则立即进行压缩,并压缩到临时目录中
		{
			sprintf(LogFileName,"ud_%02X%02X%02X%02X.log",
					LogFileDate[0],LogFileDate[1],LogFileDate[2],LogFileDate[3]);
			//执行压缩
			sprintf(szCmd,"gtar zcpvf %s/%s.tar.gz  /tpu/log/%s",TPU_TEMP_PATH,LogFileName,LogFileName);
 			system(szCmd);
	 		sprintf(FullLogFileName,"%s/%s.tar.gz",TPU_TEMP_PATH,LogFileName);
		}else
		{
			sprintf(FullLogFileName,"/tpu/log/ud_%02X%02X%02X%02X.log.tar.gz",
					LogFileDate[0],LogFileDate[1],LogFileDate[2],LogFileDate[3]);
		}

 		//获取文件大小
		lTemp = GetFileSize(FullLogFileName);
		if(lTemp>=0)
			memcpy(pdwLogFileSize,&lTemp,4);
		else
		{
			pRi->wErrCode =  RW_EC_PARAMETER_FILE_NOT_EXIST;
		}
		//又一个整数不能取地址的典型
 		//*pdwLogFileSize = g_ThreadLogTpu.GetFileSize(FullLogFileName);
	}
	else if(LogFileType==2) //系统参数文件
	{
		//执行压缩
		sprintf(szCmd,"gtar zcpvf %s/parameter.tar.gz  /tpu/parameter",TPU_TEMP_PATH);
		system(szCmd);
 		sprintf(FullLogFileName,"%s/parameter.tar.gz",TPU_TEMP_PATH);

 		//获取文件大小
 		lTemp = GetFileSize(FullLogFileName);
		if(lTemp>=0)
			memcpy(pdwLogFileSize,&lTemp,4);
		else
		{
			pRi->wErrCode =  RW_EC_PARAMETER_FILE_NOT_EXIST;
		}

	}else
	{
		pRi->wErrCode = RW_EC_INVALID_INPUT_PARAM;
	}
 	return 0;
}

//2015.11.09 获取日志文件内容
int Common_GetLogFileData(StruAPIParam APIParam,	//函数公共参数
						  RetInfo * pRi,			//返回结构体
						  BYTE LogFileType,			//日志文件类型
						  BYTE LogFileDate[4],		//日志文件时间
						  uint32 dwLogFilePos, 	//日志文件开始读取位置
						  WORD  wReadCount ,  	//日志文件读取大小
						  BYTE * pLogFileData)  	//返回的日志文件大小
{
	//char szCmd[512]; //系统命令
	BYTE Temp[100];
	char FullLogFileName[512];

 	//参数判断指针是否为空,避免程序崩溃.
	if( pRi==NULL || LogFileDate == NULL || pLogFileData == NULL)
	{
		PrintLog("call Common_GetLogFileSize,parameter is null\n");
		pRi->wErrCode = RW_EC_UNKNOWN;
		pRi->bNoticeCode = RW_EC_UNKNOWN;
		return 1;
	}
	memset((void *)pRi,0 ,sizeof(RetInfo));

	if(LogFileType==0) //日志文件
	{
		GetCurrentTime(Temp);
		if(memcmp(Temp,LogFileDate,4)==0) //如果是当天则立即进行压缩,并压缩到临时目录中
		{
			sprintf(FullLogFileName,"%s/tpu_%02X%02X%02X%02X.log.tar.gz",
					TPU_TEMP_PATH,LogFileDate[0],LogFileDate[1],LogFileDate[2],LogFileDate[3]);
		}else
		{
			sprintf(FullLogFileName,"/tpu/log/tpu_%02X%02X%02X%02X.log.tar.gz",
					LogFileDate[0],LogFileDate[1],LogFileDate[2],LogFileDate[3]);
		}
 		//获取文件大小
		if(ReadFileData(FullLogFileName,dwLogFilePos,wReadCount,pLogFileData)!=TRUE)
		{
			pRi->wErrCode =  RW_EC_FILE_PROCESS_ERROR;
		}

	}
	else if(LogFileType==1) //交易文件(说明:交易文件的处理方式完全和日志文件一样)
	{
		GetCurrentTime(Temp);
		if(memcmp(Temp,LogFileDate,4)==0) //如果是当天则立即进行压缩,并压缩到临时目录中
		{
			sprintf(FullLogFileName,"%s/ud_%02X%02X%02X%02X.log.tar.gz",
					TPU_TEMP_PATH,LogFileDate[0],LogFileDate[1],LogFileDate[2],LogFileDate[3]);
		}else
		{
			sprintf(FullLogFileName,"/tpu/log/ud_%02X%02X%02X%02X.log.tar.gz",
					LogFileDate[0],LogFileDate[1],LogFileDate[2],LogFileDate[3]);
		}
 		//获取文件内容
		if(ReadFileData(FullLogFileName,dwLogFilePos,wReadCount,pLogFileData)!=TRUE)
		{
			pRi->wErrCode =  RW_EC_FILE_PROCESS_ERROR;
		}

		//又一个整数不能取地址的典型
 		//*pdwLogFileSize = g_ThreadLogTpu.GetFileSize(FullLogFileName);
	}
	else if(LogFileType==2) //系统参数文件
	{
		sprintf(FullLogFileName,"%s/parameter.tar.gz",TPU_TEMP_PATH);
		if(ReadFileData(FullLogFileName,dwLogFilePos,wReadCount,pLogFileData)!=TRUE)
		{
			pRi->wErrCode =  RW_EC_FILE_PROCESS_ERROR;
		}
	}else
	{
		pRi->wErrCode = RW_EC_INVALID_INPUT_PARAM;
	}
 	return 0;
}
