/*********************************************************
*程序名称:		ULCardBusiness.h
*版本号:		0.1			
*功能描述:		 <<长沙轨道交通1号线读卡器接口调用API文档.docx>>文档中,
				所有的与上位机的接口处理函数都定义在本文件中,函数名称与文档中的名称一致.
*作者:			licd			
*修改记录:		
				2015.01.13 创建 
*其他:						
***********************************************************/

#ifndef __ULCARDBUSINESS_H__
#define __ULCARDBUSINESS_H__

#include "../Globle.h"
#include "../TicketEntity/ULCard_Entity.h"
#include "../TicketEntity/PollingCardEntity.h"
#include "../XPublic/XTime.h"
#include "../XPublic/Log.h"
#include "../RWParam/RWParameter.h"
#include "../SAMEntity/AccPsam.h"
#include "DegradeModeBusinuess.h"
//
//  验证卡发行有效性
 int Verify_Issue_ULCard(CARD_ACC_UL  stULCardInfo,uint8 *CheckBuff);


//验证是否允许该设备发售。
 BOOL Verify_Issue_Device_ULCard(EM_DEVICE_TYPE emCurrentDeivceType);

//内部用读卡
 int Inner_Read_ULCard(StruAPIParam APIParam,CARD_ACC_UL  *stULCardInfo);

//内部写卡
 int Inner_Write_ULCard(StruAPIParam APIParam,CARD_STATUS_INFO_ACC_UL cardProcessInfo);

 //擦除
 int Inner_Earse_ULCard(StruAPIParam APIParam,CARD_STATUS_INFO_ACC_UL cardProcessInfo);


 //UD处理
 void Fill_Sale_ULCard_UD(StruAPIParam APIParam,CARD_ACC_UL stULCardInfo,SJTSALE * pUD);

  void Fill_Entry_ULCard_UD(StruAPIParam APIParam,CARD_ACC_UL stULCardInfo,ENTRYGATE * pUD);

  void Fill_Exit_ULCard_UD(StruAPIParam APIParam,CARD_ACC_UL stULCardInfo,PURSETRADE * pUD);

 void Fill_Refund_ULCard_UD(StruAPIParam APIParam,CARD_ACC_UL stULCardInfo,DIRECTREFUND * pUD);

 void Fill_Update_ULCard_UD(StruAPIParam APIParam,CARD_ACC_UL stULCardInfo,TICKETUPDATE  * pUD);

 //付费区分析。
 BOOL PaidArea_Analysis_ULCard(StruAPIParam APIParam,CARD_ACC_UL  stULCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis);

 //非付费区分析。
 BOOL UnpaidArea_Analysis_ULCard(StruAPIParam APIParam,CARD_ACC_UL  stULCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis);

 //检查车票状态是否正确
 BOOL Check_Ticket_Status_ULCard(CARD_ACC_UL  stULCardInfo);

 //检查余额是否超出上限。
 BOOL Check_Ticket_Value_Uplimit_ULCard(CARD_ACC_UL  stULCardInfo);

 //检查车票是否过期。
 BOOL Check_Ticket_Valid_ULCard(uint8 * u8BCDCurrentDate,CARD_ACC_UL  stULCardInfo);

 BOOL Check_PaidArea_Ticket_Valid_ULCard(uint8 * u8BCDCurrentDate,uint16 paidAreaValidTimes,CARD_ACC_UL  stULCardInfo);

 //检查是否本站进站。
  BOOL Check_EntryThisStation_ULCard(CARD_ACC_UL  stULCardInfo);

  //检查进站超时。
  BOOL Check_Entry_Timeout_ULCard(CARD_ACC_UL  stULCardInfo);

  //进站次序检查。
  BOOL Check_Entry_Status_ULCard(CARD_ACC_UL  stULCardInfo);

  //余额低于最小票价。
  BOOL Check_MinValue_ULCard(StruAPIParam APIParam,CARD_ACC_UL  stULCardInfo);

  //出站次序检查。
  BOOL Check_Exit_Status_ULCard(CARD_ACC_UL  stULCardInfo);

  //非本站更新
  BOOL Check_Update_ThisStation_ULCard(CARD_ACC_UL  stULCardInfo);

  //非本日更新
  BOOL Check_Update_ThisDay_ULCard(StruAPIParam APIParam,CARD_ACC_UL  stULCardInfo);

  //出站超时
  BOOL Check_Exit_Timeout_ULCard(StruAPIParam APIParam,uint16 u16JourneyTimeLimit,CARD_ACC_UL  stULCardInfo);

  //出站超程
  BOOL Check_Exit_RemainningValue_ULCard(uint32 *u32Price,CARD_ACC_UL  stULCardInfo);



int TVM_Sale_ULCard(StruAPIParam APIParam,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRetInfo, SJTSALE * pUD);

int Sale_ULCard(StruAPIParam APIParam,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRetInfo, SJTSALE * pUD);

int Sale_Exit_ULCard(StruAPIParam APIParam,uint16 u16TranValue,RetInfo * pRetInfo, SJTSALE * pUD);

int Earse_ULCard(StruAPIParam APIParam,RetInfo * pRetInfo);

int Analysis_ULCard(StruAPIParam APIParam,uint8 u8IsDegradeMode,uint8 u8WorkArea,RetInfo * pRetInfo,BOMANALYZE * stAnalysis,TICKETLOCK * stTicketLock);

int Query_ULCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETINFO * stTicketInfo);

int Update_ULCard(StruAPIParam APIParam,uint8 u8UpdateCode,uint16 u16EntryStationCode,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRetInfo,TICKETUPDATE * stUpdateInfo);

int Refund_ULCard(StruAPIParam APIParam,uint8 u8RefundOption,uint8 u8RefundCode,uint16 u16TranValue,RetInfo * pRetInfo,DIRECTREFUND * stRefundInfo);


int Confirm_ULCard(StruAPIParam APIParam,RetInfo * pRetInfo,unsigned char szUD,unsigned short *usUDLen);


int Entry_ULCard(StruAPIParam APIParam,RetInfo * pRetInfo,ENTRYGATE *stEntryInfo,TICKETLOCK * stLockInfo);

int Exit_ULCard(StruAPIParam APIParam,RetInfo * pRetInfo,PURSETRADE *stPurseInfo,TICKETLOCK * stLockInfo);

int Get_ValidDate_ULCard(StruAPIParam APIParam,uint8 u8WorkArea,CARD_ACC_UL stULCardInfo);

//int Get_Price_ULCard(uint8 *u8CardType,uint8 *u8InGateStation,uint8* u8BCDInGateTime,uint8* u8BCDOutGateTime,
//		uint16* FareZone,uint16*JourneyTimeLimit,uint16*TimeoutsFines,uint8 *RidingTime,uint8 *TrainTicketTableID,uint32* Fare);

int ConvertULCardStatus(unsigned char ucTicketStatus);

#endif
