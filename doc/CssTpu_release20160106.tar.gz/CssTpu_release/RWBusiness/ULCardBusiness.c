
#include "ULCardBusiness.h"

/*内部变量申明；*/
static CARD_ACC_UL m_stULCardInfo;

static ST_BOM_OperationStauts m_stOperationStauts;

/*内部变量申明；*/


/*内部方法申明*/


/*内部方法申明*/



int Verify_Issue_ULCard(CARD_ACC_UL  stULCardInfo,uint8 *CheckBuff)
{
	//根据卡信息 判断卡的有效性。
	int iRet = 1;
	iRet = PsamVerify_Issue_ULCard( stULCardInfo,CheckBuff);
	return iRet;
}



//验证是否允许该设备发售。
BOOL Verify_Issue_Device_ULCard(EM_DEVICE_TYPE emCurrentDeivceType)
{
	/*1、	设备字符信息代码定义：
字符	描述
字符1	TVM
字符2	BOM
字符3	进站闸机
字符4	出站闸机
字符5	双向闸机
字符6	TCM
字符7	PCA
字符8	ES
字符9~16	预留
如参数使用设备为TVM、BOM、进站闸机、出站闸机、双向闸机、TCM、PCA、ES则取值“1111111100000000”
*/
	BOOL bRet=FALSE;
	char tempValue[2]={0};
	switch(emCurrentDeivceType)
	{
		case EM_DEVICE_TYPE_TVM:
			  memcpy(tempValue,g_BRContext.TicktPara0301.SaleDevice,1);
			  bRet= atoi(tempValue);
		break;
		case EM_DEVICE_TYPE_BOM:
			 memcpy(tempValue,g_BRContext.TicktPara0301.SaleDevice+1,1);
			 bRet= atoi(tempValue);
		break;
		default:
			bRet=FALSE;
			break;

	}
	return bRet;
}

int Inner_Read_ULCard(StruAPIParam APIParam,CARD_ACC_UL  *stULCardInfo)
{
	int iRet=-1;

	int iCount=0;
	unsigned char szCardInfo[65]={0};
	unsigned char szTime4[4]={0};
	unsigned char usTime2[2]={0};

	iRet=Read_ULCard_All_Info(szCardInfo);



	PrintLog("File[%s]Line[%d]Inner_Read_ULCard iRet=[%d] ",__FILE__,__LINE__,iRet);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard szCardInfo",__FILE__,__LINE__);
	PrintBuffer((const char *)szCardInfo,64);

	if(CE_OK!=iRet)
	{
		return RW_EC_READ_FAILED;
	}

	memcpy(stULCardInfo->CardUL,szCardInfo,64);
	//
	BitstreamInitMasks();


	// 初始信息
	memcpy(stULCardInfo->CardPhyID,szCardInfo+iCount,3);
	iCount+=4;
	memcpy(stULCardInfo->CardPhyID+3,szCardInfo+iCount,4);
	iCount+=6;

	PrintLog("File[%s]Line[%d]Inner_Read_ULCard CardPhyID",__FILE__,__LINE__);
	PrintBuffer((const char *)stULCardInfo->CardPhyID,7);

	//系统锁定
	memcpy(stULCardInfo->CardLock,szCardInfo+iCount,2);
	iCount+=2;
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard CardLock=[0x%02X%02X] ",__FILE__,__LINE__,stULCardInfo->CardLock[0],stULCardInfo->CardLock[1]);
	//(OTP)保留
	memcpy(stULCardInfo->OTP,szCardInfo+iCount,4);
	iCount+=4;
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard OTP",__FILE__,__LINE__);
	PrintBuffer((const char *)stULCardInfo->OTP,4);

	//系统流水BCD
	memcpy(stULCardInfo->SystemFlowID,szCardInfo+iCount,4);
	iCount+=4;
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard SystemFlowID",__FILE__,__LINE__);
	PrintBuffer((const char *)stULCardInfo->SystemFlowID,4);

	//认证信息
	memcpy(stULCardInfo->MAC_Code,szCardInfo+iCount,4);
	iCount+=4;
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard MAC_Code",__FILE__,__LINE__);
	PrintBuffer((const char *)stULCardInfo->MAC_Code,4);

	//发行日期
	memcpy(usTime2,szCardInfo+iCount,2);

	PrintLog("File[%s]Line[%d]Inner_Read_ULCard usTime2[%02X%02X]",__FILE__,__LINE__,usTime2[0],usTime2[1]);
	//测试标记 （0:正式卡   1:测试卡）
	stULCardInfo->TestFlag=usTime2[1]&0x01;
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard TestFlag[%d]",__FILE__,__LINE__,stULCardInfo->TestFlag);

	ProcessTime2ToBCD(usTime2,stULCardInfo->IssueDate);
	iCount+=2;

	PrintLog("File[%s]Line[%d]Inner_Read_ULCard IssueDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stULCardInfo->IssueDate,4);

	//主类型
	memcpy(&stULCardInfo->MainType,szCardInfo+iCount,1);
	iCount+=1;
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard MainType[%d]",__FILE__,__LINE__,stULCardInfo->MainType);

	//子类型
	memcpy(&stULCardInfo->SubType,szCardInfo+iCount,1);
	iCount+=1;
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard SubType[%d]",__FILE__,__LINE__,stULCardInfo->SubType);

	//车票代码+效验位
	memcpy(stULCardInfo->TicketCode,szCardInfo+iCount,2);
	iCount+=2;
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard TicketCode",__FILE__,__LINE__);
	PrintBuffer((const char *)stULCardInfo->TicketCode,2);

    //2 保留
	iCount+=2;

	////最近一次处理时间
	memcpy(szTime4,szCardInfo+iCount,4);
	ProcessTime4ToBCD(szTime4,stULCardInfo->cardProcessInfo[0].ProcessTime);
	iCount+=4;

	PrintLog("File[%s]Line[%d]Inner_Read_ULCard stULCardInfo->cardProcessInfo[0].ProcessTime",__FILE__,__LINE__);
	PrintBuffer((const char *)stULCardInfo->cardProcessInfo[0].ProcessTime,7);

	PrintLog("File[%s]Line[%d]Inner_Read_ULCard stULCardInfo->cardProcessInfo[0].ProcessTime",__FILE__,__LINE__);
	//最近一次处理线路
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[0].ProcessInfo.ProcessLine, sizeof(uint32), szCardInfo+iCount,0, 6);

	 //最近一次处理站点
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[0].ProcessInfo.ProcessStation, sizeof(uint32), szCardInfo+iCount,6, 6);

	 //最近一次处理发生的设备类型
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[0].ProcessInfo.ProcessEquType, sizeof(uint32), szCardInfo+iCount,12, 4);
	 //最近一次处理发生的设备编码
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[0].ProcessInfo.ProcessEquCode, sizeof(uint32), szCardInfo+iCount,16, 10);

	 //最近一次处理发生后车票剩余额度
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[0].ProcessInfo.CardValue, sizeof(uint32), szCardInfo+iCount+3,2, 14);

	 //最近一次处理发生后车票所处状态
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[0].ProcessInfo.CardStatus, sizeof(uint32), szCardInfo+iCount+4,8, 5);

	 //最近一次处理发生后特殊标记
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[0].ProcessInfo.CardSpecialFlag, sizeof(uint32), szCardInfo+iCount+4,13, 3);

	 //入站线路
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[0].ProcessInfo.InGateLine, sizeof(uint32), szCardInfo+iCount+4,16, 6);

	 //入站站点
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[0].ProcessInfo.InGateStation, sizeof(uint32), szCardInfo+iCount+4,22, 6);


	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[0].ProcessLine[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].ProcessInfo.ProcessLine);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[0].ProcessStation[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].ProcessInfo.ProcessStation);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[0].ProcessEquType[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].ProcessInfo.ProcessEquType);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[0].ProcessEquCode[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].ProcessInfo.ProcessEquCode);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[0].CardValue[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].ProcessInfo.CardValue);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[0].CardStatus[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].ProcessInfo.CardStatus);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[0].CardSpecialFlag[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].ProcessInfo.CardSpecialFlag);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[0].InGateLine[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].ProcessInfo.InGateLine);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[0].InGateStation[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].ProcessInfo.InGateStation);

	iCount+=9;
	//交易累计
	memcpy(&stULCardInfo->cardProcessInfo[0].TransactionTotal,szCardInfo+iCount,2);
	stULCardInfo->cardProcessInfo[0].TransactionTotal=htons(stULCardInfo->cardProcessInfo[0].TransactionTotal);
	iCount+=2;
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[0].TransactionTotal[0x%02X]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].TransactionTotal);
	//效验
	memcpy(&stULCardInfo->cardProcessInfo[0].Check,szCardInfo+iCount,1);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard stULCardInfo->cardProcessInfo[0].Check[0x%02X]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].Check);
	iCount+=1;

	////最近一次处理时间
	memcpy(szTime4,szCardInfo+iCount,4);
	ProcessTime4ToBCD(szTime4,stULCardInfo->cardProcessInfo[1].ProcessTime);
	iCount+=4;
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard stULCardInfo->cardProcessInfo[1].ProcessTime",__FILE__,__LINE__);
	PrintBuffer((const char *)stULCardInfo->cardProcessInfo[1].ProcessTime,7);

	//最近一次处理线路
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[1].ProcessInfo.ProcessLine, sizeof(uint32), szCardInfo+iCount,0, 6);

	 //最近一次处理站点
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[1].ProcessInfo.ProcessStation, sizeof(uint32), szCardInfo+iCount,6, 6);

	 //最近一次处理发生的设备类型
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[1].ProcessInfo.ProcessEquType, sizeof(uint32), szCardInfo+iCount,12, 4);
	 //最近一次处理发生的设备编码
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[1].ProcessInfo.ProcessEquCode, sizeof(uint32), szCardInfo+iCount,16, 10);

	 //最近一次处理发生后车票剩余额度
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[1].ProcessInfo.CardValue, sizeof(uint32), szCardInfo+iCount+3,2, 14);

	 //最近一次处理发生后车票所处状态
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[1].ProcessInfo.CardStatus, sizeof(uint32), szCardInfo+iCount+4,8, 5);

	 //最近一次处理发生后特殊标记
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[1].ProcessInfo.CardSpecialFlag, sizeof(uint32), szCardInfo+iCount+4,13, 3);

	 //入站线路
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[1].ProcessInfo.InGateLine, sizeof(uint32), szCardInfo+iCount+4,16, 6);

	 //入站站点
	 BitStreamUnPack(&stULCardInfo->cardProcessInfo[1].ProcessInfo.InGateStation, sizeof(uint32), szCardInfo+iCount+4,22, 6);

	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[1].ProcessLine[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[1].ProcessInfo.ProcessLine);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[1].ProcessStation[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[1].ProcessInfo.ProcessStation);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[1].ProcessEquType[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[1].ProcessInfo.ProcessEquType);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[1].ProcessEquCode[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[1].ProcessInfo.ProcessEquCode);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[1].CardValue[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[1].ProcessInfo.CardValue);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[1].CardStatus[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[1].ProcessInfo.CardStatus);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[1].CardSpecialFlag[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[1].ProcessInfo.CardSpecialFlag);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[1].InGateLine[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[1].ProcessInfo.InGateLine);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[1].InGateStation[%d]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[1].ProcessInfo.InGateStation);


	iCount+=9;

	//交易累计
	memcpy(&stULCardInfo->cardProcessInfo[1].TransactionTotal,szCardInfo+iCount,2);
	stULCardInfo->cardProcessInfo[1].TransactionTotal=htons(stULCardInfo->cardProcessInfo[1].TransactionTotal);
	iCount+=2;
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard cardProcessInfo[1].TransactionTotal[0x%02X]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[1].TransactionTotal);
	//效验
	memcpy(&stULCardInfo->cardProcessInfo[1].Check,szCardInfo+iCount,1);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard stULCardInfo->cardProcessInfo[0].Check[0x%02X]",__FILE__,__LINE__,stULCardInfo->cardProcessInfo[0].Check);
	iCount+=1;
	//状态指针 0 :状态 0; 1 :状态 1
	stULCardInfo->StatusPointer=stULCardInfo->cardProcessInfo[0].TransactionTotal>stULCardInfo->cardProcessInfo[1].TransactionTotal?0:1;

	stULCardInfo->TranTotalNumber=stULCardInfo->cardProcessInfo[stULCardInfo->StatusPointer].TransactionTotal;

	PrintLog("File[%s]Line[%d]Inner_Read_ULCard stULCardInfo->StatusPointer[%d]",__FILE__,__LINE__,stULCardInfo->StatusPointer);
	m_stULCardInfo.StatusPointer=stULCardInfo->StatusPointer;

	PrintLog("File[%s]Line[%d]Inner_Read_ULCard stULCardInfo->TranTotalNumber[%d]",__FILE__,__LINE__,stULCardInfo->TranTotalNumber);
	m_stULCardInfo.TranTotalNumber=stULCardInfo->TranTotalNumber;

	return 0;
}

int Inner_Write_ULCard(StruAPIParam APIParam,CARD_STATUS_INFO_ACC_UL cardProcessInfo)
{
	int iRet=-1;
	unsigned char szCardInfo[17]={0};
    char szStringTime[20]={0};
    unsigned short DeviceID=0;
    unsigned short usTranTotal=0;
    unsigned char szTime4[4]={0};
    int iPointer=0;

    BitstreamInitMasks();
	//处理时间
	BcdToString(APIParam.ucTimeStamp, 7, szStringTime);
	TimeStrToProcessTime4(szStringTime,szTime4);
	//当前线路
	cardProcessInfo.ProcessInfo.ProcessLine=g_BRContext.bCurrentLineID;
	//当前车站
	cardProcessInfo.ProcessInfo.ProcessStation=g_BRContext.bCurrentStationID[1];
	//设备类型
	cardProcessInfo.ProcessInfo.ProcessEquType=g_BRContext.bCurrentDeviceTypeCode;

	//cardProcessInfo.ProcessInfo.ProcessEquCode=g_BRContext.bCurrentDeviceTypeCode;
	//设备编码
	memcpy(&DeviceID,g_BRContext.bCurrentDeviceID,2);
	cardProcessInfo.ProcessInfo.ProcessEquCode=htons(DeviceID);

	PrintLog("File[%s]Line[%d]Inner_Write_ULCard cardProcessInfo.ProcessLine[%d]",__FILE__,__LINE__,cardProcessInfo.ProcessInfo.ProcessLine);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard cardProcessInfo.ProcessStation[%d]",__FILE__,__LINE__,cardProcessInfo.ProcessInfo.ProcessStation);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard cardProcessInfo.ProcessEquType[%d]",__FILE__,__LINE__,cardProcessInfo.ProcessInfo.ProcessEquType);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard cardProcessInfo.ProcessEquCode[%d]",__FILE__,__LINE__,cardProcessInfo.ProcessInfo.ProcessEquCode);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard cardProcessInfo.CardValue[%d]",__FILE__,__LINE__,cardProcessInfo.ProcessInfo.CardValue);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard cardProcessInfo.CardStatus[%d]",__FILE__,__LINE__,cardProcessInfo.ProcessInfo.CardStatus);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard cardProcessInfo.CardSpecialFlag[%d]",__FILE__,__LINE__,cardProcessInfo.ProcessInfo.CardSpecialFlag);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard cardProcessInfo.InGateLine[%d]",__FILE__,__LINE__,cardProcessInfo.ProcessInfo.InGateLine);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard cardProcessInfo.InGateStation[%d]",__FILE__,__LINE__,cardProcessInfo.ProcessInfo.InGateStation);


	//组Buffer
	memcpy(szCardInfo,szTime4,sizeof(szTime4));

	BitStreamPack(cardProcessInfo.ProcessInfo.ProcessLine, szCardInfo+4,0, 6);

	BitStreamPack(cardProcessInfo.ProcessInfo.ProcessStation, szCardInfo+4,6, 6);

	BitStreamPack(cardProcessInfo.ProcessInfo.ProcessEquType, szCardInfo+4,12, 4);

	BitStreamPack(cardProcessInfo.ProcessInfo.ProcessEquCode, szCardInfo+4,16, 10);

	BitStreamPack(cardProcessInfo.ProcessInfo.CardValue, szCardInfo+7,2, 14);

	BitStreamPack(cardProcessInfo.ProcessInfo.CardStatus, szCardInfo+8,8, 5);

	BitStreamPack(cardProcessInfo.ProcessInfo.CardSpecialFlag, szCardInfo+8,13, 3);

	BitStreamPack(cardProcessInfo.ProcessInfo.InGateLine, szCardInfo+8,16, 6);

	BitStreamPack(cardProcessInfo.ProcessInfo.InGateStation, szCardInfo+8,22, 6);

	//BitStreamPack(1, szCardInfo+12,0, 8);

	cardProcessInfo.TransactionTotal=m_stULCardInfo.TranTotalNumber==0XFF?0:m_stULCardInfo.TranTotalNumber+1;

	usTranTotal=htons(cardProcessInfo.TransactionTotal);

	memcpy(szCardInfo+13,&usTranTotal,2);
	// 计算写那块

	iPointer=m_stULCardInfo.StatusPointer==0?1:0;

	PrintLog("File[%s]Line[%d]Inner_Write_ULCard TransactionTotal[%d]",__FILE__,__LINE__,cardProcessInfo.TransactionTotal);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard iPointer[%d]",__FILE__,__LINE__,iPointer);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard szCardInfo",__FILE__,__LINE__);
	PrintBuffer((const char *)szCardInfo,17);

	iRet=Write_ULCard_Info(APIParam.AntennaMode,szCardInfo,iPointer);

	if(0!=iRet)
	{
		memcpy(g_BRContext.stSpcTicketTranInfo.szCardPhID,g_BRContext.szCardPhID,sizeof(g_BRContext.szCardPhID));
		memcpy(g_BRContext.stSpcTicketTranInfo.szTranTime,APIParam.ucTimeStamp,sizeof(APIParam.ucTimeStamp));
		memcpy(g_BRContext.stSpcTicketTranInfo.szWriteCardInfo,szCardInfo,17);
		g_BRContext.Result=RW_EC_WRITE_FAILED;
		return RW_EC_WRITE_FAILED;
	}

	PlusULCardSn();

	return CE_OK;
}

int Get_ValidDate_ULCard(StruAPIParam APIParam,uint8 u8WorkArea,CARD_ACC_UL stULCardInfo)
{
	char temp[20]={0};
	int iRet=0;
	int tempValidityMin=0;
	 uint8 szEntryStation[2]={0};
	 uint8 u8EntryTime[7]={0};
	 uint16 FareZone=0;
	 uint16 JourneyTimeLimit=0;
	 uint16 TimeoutsFines=0;
	 uint8  RidingTime=0;
	 uint8  TrainTicketTableID=0;
	 uint32 lPrice=0;
	uint8 u8CardType[2]={0x01,0x00};//单程票


	 uint8 cardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;
	 PrintLog("File[%s]Line[%d] Get_ValidDate_ULCard cardStatus = [0x%02x]",__FILE__,__LINE__,cardStatus);

	 memcpy(u8EntryTime,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7);
	 PrintLog("File[%s]Line[%d] Get_ValidDate_ULCard u8EntryTime",__FILE__,__LINE__);
	 PrintBuffer((const char*)u8EntryTime,7);

	 if(cardStatus==EM_TICKET_TRAVEL_STATUS_ENTRY||
	   cardStatus==EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION)
	 {
		 szEntryStation[0]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateLine;
		 szEntryStation[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateStation;
	 }
	 else
	 {
	 szEntryStation[0]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessLine;
	 szEntryStation[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessStation;
	 }
	 PrintLog("File[%s]Line[%d] Get_ValidDate_ULCard szProcessStation = [0x%02x%02x]",__FILE__,__LINE__,szEntryStation[0],szEntryStation[1]);


	switch(cardStatus)
	{
		case EM_TICKET_TRAVEL_STATUS_ENTRY:
		case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA:	//非付费区免费更新(BOM/pca 非付费区)
		case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA://非付费区付费更新(BOM/pca 非付费区)
		case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION://无进站码更新(BOM/pca 付费区)
		case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT		://出站码更新
		case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT://超时更新
		case EM_TICKET_TRAVEL_STATUS_RANGEOUT	://超乖更新
		case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT://免费出闸更新
			iRet=BR_CalcPrice(u8CardType,szEntryStation,g_BRContext.bCurrentStationID,u8EntryTime,APIParam.ucTimeStamp,
					&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);
			if(iRet!=CE_OK)
			{
			   PrintLog("File[%s]Line[%d] Get_ValidDate_ULCard iRet = [0x%d]",__FILE__,__LINE__,iRet);
			   tempValidityMin=0;
			}else
			{
			   tempValidityMin=JourneyTimeLimit;
			}
			break;
		case EM_TICKET_TRAVEL_STATUS_ISSUED:
		case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES:
			memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
			tempValidityMin=atoi(temp);
			break;
		default:
			memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
			tempValidityMin=atoi(temp);
			break;
	}
	PrintLog("File[%s]Line[%d] Get_ValidDate_ULCard tempValidityMin[%d]",__FILE__,__LINE__,tempValidityMin);
	return tempValidityMin;
}

int Inner_Earse_ULCard(StruAPIParam APIParam,CARD_STATUS_INFO_ACC_UL cardProcessInfo)
{
	int iRet=-1;
	unsigned char szCardInfo[17]={0};
	unsigned short usTranTotal=0;
	int iPointer=0;

	cardProcessInfo.TransactionTotal=m_stULCardInfo.TranTotalNumber;

	usTranTotal=htons(cardProcessInfo.TransactionTotal);

	memcpy(szCardInfo+13,&usTranTotal,2);

	// 计算写那块
	iPointer=m_stULCardInfo.StatusPointer;

	PrintLog("File[%s]Line[%d]Inner_Write_ULCard TransactionTotal[%d]",__FILE__,__LINE__,cardProcessInfo.TransactionTotal);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard iPointer[%d]",__FILE__,__LINE__,iPointer);
	PrintLog("File[%s]Line[%d]Inner_Write_ULCard szCardInfo",__FILE__,__LINE__);
	PrintBuffer((const char *)szCardInfo,17);

	iRet=Write_ULCard_Info(APIParam.AntennaMode,szCardInfo,iPointer);

	if(CE_OK!=iRet)
	{
		return RW_EC_WRITE_FAILED;
	}

	return CE_OK;
}

void Fill_Sale_ULCard_UD(StruAPIParam APIParam,CARD_ACC_UL stULCardInfo,SJTSALE * pUD)
{


/*	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号（单程票）
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号（单程票）
	BYTE		dtDate[7];					// 时间
	BYTE		bPaymentMeans;				// 支付方式 BCD
	char		cPaymentTKLogicalID[20];	// 支付票卡逻辑卡号
	long		lTradeCount;				// 单程票扣款计数
	char		cLogicalID[20];				// TOKEN 逻辑ID
	char		cPhysicalID[20];			// TOKEN 物理ID
	BYTE		bStatus;					// 交易状态
	short		nChargeValue;				// 充值金额
	BYTE		bTicketType[2];				// 单程票卡类型
	BYTE		bZoneID;					// 区段代码
	char		cMACorTAC[10];				// SAM生成的交易检查代码,	默认值：
	BYTE		bDepositorCost;				// 成本押金
	short		nAmountCost;				// 成本押金金额
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShiftID;				// BOM班次序号, 每个BOM每天重置
	long		lBrokerage;					// 手续费
	char		cTestFlag;					// 卡应用标识
	char		cClassicType[2];			// TAC交易分类
	char		cSamPosId[12];				// SAM卡终端编码*/
	char temp[128]={0};
	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_SALE_SJT);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);
	//long		lSAMTrSeqNo;				// SAM卡脱机交易流水号（单程票）
	GetULCardSn((unsigned char *)&pUD->lSAMTrSeqNo);
	// 时间
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	// 支付方式 BCD ---外边赋值 已赋

	// 支付票卡逻辑卡号 --- 暂时置 字符 0
	memcpy(pUD->cPaymentTKLogicalID,szTempZero,20);

	// 单程票扣款计数
	pUD->lTradeCount=stULCardInfo.TranTotalNumber;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"000000000003%02X%02X%02X%02X",
			stULCardInfo.SystemFlowID[0],
			stULCardInfo.SystemFlowID[1],
			stULCardInfo.SystemFlowID[2],
			stULCardInfo.SystemFlowID[3]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Sale_ULCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));

	sprintf(temp,"%02X%02X%02X%02X%02X%02X%02X",stULCardInfo.CardPhyID[0],
			stULCardInfo.CardPhyID[1],
			stULCardInfo.CardPhyID[2],
			stULCardInfo.CardPhyID[3],
			stULCardInfo.CardPhyID[4],
			stULCardInfo.CardPhyID[5],
			stULCardInfo.CardPhyID[6]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);

	// 交易状态  ---外边赋值

	// 充值金额   ---外边赋值

	// 单程票卡类型
	pUD->bTicketType[0]=stULCardInfo.MainType;
	pUD->bTicketType[1]=stULCardInfo.SubType;

	// 区段代码  ---外边赋值

	// 成本押金
	pUD->bDepositorCost=0x02; //00：押金，01：成本，02：不使用（押金可退，成本不可退）
	// 成本押金金额
	pUD->nAmountCost=0;



	// 操作员代码(Login)
	memcpy(pUD->cOperatorID,g_BRContext.CurrentUserID,6);

	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShiftID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);

	// 手续费
	pUD->lBrokerage=0;

	// 卡应用标识
	pUD->cTestFlag=stULCardInfo.TestFlag+'0';

	// TAC交易分类
	sprintf(pUD->cClassicType,"00");

	// SAM卡终端编码
	strncpy(pUD->cSamPosId,g_BRContext.stSamInfo[0].cSAMID,5);
	strncpy(pUD->cSamPosId+5,g_BRContext.stSamInfo[0].cSAMID+9,7);



}



void Fill_Refund_ULCard_UD(StruAPIParam APIParam,CARD_ACC_UL stULCardInfo,DIRECTREFUND * pUD)
{
/*	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];				// 设备类型
	char		cDeviceID[3];					// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;					// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];				// 票卡物理卡号
	BYTE		bStatus;						// 交易状态代码
	long		lBalanceReturned;				// 退还钱包金额, 单位为分
	short		nDepositReturned;				// 退还押金, 单位为分
	short		nForfeiture;					// 罚款, 单位为分
	BYTE		bForfeitReason;				// 罚款原因
	long		lTradeCount;					// 票卡扣款交易计数
	BYTE		bReturnTypeCode;				// 退款类型, 0－即时退款；－非即时退款
	BYTE		dtDate[7];					// 时间YYYYMMDDHHMMSS
	char		cReceiptID[4];				// 凭证ID
	BYTE		dtApplyDate[7];				// 申请日期时间, YYYYMMDDHHMMSS
	char		cMACOrTAC[10];				// 交易认证码
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShfitID;					// BOM班次序号每个BOM每天重置	（BCD）
	long		lBrokerage;					// 手续费
	char		cTestFlag;					// 卡应用标识
	char		cClassicType[2];				// TAC交易分类
	char		cSamPosId[12];				// SAM卡终端编码*/
	char temp[128]={0};

	 char szTempZero[32]={0};
	 memset(szTempZero,'0',32);

	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_REFUND);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);
	//long		lSAMTrSeqNo;				// SAM卡脱机交易流水号（单程票）
	GetULCardSn((unsigned char *)&pUD->lSAMTrSeqNo);
	// 时间
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	// 单程票卡类型
	pUD->bTicketType[0]=stULCardInfo.MainType;
	pUD->bTicketType[1]=stULCardInfo.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"000000000003%02X%02X%02X%02X",
			stULCardInfo.SystemFlowID[0],
			stULCardInfo.SystemFlowID[1],
			stULCardInfo.SystemFlowID[2],
			stULCardInfo.SystemFlowID[3]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Sale_ULCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));

	sprintf(temp,"%02X%02X%02X%02X%02X%02X%02X",stULCardInfo.CardPhyID[0],
			stULCardInfo.CardPhyID[1],
			stULCardInfo.CardPhyID[2],
			stULCardInfo.CardPhyID[3],
			stULCardInfo.CardPhyID[4],
			stULCardInfo.CardPhyID[5],
			stULCardInfo.CardPhyID[6]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);

	// 交易状态  ---外边赋值

	// lBalanceReturned;				// 退还钱包金额, 单位为分金额   ---外边赋值

	// 退还押金, 单位为分
	pUD->nDepositReturned=0;

	// 罚款, 单位为分
	pUD->nForfeiture=0;

	// 罚款原因
	pUD->bForfeitReason=0;

	// 单程票扣款计数
	pUD->lTradeCount=stULCardInfo.TranTotalNumber;

	// 退款类型, 0－即时退款；－非即时退款 0：即时退款；1：非即时退款；2：单程票退款；3：非正常模式单程票退款。
	pUD->cReturnTypeCode='2';

	// 时间YYYYMMDDHHMMSS
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	//cReceiptID[4];				// 凭证ID
	memcpy(pUD->cReceiptID,szTempZero,4);

	// 申请日期时间, YYYYMMDDHHMMSS
	memcpy(pUD->dtApplyDate,APIParam.ucTimeStamp,7);
	// 操作员代码(Login)
	memcpy(pUD->cOperatorID,g_BRContext.CurrentUserID,6);
	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShfitID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);;

	// 手续费
	pUD->lBrokerage=0;

	// 卡应用标识
	pUD->cTestFlag=stULCardInfo.TestFlag+'0';

	// TAC交易分类
	memcpy(pUD->cClassicType,szTempZero,2);
	// SAM卡终端编码
	strncpy(pUD->cSamPosId,g_BRContext.stSamInfo[0].cSAMID,5);
	strncpy(pUD->cSamPosId+5,g_BRContext.stSamInfo[0].cSAMID+9,7);


}

void Fill_Update_ULCard_UD(StruAPIParam APIParam,CARD_ACC_UL stULCardInfo,TICKETUPDATE  * pUD)
 {
	/*char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;				// 更新设备SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	long		lTradeCount;				// 票卡扣款交易计数
	BYTE		bStatus;					// 交易状态代码
	char		cUpdateZone;				// 更新区域
	BYTE		bUpdateReasonCode;			// 更新原因
											// 更新原因代码表
											// 原因代码	描述（Description）
											// 付费区：01－出站超时，02-超乘，03-无进站码
											// 非付费区：10－有进站码，
											// 11：非付费区非本站进站
											// 12：进站超时
	BYTE		dtUpdateDate[7];			// 更新日期时间YYYYMMDDHHMMSS
	BYTE		bPaymentMode;				// 罚金支付方式
											// 	1-现金，2-储值卡， 3-一卡通
											//	4-Credit， 5- civil charge '默认值''
	short		nForfeiture;				// 罚金, 需缴纳的罚款金额（现金支付），单位分
	char		cReceiptID[4];				// 支付凭证码
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bEntryStationID[2];			// 进站线路站点代码
	BYTE		bBOMShfitID;				// BOM班次序号每个BOM每天重置	（BCD）
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				// 限制使用模式
	BYTE		bLimitEntryID[2];			// 限制进站代码
	BYTE		bLimitExitID[2];			// 限制出站代码
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	char temp[128]={0};
	char szTempZero[32]={0};
	memset(szTempZero,'0',32);
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_UPDATE);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);
	//long		lSAMTrSeqNo;				// SAM卡脱机交易流水号（单程票）
	GetULCardSn((unsigned char *)&pUD->lSAMTrSeqNo);

	// 单程票卡类型
	pUD->bTicketType[0]=stULCardInfo.MainType;
	pUD->bTicketType[1]=stULCardInfo.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"000000000003%02X%02X%02X%02X",
			stULCardInfo.SystemFlowID[0],
			stULCardInfo.SystemFlowID[1],
			stULCardInfo.SystemFlowID[2],
			stULCardInfo.SystemFlowID[3]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Sale_ULCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));

	sprintf(temp,"%02X%02X%02X%02X%02X%02X%02X",stULCardInfo.CardPhyID[0],
			stULCardInfo.CardPhyID[1],
			stULCardInfo.CardPhyID[2],
			stULCardInfo.CardPhyID[3],
			stULCardInfo.CardPhyID[4],
			stULCardInfo.CardPhyID[5],
			stULCardInfo.CardPhyID[6]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);

	 // 单程票扣款计数
	pUD->lTradeCount=stULCardInfo.TranTotalNumber;

	// 交易状态  ---外边赋值

	// 更新区域  ---外边赋值

	// 更新原因  ---外边赋值

	// 更新日期时间YYYYMMDDHHMMSS
	memcpy(pUD->dtUpdateDate,APIParam.ucTimeStamp,7);

	// 罚金支付方式  ---外边赋值

	// 罚金, 需缴纳的罚款金额（现金支付），单位分  ---外边赋值

	//cReceiptID[4];				// 支付凭证码
	memcpy(pUD->cReceiptID,szTempZero,3);

	// 操作员代码(Login)
	memcpy(pUD->cOperatorID,g_BRContext.CurrentUserID,6);

	// 入口站点代码(BCD)
	pUD->bEntryStationID[0]=Byte_Decimal_to_BCD(stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateLine);
	pUD->bEntryStationID[1]=Byte_Decimal_to_BCD(stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateStation);

	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShfitID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);

	// 卡应用标识
	pUD->cTestFlag=stULCardInfo.TestFlag+'0';

	// 限制使用模式
	memcpy(pUD->cLimitMode,szTempZero,3);

	//bLimitEntryID[2];			// 限制进站代码
	pUD->bLimitEntryID[0]=0;
	pUD->bLimitEntryID[1]=0;
	// 限制出站代码	BYTE		bLimitExitID[2];
	pUD->bLimitExitID[0]=0;
	pUD->bLimitExitID[1]=0;

	//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	pUD->cTkAppMode='2';

 }

  void Fill_Entry_ULCard_UD(StruAPIParam APIParam,CARD_ACC_UL stULCardInfo,ENTRYGATE * pUD)
 {
	  /*
	 char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];				// 设备类型
	char		cDeviceID[3];					// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		dtDate[7];					// 进站日期时间如;20060211160903
	BYTE		bStatus;						// 交易状态代码
	long		lBalance;						// 余额
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				//限制使用模式
	BYTE		bLimitEntryID[2];				//限制进站代码
	BYTE		bLimitExitID[2];				//限制出站代码
	char 		cEntryMode;					//进闸工作模式
	long		lTradeCount;					//扣款计数
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	char temp[128]={0};
	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_ENTRY);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);
	//long		lSAMTrSeqNo;				// SAM卡脱机交易流水号（单程票）
	GetULCardSn((unsigned char *)&pUD->lSAMTrSeqNo);
	// 单程票卡类型
	pUD->bTicketType[0]=stULCardInfo.MainType;
	pUD->bTicketType[1]=stULCardInfo.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"000000000003%02X%02X%02X%02X",
			stULCardInfo.SystemFlowID[0],
			stULCardInfo.SystemFlowID[1],
			stULCardInfo.SystemFlowID[2],
			stULCardInfo.SystemFlowID[3]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Sale_ULCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));

	sprintf(temp,"%02X%02X%02X%02X%02X%02X%02X",stULCardInfo.CardPhyID[0],
			stULCardInfo.CardPhyID[1],
			stULCardInfo.CardPhyID[2],
			stULCardInfo.CardPhyID[3],
			stULCardInfo.CardPhyID[4],
			stULCardInfo.CardPhyID[5],
			stULCardInfo.CardPhyID[6]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);
	// 进站时间
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	// 交易状态  ---外边赋值

	// 余额
	pUD->lBalance=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;

	// 卡应用标识
	pUD->cTestFlag=stULCardInfo.TestFlag+'0';

	//限制使用模式
	sprintf(pUD->cLimitMode,"000");

	//限制进站代码
	//pUD->bLimitEntryID[2];
	//sprintf(pUD->bLimitEntryID,"00");
	//限制出站代码
	//pUD->bLimitExitID[2];
	//sprintf(pUD->bLimitExitID,"00");
	//进闸工作模式
	//pUD->cEntryMode;
	sprintf(&pUD->cEntryMode,"0");
	// 单程票扣款计数
	pUD->lTradeCount=stULCardInfo.TranTotalNumber;

	//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	pUD->cTkAppMode='2';

 }

  void Fill_Exit_ULCard_UD(StruAPIParam APIParam,CARD_ACC_UL stULCardInfo,PURSETRADE * pUD)
 {
	  /*	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// 本次交易SAM逻辑卡号
	long		lSAMTrSeqNo;				// 本次交易SAM卡脱机交易流水号
	BYTE		dtDate[7];					// 日期时间(BCD)
	BYTE		bTicketType[2];				// 票卡类型(BCD)
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		bStatus;					// 交易状态代码
	long		lTradeAmount;				// 交易金额, 单位为分
	long		lBalance;					// 余额, 单位为分
	long		lChargeCount;				// 票卡充值计数
	long		lTradeCount;				// 票卡扣款交易计数
	char		cPaymentType[2];			// 支付类型
	char		cReceiptID[4];				// 支付凭证码
	char		cMACorTAC[10];				// 交易认证码
	BYTE		bEntryStationID[2];			// 入口站点代码(BCD)
	char		cEntrySAMID[16];			// 入口SAM逻辑卡号
	BYTE		dtEntryDate[7];				// 进站日期时间(BCD)
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShiftID;				// BOM班次序号
	char		cSamLast[16];				// 上次交易的SAM卡号
	BYTE		dtLast[7];					// 上次交易日期时间
	long		lTradeWallet;				// 钱包交易额，卡片实际需要变动的钱包值
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				// 限制使用模式
	BYTE		bLimitEntryID[2];			// 限制进站代码
	BYTE		bLimitExitID[2];			// 限制出站代码
	char		cExitMode;					//出闸工作模式
	char		cCityCode[4];				// 城市代码
	char		cIndustryCode[4];			// 行业代码
	char		cClassicType[2];			// TAC交易分类
	char		cSamPosId[12];				// SAM卡终端编码
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/

	 char temp[128]={0};
	 char szTempZero[32]={0};
	 memset(szTempZero,'0',32);

	// 交易类型
	sprintf(pUD->cTradeType,"%02d",EM_CS_TRAN_TYPE_PURSE);
	// 线路站点代码
	sprintf(pUD->cStationID,"%02d%02d",g_BRContext.bCurrentStationID[0],g_BRContext.bCurrentStationID[1]);
	// 设备类型
	sprintf(pUD->cDevGroupType,"%02d",g_BRContext.bCurrentDeviceTypeCode);
	// 设备代码
	sprintf(pUD->cDeviceID,"%d%02d",g_BRContext.bCurrentDeviceID[0],g_BRContext.bCurrentDeviceID[1]);
	// SAM卡逻辑卡号（单程票）
	memcpy(pUD->cSAMID,g_BRContext.stSamInfo[0].cSAMID,16);
	//long		lSAMTrSeqNo;				// SAM卡脱机交易流水号（单程票）
	GetULCardSn((unsigned char *)&pUD->lSAMTrSeqNo);
	// 时间
	memcpy(pUD->dtDate,APIParam.ucTimeStamp,7);

	// 单程票卡类型
	pUD->bTicketType[0]=stULCardInfo.MainType;
	pUD->bTicketType[1]=stULCardInfo.SubType;

	// TOKEN 逻辑ID
	memset(temp,0,sizeof(temp));
	sprintf(temp,"000000000003%02X%02X%02X%02X",
			stULCardInfo.SystemFlowID[0],
			stULCardInfo.SystemFlowID[1],
			stULCardInfo.SystemFlowID[2],
			stULCardInfo.SystemFlowID[3]);
	strncpy(pUD->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Fill_Sale_ULCard_UD  cLogicalID[%s]",__FILE__,__LINE__,pUD->cLogicalID);

	// TOKEN 物理ID
	memset(temp,0,sizeof(temp));

	sprintf(temp,"%02X%02X%02X%02X%02X%02X%02X",stULCardInfo.CardPhyID[0],
			stULCardInfo.CardPhyID[1],
			stULCardInfo.CardPhyID[2],
			stULCardInfo.CardPhyID[3],
			stULCardInfo.CardPhyID[4],
			stULCardInfo.CardPhyID[5],
			stULCardInfo.CardPhyID[6]);
	strncpy(pUD->cPhysicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,pUD->cPhysicalID);


	// 交易状态  ---外边赋值

	// 交易金额, 单位为分   ---外边赋值

	// 余额, 单位为分  ---外边赋值

	// 票卡充值计数
	 pUD->lChargeCount=0;

	 // 单程票扣款计数
	pUD->lTradeCount=stULCardInfo.TranTotalNumber;

	// 支付凭证码
	memcpy(pUD->cReceiptID,szTempZero,4);
	// 入口站点代码(BCD)
	pUD->bEntryStationID[0]=Byte_Decimal_to_BCD(stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateLine);
	pUD->bEntryStationID[1]=Byte_Decimal_to_BCD(stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateStation);

	// 入口SAM逻辑卡号
	memcpy(pUD->cEntrySAMID,szTempZero,16);
	// 进站日期时间(BCD)
	memcpy(pUD->dtEntryDate,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7);

	// 操作员代码(Login)
	memcpy(pUD->cOperatorID,g_BRContext.CurrentUserID,6);

	// BOM班次序号, 每个BOM每天重置
	pUD->bBOMShiftID=Byte_Decimal_to_BCD(g_BRContext.CurrentClassID);

	// 上次交易的SAM卡号pUD->cSamLast[16];
	memcpy(pUD->cSamLast,szTempZero,16);

	// 上次交易日期时间pUD->dtLast[7];
	memcpy(pUD->dtLast,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7);

	// 钱包交易额，卡片实际需要变动的钱包值
	pUD->lTradeWallet=0;

	// 卡应用标识
	pUD->cTestFlag=stULCardInfo.TestFlag+'0';

	// 限制使用模式
	memcpy(pUD->cLimitMode,szTempZero,3);
	// 限制进站代码 BYTE		bLimitEntryID[2];
	pUD->bLimitEntryID[0]=0;
	pUD->bLimitEntryID[1]=0;
	// 限制出站代码	BYTE		bLimitExitID[2];
	pUD->bLimitExitID[0]=0;
	pUD->bLimitExitID[1]=0;
	//出闸工作模式
	memcpy(&pUD->cExitMode,szTempZero,1);
	// 城市代码
	memcpy(pUD->cCityCode,szTempZero,4);
	//行业代码
	memcpy(pUD->cIndustryCode,szTempZero,4);
	// TAC交易分类
	memcpy(pUD->cClassicType,szTempZero,2);

	// SAM卡终端编码
	strncpy(pUD->cSamPosId,g_BRContext.stSamInfo[0].cSAMID,5);
	strncpy(pUD->cSamPosId+5,g_BRContext.stSamInfo[0].cSAMID+9,7);

	//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1*/
	pUD->cTkAppMode='2';
	// SAM生成的交易检查代码
	//pUD->cMACorTAC
 }

int TVM_Sale_ULCard(StruAPIParam APIParam,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRetInfo, SJTSALE * pUD)
{
	//PaymentType 1=现金，2=储值卡，3=一卡通

	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;

	char szTemp[10]={0};
	unsigned char szTAC[4]={0};

	CARD_ACC_UL stULCardInfo;
	memset(&stULCardInfo,0,sizeof(CARD_ACC_UL));

	CARD_STATUS_INFO_ACC_UL cardProcessInfo;
	memset(&cardProcessInfo,0,sizeof(CARD_STATUS_INFO_ACC_UL));

	if(NULL==pRetInfo||NULL==pUD)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	if(u8PaymentType!=EM_TOKEN_PAYMENT_TYPE_CASH&&u8PaymentType!=EM_TOKEN_PAYMENT_TYPE_SVC&&u8PaymentType!=EM_TOKEN_PAYMENT_TYPE_YKT)
	{
		PrintLog("File[%s]Line[%d] Tvm_SjtSale RW_EC_INVALID_INPUT_PARAM u8PaymentType[%d]",__FILE__,__LINE__,u8PaymentType);
		 pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	iRet=Inner_Read_ULCard(APIParam,&stULCardInfo);
	PrintLog("File[%s]Line[%d] Tvm_SjtSale Inner_Read_ULCard iRet[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	iRet= BR_GetParaTicketsTypeTable_h(stULCardInfo.MainType, stULCardInfo.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Tvm_SjtSale BR_GetParaTicketsTypeTable_h iRet[%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}

	bRet=Verify_Issue_Device_ULCard(g_BRContext.emCurrentDeviceType);
	PrintLog("File[%s]Line[%d] Tvm_SjtSale Verify_Issue_Device_ULCard bRet[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		// 参数不允许当前设备发售车票。
		pRetInfo->wErrCode=RW_EC_INVALID_API_CALL;
		return pRetInfo->wErrCode;
	}
	//检查车票余额/次上限

	memcpy(szTemp,g_BRContext.TicktPara0301.UpperLimit,6);

	PrintLog("File[%s]Line[%d] Tvm_SjtSale u16TranValue [%d]",__FILE__,__LINE__,u16TranValue);
	PrintLog("File[%s]Line[%d] Tvm_SjtSale UpperLimit [%d]",__FILE__,__LINE__,atoi(szTemp));
	if(u16TranValue>atoi(szTemp))
	{
		pRetInfo->wErrCode=RW_EC_ILLEGAL_INPUT_PARAM;
		return pRetInfo->wErrCode;
	}

	/*
	bRet=Verify_Blacklist_ULCard(stULCardInfo);
	if(bRet)
	{
		// 返回 黑名单 卡
		pRetInfo->wErrCode=RW_EC_BLACKLIST;
		return pRetInfo->wErrCode;
	}
	*/

	//车票余额
	cardProcessInfo.ProcessInfo.CardValue=u16TranValue;
	//车票状态
	cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_ISSUED;//:SJT发售
	//特殊标记
	cardProcessInfo.ProcessInfo.CardSpecialFlag=EM_CS_SPEC_FLAG_NORMAL;//正常

	iRet=Inner_Write_ULCard(APIParam,cardProcessInfo);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD

	// 支付方式 BCD
	pUD->bPaymentMeans=u8PaymentType;

	// 交易状态
	pUD->bStatus=RW_LIFECODE_SALE_BOM_OR_TVM;

	 //充值金额
	pUD->nChargeValue=u16TranValue;
	
	// 区段代码
	pUD->bZoneID=1;//

	//公共字段
	Fill_Sale_ULCard_UD(APIParam,stULCardInfo,pUD);

	// SAM生成的交易检查代码
	GetULCardUDTAC(stULCardInfo.SystemFlowID,pUD->nChargeValue,pUD->lSAMTrSeqNo,pUD->dtDate,szTAC);

	sprintf(pUD->cMACorTAC,"%02X%02X%02X%02X",szTAC[0],szTAC[1],szTAC[2],szTAC[3]);

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;
}

int Sale_ULCard(StruAPIParam APIParam,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRetInfo, SJTSALE * pUD)
{
	//PaymentType 1=现金，2=储值卡，3=一卡通

	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;

	unsigned char szTAC[4]={0};
	//CARD_ACC_UL stULCardInfo;
	//memset(&stULCardInfo,0,sizeof(CARD_ACC_UL));

	CARD_STATUS_INFO_ACC_UL cardProcessInfo;
	memset(&cardProcessInfo,0,sizeof(CARD_STATUS_INFO_ACC_UL));

	if(NULL==pRetInfo||NULL==pUD)
	{
		PrintLog("File[%s]Line[%d] RW_EC_INVALID_INPUT_PARAM",__FILE__,__LINE__);
		return RW_EC_INVALID_INPUT_PARAM;
	}
	PrintLog("File[%s]Line[%d] Sale_ULCard  m_stOperationStauts.bAllowSale= [0x%02X]",__FILE__,__LINE__,m_stOperationStauts.bAllowSale);



	if(u8PaymentType!=EM_TOKEN_PAYMENT_TYPE_CASH&&u8PaymentType!=EM_TOKEN_PAYMENT_TYPE_SVC&&u8PaymentType!=EM_TOKEN_PAYMENT_TYPE_YKT)
	{
		PrintLog("File[%s]Line[%d] u8PaymentType[%d]",__FILE__,__LINE__,u8PaymentType);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	bRet=Verify_Issue_Device_ULCard(g_BRContext.emCurrentDeviceType);
	if(!bRet)
	{
		PrintLog("File[%s]Line[%d] Verify_Issue_Device_ULCard=[%d]",__FILE__,__LINE__,bRet);
		// 参数不允许当前设备发售车票。
		pRetInfo->wErrCode=RW_EC_INVALID_API_CALL;
		return pRetInfo->wErrCode;
	}

	//车票余额
	cardProcessInfo.ProcessInfo.CardValue=u16TranValue;
	PrintLog("File[%s]Line[%d] cardProcessInfo.ProcessInfo.CardValue=[%d]",__FILE__,__LINE__,u16TranValue);
	//车票状态
	cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_ISSUED;//:SJT发售
	PrintLog("File[%s]Line[%d] cardProcessInfo.ProcessInfo.CardStatus=[%d]",__FILE__,__LINE__,EM_TICKET_TRAVEL_STATUS_ISSUED);
	//特殊标记
	cardProcessInfo.ProcessInfo.CardSpecialFlag=EM_CS_SPEC_FLAG_NORMAL;//正常
	PrintLog("File[%s]Line[%d] cardProcessInfo.ProcessInfo.CardSpecialFlag=[%d]",__FILE__,__LINE__,EM_CS_SPEC_FLAG_NORMAL);

	iRet=Inner_Write_ULCard(APIParam,cardProcessInfo);


	//组UD

	// 支付方式 BCD
	pUD->bPaymentMeans=0x01;

	// 交易状态
	pUD->bStatus=RW_LIFECODE_SALE_BOM_OR_TVM;

	 //充值金额
	pUD->nChargeValue=u16TranValue;

	// 区段代码
	pUD->bZoneID=1;//

	//公共字段
	Fill_Sale_ULCard_UD(APIParam,m_stULCardInfo,pUD);

	// SAM生成的交易检查代码
	GetULCardUDTAC(m_stULCardInfo.SystemFlowID,pUD->nChargeValue,pUD->lSAMTrSeqNo,pUD->dtDate,szTAC);

	sprintf(pUD->cMACorTAC,"%02X%02X%02X%02X",szTAC[0],szTAC[1],szTAC[2],szTAC[3]);

	if(CE_OK!=iRet)
	{
		memcpy(g_BRContext.stSpcTicketTranInfo.szTranUD,pUD,sizeof(SJTSALE));
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;
}

int Sale_Exit_ULCard(StruAPIParam APIParam,uint16 u16TranValue,RetInfo * pRetInfo, SJTSALE * pUD)
{
	//PaymentType 1=现金，2=储值卡，3=一卡通

	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;

	unsigned char szTAC[4]={0};
	//CARD_ACC_UL stULCardInfo;
	//memset(&stULCardInfo,0,sizeof(CARD_ACC_UL));

	CARD_STATUS_INFO_ACC_UL cardProcessInfo;
	memset(&cardProcessInfo,0,sizeof(CARD_STATUS_INFO_ACC_UL));

	if(NULL==pRetInfo||NULL==pUD)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}
	PrintLog("File[%s]Line[%d] Sale_Exit_ULCard  m_stOperationStauts.bAllowSale= [0x%02X]",__FILE__,__LINE__,m_stOperationStauts.bAllowSale);



	bRet=Verify_Issue_Device_ULCard(g_BRContext.emCurrentDeviceType);
	PrintLog("File[%s]Line[%d] Verify_Issue_Device_ULCard=[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		// 参数不允许当前设备发售车票。
		pRetInfo->wErrCode=RW_EC_INVALID_API_CALL;
		return pRetInfo->wErrCode;
	}
	PrintLog("File[%s]Line[%d] u16TranValue=[%d]",__FILE__,__LINE__,u16TranValue);
	//车票余额
	cardProcessInfo.ProcessInfo.CardValue=u16TranValue;
	//车票状态
	cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE;//:出站票
	//特殊标记
	cardProcessInfo.ProcessInfo.CardSpecialFlag=EM_CS_SPEC_FLAG_NORMAL;//正常


	iRet=Inner_Write_ULCard(APIParam,cardProcessInfo);
	PrintLog("File[%s]Line[%d] Sale_Exit_ULCard Inner_Write_ULCard=[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	// 支付方式 BCD  01：现金，02：储值卡， 03：公交一卡通，04：信用卡；05：行政处理收费
	pUD->bPaymentMeans=0x05;

	// 交易状态
	pUD->bStatus=RW_LIFECODE_ET_FOR_EXIT;

	 //充值金额
	pUD->nChargeValue=u16TranValue;

	// 区段代码
	pUD->bZoneID=0;//

	//公共字段
	Fill_Sale_ULCard_UD(APIParam,m_stULCardInfo,pUD);

	// SAM生成的交易检查代码
	GetULCardUDTAC(m_stULCardInfo.SystemFlowID,pUD->nChargeValue,pUD->lSAMTrSeqNo,pUD->dtDate,szTAC);

	sprintf(pUD->cMACorTAC,"%02X%02X%02X%02X",szTAC[0],szTAC[1],szTAC[2],szTAC[3]);

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;

}

int Earse_ULCard(StruAPIParam APIParam,RetInfo * pRetInfo)
{
	int iRet=-1;
	//BOOL bRet=FALSE;

	CARD_ACC_UL stULCardInfo;
	memset(&stULCardInfo,0,sizeof(CARD_ACC_UL));

	CARD_STATUS_INFO_ACC_UL cardProcessInfo;

	if(NULL==pRetInfo)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	iRet=Inner_Read_ULCard(APIParam,&stULCardInfo);
	PrintLog("File[%s]Line[%d] Earse_ULCard Inner_Read_ULCard Result[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	memset(&cardProcessInfo,0,sizeof(cardProcessInfo));

	iRet=Inner_Earse_ULCard(APIParam,cardProcessInfo);
	PrintLog("File[%s]Line[%d] Earse_ULCard Inner_Earse_ULCard Result[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;
}

int Analysis_ULCard(StruAPIParam APIParam,uint8 u8IsDegradeMode,uint8 u8WorkArea,RetInfo * pRetInfo,BOMANALYZE * stAnalysis,TICKETLOCK * stTicketLock)
{
	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;

	char temp[32]={0};

	char szTempZero[32]={0};
	memset(szTempZero,'0',32);

	unsigned char u8stOperationStauts=0;


	memset(&m_stOperationStauts,0,sizeof(ST_BOM_OperationStauts));

	if(NULL==pRetInfo||NULL==stAnalysis||NULL==stTicketLock)
	{
		PrintLog("File[%s]Line[%d] Analysis_ULCard pRi->wErrCode RW_EC_INVALID_INPUT_PARAM",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	if(u8WorkArea!=EM_CS_AREA_TYPE_PAID_AREA&&u8WorkArea!=EM_CS_AREA_TYPE_UNPAID_AREA)
	{
		PrintLog("File[%s]Line[%d] Analysis_ULCard pRi->wErrCode RW_EC_INVALID_INPUT_PARAM",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}


	memset(&m_stULCardInfo,0,sizeof(m_stULCardInfo));

	g_BRContext.ucCurrentStationMode=GetLocalStationMode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID);

	iRet=Inner_Read_ULCard(APIParam,&m_stULCardInfo);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Analysis_ULCard  Inner_Read_ULCard iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=iRet;
		return iRet;
	}
	PrintLog("File[%s]Line[%d] Analysis_ULCard  Inner_Read_ULCard MainType= [%d], SubType=[%d]",__FILE__,__LINE__,m_stULCardInfo.MainType,m_stULCardInfo.SubType);

	iRet= BR_GetParaTicketsTypeTable_h(m_stULCardInfo.MainType, m_stULCardInfo.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Analysis_ULCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}


	// 物理卡号,
	memset(temp,0,sizeof(temp));

	sprintf(temp,"%02X%02X%02X%02X%02X%02X%02X",m_stULCardInfo.CardPhyID[0],
			m_stULCardInfo.CardPhyID[1],
			m_stULCardInfo.CardPhyID[2],
			m_stULCardInfo.CardPhyID[3],
			m_stULCardInfo.CardPhyID[4],
			m_stULCardInfo.CardPhyID[5],
			m_stULCardInfo.CardPhyID[6]);
	strncpy(stAnalysis->cPhysicalID,temp,20);

	PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,stAnalysis->cPhysicalID);

	// 逻辑卡号
	memset(temp,0,sizeof(temp));

	sprintf(temp,"000000000003%02X%02X%02X%02X",
			m_stULCardInfo.SystemFlowID[0],
			m_stULCardInfo.SystemFlowID[1],
			m_stULCardInfo.SystemFlowID[2],
			m_stULCardInfo.SystemFlowID[3]);
	strncpy(stAnalysis->cLogicalID,temp,20);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  cLogicalID[%s]",__FILE__,__LINE__,stAnalysis->cLogicalID);

	// 车票类型(主类型+子类型)
	stAnalysis->bTicketType[0]=m_stULCardInfo.MainType;
	stAnalysis->bTicketType[1]=m_stULCardInfo.SubType;

	PrintLog("File[%s]Line[%d] Analysis_ULCard  bTicketType= [0x%02X%02X]",__FILE__,__LINE__,stAnalysis->bTicketType[0],stAnalysis->bTicketType[1]);

	// 余值
	 
	stAnalysis->lBalance=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.CardValue;
	PrintLog("File[%s]Line[%d] Analysis_ULCard  lBalance= [%d]",__FILE__,__LINE__,stAnalysis->lBalance);
		

	// 押金 (单程票无押金)
	stAnalysis->lDepositorCost=0;
	PrintLog("File[%s]Line[%d] Analysis_ULCard  lDepositorCost= [%d]",__FILE__,__LINE__,stAnalysis->lDepositorCost);
	// 车票最高上限值
	memset(temp,0,sizeof(temp));
	memcpy(temp,( char*)g_BRContext.TicktPara0301.UpperLimit,6);
	stAnalysis->lLimitedBalance=atoi(temp);

	PrintLog("File[%s]Line[%d] Analysis_ULCard  lLimitedBalance= [%d]",__FILE__,__LINE__,stAnalysis->lLimitedBalance);

	// 发行时间
	memcpy(stAnalysis->bIssueData,m_stULCardInfo.IssueDate,4);

	PrintLog("File[%s]Line[%d] Analysis_ULCard  bIssueData= [0x%02X%02X%02X%02X]",__FILE__,__LINE__,
			stAnalysis->bIssueData[0],
			stAnalysis->bIssueData[1],
			stAnalysis->bIssueData[2],
			stAnalysis->bIssueData[3]);

	// 物理有效期截止时间(BCD)(无)
	//stAnalysis->bExpiry[7];

	// 逻辑有效期开始时间(BCD)
	memcpy(stAnalysis->bStartDate,m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessTime,7);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  bStartDate= [0x%02X%02X%02X%02X%02X%02X%02X]",__FILE__,__LINE__,
			stAnalysis->bStartDate[0],
			stAnalysis->bStartDate[1],
			stAnalysis->bStartDate[2],
			stAnalysis->bStartDate[3],
			stAnalysis->bStartDate[4],
			stAnalysis->bStartDate[5],
			stAnalysis->bStartDate[6]);
	// 逻辑有效期结束时间(BCD)=逻辑有效期开始时间(BCD)+ g_BRContext.TicktPara0301.ValidityMin
	int tempValidityMin=0;
	memset(temp,0,sizeof(temp));
	memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
	tempValidityMin=atoi(temp);
    //int tempValidityMin=Get_ValidDate_ULCard(APIParam,u8WorkArea,m_stULCardInfo);
    PrintLog("File[%s]Line[%d] Analysis_ULCard  tempValidityMin= [%d]",__FILE__,__LINE__,tempValidityMin);

	BCDTimeAddSeconds(tempValidityMin*60,stAnalysis->bStartDate,stAnalysis->bEndDate);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  bEndDate= [0x%02X%02X%02X%02X%02X%02X%02X]",__FILE__,__LINE__,
			stAnalysis->bEndDate[0],
			stAnalysis->bEndDate[1],
			stAnalysis->bEndDate[2],
			stAnalysis->bEndDate[3],
			stAnalysis->bEndDate[4],
			stAnalysis->bEndDate[5],
			stAnalysis->bEndDate[6]);
	// 交易状态
	stAnalysis->bStatus=ConvertULCardStatus(m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.CardStatus);

	PrintLog("File[%s]Line[%d] Analysis_ULCard  bStatus= [%d]",__FILE__,__LINE__,stAnalysis->bStatus);

	// 上次交易线路站点(BCD)
	unsigned short tempProcessStation=0;
	unsigned short tempProcessLine=0;
	tempProcessLine=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessLine;
	tempProcessStation=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessStation;
	//stAnalysis->bLastStationID[0]=tempProcessLine;
	//stAnalysis->bLastStationID[1]=tempProcessStation;
	stAnalysis->bLastStationID[0]=Byte_Decimal_to_BCD(tempProcessLine);
	stAnalysis->bLastStationID[1]=Byte_Decimal_to_BCD(tempProcessStation);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  bLastStationID= [0x%02X%02X]",__FILE__,__LINE__,stAnalysis->bLastStationID[0],stAnalysis->bLastStationID[1]);
	
	// 上次交易设备编号(BCD),第0字节仅低4bit有效
	//unsigned short ProcessEquCode=0;
	//ProcessEquCode=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessEquCode;
	//stAnalysis->bLastDeviceID[1]=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessEquCode;
	stAnalysis->bLastDeviceID[1]=Byte_Decimal_to_BCD(m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessEquCode);
	PrintLog("File[%s]Line[%d] Analysis_ULCard  bLastDeviceID= [0x%02X%02X]",__FILE__,__LINE__,stAnalysis->bLastDeviceID[0],stAnalysis->bLastDeviceID[1]);

	// 上次交易设备类型
	stAnalysis->bLastDeviceType=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessEquType;
	PrintLog("File[%s]Line[%d] Analysis_ULCard  bLastDeviceType= [0x%02X]",__FILE__,__LINE__,stAnalysis->bLastDeviceType);

	// 上次交易时间
	memcpy(stAnalysis->dtLastDate,m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessTime,7);

	PrintLog("File[%s]Line[%d] Analysis_ULCard  dtLastDate= [0x%02X%02X%02X%02X%02X%02X%02X]",__FILE__,__LINE__,
				stAnalysis->dtLastDate[0],
				stAnalysis->dtLastDate[1],
				stAnalysis->dtLastDate[2],
				stAnalysis->dtLastDate[3],
				stAnalysis->dtLastDate[4],
				stAnalysis->dtLastDate[5],
				stAnalysis->dtLastDate[6]);

	// 上次进站站点
	stAnalysis->bEntrySationID[0]=Byte_Decimal_to_BCD(m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.InGateLine);
	stAnalysis->bEntrySationID[1]=Byte_Decimal_to_BCD(m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.InGateStation);

	PrintLog("File[%s]Line[%d] Analysis_ULCard  bEntrySationID= [0x%02X%02X]",__FILE__,__LINE__,stAnalysis->bEntrySationID[0],stAnalysis->bEntrySationID[1]);

	//上次进站时间
	memcpy(stAnalysis->dtEntryDate,m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessTime,7);
	PrintLog("File[%s]Line[%d]stAnalysis-> dtEntryDate",__FILE__,__LINE__);
	PrintBuffer((const char *)stAnalysis->dtEntryDate,7);

	// 消费计数
	stAnalysis->lTradeCount=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].TransactionTotal;
	PrintLog("File[%s]Line[%d] Analysis_ULCard  lTradeCount= [0x%02X]",__FILE__,__LINE__,stAnalysis->lTradeCount);

	stAnalysis->cTestFlag=m_stULCardInfo.TestFlag+'0';		// 卡应用标识
	PrintLog("File[%s]Line[%d] Analysis_ULCard  lTradeCount= [0x%02X]",__FILE__,__LINE__,stAnalysis->lTradeCount);


	// 城市代码
	memcpy(stAnalysis->cCityCode,szTempZero,4);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cCityCode= [0x%02X]",__FILE__,__LINE__,0);

	// 发行商代码
	memcpy(stAnalysis->cSellerCode,szTempZero,4);
	PrintLog("File[%s]Line[%d] Analysis_AccCpuCard  cSellerCode= [0x%02X]",__FILE__,__LINE__,0);

	//char		cCertificateCode[32];			// 证件代码
	memcpy(stAnalysis->cCertificateCode,szTempZero,32);

	//char		cCertificateName[20];			// 证件持有人姓名
	memcpy(stAnalysis->cCertificateName,szTempZero,20);

	//卡应用模式
	stAnalysis->cTkAppMode='2';

	//检查车票状态是否正确。
	bRet=Check_Ticket_Status_ULCard(m_stULCardInfo);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_STATUS_CODE;
		return CE_OK;
	}
	//检查余额是否超出上限。
	bRet=Check_Ticket_Value_Uplimit_ULCard(m_stULCardInfo);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return CE_OK;
	}
//	  //检查车票是否过期。
//	bRet=Check_Ticket_Valid_ULCard(APIParam.ucTimeStamp,m_stULCardInfo);
//	PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  bRet= [%d]",__FILE__,__LINE__,bRet);
//	if(!bRet)
//	{
//		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
//		m_stOperationStauts.bAllowSale=TRUE;
//		memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
//		stAnalysis->dwOperationStauts=u8stOperationStauts;
//		return CE_OK;
//	}

	PrintLog("File[%s]Line[%d] Analysis_ULCard  u8WorkArea= [%d]",__FILE__,__LINE__,u8WorkArea);
	switch(u8WorkArea)
	{
	  case EM_CS_AREA_TYPE_PAID_AREA:
//		  bRet=Check_Update_ThisDay_ULCard(APIParam,m_stULCardInfo);
//		  PrintLog("File[%s]Line[%d] Analysis_ULCard  Check_Update_ThisDay_ULCard bRet= [%d]",__FILE__,__LINE__,bRet);
//		  if(!bRet)
//			{
//				pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_DATE;
//				return CE_OK;
//			}
//		  bRet=Check_Update_ThisStation_ULCard(m_stULCardInfo);
//		  PrintLog("File[%s]Line[%d] Analysis_ULCard Check_Update_ThisStation_ULCard bRet= [%d]",__FILE__,__LINE__,bRet);
//		  if(!bRet)
//			{
//				pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_SATION;
//				return CE_OK;
//			}
		  PaidArea_Analysis_ULCard(APIParam,m_stULCardInfo, pRetInfo,stAnalysis);
		break;
	  case EM_CS_AREA_TYPE_UNPAID_AREA:
		   UnpaidArea_Analysis_ULCard(APIParam,m_stULCardInfo, pRetInfo,stAnalysis);
		  break;
	}

	 memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
	 stAnalysis->dwOperationStauts=u8stOperationStauts;
	PrintLog("File[%s]Line[%d] stAnalysis.dwOperationStauts = [0x%02x]",__FILE__,__LINE__,stAnalysis->dwOperationStauts);
	return CE_OK;
}

/*//车票状态代码定义
	EM_TICKET_TRAVEL_STATUS_INITIALIZATION			=1,	//e/s 初始化(init 0)
	EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES		=2,	//e/s 初始化(init 1)
	EM_TICKET_TRAVEL_STATUS_ISSUED					=3,	// SJT发售(init 2)
	EM_TICKET_TRAVEL_STATUS_ENTRY					=4,	//已进站
	EM_TICKET_TRAVEL_STATUS_EXITED					=5,	//已出站
	EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE				=6,	//出站票
	EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE		=7,	//列车故障模式出站(exit during Train-disruption)
	EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA	=8,	//非付费区免费更新(BOM/pca 非付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA	=9,	//非付费区付费更新(BOM/pca 非付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION	=10,//无进站码更新(BOM/pca 付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT				=11,//出站码更新
	EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT			=12,//超时更新
	EM_TICKET_TRAVEL_STATUS_RANGEOUT				=13,//超时及超乖更新
	EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT		=14,//免费出闸更新
	EM_TICKET_TRAVEL_STATUS_REFUND					=15,//已退卡*/
//	stAnalysis->dwOperationStauts;				// 可操作状态与RetInfo的错误对应
// 按位对应以下几种，1表示可操作
										// 	bit0:是否可充(值/乘次)
										// 	bit1:是否可更新
										// 	bit2:是否可发售
										// 	bit3:是否可激活
										// 	bit4:是否可延期
										// 	bit5:是否可退款
										// 	bit6:是否可解锁


  //非付费区分析。
 BOOL UnpaidArea_Analysis_ULCard(StruAPIParam APIParam,CARD_ACC_UL  stULCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis)
 { 
	 BOOL bRet=FALSE;
	 uint8 szEntryStation[2]={0};
	 uint8 u8EntryTime[7]={0};
	 uint32 u32EntryTimeT=0;
	 uint32 u32CurrentTimeT=0;
	 unsigned char szLastProcessStation[2]={0};
	 unsigned char u8stOperationStauts=0;

	 uint8 cardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard cardStatus = [0x%02x]",__FILE__,__LINE__,cardStatus);

	 szEntryStation[0]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateLine;
	 szEntryStation[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateStation;

	 szLastProcessStation[0]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessLine;
	 szLastProcessStation[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessStation;

	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard szEntryStation = [0x%02x%02x]",__FILE__,__LINE__,szEntryStation[0],szEntryStation[1]);

	 memcpy(u8EntryTime,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7);

	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard u8EntryTime",__FILE__,__LINE__);
	 PrintBuffer(u8EntryTime,7);

	 BCD_to_TimeT(u8EntryTime,&u32EntryTimeT);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard u32EntryTimeT[%d]",__FILE__,__LINE__,u32EntryTimeT);
	 PrintBuffer(u8EntryTime,7);

	 BCD_to_TimeT(APIParam.ucTimeStamp,&u32CurrentTimeT);
	 PrintBuffer(APIParam.ucTimeStamp,7);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard u32CurrentTimeT[%d]",__FILE__,__LINE__,u32CurrentTimeT);


	bRet=Allow_Entry_InDegradeMode(APIParam.ucTimeStamp,u8EntryTime,szLastProcessStation,cardStatus);
	if(bRet)
	{
		memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
		stAnalysis->dwOperationStauts=u8stOperationStauts;
		return CE_OK;
	}

	  //检查车票是否过期。
	bRet=Check_Ticket_Valid_ULCard(APIParam.ucTimeStamp,stULCardInfo);
	PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		m_stOperationStauts.bAllowSale=TRUE;
		memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
		stAnalysis->dwOperationStauts=u8stOperationStauts;
		return CE_OK;
	}

	 switch(cardStatus)
	 {
	   case EM_TICKET_TRAVEL_STATUS_REFUND://已退卡
		   pRetInfo->wErrCode=RW_EC_STATUS_REFUND;
		   m_stOperationStauts.bAllowSale=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_INITIALIZATION://初始化
		   pRetInfo->wErrCode=RW_EC_UNSALE;
		   //stAnalysis->dwOperationStauts|=0x04;//可发售
		   m_stOperationStauts.bAllowSale=TRUE;
		 break;
	   case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES://Init II (Pre-value loaded @E/S)(预赋值)
		  // stAnalysis->dwOperationStauts|=0x20;//可退款
		   m_stOperationStauts.bAllowRefund=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_ISSUED://(BOM/TVM)发售
		   //stAnalysis->dwOperationStauts|=0x20;//可退款
		   m_stOperationStauts.bAllowRefund=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA://非付费区免费更新(BOM/pca 非付费区)
		   //stAnalysis->dwOperationStauts|=0x20;//可退款
		   m_stOperationStauts.bAllowRefund=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_ENTRY:  ////已进站
		   if(memcmp(szEntryStation,(char*)g_BRContext.bCurrentStationID,2)==0)//入站为本站
		   {
			   if(u32CurrentTimeT>(u32EntryTimeT+(20*60)))
			   {
				   pRetInfo->wErrCode=RW_EC_ENTRY_TIMOUT_UNPAID_AREA;//非付费区进站超时
				   pRetInfo->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;//回收票
			   }else
			   {
				   pRetInfo->wErrCode=RW_EC_ENTRY_ENTRYCODE_WRITTEN_UNPAID_AREA;//非付费区有进站码
				   stAnalysis->wError=RW_EC_ENTRY_ENTRYCODE_WRITTEN_UNPAID_AREA;
				   stAnalysis->lPenalty=0;//免费更新
				   m_stOperationStauts.bAllowUpdate=TRUE;
			   }
		   }else//入站非本站
		   {
			   pRetInfo->wErrCode=RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA;////"非付费区非本站进站"
			   pRetInfo->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;//回收票
		   }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:  //无进站码更新(BOM/pca 付费区)
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:  //超时更新(BOM/pca 付费区)
		   case EM_TICKET_TRAVEL_STATUS_RANGEOUT:  //超乖更新(BOM/pca 付费区)
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:		//免费出闸更新
			   pRetInfo->wErrCode=RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA;////"非付费区非本站进站"
			   pRetInfo->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;//回收票
			   break;
		   case EM_TICKET_TRAVEL_STATUS_EXITED://已出站
			    m_stOperationStauts.bAllowSale=TRUE;
			    pRetInfo->wErrCode=RW_EC_UNKNOWN;
				pRetInfo->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;//回收票
			   break;
		   case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:////出站票
			   pRetInfo->wErrCode=RW_EC_UNKNOWN;
			   pRetInfo->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;//回收票
			   break;
		   case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:
				 pRetInfo->wErrCode=RW_EC_UNKNOWN;
				 pRetInfo->bNoticeCode=RW_SUBEC_TRAIN_FAULT;//列车故障模式出站
				break;
	 }
	 memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
	 stAnalysis->dwOperationStauts=u8stOperationStauts;
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard bAllowActive[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowActive);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard bAllowCharge[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowCharge);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard bAllowDelay[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowDelay);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard bAllowRefund[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowRefund);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard bAllowSale[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowSale);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard bAllowUnlock[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUnlock);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard bAllowUpdate[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUpdate);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard dwOperationStauts[%d]",__FILE__,__LINE__,stAnalysis->dwOperationStauts);
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard pRetInfo->wErrCode[0x%02X]",__FILE__,__LINE__,pRetInfo->wErrCode);

	 return TRUE;
 }
 //付费区分析。
 BOOL PaidArea_Analysis_ULCard(StruAPIParam APIParam,CARD_ACC_UL  stULCardInfo,RetInfo * pRetInfo,BOMANALYZE * stAnalysis)
 {
     int iRet=0;
     BOOL bRet=FALSE;
	 uint8 szProcessStation[2]={0};
	 uint8 szEntryStation[2]={0};
	 uint8 u8EntryTime[7]={0};
	 long  lRemainningValue=0;
	 //ST_BOM_OperationStauts stOperationStauts;
	 unsigned char u8stOperationStauts=0;
	 uint32 u32EntryTimeT=0;
	 uint32 u32CurrentTimeT=0;
	 uint32  lPrice=0;
	 uint16 FareZone=0;
	 uint16 JourneyTimeLimit=0;
	 uint16 TimeoutsFines=0;
	 uint8  RidingTime=0;
	 uint8  TrainTicketTableID=0;
	 uint8 u8CardType[2]={0};//单程票
	 u8CardType[0]= stULCardInfo.MainType;
	 u8CardType[1]=stULCardInfo.SubType;

	 uint8 cardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;
	 PrintLog("File[%s]Line[%d] UnpaidArea_Analysis_ULCard cardStatus = [0x%02x]",__FILE__,__LINE__,cardStatus);

	 memcpy(u8EntryTime,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard u8EntryTime",__FILE__,__LINE__);
	 PrintBuffer((const char*)u8EntryTime,7);


	 BCD_to_TimeT(u8EntryTime,&u32EntryTimeT);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard u32EntryTimeT[%d]",__FILE__,__LINE__,u32EntryTimeT);

	 BCD_to_TimeT(APIParam.ucTimeStamp,&u32CurrentTimeT);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard u32CurrentTimeT[%d]",__FILE__,__LINE__,u32CurrentTimeT);

	 lRemainningValue=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard lRemainningValue[%d]",__FILE__,__LINE__,lRemainningValue);

	 szProcessStation[0]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessLine;
	 szProcessStation[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessStation;

	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard szProcessStation = [0x%02x%02x]",__FILE__,__LINE__,szProcessStation[0],szProcessStation[1]);


	 szEntryStation[0]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateLine;
	 szEntryStation[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateStation;


	bRet=Allow_Exit_InFreeEntryStationCode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID,szProcessStation);
	if(bRet)
	{
		memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
		stAnalysis->dwOperationStauts=u8stOperationStauts;
		return CE_OK;
	}


	  //检查车票是否过期。
	bRet=Check_Ticket_Valid_ULCard(APIParam.ucTimeStamp,m_stULCardInfo);
	PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  bRet= [%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		m_stOperationStauts.bAllowSale=TRUE;
		memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
		stAnalysis->dwOperationStauts=u8stOperationStauts;
		return CE_OK;
	}

	  bRet=Check_Update_ThisDay_ULCard(APIParam,stULCardInfo);
	  PrintLog("File[%s]Line[%d] Analysis_ULCard  Check_Update_ThisDay_ULCard bRet= [%d]",__FILE__,__LINE__,bRet);
	  if(!bRet)
		{
			pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_DATE;
			return CE_OK;
		}
	  bRet=Check_Update_ThisStation_ULCard(stULCardInfo);
	  PrintLog("File[%s]Line[%d] Analysis_ULCard Check_Update_ThisStation_ULCard bRet= [%d]",__FILE__,__LINE__,bRet);
	  if(!bRet)
		{
			pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_SATION;
			return CE_OK;
		}

	 switch(cardStatus)
	 {
	   case EM_TICKET_TRAVEL_STATUS_REFUND://已退卡
		   pRetInfo->wErrCode=RW_EC_STATUS_REFUND;
		   m_stOperationStauts.bAllowSale=TRUE;
		   break;
	   case EM_TICKET_TRAVEL_STATUS_INITIALIZATION://初始化
		    pRetInfo->wErrCode=RW_EC_UNSALE;
			break;
	   case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES://Init II (Pre-value loaded @E/S)(预赋值)
		   pRetInfo->wErrCode=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;//"付费区无进站码","需要更新"
		   stAnalysis->wError=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;
		   m_stOperationStauts.bAllowUpdate=TRUE;//可更新
		   break;
	   case EM_TICKET_TRAVEL_STATUS_ISSUED://(BOM/TVM)发售
		   pRetInfo->wErrCode=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;//"付费区无进站码","需要更新"
		   stAnalysis->wError=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;
		   m_stOperationStauts.bAllowUpdate=TRUE;//可更新
		   break;
	   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA://非付费区免费更新(BOM/pca 非付费区)
		   pRetInfo->wErrCode=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;//"付费区无进站码","需要更新"
		   stAnalysis->wError=RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA;
		   m_stOperationStauts.bAllowUpdate=TRUE;//可更新
		   break;
	    case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:  //无进站码更新(BOM/pca 付费区)
			  //超时 站内滞留时间.
	    	iRet=Get_Price_InDegrade(u8CardType,szProcessStation,u8EntryTime,APIParam.ucTimeStamp,
	    						&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);

	    	PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
	    	PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice JourneyTimeLimit= [%d] u32Price[%d]",__FILE__,__LINE__,JourneyTimeLimit,lPrice);
	    	if(iRet!=CE_OK)
	    	{
	    		PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
	    		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
	    		return pRetInfo->wErrCode;
	    	}
			PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard u32EntryTimeT+(JourneyTimeLimit*60)[%d] u32CurrentTimeT[%d]",__FILE__,__LINE__,(u32EntryTimeT+(JourneyTimeLimit*60)),u32CurrentTimeT);
			//if((u32EntryTimeT+(JourneyTimeLimit*60))<u32CurrentTimeT)
			if(!Check_Exit_Timeout_ULCard(APIParam,JourneyTimeLimit,stULCardInfo))
			{
			   pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;//"付费区超时",
			   stAnalysis->wError=RW_EC_EXIT_TIMOUT_PAID_AREA;
			   //stAnalysis->dwOperationStauts|=0x02;//可更新
			   m_stOperationStauts.bAllowUpdate=TRUE;//可更新
			   stAnalysis->lPenalty=TimeoutsFines;//更新金额,
			   PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard 超时 lPenalty1[%d]",__FILE__,__LINE__,stAnalysis->lPenalty1);
			}
	    	break;
		case EM_TICKET_TRAVEL_STATUS_ENTRY: ////已进站
		{

	    	iRet=Get_Price_InDegrade(u8CardType,szProcessStation,u8EntryTime,APIParam.ucTimeStamp,
	    						&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);

	    	PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
	    	PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice JourneyTimeLimit= [%d] u32Price[%d]",__FILE__,__LINE__,JourneyTimeLimit,lPrice);
	    	if(iRet!=CE_OK)
	    	{
	    		PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
	    		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
	    		return pRetInfo->wErrCode;
	    	}
			PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard lRemainningValue[%d] lPrice[%d]",__FILE__,__LINE__,lRemainningValue,lPrice);
		   //if(lRemainningValue<lPrice) //超乘
			if(!Check_Exit_RemainningValue_ULCard(&lPrice,stULCardInfo))
		   {

			   pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_PAID_AREA;//"付费区超乘",
			   stAnalysis->wError1=RW_EC_EXIT_OUTRANGE_PAID_AREA;
			   //stAnalysis->dwOperationStauts|=0x02;//可更新
			   m_stOperationStauts.bAllowUpdate=TRUE;//可更新
			   stAnalysis->lPenalty1=(lPrice-lRemainningValue);//更新金额
			   PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard 超乘 lPenalty[%d]",__FILE__,__LINE__,stAnalysis->lPenalty);

		   }
		   //超时 站内滞留时间.
		    PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard u32EntryTimeT+(JourneyTimeLimit*60)[%d] u32CurrentTimeT[%d]",__FILE__,__LINE__,(u32EntryTimeT+(JourneyTimeLimit*60)),u32CurrentTimeT);
			//if((u32EntryTimeT+(JourneyTimeLimit*60))<u32CurrentTimeT)
		    if(!Check_Exit_Timeout_ULCard(APIParam,JourneyTimeLimit,stULCardInfo))
			{
			   pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;//"付费区超时",
			   stAnalysis->wError=RW_EC_EXIT_TIMOUT_PAID_AREA;
			   //stAnalysis->dwOperationStauts|=0x02;//可更新
			   m_stOperationStauts.bAllowUpdate=TRUE;//可更新
			   stAnalysis->lPenalty=TimeoutsFines;//更新金额,
			   PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard 超时 lPenalty1[%d]",__FILE__,__LINE__,stAnalysis->lPenalty1);
			}

			if(stAnalysis->wError==RW_EC_EXIT_TIMOUT_PAID_AREA&&stAnalysis->wError1==RW_EC_EXIT_OUTRANGE_PAID_AREA)
			{
				//stAnalysis->lPenalty1=0;
				PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard 超时超乘 lPenalty1[%d]",__FILE__,__LINE__,stAnalysis->lPenalty1);
				pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_AND_TIMEOUT;

			}
		   }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:  //超时更新(BOM/pca 付费区)
		   {
		    	iRet=Get_Price_InDegrade(u8CardType,szProcessStation,u8EntryTime,APIParam.ucTimeStamp,
		    						&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);

		    	PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
		    	PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice JourneyTimeLimit= [%d] u32Price[%d]",__FILE__,__LINE__,JourneyTimeLimit,lPrice);
		    	if(iRet!=CE_OK)
		    	{
		    		PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
		    		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		    		return pRetInfo->wErrCode;
		    	}
				PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard lRemainningValue[%d] lPrice[%d]",__FILE__,__LINE__,lRemainningValue,lPrice);
			   //if(lRemainningValue<lPrice) //超乘
				if(!Check_Exit_RemainningValue_ULCard(&lPrice,stULCardInfo))
			   {

				   pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_PAID_AREA;//"付费区超乘",
				   stAnalysis->wError=RW_EC_EXIT_OUTRANGE_PAID_AREA;
				   //stAnalysis->dwOperationStauts|=0x02;//可更新
				   m_stOperationStauts.bAllowUpdate=TRUE;//可更新
				   stAnalysis->lPenalty=(lPrice-lRemainningValue);//更新金额
				   PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard 超乘 lPenalty[%d]",__FILE__,__LINE__,stAnalysis->lPenalty);

			   }


		   }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_RANGEOUT:  //超乖更新(BOM/pca 付费区)
		   {

		    	iRet=Get_Price_InDegrade(u8CardType,szProcessStation,u8EntryTime,APIParam.ucTimeStamp,
		    						&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&lPrice);

		    	PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
		    	PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice JourneyTimeLimit= [%d] u32Price[%d]",__FILE__,__LINE__,JourneyTimeLimit,lPrice);
		    	if(iRet!=CE_OK)
		    	{
		    		PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
		    		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		    		return pRetInfo->wErrCode;
		    	}
				PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard lRemainningValue[%d] lPrice[%d]",__FILE__,__LINE__,lRemainningValue,lPrice);
				//if((u32EntryTimeT+(JourneyTimeLimit*60))<u32CurrentTimeT)
				 if(!Check_Exit_Timeout_ULCard(APIParam,JourneyTimeLimit,stULCardInfo))
				{
				   pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;//"付费区超时",
				   stAnalysis->wError=RW_EC_EXIT_TIMOUT_PAID_AREA;
				   //stAnalysis->dwOperationStauts|=0x02;//可更新
				   m_stOperationStauts.bAllowUpdate=TRUE;//可更新
				   stAnalysis->lPenalty=TimeoutsFines;//更新金额,
				   PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard 超时 lPenalty1[%d]",__FILE__,__LINE__,stAnalysis->lPenalty1);
				}
		   }
		   break;
		   case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:		//免费出闸更新
			   {
			    if(memcmp(szProcessStation,(char*)g_BRContext.bCurrentStationID,2)==0)//更新站为本站
				{
				   if(u32EntryTimeT+(24*3600)<u32CurrentTimeT)//本站24前更新
				   {
					   PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard 非本日更新的车票",__FILE__,__LINE__);
					   pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_DATE;//"非本日更新的车票",，不可更新。
					   pRetInfo->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;//回收票
				   }
				}else
				{
					 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard 非本站更新的车票",__FILE__,__LINE__);
					 pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_SATION;//非本站更新的车票","可以建议乘客去更新的车站出站，也可以根据乘客的要求做票卡更新"
					 //stAnalysis->dwOperationStauts|=0x02;//可更新
					// m_stOperationStauts.bAllowUpdate=TRUE;//可更新
					 pRetInfo->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;//回收票

				}
			   }
			   break;
			 case EM_TICKET_TRAVEL_STATUS_EXITED://已出站
				 {
					 if((u32EntryTimeT+(10*60))<=u32CurrentTimeT&&(memcmp(szProcessStation,(char*)g_BRContext.bCurrentStationID,2)==0))//本站X秒内出站
					 {
					   PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard 上次出站在X秒内",__FILE__,__LINE__);
					   pRetInfo->wErrCode=RW_EC_LAST_EXIT_BELOW_X_MINUTE;
					   pRetInfo->bNoticeCode=RW_SUBEC_LAST_EXIT_BELOW_X_MINUTE;////上次出站在X秒内
					 }else
					 {
					   PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard 上次出站在X秒外",__FILE__,__LINE__);
					   pRetInfo->wErrCode=RW_EC_UNKNOWN;
					   pRetInfo->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;//回收票
					 }
				 }
			   break;
			 case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE://出站票
				 {
					 if(memcmp(szProcessStation,(char*)g_BRContext.bCurrentStationID,2)!=0)
					 {
						PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard 非本站上次出站在X秒外",__FILE__,__LINE__);
						pRetInfo->wErrCode=RW_EC_UNKNOWN;
						pRetInfo->bNoticeCode=RW_SUBEC_WITHDRAW_TICKET;//回收票
						//可发售付费出站票。
					 }else
					 {
						 pRetInfo->wErrCode=RW_EC_OK;
					 }
				 }
			   break;
			 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:
				 pRetInfo->wErrCode=RW_EC_UNKNOWN;
				 pRetInfo->bNoticeCode=RW_SUBEC_TRAIN_FAULT;//列车故障模式出站
				 break;
	 }

	 memcpy(&u8stOperationStauts,&m_stOperationStauts,sizeof(m_stOperationStauts));
	 stAnalysis->dwOperationStauts=u8stOperationStauts;
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard bAllowActive[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowActive);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard bAllowCharge[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowCharge);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard bAllowDelay[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowDelay);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard bAllowRefund[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowRefund);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard bAllowSale[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowSale);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard bAllowUnlock[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUnlock);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard bAllowUpdate[%d]",__FILE__,__LINE__,m_stOperationStauts.bAllowUpdate);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard dwOperationStauts[%d]",__FILE__,__LINE__,stAnalysis->dwOperationStauts);
	 PrintLog("File[%s]Line[%d] PaidArea_Analysis_ULCard pRetInfo->wErrCode[0x%02X]",__FILE__,__LINE__,pRetInfo->wErrCode);
	 return TRUE;
 }

int Query_ULCard(StruAPIParam APIParam,RetInfo * pRetInfo,TICKETINFO * stTicketInfo)
{
	int iRet=-1;
	//BOOL bRet=FALSE;
	char temp[32]={0};
	CARD_ACC_UL stULCardInfo;
	memset(&stULCardInfo,0,sizeof(CARD_ACC_UL));

	if(NULL==pRetInfo||NULL==stTicketInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	iRet=Inner_Read_ULCard(APIParam,&stULCardInfo);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}
	PrintLog("File[%s]Line[%d] Query_ULCard  Inner_Read_ULCard MainType= [%d], SubType=[%d]",__FILE__,__LINE__,m_stULCardInfo.MainType,m_stULCardInfo.SubType);

	iRet= BR_GetParaTicketsTypeTable_h(stULCardInfo.MainType, stULCardInfo.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Query_ULCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}


	// 物理卡号,
		memset(temp,0,sizeof(temp));

		sprintf(temp,"%02X%02X%02X%02X%02X%02X%02X",stULCardInfo.CardPhyID[0],
				stULCardInfo.CardPhyID[1],
				stULCardInfo.CardPhyID[2],
				stULCardInfo.CardPhyID[3],
				stULCardInfo.CardPhyID[4],
				stULCardInfo.CardPhyID[5],
				stULCardInfo.CardPhyID[6]);
		strncpy(stTicketInfo->cPhysicalID,temp,14);

		PrintLog("File[%s]Line[%d] Analysis_ULCard  cPhysicalID[%s]",__FILE__,__LINE__,stTicketInfo->cPhysicalID);

		// 逻辑卡号
		memset(temp,0,sizeof(temp));

		sprintf(temp,"000000000003%02X%02X%02X%02X",
				stULCardInfo.SystemFlowID[0],
				stULCardInfo.SystemFlowID[1],
				stULCardInfo.SystemFlowID[2],
				stULCardInfo.SystemFlowID[3]);
		strncpy(stTicketInfo->cLogicalID,temp,20);
		PrintLog("File[%s]Line[%d] Analysis_ULCard  cLogicalID[%s]",__FILE__,__LINE__,stTicketInfo->cLogicalID);

		// 车票类型(主类型+子类型)
		stTicketInfo->bTicketType[0]=stULCardInfo.MainType;
		stTicketInfo->bTicketType[1]=stULCardInfo.SubType;

		PrintLog("File[%s]Line[%d] Analysis_ULCard  bTicketType= [0x%02X%02X]",__FILE__,__LINE__,stTicketInfo->bTicketType[0],stTicketInfo->bTicketType[1]);

		// 余值

		stTicketInfo->lBalance=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;
		PrintLog("File[%s]Line[%d] Analysis_ULCard  lBalance= [%d]",__FILE__,__LINE__,stTicketInfo->lBalance);


		// 押金 (单程票无押金)
		stTicketInfo->lDepositorCost=0;
		PrintLog("File[%s]Line[%d] Analysis_ULCard  lDepositorCost= [%d]",__FILE__,__LINE__,stTicketInfo->lDepositorCost);
		// 车票最高上限值
		memset(temp,0,sizeof(temp));
		memcpy(temp,( char*)g_BRContext.TicktPara0301.UpperLimit,6);
		stTicketInfo->lLimitedBalance=atoi(temp);

		PrintLog("File[%s]Line[%d] Analysis_ULCard  lLimitedBalance= [%d]",__FILE__,__LINE__,stTicketInfo->lLimitedBalance);

		// 发行时间
		memcpy(stTicketInfo->bIssueData,stULCardInfo.IssueDate,4);

		PrintLog("File[%s]Line[%d] Analysis_ULCard  bIssueData= [0x%02X%02X%02X%02X]",__FILE__,__LINE__,
				stTicketInfo->bIssueData[0],
				stTicketInfo->bIssueData[1],
				stTicketInfo->bIssueData[2],
				stTicketInfo->bIssueData[3]);

		// 物理有效期截止时间(BCD)(无)
		//stTicketInfo->bExpiry[7];

		// 逻辑有效期开始时间(BCD)
		memcpy(stTicketInfo->bStartDate,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7);
		PrintLog("File[%s]Line[%d] Analysis_ULCard  bStartDate= [0x%02X%02X%02X%02X%02X%02X%02X]",__FILE__,__LINE__,
				stTicketInfo->bStartDate[0],
				stTicketInfo->bStartDate[1],
				stTicketInfo->bStartDate[2],
				stTicketInfo->bStartDate[3],
				stTicketInfo->bStartDate[4],
				stTicketInfo->bStartDate[5],
				stTicketInfo->bStartDate[6]);
		// 逻辑有效期结束时间(BCD)=逻辑有效期开始时间(BCD)+ g_BRContext.TicktPara0301.ValidityMin
		memset(temp,0,sizeof(temp));

		memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
	    int tempValidityMin=0;
	    tempValidityMin=atoi(temp);
	    PrintLog("File[%s]Line[%d] Analysis_ULCard  tempValidityMin= [%d]",__FILE__,__LINE__,tempValidityMin);

		BCDTimeAddSeconds(tempValidityMin*60,stTicketInfo->bStartDate,stTicketInfo->bEndDate);
		PrintLog("File[%s]Line[%d] Analysis_ULCard  bEndDate= [0x%02X%02X%02X%02X%02X%02X%02X]",__FILE__,__LINE__,
				stTicketInfo->bEndDate[0],
				stTicketInfo->bEndDate[1],
				stTicketInfo->bEndDate[2],
				stTicketInfo->bEndDate[3],
				stTicketInfo->bEndDate[4],
				stTicketInfo->bEndDate[5],
				stTicketInfo->bEndDate[6]);
		// 交易状态
		stTicketInfo->bStatus=ConvertULCardStatus(stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus);

		PrintLog("File[%s]Line[%d] Analysis_ULCard  bStatus= [%d]",__FILE__,__LINE__,stTicketInfo->bStatus);

		// 上次交易线路站点(BCD)
		unsigned short tempProcessStation=0;
		unsigned short tempProcessLine=0;
		tempProcessLine=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessLine;
		tempProcessStation=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessStation;
		stTicketInfo->bLastStationID[0]=tempProcessLine;
		stTicketInfo->bLastStationID[1]=tempProcessStation;
		PrintLog("File[%s]Line[%d] Analysis_ULCard  bLastStationID= [0x%02X%02X]",__FILE__,__LINE__,stTicketInfo->bLastStationID[0],stTicketInfo->bLastStationID[1]);

		// 上次交易设备编号(BCD),第0字节仅低4bit有效
		//unsigned short ProcessEquCode=0;
		//ProcessEquCode=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessEquCode;
		stTicketInfo->bLastDeviceID[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessEquCode;
		PrintLog("File[%s]Line[%d] Analysis_ULCard  bLastDeviceID= [0x%02X%02X]",__FILE__,__LINE__,stTicketInfo->bLastDeviceID[0],stTicketInfo->bLastDeviceID[1]);

		// 上次交易设备类型
		stTicketInfo->bLastDeviceType=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessEquType;
		PrintLog("File[%s]Line[%d] Analysis_ULCard  bLastDeviceType= [0x%02X]",__FILE__,__LINE__,stTicketInfo->bLastDeviceType);

		// 上次交易时间
		memcpy(stTicketInfo->dtLastDate,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7);

		PrintLog("File[%s]Line[%d] Analysis_ULCard  dtLastDate= [0x%02X%02X%02X%02X%02X%02X%02X]",__FILE__,__LINE__,
					stTicketInfo->dtLastDate[0],
					stTicketInfo->dtLastDate[1],
					stTicketInfo->dtLastDate[2],
					stTicketInfo->dtLastDate[3],
					stTicketInfo->dtLastDate[4],
					stTicketInfo->dtLastDate[5],
					stTicketInfo->dtLastDate[6]);

		// 上次进站站点
		stTicketInfo->bEntrySationID[0]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateLine;
		stTicketInfo->bEntrySationID[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateStation;

		PrintLog("File[%s]Line[%d] Analysis_ULCard  bEntrySationID= [0x%02X%02X]",__FILE__,__LINE__,stTicketInfo->bEntrySationID[0],stTicketInfo->bEntrySationID[1]);

		//上次进站时间
		memcpy(stTicketInfo->dtEntryDate,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7);
		PrintLog("File[%s]Line[%d]stTicketInfo-> dtEntryDate",__FILE__,__LINE__);
		PrintBuffer((const char *)stTicketInfo->dtEntryDate,7);

		// 消费计数
		stTicketInfo->lTradeCount=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].TransactionTotal;
		PrintLog("File[%s]Line[%d] Analysis_ULCard  lTradeCount= [0x%02X]",__FILE__,__LINE__,stTicketInfo->lTradeCount);

		stTicketInfo->cTestFlag=stULCardInfo.TestFlag+30;		// 卡应用标识
		PrintLog("File[%s]Line[%d] Analysis_ULCard  lTradeCount= [0x%02X]",__FILE__,__LINE__,stTicketInfo->lTradeCount);

		//卡应用模式
		stTicketInfo->cTkAppMode='2';

		pRetInfo->wErrCode=0;

	return CE_OK;
}
int Update_ULCard(StruAPIParam APIParam,uint8 u8UpdateCode,uint16 u16EntryStationCode,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRetInfo,TICKETUPDATE * stUpdateInfo)
{
	int iRet=-1;
	//BOOL bRet=FALSE;

	uint8 updateArea=0;
	uint8 u8TranStatus=0;
	unsigned char szTAC[4]={0};

	CARD_STATUS_INFO_ACC_UL cardProcessInfo;
	memset(&cardProcessInfo,0,sizeof(CARD_STATUS_INFO_ACC_UL));

	if(NULL==pRetInfo||NULL==stUpdateInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}
	PrintLog("File[%s]Line[%d] Update_ULCard  m_stOperationStauts.bAllowUpdate= [0x%02X]",__FILE__,__LINE__,m_stOperationStauts.bAllowUpdate);

	if(!m_stOperationStauts.bAllowUpdate)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	//车票余额
	//车票状态
	/*1：付费区出站超时
	2：付费区超乘
	3：付费区无进站码
	10：非付费区有进站码
	11：非付费区非本站进站
	12：非付费区进站超时；
	*/


	switch(u8UpdateCode)
	{
		case 1://1：付费区出站超时
			cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT;
			cardProcessInfo.ProcessInfo.InGateLine= m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessLine;
			cardProcessInfo.ProcessInfo.InGateStation=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessStation;
			updateArea='1';
			u8TranStatus=RW_LIFECODE_UPDATE_TIMEOUT;
			break;
		case 2://2：付费区超乘
			cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_RANGEOUT;
			cardProcessInfo.ProcessInfo.InGateLine= m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessLine;
			cardProcessInfo.ProcessInfo.InGateStation=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessStation;
			updateArea='1';
			u8TranStatus=RW_LIFECODE_UPDATE_RANGEOUT;
			break;
		case 3://3：付费区无进站码
			cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION;
			cardProcessInfo.ProcessInfo.InGateLine= m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessLine;//u16EntryStationCode&0xFF00>>8;
			cardProcessInfo.ProcessInfo.InGateStation=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.ProcessStation;//u16EntryStationCode&0x00FF;
			updateArea='1';
			u8TranStatus=RW_LIFECODE_UPDATE_NO_ENTRY_STATION;
			break;
		case 10://10：非付费区有进站码
			if(u16TranValue>0)
			{
			  cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA;
			  u8TranStatus=RW_LIFECODE_UPDATE_PAYED_UNPAYAREA;
			}else
			{
			  cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA;
			  u8TranStatus=RW_LIFECODE_UPDATE_FREE_UNPAYAREA;
			}
			updateArea='2';
			break;
		case 11://11：非付费区非本站进站
			cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA;
			updateArea='2';
			u8TranStatus=RW_LIFECODE_UPDATE_PAYED_UNPAYAREA;
			break;
		case 12://非付费区进站超时；
			cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA;
			updateArea='2';
			u8TranStatus=RW_LIFECODE_UPDATE_PAYED_UNPAYAREA;
			break;
		default:
			pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
			return iRet;
	}

	cardProcessInfo.ProcessInfo.CardValue=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.CardValue;

	iRet=Inner_Write_ULCard(APIParam,cardProcessInfo);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD

	// 罚金支付方式  //01：现金，02：票卡
	stUpdateInfo->bPaymentMode=u8PaymentType;

	stUpdateInfo->nForfeiture=u16TranValue;

	//// 更新区域 1：付费区，2：非付费区
	stUpdateInfo->cUpdateZone=updateArea;
	stUpdateInfo->bUpdateReasonCode=Byte_Decimal_to_BCD(u8UpdateCode);
	stUpdateInfo->bStatus=u8TranStatus;


	Fill_Update_ULCard_UD(APIParam,m_stULCardInfo,stUpdateInfo);

	// SAM生成的交易检查代码
	//GetULCardUDTAC(m_stULCardInfo.SystemFlowID,stUpdateInfo->nForfeiture,stUpdateInfo->lSAMTrSeqNo,stUpdateInfo->dtUpdateDate,szTAC);

	//sprintf(stUpdateInfo->cMACorTAC,"%02X%02X%02X%02X",szTAC[0],szTAC[1],szTAC[2],szTAC[3]);

	pRetInfo->wErrCode=0;

	return CE_OK;
}


int Refund_ULCard(StruAPIParam APIParam,uint8 u8RefundOption,uint8 u8RefundCode,uint16 u16TranValue,RetInfo * pRetInfo,DIRECTREFUND * stRefundInfo)
{
	int iRet=-1;
	//BOOL bRet=FALSE;
	char temp[10]={0};

	unsigned char szTAC[4]={0};

	CARD_STATUS_INFO_ACC_UL cardProcessInfo;
	memset(&cardProcessInfo,0,sizeof(CARD_STATUS_INFO_ACC_UL));

	if(NULL==pRetInfo||NULL==stRefundInfo)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	PrintLog("File[%s]Line[%d] Refund_ULCard  u8RefundCode= [0x%02X]",__FILE__,__LINE__,u8RefundCode);

	PrintLog("File[%s]Line[%d] Refund_ULCard  m_stOperationStauts.bAllowRefund= [0x%02X]",__FILE__,__LINE__,m_stOperationStauts.bAllowRefund);
	
	if(u8RefundOption!=1&&u8RefundOption!=3)
	{
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	if(u8RefundOption!=3)
	{
		if(!m_stOperationStauts.bAllowRefund)
		{
			pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
			return RW_EC_INVALID_INPUT_PARAM;
		}
	}

	iRet= BR_GetParaTicketsTypeTable_h(m_stULCardInfo.MainType, m_stULCardInfo.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Refund_ULCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}


	temp[0]=g_BRContext.TicktPara0301.Refund[0];

    if(!atoi(temp))
    {
    	PrintLog("File[%s]Line[%d] Refund_ULCard  TicktPara0301 iRet= [%d]",__FILE__,__LINE__,atoi(temp));
		pRetInfo->wErrCode=RW_EC_INVALID_API_CALL;
		return pRetInfo->wErrCode;
    }

    if(m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.CardStatus==RW_EC_STATUS_REFUND)
    {
    	PrintLog("File[%s]Line[%d] Refund_ULCard  票卡已退款(注销) ",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_STATUS_REFUND;
		return pRetInfo->wErrCode;
    }

    memset(temp,0,sizeof(temp));
    memcpy(temp,g_BRContext.TicktPara0301.RefundMoneyLimit,6);

    if(atoi(temp)<m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.CardValue)
    {
    	PrintLog("File[%s]Line[%d] Refund_ULCard  RW_EC_AMOUNT_EXCEED_MAX_AMOUNT ",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return pRetInfo->wErrCode;
    }


	//车票余额
	cardProcessInfo.ProcessInfo.CardValue=0;
	//车票状态
	cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_REFUND;
	//特殊标记
	cardProcessInfo.ProcessInfo.CardSpecialFlag=EM_CS_SPEC_FLAG_FORBID;//禁止使用（退卡、非即时退款申请、行政处理）

	iRet=Inner_Write_ULCard(APIParam,cardProcessInfo);
	PrintLog("File[%s]Line[%d] Refund_ULCard  Inner_Write_ULCard [%d]",__FILE__,__LINE__,iRet);

	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//// 退还钱包金额, 单位为分
	stRefundInfo->lBalanceReturned=m_stULCardInfo.cardProcessInfo[m_stULCardInfo.StatusPointer].ProcessInfo.CardValue;

	stRefundInfo->bStatus=RW_LIFECODE_REBACK_CARD;
	//组UD
	Fill_Refund_ULCard_UD(APIParam,m_stULCardInfo,stRefundInfo);

	// SAM生成的交易检查代码
	GetULCardUDTAC(m_stULCardInfo.SystemFlowID,stRefundInfo->lBalanceReturned,stRefundInfo->lSAMTrSeqNo,stRefundInfo->dtDate,szTAC);

	sprintf(stRefundInfo->cMACOrTAC,"%02X%02X%02X%02X",szTAC[0],szTAC[1],szTAC[2],szTAC[3]);


	pRetInfo->wErrCode=RW_EC_OK;

	return CE_OK;
}

int Entry_ULCard(StruAPIParam APIParam,RetInfo * pRetInfo,ENTRYGATE *stEntryInfo,TICKETLOCK * stLockInfo)
{
	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;
	BOOL bAllowEntryInMode=FALSE;


	CARD_ACC_UL stULCardInfo;
	memset(&stULCardInfo,0,sizeof(CARD_ACC_UL));

	CARD_STATUS_INFO_ACC_UL cardProcessInfo;
	memset(&cardProcessInfo,0,sizeof(CARD_STATUS_INFO_ACC_UL));

	uint8 szLastProcessStation[2]={0};
	uint8 szLastProcessTime[7]={0};
	uint8 u8CardStatus=0;

	if(NULL==pRetInfo||NULL==stEntryInfo||NULL==stLockInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}


	g_BRContext.ucCurrentStationMode=GetLocalStationMode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID);

	PrintLog("File[%s]Line[%d]Entry_ULCard   CurrentStationMode=[%d]",__FILE__,__LINE__,g_BRContext.ucCurrentStationMode);

	if(g_BRContext.ucCurrentStationMode==EM_MODE_EMERGENCY
	  ||g_BRContext.ucCurrentStationMode==EM_MODE_TRAIN_FAULT
	  ||g_BRContext.ucCurrentStationMode==EM_MODE_FREE_ENTRY)
	{
		PrintLog("File[%s]Line[%d]Entry_ULCard   StationMode=EM_MODE_EMERGENCY",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}


	iRet=Inner_Read_ULCard(APIParam,&stULCardInfo);
	PrintLog("File[%s]Line[%d]Entry_ULCard  Inner_Read_ULCard Result=[%d]",__FILE__,__LINE__,iRet);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	PrintLog("File[%s]Line[%d] Analysis_ULCard  Inner_Read_ULCard MainType= [%d], SubType=[%d]",__FILE__,__LINE__,m_stULCardInfo.MainType,m_stULCardInfo.SubType);

	iRet= BR_GetParaTicketsTypeTable_h(stULCardInfo.MainType, stULCardInfo.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Analysis_ULCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}

	szLastProcessStation[0]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessLine;
	szLastProcessStation[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessStation;
	memcpy(szLastProcessTime,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7);
	u8CardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;

	//检查车票状态是否正确。
	bRet=Check_Ticket_Status_ULCard(stULCardInfo);
	PrintLog("File[%s]Line[%d]Entry_ULCard  Check_Ticket_Status_ULCard Result=[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_STATUS_CODE;
		return pRetInfo->wErrCode;
	}

	//检查余额是否超出上限。
	bRet=Check_Ticket_Value_Uplimit_ULCard(stULCardInfo);
	PrintLog("File[%s]Line[%d]Entry_ULCard  Check_Ticket_Value_Uplimit_ULCard Result=[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return pRetInfo->wErrCode;
	}

	//BOOL bGetTranFaultMode=FALSE;
	//BOOL bGetEmergecyMode=FALSE;
	//检查车票是否过期。
	bRet=Check_Ticket_Valid_ULCard(APIParam.ucTimeStamp,stULCardInfo);
	PrintLog("File[%s]Line[%d]Entry_ULCard  Check_Ticket_Valid_ULCard Result=[%d]",__FILE__,__LINE__,bRet);

	if((!bRet)&&(!bAllowEntryInMode))
	{

		bAllowEntryInMode=Allow_Entry_InDegradeMode(APIParam.ucTimeStamp,szLastProcessTime,szLastProcessStation,u8CardStatus);
		PrintLog("File[%s]Line[%d]Entry_ULCard  Allow_Entry_InDegradeMode bAllowEntryInMode=[%d]",__FILE__,__LINE__,bAllowEntryInMode);
		if(!bAllowEntryInMode)
		{
		   pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		   return pRetInfo->wErrCode;
		}
	}
	//进站次序检查。
	bRet=Check_Entry_Status_ULCard(stULCardInfo);
	PrintLog("File[%s]Line[%d]Entry_ULCard  Check_Entry_Status_ULCard Result=[%d]",__FILE__,__LINE__,bRet);
	if((!bRet)&&(!bAllowEntryInMode))
	{
		bAllowEntryInMode=Allow_Entry_InDegradeMode(APIParam.ucTimeStamp,szLastProcessTime,szLastProcessStation,u8CardStatus);
		PrintLog("File[%s]Line[%d]Entry_ULCard  Allow_Entry_InDegradeMode bAllowEntryInMode=[%d]",__FILE__,__LINE__,bAllowEntryInMode);
		if(!bAllowEntryInMode)
		{
		  pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
		  return pRetInfo->wErrCode;
		}
	}
	//检查是否只允许本站进站。
	bRet=Check_EntryThisStation_ULCard(stULCardInfo);
	PrintLog("File[%s]Line[%d]Entry_ULCard  Check_EntryThisStation_ULCard Result=[%d]",__FILE__,__LINE__,bRet);
	if((!bRet)&&(!bAllowEntryInMode))
	{
		bAllowEntryInMode=Allow_Entry_InDegradeMode(APIParam.ucTimeStamp,szLastProcessTime,szLastProcessStation,u8CardStatus);
		PrintLog("File[%s]Line[%d]Entry_ULCard  Allow_Entry_InDegradeMode bAllowEntryInMode=[%d]",__FILE__,__LINE__,bAllowEntryInMode);
		if(!bAllowEntryInMode)
		{
		   pRetInfo->wErrCode=RW_EC_OTHER_SATION;
		   return pRetInfo->wErrCode;
		}
	}

	//余额低于最小票价。
	bRet=Check_MinValue_ULCard( APIParam,stULCardInfo);
	PrintLog("File[%s]Line[%d]Entry_ULCard  Check_MinValue_ULCard Result=[%d]",__FILE__,__LINE__,bRet);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_INSUFFICIENT;
		return pRetInfo->wErrCode;
	}

	//写卡准备
	//车票状态
	cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_ENTRY;//:已进站
	cardProcessInfo.ProcessInfo.CardValue=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;
	cardProcessInfo.ProcessInfo.CardSpecialFlag=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardSpecialFlag;
	cardProcessInfo.ProcessInfo.InGateLine=g_BRContext.bCurrentLineID;
	cardProcessInfo.ProcessInfo.InGateStation=g_BRContext.bCurrentStationID[1];
	iRet=Inner_Write_ULCard(APIParam,cardProcessInfo);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	//组UD
	// 交易状态
	stEntryInfo->bStatus=RW_LIFECODE_ENTRY_STATION;

	Fill_Entry_ULCard_UD(APIParam,stULCardInfo,stEntryInfo);

	pRetInfo->wErrCode=0;

	return CE_OK;
}

int Exit_ULCard(StruAPIParam APIParam,RetInfo * pRetInfo,PURSETRADE *stPurseInfo,TICKETLOCK * stLockInfo)
{
	//入参检查.

	int iRet=-1;
	BOOL bRet=FALSE;
	BOOL bHasFreeMode=FALSE;
	uint32 u32Price=0;
	 uint16 FareZone=0;
	 uint16 JourneyTimeLimit=0;
	 uint16 TimeoutsFines=0;
	 uint8  RidingTime=0;
	 uint8  TrainTicketTableID=0;
	 uint8 u8CardType[2]={0};
	 uint8 szProcessStation[2]={0};
	 uint8 u8EntryTime[7]={0};

	 unsigned char szTAC[4]={0};

	CARD_ACC_UL stULCardInfo;
	memset(&stULCardInfo,0,sizeof(CARD_ACC_UL));

	CARD_STATUS_INFO_ACC_UL cardProcessInfo;
	memset(&cardProcessInfo,0,sizeof(CARD_STATUS_INFO_ACC_UL));

	if(NULL==pRetInfo||NULL==stPurseInfo||NULL==stLockInfo)
	{
		return RW_EC_INVALID_INPUT_PARAM;
	}

	g_BRContext.ucCurrentStationMode=GetLocalStationMode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID);

	if(g_BRContext.ucCurrentStationMode==EM_MODE_EMERGENCY)
	{
		PrintLog("File[%s]Line[%d]Exit_ULCard   StationMode=EM_MODE_EMERGENCY",__FILE__,__LINE__);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return RW_EC_INVALID_INPUT_PARAM;
	}

	iRet=Inner_Read_ULCard(APIParam,&stULCardInfo);
	if(CE_OK!=iRet)
	{
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	PrintLog("File[%s]Line[%d] Analysis_ULCard  Inner_Read_ULCard MainType= [%d], SubType=[%d]",__FILE__,__LINE__,m_stULCardInfo.MainType,m_stULCardInfo.SubType);

	iRet= BR_GetParaTicketsTypeTable_h(stULCardInfo.MainType, stULCardInfo.SubType,(uint8*)&g_BRContext.TicktPara0301);
	if(CE_OK!=iRet)
	{
		PrintLog("File[%s]Line[%d] Analysis_ULCard  BR_GetParaTicketsTypeTable_h iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_UNKNOW_TICKETTYPE;
		return pRetInfo->wErrCode;
	}

	u8CardType[0]=stULCardInfo.MainType;
	u8CardType[1]=stULCardInfo.SubType;
	szProcessStation[0]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateLine;
	szProcessStation[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.InGateStation;

	memcpy(u8EntryTime,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7);




	//检查车票状态是否正确。
	bRet=Check_Ticket_Status_ULCard(stULCardInfo);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_STATUS_CODE;
		return pRetInfo->wErrCode;
	}
	//检查余额是否超出上限。
	bRet=Check_Ticket_Value_Uplimit_ULCard(stULCardInfo);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_AMOUNT_EXCEED_MAX_AMOUNT;
		return pRetInfo->wErrCode;
	}

	//检查车票是否过期。
	bRet=Check_Ticket_Valid_ULCard(APIParam.ucTimeStamp,stULCardInfo);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_LOGICAL_PERIOD_TIMEOUT;
		return pRetInfo->wErrCode;
	}
	//出站次序检查。
	bRet=Check_Exit_Status_ULCard(stULCardInfo);
	if((!bRet)&&(!bHasFreeMode))
	{
		bHasFreeMode=Allow_Exit_InFreeEntryStationCode(APIParam.ucTimeStamp,g_BRContext.bCurrentStationID,szProcessStation);
		if(!bHasFreeMode)
		{
			pRetInfo->wErrCode=RW_EC_INVALID_TICKET;
			return pRetInfo->wErrCode;
		}
	}
	//非本站更新
	bRet=Check_Update_ThisStation_ULCard(stULCardInfo);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_SATION;
		return pRetInfo->wErrCode;
	}

//	//非本日更新
	bRet=Check_Update_ThisDay_ULCard( APIParam,stULCardInfo);
	if(!bRet)
	{
		pRetInfo->wErrCode=RW_EC_UPDATE_OTHER_DATE;
		return pRetInfo->wErrCode;
	}

	iRet=Get_Price_InDegrade(u8CardType,szProcessStation,u8EntryTime,APIParam.ucTimeStamp,
						&FareZone,&JourneyTimeLimit,&TimeoutsFines,&RidingTime,&TrainTicketTableID,&u32Price);

	PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
	PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice JourneyTimeLimit= [%d] u32Price[%d]",__FILE__,__LINE__,JourneyTimeLimit,u32Price);
	if(iRet!=CE_OK)
	{
		PrintLog("File[%s]Line[%d] Exit_ULCard  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
		pRetInfo->wErrCode=RW_EC_INVALID_INPUT_PARAM;
		return pRetInfo->wErrCode;
	}

	//出站超时
	bRet=Check_Exit_Timeout_ULCard(APIParam,JourneyTimeLimit,stULCardInfo);
	if(!bRet)
	{
		PrintLog("File[%s]Line[%d] Exit_ULCard  Check_Exit_Timeout_ULCard iRet= [%d]",__FILE__,__LINE__,bRet);
		pRetInfo->wErrCode=RW_EC_EXIT_TIMOUT_PAID_AREA;
		return pRetInfo->wErrCode;
	}
	//出站超程
	bRet=Check_Exit_RemainningValue_ULCard(&u32Price,stULCardInfo);
	if(!bRet)
	{
		PrintLog("File[%s]Line[%d] Exit_ULCard  Check_Exit_RemainningValue_ULCard iRet= [%d]",__FILE__,__LINE__,bRet);
		pRetInfo->wErrCode=RW_EC_EXIT_OUTRANGE_PAID_AREA;
		return pRetInfo->wErrCode;
	}

	if(g_BRContext.ucCurrentStationMode==EM_MODE_TRAIN_FAULT
	 &&stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus!=EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE)
	{
		//车票余额
		cardProcessInfo.ProcessInfo.CardValue=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;
		//车票状态
		cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE;//列车故障模式出站(

		cardProcessInfo.ProcessInfo.CardSpecialFlag=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardSpecialFlag;
	}
	else
	{
		//车票余额
		cardProcessInfo.ProcessInfo.CardValue=0;
		//车票状态
		cardProcessInfo.ProcessInfo.CardStatus=EM_TICKET_TRAVEL_STATUS_EXITED;//:已出站

		cardProcessInfo.ProcessInfo.CardSpecialFlag=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardSpecialFlag;
	}
	iRet=Inner_Write_ULCard(APIParam,cardProcessInfo);

	//组UD
	// 由支付方式代码（高位）和交易分类代码（低位）组成：
	stPurseInfo->cPaymentType[0]=0x01+'0';
	stPurseInfo->cPaymentType[1]=0x02+'0';
	// 交易状态
	if(g_BRContext.ucCurrentStationMode==EM_MODE_TRAIN_FAULT
		 &&stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus!=EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE)
	{
		stPurseInfo->bStatus=RW_LIFECODE_EXIT_TRAINFAULT;
		stPurseInfo->lTradeAmount=0;
		stPurseInfo->lBalance=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;
	}
	else if(stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus==EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE)
	{
		stPurseInfo->bStatus=RW_LIFECODE_ET_FOR_EXIT;
		stPurseInfo->lTradeAmount=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;
		stPurseInfo->lBalance=0;
	}else
	{
	   stPurseInfo->bStatus=RW_LIFECODE_EXIT_STAION;
	   stPurseInfo->lTradeAmount=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;
	   stPurseInfo->lBalance=0;
	}

	Fill_Exit_ULCard_UD(APIParam,stULCardInfo,stPurseInfo);

	//SAM生成的交易检查代码
	GetULCardUDTAC(stULCardInfo.SystemFlowID,stPurseInfo->lTradeAmount,stPurseInfo->lSAMTrSeqNo,stPurseInfo->dtDate,szTAC);

	sprintf(stPurseInfo->cMACorTAC,"%02X%02X%02X%02X",szTAC[0],szTAC[1],szTAC[2],szTAC[3]);

	if(CE_OK!=iRet)
	{
		memcpy(g_BRContext.stSpcTicketTranInfo.szTranUD,stPurseInfo,sizeof(stPurseInfo));
		pRetInfo->wErrCode=iRet;
		return iRet;
	}

	return CE_OK;
}



  //检查车票状态是否正确
 BOOL Check_Ticket_Status_ULCard(CARD_ACC_UL  stULCardInfo)
 {
	 BOOL bRet=FALSE;
	 uint8 u8CurrentCardStatus=0;
	 u8CurrentCardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;
	 PrintLog("File[%s]Line[%d] Check_Ticket_Status_ULCard  u8CurrentCardStatus= [%d]",__FILE__,__LINE__,u8CurrentCardStatus);
	 switch(u8CurrentCardStatus)
	 {
		 case EM_TICKET_TRAVEL_STATUS_INITIALIZATION:			//e/s 初始化(init 0)
		 case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES:		//e/s 初始化(init 1)
		 case EM_TICKET_TRAVEL_STATUS_ISSUED:					// SJT发售(init 2)
		 case EM_TICKET_TRAVEL_STATUS_ENTRY:					//已进站
		 case EM_TICKET_TRAVEL_STATUS_EXITED:					//已出站
		 case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:				//出站票
		 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:		//列车故障模式出站(exit during Train-disruption)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA:	//非付费区免费更新(BOM/pca 非付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA:	//非付费区付费更新(BOM/pca 非付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
		 case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
		 case EM_TICKET_TRAVEL_STATUS_REFUND:					//已退卡
			 bRet=TRUE;
			 break;
		 default:
			 bRet=FALSE;
			 break;

	 }
	 PrintLog("File[%s]Line[%d] Check_Ticket_Status_ULCard  bRet= [%d]",__FILE__,__LINE__,bRet);
	 return bRet;
 }

  //检查余额是否超出上限。
 BOOL Check_Ticket_Value_Uplimit_ULCard(CARD_ACC_UL  stULCardInfo)
 {
	 BOOL bRet=FALSE;
	 uint8 u8CurrentCardValue=0;
	 long u32UplimitValue=0;
     char szUpperLimit[10]={0};
     char temp[10]={0};
     //是否检查余额/余次	CHAR	1	0：不检查，1：检查
     temp[0]=g_BRContext.TicktPara0301.RemainCheck[0];
     if(!atoi(temp))
     {
    	 PrintLog("File[%s]Line[%d] Check_Ticket_Value_Uplimit_ULCard  g_BRContext.TicktPara0301.RemainCheck= [%d]",__FILE__,__LINE__,atoi(temp));
    	 return TRUE;
     }

	 u8CurrentCardValue=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;
	 PrintLog("File[%s]Line[%d] Check_Ticket_Value_Uplimit_ULCard  u8CurrentCardValue= [%d]",__FILE__,__LINE__,u8CurrentCardValue);
	 memcpy(szUpperLimit,g_BRContext.TicktPara0301.UpperLimit,6);

	 u32UplimitValue=atoi(szUpperLimit);
	 PrintLog("File[%s]Line[%d] Check_Ticket_Value_Uplimit_ULCard  u32UplimitValue= [%d]",__FILE__,__LINE__,u32UplimitValue);



	 if(u8CurrentCardValue>u32UplimitValue)
	 {
		 bRet=FALSE;
	 }else
	 {
		 bRet=TRUE;
	 }
	 PrintLog("File[%s]Line[%d] Check_Ticket_Value_Uplimit_ULCard  bRet= [%d]",__FILE__,__LINE__,bRet);
	 return bRet;
 }

  //检查车票是否过期。
 BOOL Check_Ticket_Valid_ULCard(uint8 * u8BCDCurrentDate,CARD_ACC_UL  stULCardInfo)
 {
	char temp[20]={0};
	unsigned char szEndDate[7]={0};

	memset(temp,0,sizeof(temp));


	if(g_BRContext.ucCurrentStationMode==EM_MODE_FREE_DATE)
	{
		PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard ucCurrentStationMode==EM_MODE_FREE_DATE",__FILE__,__LINE__);
		return TRUE;
	}


     ////逻辑及物理有效期检查	CHAR	1	0：不检查逻辑及物理有效期；1：检查逻辑及物理有效期；2：检查逻辑但不检查物理有效期；3：不检查逻辑期但检查物理有效期
     temp[0]=g_BRContext.TicktPara0301.PhysicsCheck[0];
     if(!atoi(temp))
     {
    	 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  g_BRContext.TicktPara0301.PhysicsCheck= [%d]",__FILE__,__LINE__,atoi(temp));
    	 return TRUE;
     }

     //进站时间>出站时间
     if(memcmp(u8BCDCurrentDate,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7)<0)
     {
    	 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  u8BCDCurrentDate<ProcessTime",__FILE__,__LINE__);
    	 return FALSE;
     }
	memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
	int tempValidityMin=atoi(temp);
	PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  tempValidityMin= [%d]",__FILE__,__LINE__,tempValidityMin);

	BCDTimeAddSeconds(tempValidityMin*60,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,szEndDate);
	PrintLog("File[%s]Line[%d]Check_Ticket_Valid_ULCard bEndDate",__FILE__,__LINE__);
	PrintBuffer((const char *)szEndDate,7);

	 if(memcmp(u8BCDCurrentDate,szEndDate,7)>0||memcmp(u8BCDCurrentDate,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7)<0)
	 {
		 PrintLog("File[%s]Line[%d]Check_Ticket_Valid_ULCard u8BCDCurrentDate> bEndDate",__FILE__,__LINE__);
		 return FALSE;
	 }
	 return TRUE;
 }

 //检查车票是否过期。
BOOL Check_PaidArea_Ticket_Valid_ULCard(uint8 * u8BCDCurrentDate,uint16 paidAreaValidTimes,CARD_ACC_UL  stULCardInfo)
{
	char temp[20]={0};
	unsigned char szEndDate[7]={0};

	memset(temp,0,sizeof(temp));
    ////逻辑及物理有效期检查	CHAR	1	0：不检查逻辑及物理有效期；1：检查逻辑及物理有效期；2：检查逻辑但不检查物理有效期；3：不检查逻辑期但检查物理有效期
    temp[0]=g_BRContext.TicktPara0301.PhysicsCheck[0];
    if(!atoi(temp))
    {
   	 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  g_BRContext.TicktPara0301.PhysicsCheck= [%d]",__FILE__,__LINE__,atoi(temp));
   	 return TRUE;
    }

    if(memcmp(u8BCDCurrentDate,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7)<0)
    {
   	 PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  u8BCDCurrentDate<ProcessTime",__FILE__,__LINE__);
   	 return FALSE;
    }


//	memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
//	int tempValidityMin=atoi(temp);
//	PrintLog("File[%s]Line[%d] Check_Ticket_Valid_ULCard  tempValidityMin= [%d]",__FILE__,__LINE__,tempValidityMin);

	BCDTimeAddSeconds(paidAreaValidTimes*60,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,szEndDate);
	PrintLog("File[%s]Line[%d]Check_Ticket_Valid_ULCard bEndDate",__FILE__,__LINE__);
	PrintBuffer((const char *)szEndDate,7);

	 if(memcmp(u8BCDCurrentDate,szEndDate,7)>0)
	 {
		 PrintLog("File[%s]Line[%d]Check_PaidArea_Ticket_Valid_ULCard u8BCDCurrentDate> bEndDate",__FILE__,__LINE__);
		 return FALSE;
	 }
	 return TRUE;
}



 //检查是否本站进站。
  BOOL Check_EntryThisStation_ULCard(CARD_ACC_UL  stULCardInfo)
  {
	 BOOL bRet=FALSE;
	 uint8 u8CardStatus=0;

	 uint8 szSaleStation[2]={0};
	 int  tempValue=0;
	 char temp[10]={0};
	 //本站发售控制标记	CHAR	1	0：表示只有在本在购买的单程票才能进站1：表示从其它车站购买的单程票，可以在本站进入
     temp[0]=g_BRContext.TicktPara0301.SailStationCheck[0];
     tempValue=atoi(temp);
     if(tempValue==1)
     {
    	 PrintLog("File[%s]Line[%d] Check_EntryThisStation_ULCard  g_BRContext.TicktPara0301.SailStationCheck= [%d]",__FILE__,__LINE__,tempValue);
    	 return TRUE;
     }

     u8CardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;
     if(u8CardStatus==EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES)
     {
    	 PrintLog("File[%s]Line[%d] Check_EntryThisStation_ULCard  EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES u8CardStatus= [%d]",__FILE__,__LINE__,u8CardStatus);
    	 return TRUE;
     }

	 szSaleStation[0]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessLine;
	 szSaleStation[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessStation;
	 PrintLog("File[%s]Line[%d] Check_EntryThisStation_ULCard szSaleStation=[%02d%02d]",__FILE__,__LINE__,szSaleStation[0],szSaleStation[1]);
	 if(memcmp(szSaleStation,(char*)g_BRContext.bCurrentStationID,2)==0)
	 {
		 bRet=TRUE;
	 }else
	 {
		 bRet=Check_IsTranStaton(szSaleStation,g_BRContext.bCurrentStationID);
		 PrintLog("File[%s]Line[%d] Check_IsTranStaton_ULCard bRet=[%d]",__FILE__,__LINE__,bRet);
	 }

	 return bRet;
  }



    //检查进站超时。
  BOOL Check_Entry_Timeout_ULCard(CARD_ACC_UL  stULCardInfo)
  {
	  	 //未实现
	 return TRUE;
  }

    //进站次序检查。
  BOOL Check_Entry_Status_ULCard(CARD_ACC_UL  stULCardInfo)
  {
	 BOOL bRet=FALSE;
	 uint8 u8CurrentCardStatus=0;
	 int  tempValue=0;
	 char temp[10]={0};
     ////进出站次序检查	CHAR	1	0：进出站均不检查进出站次序1：进出站均检查进出站次序2：进站不检查进出站次序，出站检查进出站次序3：进站检查进出站次序，出站不检查进出站次序
     temp[0]=g_BRContext.TicktPara0301.InOutOrderCheck[0];
     tempValue=atoi(temp);
     if(tempValue==0||tempValue==2)
     {
    	 PrintLog("File[%s]Line[%d] Check_Entry_Status_ULCard  g_BRContext.TicktPara0301.InOutOrderCheck= [%d]",__FILE__,__LINE__,tempValue);
    	 return TRUE;
     }
	 u8CurrentCardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;



	 switch(u8CurrentCardStatus)
	 {
		 case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES:		//e/s 初始化(init 1)
		 case EM_TICKET_TRAVEL_STATUS_ISSUED:					// SJT发售(init 2)
		 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:		//列车故障模式出站(exit during Train-disruption)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA:	//非付费区免费更新(BOM/pca 非付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA:	//非付费区付费更新(BOM/pca 非付费区)
			 bRet=TRUE;
			 break;
		 default:
			 bRet=FALSE;
			 break;

	 }

	 return bRet;
  }

    //余额低于最小票价。
  BOOL Check_MinValue_ULCard(StruAPIParam APIParam,CARD_ACC_UL  stULCardInfo)
  {
	  int iRet=-1;
	  uint8 cardType[2]={0};
	  uint32 u32MinPrice=0;

	  uint32 iCardValue=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;

	  cardType[0]=stULCardInfo.MainType;
	  cardType[1]=stULCardInfo.SubType;
	  iRet=BR_GetMinPrice(cardType,g_BRContext.bCurrentStationID,APIParam.ucTimeStamp,&u32MinPrice);
	  if(iRet!=0)
	   {
		   PrintLog("File[%s]Line[%d]  BR_GetMinPrice Failed[%d]",__FILE__,__LINE__,u32MinPrice);
		   return FALSE;
	   }

	   PrintLog("File[%s]Line[%d]  Check_MinValue_ULCard u32MinPrice[%d]",__FILE__,__LINE__,u32MinPrice);

	   if(iCardValue<u32MinPrice)
	   {
		   return FALSE;
	   }

	   return TRUE;
  }

    //出站次序检查。
  BOOL Check_Exit_Status_ULCard(CARD_ACC_UL  stULCardInfo)
  {
	  BOOL bRet=FALSE;
	 uint8 u8CurrentCardStatus=0;
	 int  tempValue=0;
	 char temp[10]={0};
     ////进出站次序检查	CHAR	1	0：进出站均不检查进出站次序1：进出站均检查进出站次序2：进站不检查进出站次序，出站检查进出站次序3：进站检查进出站次序，出站不检查进出站次序
     temp[0]=g_BRContext.TicktPara0301.InOutOrderCheck[0];
     tempValue=atoi(temp);
     if(tempValue==0||tempValue==3)
     {
    	 PrintLog("File[%s]Line[%d] Check_Exit_Status_ULCard  g_BRContext.TicktPara0301.InOutOrderCheck= [%d]",__FILE__,__LINE__,tempValue);
    	 return TRUE;
     }
	 u8CurrentCardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;

	 switch(u8CurrentCardStatus)
	 {

		 case EM_TICKET_TRAVEL_STATUS_ENTRY:					//已进站
		 case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:				//出站票
		 case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:		//列车故障模式出站(exit during Train-disruption)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
		 case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
			 bRet=TRUE;
			 break;
		 default:
			 break;

	 }

	 return bRet;
  }

  //非本站更新？
  BOOL Check_Update_ThisStation_ULCard(CARD_ACC_UL  stULCardInfo)
  {
	 BOOL bRet=FALSE;
	 uint8 u8CurrentCardStatus=0;
	 uint8 szUpdateStation[2]={0};

	 int  tempValue=0;
	 char temp[10]={0};
	 ////付费区非本站更新检查标志	CHAR	1	0：不检查，1：检查
	 temp[0]=g_BRContext.TicktPara0301.PaintPlaceCheck1[0];
	 tempValue=atoi(temp);
	 if(tempValue==0)
	 {
		 PrintLog("File[%s]Line[%d] Check_Update_ThisStation_ULCard  g_BRContext.TicktPara0301.PaintPlaceCheck1= [%d]",__FILE__,__LINE__,tempValue);
		 return TRUE;
	 }

	 u8CurrentCardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;

	 szUpdateStation[0]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessLine;
	 szUpdateStation[1]=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.ProcessStation;
	 


	 switch(u8CurrentCardStatus)
	 {
		 //case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
		 case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
		 case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
		 case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:
			 {
				if(memcmp(szUpdateStation,(char*)g_BRContext.bCurrentStationID,2)==0)
				 {
					 bRet=TRUE;
				 }else
				{
					 bRet=Check_IsTranStaton(szUpdateStation,g_BRContext.bCurrentStationID);
					 PrintLog("File[%s]Line[%d] Check_IsTranStaton_ULCard bRet=[%d]",__FILE__,__LINE__,bRet);
				 }
			 }
			 break;
		 default:
			 bRet=TRUE;
			 break;

	 }

	 return bRet;
  }

    //非本日更新
BOOL Check_Update_ThisDay_ULCard(StruAPIParam APIParam,CARD_ACC_UL  stULCardInfo)
{
	 BOOL bRet=FALSE;
	 uint8 u8CurrentCardStatus=0;
	 int  tempValue=0;
	 char temp[10]={0};

	 unsigned char szEndTime[7]={0};
	 ////付费区非本日更新检查标志	CHAR	1	0：不检查，1：检查
	 temp[0]=g_BRContext.TicktPara0301.PaintPlaceCheck2[0];
	 tempValue=atoi(temp);
	 if(tempValue==0)
	 {
		 PrintLog("File[%s]Line[%d] Check_Update_ThisDay_ULCard  g_BRContext.TicktPara0301.PaintPlaceCheck2= [%d]",__FILE__,__LINE__,tempValue);
		 return TRUE;
	 }

	u8CurrentCardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;

	switch(u8CurrentCardStatus)
	{
		case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:	//无进站码更新(BOM/pca 付费区)
		case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:				//出站码更新
		case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:			//超时更新
		case EM_TICKET_TRAVEL_STATUS_RANGEOUT:					//超时及超乖更新
		case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:			//免费出闸更新
			{
			  //if(memcmp(APIParam.ucTimeStamp,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,4)==0)
				int tempValidityMin=0;
				memset(temp,0,sizeof(temp));
				memcpy(temp,g_BRContext.TicktPara0301.ValidityMin,16);
				tempValidityMin=atoi(temp);
			    PrintLog("File[%s]Line[%d] Check_Update_ThisDay_ULCard  tempValidityMin= [%d]",__FILE__,__LINE__,tempValidityMin);

				BCDTimeAddSeconds(tempValidityMin*60,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,szEndTime);
				if(memcmp(APIParam.ucTimeStamp,szEndTime,7)<=0&&memcmp(APIParam.ucTimeStamp,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7)>=0)
			  {
				bRet=TRUE;
			  }
			}
			break;
		default:
			bRet=TRUE;
			break;

	}

	return bRet;
}
  //出站超时
BOOL Check_Exit_Timeout_ULCard(StruAPIParam APIParam,uint16 u16JourneyTimeLimit,CARD_ACC_UL  stULCardInfo)
{
	 BOOL bRet=TRUE;

	 uint8 szEntryTime[7]={0};
	 uint8 szStayTime[8]={0};
	 int  tempValue=0;
	 char temp[10]={0};
	 unsigned char usCardStatus=0;

	if(g_BRContext.ucCurrentStationMode==EM_MODE_FREE_DATE)
	{
		PrintLog("File[%s]Line[%d] Check_Exit_Timeout_ULCard ucCurrentStationMode==EM_MODE_FREE_DATE",__FILE__,__LINE__);
		return TRUE;
	}

	 //是否检查超时	CHAR	1	0：不检查，1：检查
     temp[0]=g_BRContext.TicktPara0301.OverTimeCheck[0];
     tempValue=atoi(temp);
     if(tempValue==0)
     {
    	 PrintLog("File[%s]Line[%d] Check_Exit_Timeout_ULCard  g_BRContext.TicktPara0301.OverTimeCheck= [%d]",__FILE__,__LINE__,tempValue);
    	 return TRUE;
     }

     usCardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;

     if(usCardStatus==EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE)
     {
    	 PrintLog("File[%s]Line[%d] Check_Exit_Timeout_ULCard  EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE",__FILE__,__LINE__);
    	  return TRUE;
     }


	 memcpy(szEntryTime,stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessTime,7);
	 PrintLog("File[%s]Line[%d] Check_Exit_Timeout_ULCard  szEntryTime",__FILE__,__LINE__);
	 PrintBuffer(szEntryTime,7);
	 BCDTimeAddSeconds(u16JourneyTimeLimit*60,szEntryTime,szStayTime);
	 PrintLog("File[%s]Line[%d] Check_Exit_Timeout_ULCard  szStayTime",__FILE__,__LINE__);
	 PrintBuffer(szStayTime,7);

	if(memcmp(APIParam.ucTimeStamp,szStayTime,7)>0)
	{
		PrintLog("File[%s]Line[%d] Check_Exit_Timeout_ULCard  超时",__FILE__,__LINE__);
	    bRet=FALSE;
	}
	 return bRet;
}

  //出站超程
BOOL Check_Exit_RemainningValue_ULCard(uint32 *u32Price,CARD_ACC_UL  stULCardInfo)
{
	 BOOL bRet=FALSE;
	 long lCardValue=0;
	 unsigned char usCardStatus=0;
	 int  tempValue=0;
	 char temp[10]={0};


	 //是否检查超乘	CHAR	1	0：不检查，1：检查
     temp[0]=g_BRContext.TicktPara0301.OverTaken[0];
     tempValue=atoi(temp);
     if(tempValue==0)
     {
    	 PrintLog("File[%s]Line[%d] Check_Exit_RemainningValue_ULCard  g_BRContext.TicktPara0301.OverTaken= [%d]",__FILE__,__LINE__,tempValue);
    	 return TRUE;
     }



     usCardStatus=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardStatus;

     if(usCardStatus==EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE||usCardStatus==EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION)
     {
    	 PrintLog("File[%s]Line[%d] Check_Exit_RemainningValue_ULCard  EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE or EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION"
    			 ,__FILE__,__LINE__);
    	 *u32Price=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;
    	 return TRUE;
     }

 	 if(usCardStatus==EM_TICKET_TRAVEL_STATUS_RANGEOUT)
 	 {
 		PrintLog("File[%s]Line[%d] Check_Exit_RemainningValue_ULCard  EM_TICKET_TRAVEL_STATUS_RANGEOUT",__FILE__,__LINE__);
 		return TRUE;
 	 }


	 lCardValue=stULCardInfo.cardProcessInfo[stULCardInfo.StatusPointer].ProcessInfo.CardValue;
	if(lCardValue>=(*u32Price))
	{
	   bRet=TRUE;
	}

	 return bRet;
}


//int Get_Price_InDegrade(uint8 *u8CardType,uint8 *u8InGateStation,uint8* u8BCDInGateTime,uint8* u8BCDOutGateTime,
//		uint16* FareZone,uint16*JourneyTimeLimit,uint16*TimeoutsFines,uint8 *RidingTime,uint8 *TrainTicketTableID,uint32* Fare)
//{
//	int iRet=-1;
//
//	if(g_BRContext.ucCurrentStationMode==EM_MODE_FREE_FARE)
//	{
//		iRet=BR_CalcPrice(u8CardType,g_BRContext.bCurrentStationID,g_BRContext.bCurrentStationID,u8BCDInGateTime,u8BCDOutGateTime,
//							FareZone,JourneyTimeLimit,TimeoutsFines,RidingTime,TrainTicketTableID,Fare);
//	}else
//	{
//
//	    iRet=BR_CalcPrice(u8CardType,u8InGateStation,g_BRContext.bCurrentStationID,u8BCDInGateTime,u8BCDOutGateTime,
//					FareZone,JourneyTimeLimit,TimeoutsFines,RidingTime,TrainTicketTableID,Fare);
//	}
//	PrintLog("File[%s]Line[%d] Get_Price_InDegrade  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
//	PrintLog("File[%s]Line[%d] Get_Price_InDegrade  BR_CalcPrice JourneyTimeLimit= [%d] u32Price[%d]",__FILE__,__LINE__,*JourneyTimeLimit,*Fare);
//	if(iRet!=CE_OK)
//	{
//		PrintLog("File[%s]Line[%d] Get_Price_InDegrade  BR_CalcPrice iRet= [%d]",__FILE__,__LINE__,iRet);
//		return RW_EC_INVALID_INPUT_PARAM;
//	}
//
//	return CE_OK;
//}


int Confirm_ULCard(StruAPIParam APIParam,RetInfo * pRetInfo,unsigned char szUD,unsigned short *usUDLen)
{




 return 0;
}

int ConvertULCardStatus(unsigned char ucTicketStatus)
{
	/*EM_TICKET_TRAVEL_STATUS_INITIALIZATION			=1,	//e/s 初始化(init 0)
	EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES		=2,	//e/s 预赋值(init 1)
	EM_TICKET_TRAVEL_STATUS_ISSUED					=3,	// SJT发售(init 2)
	EM_TICKET_TRAVEL_STATUS_ENTRY					=4,	//已进站
	EM_TICKET_TRAVEL_STATUS_EXITED					=5,	//已出站
	EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE				=6,	//出站票
	EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE		=7,	//列车故障模式出站(exit during Train-disruption)
	EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA	=8,	//非付费区免费更新(BOM/pca 非付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA	=9,	//非付费区付费更新(BOM/pca 非付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION	=10,//无进站码更新(BOM/pca 付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT				=11,//出站码更新
	EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT			=12,//超时更新
	EM_TICKET_TRAVEL_STATUS_RANGEOUT				=13,//超乖更新
	EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT		=14,//免费出闸更新
	EM_TICKET_TRAVEL_STATUS_REFUND					=15,//已退卡*/
	unsigned char ucStatus=RW_STATUSCODE_UNKNOWN;
    switch(ucTicketStatus)
    {
        case EM_TICKET_TRAVEL_STATUS_INITIALIZATION:
        	ucStatus=RW_STATUSCODE_INITIALIZATION;
    	 break;
        case EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES:
               	ucStatus=RW_STATUSCODE_PREVALUE_LOADED_ES;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_ISSUED:
               	ucStatus=RW_STATUSCODE_SALE_BOM_OR_TVM;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_ENTRY:
               	ucStatus=RW_STATUSCODE_ENTRY_STATION;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_EXITED:
               	ucStatus=RW_STATUSCODE_EXIT_STAION;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE:
               	ucStatus=RW_STATUSCODE_ET_FOR_EXIT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE:
               	ucStatus=RW_STATUSCODE_EXIT_TRAINFAULT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA:
               	ucStatus=RW_STATUSCODE_UPDATE_FREE_UNPAYAREA;
           	 break;

        case EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA:
               	ucStatus=RW_STATUSCODE_UPDATE_PAYED_UNPAYAREA;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION:
               	ucStatus=RW_STATUSCODE_UPDATE_NO_ENTRY_STATION;
           	 break;

        case EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT:
               	ucStatus=RW_STATUSCODE_UPDATE_EXIT_ATBOM;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT:
               	ucStatus=RW_STATUSCODE_UPDATE_TIMEOUT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_RANGEOUT:
               	ucStatus=RW_STATUSCODE_UPDATE_RANGEOUT;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT:
               	ucStatus=RW_STATUSCODE_UPDATE_ENTRY_ATBOM;
           	 break;
        case EM_TICKET_TRAVEL_STATUS_REFUND:
               	ucStatus=RW_STATUSCODE_REBACK_CARD;
           	 break;
    }

    return ucStatus;
}
