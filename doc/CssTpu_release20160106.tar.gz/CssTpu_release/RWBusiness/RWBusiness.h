/*********************************************************
*程序名称:		readprocessmg.h
*版本号:		0.1			
*功能描述:		 <<长沙轨道交通1号线读卡器接口调用API文档.docx>>文档中,
				所有的与上位机的接口处理函数都定义在本文件中,函数名称与文档中的名称一致.
*作者:			王洪峰			
*修改记录:		
				2015.01.13 创建 
*其他:						
***********************************************************/

#ifndef __RWBUSINESS_H__
#define __RWBUSINESS_H__

#include "ULCardBusiness.h"
#include "AccCpuCardBusiness.h"
#include "YktM1CardBusiness.h"
#include "YktCpuCardBusiness.h"
#include "../TicketEntity/PollingCardEntity.h"
#include "../DataTypeDefine.h"

//定义对齐方式





//读写器打开串口
//int Common_OpenCommPort(int iPort);

//读写器打开串口
//int Common_CloseCommPort(int iPort);

/*3.1.1	设备环境初始化
	函数原型:
		RetInfo Common_Initialize_Device (int nPort, StruAPIParam APIParam,BYTE bStationID[2], BYTE bDeviceType, BYTE wDeviceID[2] ,WORD * pLen1, unsigned char * pMsg1, ,WORD * pLen2, unsigned char * pMsg2);
	功能：
	根据接口传入的参数，加载设备所需参数，申请内部资源。设备要调用读写器处理票卡前必须先执行此调用。
	设备在初始化之前应先调用'Config_Parameter'配置好设备必须的参数，各种设备必须的参数详情参见附录五。
	输入参数：
	nPort - 设备通信端口编号
	APIParam -API函数公共参数
	bStationID[2] -线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
	bDeviceType - 设备类型，十进制表示。1字节BCD编码
	bDeviceID[2] -当前设备编码，"\x09\x87"表示设备号为987的设备

	输出参数：
		pLen1: 检测到的SAM卡个数(当前字段值为8)
		pMsg1:	pSAMCount个SAM卡中每个SAM卡槽的状态, 0为可用.
		pLen2: 预留信息的数据长度(目前默认为0)
		pMsg2:	预留信息的内容.(目前没有预留信息)

	返回值: 
		函数返回值结构体中错误码:
		0 - 成功，输出参数可用；
		非0值 -具体见附录"API返回值代码对照表"，输出参数无效
	注：
		本接口只在设备启动时成功调用一次即可，如果调用不成功，应根据返回码，配合参数据下载接口调用。
*/
int Common_Initialize_Device(		//设备通信端口编号
											  StruAPIParam APIParam,//函数公共参数
											  RetInfo * pRi,
											  BYTE bStationID[2],	//线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
											  BYTE bDeviceType,		//设备类型，十进制表示。1字节BCD编码
											  BYTE bDeviceID[2],	//当前设备编码，"\x09\x87"表示设备号为987的设备
											  WORD * pLen1,			//检测到的SAM卡个数(当前字段值为8)
											  unsigned char * pMsg1,//pSAMCount个SAM卡中每个SAM卡槽的状态, 0为可用
											  WORD * pLen2,			//预留信息的数据长度(目前默认为0)
											  unsigned char * pMsg2);//预留信息的内容.(目前没有预留信息)



/*3.1.2	获取版本信息
函数原型:
RetInfo Common_GetVersion (int iPort, StruAPIParam APIParam, WORD * pLen1, unsigned char * pMsg1, ,WORD * pLen2, unsigned char * pMsg2);
功能：	
读取读写器对应的版本信息。
输入参数：
iPort - 设备通信端口编号
APIParam -API函数公共参数

输出参数：
pLen1: 有效时为sizeof(READERVERSION)
pMsg1: 设备版本信息(参见READERVERSION结构体)
pLen2: 预留信息的数据长度(目前默认为0)
pMsg2:	预留信息的内容.(目前没有预留信息)

 返回值: 
 函数返回值结构体中错误码:
 0 - 成功，输出参数可用；
 非0值 -具体见附录"API返回值代码对照表"，输出参数无效COMMON_GETVERSION
*/
int Common_GetVersion (StruAPIParam APIParam, RetInfo * pRi,WORD * pLen1, unsigned char * pMsg1 ,WORD * pLen2, unsigned char * pMsg2);

 

/*3.1.3	获取SAM卡信息
功能：
读取读写器对应类型的SAM卡相关信息。
输入参数：
nPort - 设备通信端口编号
APIParam -API函数公共参数

  输出参数：
  ri	: 函数返回值结构体中错误信息
  pLen1: 有效时长度即N1＝8*sizeof(SAMSTATUS)
  pMsg1: SAM卡状态信息PSAMSTATUS
  pLen2: 预留信息的数据长度(目前默认为0)
  pMsg2:	预留信息的内容.(目前没有预留信息)
  
	返回值: 
	函数返回值结构体中错误码:
	0 - 成功，输出参数可用；
	非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Common_GetSamInfo (StruAPIParam APIParam, RetInfo * pRi,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);


/*3.1.4	设备降级模式
功能：
当SLE接收到SC下发的降级模式通知或降级模式控制命令后，SLE将通知或控制命令的内容填入结构pDegradeCmd后调用本接口，本接口被调用后，API不对pDegradeCmd信息做永久记录，API从内存释放后pDegradeCmd信息丢失，API被再次载入内存时，上次载入时的pDegradeCmd信息被忽略，除非ECU再次调用本接口。
ECU应永久记录pDegradeCmd相关信息直至该信息失效（当前时间超出该降级消息的敏感期），并在每次调用完初始化接口后调用本接口。
当有新的降级模式参数后，API将以降级模式参数为准，忽略之前所有调用本接口所产生的降级。
输入参数：
iPort - 设备通信端口编号
APIParam -API函数公共参数
PDegradeCMD 降级模式结构体,参见(2.1.5降级模式命令结构体)
输出参数：
ri	: 函数返回值结构体中错误信息
pLen1: 预留信息的数据长度(目前默认为0)
pMsg1: 预留信息的内,容.(目前没有预留信息)
pLen2: 预留信息的数据长度(目前默认为0)
pMsg2:	预留信息的内容.(目前没有预留信息)

		
		  返回值: 
		  函数返回值结构体中错误码:
		  0 - 成功，输出参数可用；
		  非0值 -具体见附录"API返回值代码对照表"，输出参数无效COMMON_SETDEGRADEMODE
*/
int Common_SetDegradeMode(StruAPIParam APIParam, DEGRADECMD DegradeCMD, RetInfo * pRi, WORD * pLen1, unsigned char * pMsg1,WORD * pLen2, unsigned char * pMsg2);


/*3.1.5	获取到本站的票价
函数原型:
功能：
获取当前时间其它站到本站的票价，做付费区无进站码更新时可能需要额外补款，可以通过本接口配合。

  输入参数：
  nPort - 设备通信端口编号
  APIParam -API函数公共参数
  bTicketType - 2字节BCD编码
  bStationID - 2字节车站ID,BCD编码如"\x03\x01"，表示3号线第1个站点
  输出参数：
  ri	: 函数返回值结构体中错误信息
  pLen1: 票价数据长度(目前默认为4,因为信息内容为long)
  pMsg1: long数据内容,单位是票价(分为单位)
  pLen2: 预留信息的数据长度(目前默认为0)
  pMsg2:	预留信息的内容.(目前没有预留信息)
		
		  返回值: 
		  函数返回值结构体中错误码:
		  0 - 成功，输出参数可用；
		  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Comm_GetFare(StruAPIParam APIParam, BYTE bTicketType[2], BYTE bStationID[2], RetInfo * pRi, WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);




/*3.1.6	获取参数信息
函数原型:
功能：
读取指定参数类型对应的参数文件名称

  输入参数：
  nPort - 设备通信端口编号
  APIParam -API函数公共参数
  wParamType- 2字节HEX,参数类型如票价表，当前字段值为0x0400
  
	输出参数：
	pRi	: 函数返回值结构体中错误信息
	pLen1: 参数文件字节数
	pMsg1: 参数文件名称内容
	pLen2: 预留信息的数据长度(目前默认为0)
	pMsg2:	预留信息的内容.(目前没有预留信息)
	
	  返回值: 
	  函数返回值结构体中错误码:
	  0 - 成功，输出参数可用；
	  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Comm_GetParamInfo (StruAPIParam APIParam,WORD wParamType, RetInfo * pRi,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);



/*3.1.7	获取单个寄存器值
功能：
读取当前设备固定地址的寄存器值

  输入参数：
  nPort - 设备通信端口编号
  APIParam -API函数公共参数
  wRegID- 2字节HEX, 寄存器地址
  
	输出参数：
	ri	: 函数返回值结构体中错误信息
	pLen1: 寄存器值长度,目前固定为4
	pMsg1: 寄存器值(4字节HEX)
	pLen2: 预留信息的数据长度(目前默认为0)
	pMsg2:	预留信息的内容.(目前没有预留信息)
	
	  返回值: 
	  函数返回值结构体中错误码:
	  0 - 成功，输出参数可用；
	  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Get_Reg_Value (StruAPIParam APIParam ,WORD wRegID, RetInfo * pRi, WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);



/*3.1.8	获取所有寄存器值
功能：
读取当前设备固定地址的寄存器值

  输入参数：
  nPort - 设备通信端口编号
  APIParam -API函数公共参数
  
	输出参数：
	ri	: 函数返回值结构体中错误信息
	pLen1: 固定为4的倍数(即寄存器个数*4)
	pMsg1: 寄存器值数组内容
	pLen2: 预留信息的数据长度(目前默认为0)
	pMsg2:	预留信息的内容.(目前没有预留信息)
	
	  返回值: 
	  函数返回值结构体中错误码:
	  0 - 成功，输出参数可用；
	  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Get_Reg_Info(StruAPIParam APIParam, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);



/*3.2.1	通道类型设置
功能：
设定读写器当前所属通道类型，此函数只适用于闸机，闸机车票处理流程中读写器根据此通道类型去处理对应类型的车票。
ECU应用软件调用完读写器初始化接口后紧接着调用此接口函数，如不调用此接口函数，在入/出闸处理中做为正常通道处理。

  输入参数：
  nPort - 设备通信端口编号
  APIParam -API函数公共参数
  AisleType - 	1：普通通道（不接受优惠票）
  2：专用通道（只接受优惠票）
  3：正常通道（接受所有票票种）
  输出参数：
  pLen1: 预留信息的数据长度(实际值为0)
  pMsg1: 预留信息的内容(目前没有预留信息)
  pLen2: 预留信息的数据长度(目前默认为0)
  pMsg2:	预留信息的内容.(目前没有预留信息)
		
		  返回值: 
		  函数返回值结构体中错误码:
		  0 - 成功，输出参数可用；
		  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Gate_AisleModel (StruAPIParam APIParam, BYTE AisleType, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int SetOperaterInfo (StruAPIParam APIParam, char * Id,uint8 u8ClassID, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);


/*5.7.1.1.	参数下载
参数下载开始前调用。*/
int StartToDownloadParameter(StruAPIParam APIParam, ST_Parameter_Info pstParameterInfo, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

/*5.7.1.1.	生效通知
参数下载完成后调用。*/
int EffectParameter(StruAPIParam APIParam, ST_Parameter_Info pstParameterInfo, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

//将参数文件分包下发到读写器，每次下发最大数据内容为4Kbyte。
int DownloadParameter(StruAPIParam APIParam, uint32 u32BufferLength,uint32 u32RemainnigLength,char * buffer, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);
/*3.2.2	入闸处理
功能：
在入口闸机中调用此接口，ECU调用票卡轮询接口返回0后，调用本接口，成功进行交易后返回进闸交易数据，否则返回操作错误状态码。
输入参数：
nPort - 设备通信端口编号
APIParam -API函数公共参数
输出参数：
pLen1: 入闸信息有效时长度为sizeof(ENTRYGATE)
pMsg1: PENTRYGATE结构体
pLen2: 锁卡信息有效时长度为sizeof(TICKETLOCK)
pMsg2:	PTICKETLOCK

  返回值: 
  函数返回值结构体中错误码:
  0 - 成功，输出参数可用；
  非0值 -具体见附录"API返回值代码对照表"，输出参数无效
*/
int Gate_EntryFlow (StruAPIParam APIParam, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);



/*2.1.3.3	出闸处理
函数原型：
Int Gate_ExitFlow(int nPort, int nAntMode, WORD wWorkMode, long* pCurTripCount, struct _PurseTrade*, struct TicketLock *)
功能：
在出口闸机中调用此接口，每发起一次调用，读写器就进行一次票卡轮循，如发现票卡则进入出闸处理流程，成功进行交易后返回出闸交易数据，否则返回操作错误状态码。
输入参数：
nPort 		- 设备通信端口编号，与初始化时的端口号相同
nAntMode 		- 天线工作模式
01-指定主天线感应区处理（单程票在感应区时返回错误代码）
02-指定副天线感应区处理单程票
wWorkMode - 运营模式（降级模式）
正常工作模式时此值为0，否则按从低到高位置位对应以下降级模式，允许模式组合（详细说明见DegradeMode_Operation）。
?	bit0:列车故障模式
?	bit1:进出站次序免检模式
?	bit2:乘车时间免检模式
?	bit3:车票日期免检模式
?	bit4:车费免检模式
?	bit5:紧急放行模式
输出参数：
	pCurTripCount	对于羊城通月票有效，其他票种无效，返回当月可用乘次。
正常出闸钱包交易记录
struct _PurseTrade数据结构定义详见"入闸处理"说明；
API返回值=1042时struct Ticketlock结构有效。数据结构定义详见"入闸处理"的Ticketlock定义。
返回值: 
0 - 对票卡处理成功，输出参数struct _EntryGate有效；
1042－本设备锁定黑名单卡，输出参数struct TicketLock有效；
21－ 已被锁定黑名单卡，输出参数无效；
1090 - 天线感应区无卡，输出参数无效，闸机上面板不做任何反应，如回收口中感应有票进入，提示该错误代码；
1091 - 在天线感应区有多张票卡，输出参数无效；
51 - 车票不适用普通通道，请去专用通道；
52 - 车票不适用专用通道，请去普通通道；

其它非0值 - 具体见附录"API返回值代码对照表"
*/
 int Gate_ExitFlow(StruAPIParam APIParam, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);


/*2.1.4	自动售票机(TVM)接口
2.1.4.1	SJT发售
函数原型：
int int Tvm_SjtSale(StruAPIParam APIParam,uint16 u16TranValue,uint8 u8PaymentType, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);
功能：
TVM对单程票进行发售时，上层应用程序勿需关心是何种Token票卡，API接口能自动识别系统内发行的Token并作发售处理。当感应到有票卡时执行发售单程票流程操作，成功后返回交易数据，否则返回API错误代码。
输入参数：
nPort 		- 设备通信端口编号，与初始化时的端口号相同
nAntMode 		- 天线工作模式
01-指定主天线感应区进行处理
02-指定副天线感应区进行处理
lValue		- 发售金额,单位为分
nPaymentMeans - 支付方式
(1-现金、2-储值卡，3-羊城通,4-Credit,5- civil charge)
输出参数：
struct SJTSaleRecord 结构体及各字段类型定义如下（具体说明见公共接口规范9.1.1.1）：
struct _SJTSaleRecord {
	char		cTradeType[2];			// 交易类型
	BYTE		bStationID[2];			// 站点代码
	BYTE		bDevGroupType;			// 设备类型
	BYTE		bDeviceID[2];				// 设备代码
	char		cSAMID[16];				// SAM卡逻辑卡号（单程票）
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号（单程票）
	BYTE		dtDate[7];				// 时间
	BYTE		bPaymentMeans;			// 支付方式
	char		cPaymentTKLogicalID[16];	// 支付票卡逻辑卡号
	long		lTicketMarkdownCount;		// 票卡扣款交易计数, 每次扣款交易累加1
	char		cLogicalID[16];			// TOKEN 逻辑ID
	char		cPhysicalID[20];			// TOKEN 物理ID
	BYTE		bTokenStatus;				// TOKEN状态
	short	nChargeValue;				// 充值金额
	BYTE		bTokenType[2];			// 单程票卡类型
	BYTE		bZoneID;					// 区段代码
	char		cMACorTAC[10];			// SAM生成的交易检查代码,	默认值：0000000000
	BYTE		bDepositorCost;			// 成本/押金
	short	nAmountofDepositorCost;		// 成本/押金 金额, 单位为分的整数，默认0
	char		cOperatorID[6];			// 操作员代码(Login)
	BYTE		bBOMShiftID;				// BOM班次序号,
};
返回值: 
0 - 对票卡处理成功，输出参数可用
1090 - 天线感应区无卡，输出参数无效；
1091 - 在天线感应区有多张票卡，输出参数无效；
2010 - 旧密钥系统LSAM卡信用值达到报警下限值，操作成功，输出参数有效，需向MPS发起充值请求；
2011- 旧密钥系统LSAM卡信用值第一次达到停机下限值，操作成功，输出参数有效，需向MPS发起充值请求；
2012 - 旧密钥系统LSAM卡信用值等于或小于停机下限值，操作失败，输出无效，需向MPS发起充值请求；
2013 - 新密钥系统LSAM卡信用值达到报警下限值，操作成功，输出参数有效，需向MPS发起充值请求；
2014- 新密钥系统LSAM卡信用值第一次达到停机下限值，操作成功，输出参数有效，需向MPS发起充值请求；
2015 - 新密钥系统LSAM卡信用值等于或小于停机下限值，操作失败，输出无效，需向MPS发起充值请求；
非0值 - 具体见附录"API返回值代码对照表"
2.1.4.2	SJT擦除
函数原型：
int Tvm_SjtClear(int nPort, int nAntMode)
功能：
当操作失败且不知票卡是否操作成功时，可以调用该接口将废票箱中的Token的金额清除。
输入参数：
nPort 		- 通信端口，与初始化时的端口号相同
nAntMode 		- 天线工作模式
01-指定主天线感应区进行车票处理
02-指定副天线感应区进行车票处理
输出参数：
无
返回值: 
0 - 擦除成功
非0值 - 具体见附录"API返回值代码对照表"
*/
int Tvm_SjtSale(StruAPIParam APIParam,uint16 u16TranValue,uint8 u8PaymentType, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Tvm_SjtClear(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Tvm_SvtAnalyze(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Tvm_SvtDecrease(StruAPIParam APIParam,uint32 u32Price,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_SaleTicket(StruAPIParam APIParam,uint16 u16TranValue,uint8 u8PaymentType,uint8 u8MoneyType, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);


int Bom_TicketAnalyze(StruAPIParam APIParam,uint8 u8IsDegradeMode,uint8 u8WorkArea, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_GetTicketInfo(StruAPIParam APIParam, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_GetPriceDiff(StruAPIParam APIParam,BYTE *bTicketType, BYTE *bStationID,int iRemainningValue, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_GetPenalty(StruAPIParam APIParam,BYTE *bTicketType, BYTE bPenaltyCode, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_GetActiveInfo(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_Active(StruAPIParam APIParam,EquipmentActivateServer st_EquipmentActivateServer,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_TopupInit(StruAPIParam APIParam,uint8 TopupType,uint32 TopupValue,uint8 *NetPoint,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_TopupOperate(StruAPIParam APIParam,TopupRequestServer st_TopupRequestServer,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);


int ChargeBackInit(StruAPIParam APIParam,uint8 Type,uint32 Value,uint32 remainningValue,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int ChargeBackOperate(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);




int Bom_Unblock(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_Refund(StruAPIParam APIParam,uint8 u8RefundOption,uint8 u8RefundCode,uint16 u16TranValue,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_Deffer(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_SvtDecrease(StruAPIParam APIParam,uint32 u32Price,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_Update(StruAPIParam APIParam,uint8 u8UpdateCode,uint16 u16EntryStationCode,uint16 u16TranValue,uint8 u8PaymentType,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_SaleExitSJT(StruAPIParam APIParam,uint16 u16Price,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Bom_ConfirmTran(StruAPIParam APIParam,uint8 u8Option,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Tcm_GetTicketInfo(StruAPIParam APIParam, RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Test_Read_Acc_ULCard(StruAPIParam APIParam,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int Test_Write_Acc_ULCard(StruAPIParam APIParam,uint8 * u8Buffer,RetInfo * pRi ,WORD * pLen1, unsigned char * pMsg1, WORD * pLen2, unsigned char * pMsg2);

int InitBiz();

//2015.11.07 获取日志大小
int Common_GetLogFileSize(StruAPIParam APIParam,	//函数公共参数
						  RetInfo * pRi,			//返回结构体
						  BYTE LogFileType,			//日志文件类型
						  BYTE LogFileDate[4],		//日志文件时间
						  uint32 * pdwLogFileSize);  	//返回的日志文件大小

//2015.11.09 获取日志文件内容
int Common_GetLogFileData(StruAPIParam APIParam,	//函数公共参数
						  RetInfo * pRi,			//返回结构体
						  BYTE LogFileType,			//日志文件类型
						  BYTE LogFileDate[4],		//日志文件时间
						  uint32 dwLogFilePos, 	//日志文件开始读取位置
						  WORD  wReadCount ,  	//日志文件读取大小
						  BYTE * pLogFileData);  	//返回的日志文件大小



#endif

