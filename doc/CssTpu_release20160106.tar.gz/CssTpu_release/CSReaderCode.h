/*********************************************************
*程序名称:		CSReaderCode.h
*版本号:		0.1			
*功能描述:  	定义在读卡器中使用的所有的全局宏定义
*作者:			王洪峰			
*修改记录:		
				2015.01.07 创建 
*其他:						
***********************************************************/

#ifndef __CSREADERCODE_H__
#define __CSREADERCODE_H__

#include "DataTypeDefine.h"


#define CE_OK                  0x00            //命令成功完成
#define CE_FAIL				   0x01		   //命令执行失败
#define CE_PARAM_ERROR		   0x02		   //入参错误
#define CE_CHECKERROR          0x04            //校验和错误

//物理卡类型定义
#define ACC_UL_CARD               0x01
#define ACC_M1_CARD               0x02
#define ACC_CPU_CARD              0x03

#define ACC_NFC_CPU_CARD          0x04

#define CITY_M1_CARD              0x11
#define CITY_CPU_CARD             0x12

#define PBOC_CPU_CARD             0x21
//

//读卡操作类型定义
#define READ_FOR_SALE             	0x01
#define READ_FOR_INCREASE         	0x02
#define READ_FOR_DECREASE         	0x03
#define READ_FOR_CARD_REFUND    	0x04

//所有的与上位机之间的命令代码

#define MSG_COMMON_INITIALIZE_DEVICE	0x0100	//设备环境初始化
#define MSG_COMMON_GETVERSION			0x0101	//获取版本信息
#define MSG_COMMON_GETSAMINFO			0x0102	//获取SAM卡信息	ALL
#define MSG_COMMON_SETDEGRADEMODE		0x0103 	//降级模式消息	ALL
#define MSG_COMM_GETFARE				0x0104 	//获取到本站的票价	ALL
#define MSG_COMM_GETPARAMINFO			0x0105	//获取参数信息	ALL
#define MSG_GET_REG_VALUE				0x0106	//获取单个寄存器值	ALL
#define MSG_GET_REG_INF					0x0107	//获取所有寄存器值	ALL
#define MSG_RESET_REF_INF				0x0108	//重置寄存器	ALL
#define MSG_COMMON_LASTTRADE			0x0109	//获取上次通讯数据	ALL
#define MSG_GATE_AISLEMODEL				0x010D	//设置专用通道	AGM
#define MSG_GATE_ENTRYFLOW				0x010E	//进闸	AGM
#define MSG_GATE_EXITFLOW				0x010F	//出闸	AGM
#define MSG_TVM_TICKET_SALE				0x0114	//车票发售	TVM
#define MSG_TVM_SJTCLEAR				0x0115	//单程票余额清零	TVM
#define MSG_TVM_TICKETANALYZE			0x0116	//分析	TVM
#define MSG_TVM_PURSEDECREASE			0x0117	//票卡减值	TVM
#define MSG_TVM_SVTINCREASE1			0x0118	//在线充值-初始化	TVM
#define MSG_TVM_SVTINCREASE2			0x0119	//在线充值-充值操作	
#define MSG_BOM_LOGIN					0x011E	//BOM操作员登录	BOM
#define MSG_BOM_TICKETANALYZE			0x011F	//票卡分析	BOM
#define MSG_BOM_GETTICKETINFO			0x0120	//验票	BOM
#define MSG_BOM_TICKET_SALE				0x0121	//车票发售	BOM
#define MSG_BOM_TRANSACTCONFIRM			0x0123	//交易确认	BOM
#define MSG_BOM_EXITSALE				0x0124	//发售出站票	BOM
#define MSG_BOM_TICKETUPDATE			0x0125	//	票卡更新	BOM
#define MSG_BOM_PURSEDECREASE			0x0126	//	票卡减值	BOM
#define MSG_BOM_DIRECTREFUND			0x0127	//	即时退款	BOM
#define MSG_BOM_TICKETDEFER				0x0128	//	延期	BOM
#define MSG_BOM_TICKETUNLOCK			0x0129	//	解锁	BOM
#define MSG_BOM_SVTINCREASE1			0x012A	//在线充值-初始化	BOM
#define MSG_BOM_SVTINCREASE2			0x012B	//在线充值-充值操作	BOM
#define MSG_BOM_FUNACTIVE1				0x012C	//功能激活信息获取	BOM
#define MSG_BOM_FUNACTIVE2				0x012D	//读写器功能激活操作	BOM
#define MSG_BOM_CHARGE_DESCIND1			0x012E	//充值撤销初始化	BOM
#define MSG_BOM_CHARGE_DESCIND2			0x012F	//充值撤销	BOM
#define MSG_BOM_QUERY_POLICY_PENALTY	0x0130	//查询行政罚金	BOM
#define MSG_BOM_QUERY_OVERTRIP_VAL		0x0131	//查询车费差价	BOM
#define MSG_TCM_GETTICKETINFO			0x0132	//Private	TCM
#define MSG_PARAM_DOWNLOAD_NOFIFY		0x0200	//参数下载/生效通知
#define MSG_PARAM_DOWNLOAD_DATA			0x0201	//MSG_参数内容传输
#define MSG_REMOTE_REBOOT_APPLICATION	0x0301	//远程重启读写器应用		
#define MSG_REMOTE_REBOOT_SYSTEM		0x0302	//MD_远程重启读写器系统

//自定义
#define MSG_READ_ACC_ULCARD				0x0901	//Read Acc ULcard
#define MSG_WRITE_ACC_ULCARD			0x0902	//Write Acc ULcard

#define MSG_GET_LOGFILE_SIZE			0x010A	//获取日志文件大小	ALL
#define MSG_GET_LOGFILE_DATA			0x010B	//获取日志文件内容	ALL

#pragma pack(push,1)
//2.1	API公共参数(所有函数公共参数)
typedef struct _StruAPIParam 
{	 	
	char	Reserved0Param;			//预留
	char 	Reserved1Param;			//预留(低4位有效)
	char	BuzzerCount;			//低2位有效,最多3次蜂鸣
	char	AntennaMode;			//天线模式0=主天线，1=副天线}TICKETLOCK, * 
	unsigned char ucTimeStamp[7];	//当前时间取值BCD编码	
}StruAPIParam;

//2.2	降级模式命令结构体
typedef struct _DegradeCmd
{
	BYTE	bDegradeType;		//降级模式类型
								//1	列车故障模式
								//2	进出次序免检模式
								//3	日期免检模式
								//4	时间免检模式
								//5	车费免检模式
								//6	紧急模式
	BYTE	bTime[7];			//降级模式生效/取消时间（BCD码）
	BYTE	bStationID[2];		//降级模式生效/取消车站（如"\0x01\0x01"一号线第一个车站）
	BYTE	bFlag;				//降级模式生效/取消标志
								//0x01 - 生效,0x02 - 取消
}DEGRADECMD, *PDEGRADECMD;

typedef struct _ST_RW_DegradeCmd_
{
	BYTE	bDegradeType;		//降级模式类型
								//1	列车故障模式
								//2	进出次序免检模式
								//3	日期免检模式
								//4	时间免检模式
								//5	车费免检模式
								//6	紧急模式
	BYTE	bStartTime[7];		//降级模式生效时间（BCD码
	BYTE	bEndTime[7];		//降级模式取消时间（BCD码
	BYTE	bStationID[2];		//降级模式生效/取消车站（如"\0x01\0x01"一号线第一个车站）
	BYTE	bFlag;				//降级模式生效/取消标志
								//0x01 - 生效,0x02 - 取消
}ST_RW_DEGRADECMD;


//2.3	SAM卡状态信息
typedef struct _SamStatus
{
	BYTE	bSAMStatus;					// SAM卡状态
										// 0x00－表示正常
										// 0x01- 卡号与设备注册信息不对应
										// 未知
	char	cSAMID[16];					// SAM卡ID号
}SAMSTATUS, * PSAMSTATUS;


//2.4	入闸交易
typedef struct _EntryGate 
{
	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];				// 设备类型
	char		cDeviceID[3];					// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		dtDate[7];					// 进站日期时间如;20060211160903
	BYTE		bStatus;						// 交易状态代码
	long		lBalance;						// 余额
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				//限制使用模式
	BYTE		bLimitEntryID[2];				//限制进站代码
	BYTE		bLimitExitID[2];				//限制出站代码
	char 		cEntryMode;					//进闸工作模式
	long		lTradeCount;					//扣款计数
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1
}ENTRYGATE, * PENTRYGATE;

//2.5	钱包交易
typedef struct _PurseTrade
{
	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// 本次交易SAM逻辑卡号
	long		lSAMTrSeqNo;				// 本次交易SAM卡脱机交易流水号
	BYTE		dtDate[7];					// 日期时间(BCD)
	BYTE		bTicketType[2];				// 票卡类型(BCD)
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		bStatus;					// 交易状态代码
	long		lTradeAmount;				// 交易金额, 单位为分
	long		lBalance;					// 余额, 单位为分
	long		lChargeCount;				// 票卡充值计数
	long		lTradeCount;				// 票卡扣款交易计数
	char		cPaymentType[2];			// 支付类型
	char		cReceiptID[4];				// 支付凭证码
	char		cMACorTAC[10];				// 交易认证码
	BYTE		bEntryStationID[2];			// 入口站点代码(BCD)
	char		cEntrySAMID[16];			// 入口SAM逻辑卡号
	BYTE		dtEntryDate[7];				// 进站日期时间(BCD)
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShiftID;				// BOM班次序号
	char		cSamLast[16];				// 上次交易的SAM卡号
	BYTE		dtLast[7];					// 上次交易日期时间
	long		lTradeWallet;				// 钱包交易额，卡片实际需要变动的钱包值
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				// 限制使用模式
	BYTE		bLimitEntryID[2];			// 限制进站代码
	BYTE		bLimitExitID[2];			// 限制出站代码
	char		cExitMode;					//出闸工作模式
	char		cCityCode[4];				// 城市代码
	char		cIndustryCode[4];			// 行业代码
	char		cClassicType[2];			// TAC交易分类
	char		cSamPosId[12];				// SAM卡终端编码
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1
}PURSETRADE, * PPURSETRADE;

//2.6	非单程票发售记录
typedef struct _OtherSale 
{
	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		bStatus;					// 交易状态代码	
	char		cBusinessseqno[12];			// 脱机业务流水号
	char		cSAMID[16];					// SAM卡逻辑卡号（单程票）
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号（单程票）
	BYTE		bAmountType;				// 金额类型
	short		nAmount;					// 金额
	BYTE		dtDate[7];					// 销售时间BCD
	char		cReceiptID[4];				// 支付凭证码
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShfitID;				// BOM班次序号每个BOM每天重置	(BCD)
	long		lBrokerage;					// 手续费
char		cTestFlag;						// 卡应用标识
}OTHERSALE, * POTHERSALE;

//2.7	单程票发售记录
typedef struct _SJTSale 
{
	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号（单程票）
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号（单程票）
	BYTE		dtDate[7];					// 时间
	BYTE		bPaymentMeans;				// 支付方式 BCD
	char		cPaymentTKLogicalID[20];	// 支付票卡逻辑卡号
	long		lTradeCount;				// 单程票扣款计数
	char		cLogicalID[20];				// TOKEN 逻辑ID
	char		cPhysicalID[20];			// TOKEN 物理ID
	BYTE		bStatus;					// 交易状态
	short		nChargeValue;				// 充值金额
	BYTE		bTicketType[2];				// 单程票卡类型
	BYTE		bZoneID;					// 区段代码
	char		cMACorTAC[10];				// SAM生成的交易检查代码,	默认值：
	BYTE		bDepositorCost;				// 成本押金
	short		nAmountCost;				// 成本押金金额
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShiftID;				// BOM班次序号, 每个BOM每天重置
	long		lBrokerage;					// 手续费
	char		cTestFlag;					// 卡应用标识
	char		cClassicType[2];			// TAC交易分类
	char		cSamPosId[12];				// SAM卡终端编码
}SJTSALE, * PSJTSALE;

//2.8	交易确认信息结构
typedef struct _TransactConfirm 
{
	BYTE	bTradeType;						// 交易类型
	BYTE	bData[512];						// 上次的交易记录结构的拷贝
}TRANSACTCONFIRM, * PTRANSACTCONFIRM;

//2.9	更新交易
typedef struct _TicketUpdate 
{
	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;				// 更新设备SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	long		lTradeCount;				// 票卡扣款交易计数
	BYTE		bStatus;					// 交易状态代码
	char		cUpdateZone;				// 更新区域
	BYTE		bUpdateReasonCode;			// 更新原因
											// 更新原因代码表
											// 原因代码	描述（Description）
											// 付费区：01－出站超时，02-超乘，03-无进站码
											// 非付费区：10－有进站码，
											// 11：非付费区非本站进站
											// 12：进站超时
	BYTE		dtUpdateDate[7];			// 更新日期时间YYYYMMDDHHMMSS
	BYTE		bPaymentMode;				// 罚金支付方式
											// 	1-现金，2-储值卡， 3-一卡通
											//	4-Credit， 5- civil charge '默认值''
	short		nForfeiture;				// 罚金, 需缴纳的罚款金额（现金支付），单位分
	char		cReceiptID[4];				// 支付凭证码
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bEntryStationID[2];			// 进站线路站点代码
	BYTE		bBOMShfitID;				// BOM班次序号每个BOM每天重置	（BCD）
	char		cTestFlag;					// 卡应用标识
	char		cLimitMode[3];				// 限制使用模式
	BYTE		bLimitEntryID[2];			// 限制进站代码
	BYTE		bLimitExitID[2];			// 限制出站代码
	char		cTkAppMode;					//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1
}TICKETUPDATE, * PTICKETUPDATE;

//2.10	票卡延期交易
typedef struct _TicketDefer {
	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];				// 设备类型
	char		cDeviceID[3];					// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;					// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];				// 票卡物理卡号
	BYTE		bStatus;						// 交易状态代码
	BYTE		dtOldExpiryDate[7];			// 原有效时间
	BYTE		dtNewExpiryDate[7];			// 现有效时间
	BYTE		dtOperateDate[7];				// 操作时间
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShfitID;					// BOM班次序号每个BOM每天重置	（BCD）
char		cTestFlag;					// 卡应用标识
}TICKETDEFER, * PTICKETDEFER;


//2.11	票卡加解锁交易
typedef struct _TicketLock 
{	 	
	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];			// 设备类型
	char		cDeviceID[3];				// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;				// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];			// 票卡物理卡号
	BYTE		bStatus;					// 交易状态代码
	char		cLockFlag;					// 加解锁标志
	BYTE		dtDate[7];					// 时间YYYYMMDDHHMMSS
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShfitID;				// BOM班次序号每个BOM每天重置	(BCD)
char		cTestFlag;						// 卡应用标识
char		cTkAppMode;						//卡应用模式 ， 1：CPU， 2：M1/UL, 3：仿M1
}TICKETLOCK, * PTICKETLOCK;

//2.12	退款交易
typedef struct	_DirectRefund 
{
	char		cTradeType[2];				// 交易类型
	char		cStationID[4];				// 线路站点代码
	char		cDevGroupType[2];				// 设备类型
	char		cDeviceID[3];					// 设备代码
	char		cSAMID[16];					// SAM卡逻辑卡号
	long		lSAMTrSeqNo;					// SAM卡脱机交易流水号
	BYTE		bTicketType[2];				// 票卡类型
	char		cLogicalID[20];				// 票卡逻辑卡号
	char		cPhysicalID[20];				// 票卡物理卡号
	BYTE		bStatus;						// 交易状态代码
	long		lBalanceReturned;				// 退还钱包金额, 单位为分
	short		nDepositReturned;				// 退还押金, 单位为分
	short		nForfeiture;					// 罚款, 单位为分
	BYTE		bForfeitReason;				// 罚款原因
	long		lTradeCount;					// 票卡扣款交易计数
	char		cReturnTypeCode;				// 退款类型, 0－即时退款；－非即时退款
	BYTE		dtDate[7];					// 时间YYYYMMDDHHMMSS
	char		cReceiptID[4];				// 凭证ID
	BYTE		dtApplyDate[7];				// 申请日期时间, YYYYMMDDHHMMSS
	char		cMACOrTAC[10];				// 交易认证码
	char		cOperatorID[6];				// 操作员代码(Login)
	BYTE		bBOMShfitID;					// BOM班次序号每个BOM每天重置	（BCD）
	long		lBrokerage;					// 手续费
	char		cTestFlag;					// 卡应用标识
	char		cClassicType[2];				// TAC交易分类
	char		cSamPosId[12];				// SAM卡终端编码
}DIRECTREFUND, * PDIRECTREFUND;



//2.13	票卡分析返回结构
typedef struct _BomAnalyze {
	char		cPhysicalID[20];				// 物理卡号,
	char		cLogicalID[20];				// 逻辑卡号
	BYTE		bTicketType[2];				// 车票类型(主类型+子类型)
	long		lBalance;						// 余值
	long 		lDepositorCost;				// 押金
	long		lLimitedBalance;				// 车票最高上限值
	long		lPenalty;						// 更新罚金
	BYTE		bIssueData[4];				// 发行时间
	BYTE		bExpiry[7];					// 物理有效期截止时间(BCD)
	BYTE		bStartDate[7];				// 逻辑有效期开始时间(BCD)
	BYTE		bEndDate[7];					// 逻辑有效期结束时间(BCD)
	BYTE		bStatus;						// 交易状态
	BYTE		bLastStationID[2];				// 上次交易线路站点(BCD)
	BYTE		bLastDeviceID[2];				// 上次交易设备编号(BCD),第0字节仅低4bit有效
	BYTE 		bLastDeviceType; 				// 上次交易设备类型
	BYTE		dtLastDate[7];				// 上次交易时间
	BYTE		bEntrySationID[2];			// 上次进站站点
	BYTE		dtEntryDate[7];				// 上次进站时间
	DWORD		dwOperationStauts;				// 可操作状态与RetInfo的错误对应
// 按位对应以下几种，1表示可操作
										// 	bit0:是否可充(值/乘次)
										// 	bit1:是否可更新
										// 	bit2:是否可发售
										// 	bit3:是否可激活
										// 	bit4:是否可延期
										// 	bit5:是否可退款
										// 	bit6:是否可解锁
	BYTE		bLimitMode;					// 限制模式
	BYTE		bLimitEntryID[2];				// 进站站点限制（BCD码）
	BYTE		bLimitExitID[2];				// 出站站点限制(BCD码)
	BYTE		bActiveStatus;				// 激活状态或激活标记
	char		cCityCode[4];					// 城市代码
	char		cSellerCode[4];				// 发行商代码
	long		lChargeCount;					// 充值计数
	long		lTradeCount;					// 消费计数
	BYTE		bCertificateType;				// 证件类型
	char		cCertificateCode[32];			// 证件代码
	char		cCertificateName[20];			// 证件持有人姓名
	char		cTestFlag;					// 卡应用标识
	long		lChargeUpper;					// 充值上限，可充值标志位非0时有效
	long 		lDepositeSale;				// 发售押金，可发售标志位非0时有效，实际使用时
// 应结合发售命令的“金额类型”字段使用
	long		lBrokerage;					// 手续费，后续操作需要收取额外费用时有效
// 如非单程票发售、退款
	char		cTkAppMode;					// 卡应用模式，'1'：CPU，'2'：M1/UL, '3'：仿M1
	BYTE		bCertExpire[4];				// 证件有效期，目前主要用于公交学生票，当该有
									// 效期过期时，学生票按普通票扣费
	WORD		wError;						// 错误码，对应更新罚金lPenalty
	long		lPenalty1;					// 更新罚金lPenalty1
	WORD		wError1;						// 错误码，对应更新罚金

	BYTE		bRfu[19];
}BOMANALYZE, * PBOMANALYZE;

typedef struct _ST_OperationStauts_
{
	unsigned char bAllowCharge:1;	// 	bit0:是否可充(值/乘次)
	unsigned char bAllowUpdate:1;	// 	bit1:是否可更新
	unsigned char bAllowSale:1;		// 	bit2:是否可发售
	unsigned char bAllowActive:1;	// 	bit3:是否可激活
	unsigned char bAllowDelay:1	;	// 	bit4:是否可延期
	unsigned char bAllowRefund:1;	// 	bit5:是否可退款
	unsigned char bAllowUnlock:1;	// 	bit6:是否可解锁
	unsigned char bAllowRefundDeposit:1;			//bit7:是否可退押金
}ST_BOM_OperationStauts;

//2.14	单条历史结构
typedef struct _hsSvt 
{
	BYTE		dtDate[7];					// 交易时间（BCD码）
	BYTE		bStationID[2];				// 交易车站ID号（BCD码）
	BYTE		bStatus;					// M1票卡生命周期索引,具体定义见附录四；
											//如果票卡为cpu卡则表示交易类型
	long		lTradeAmount;				// 交易金额,单位分
	BYTE		bDeviceID[2];				// 设备编码（BCD）
	BYTE		bDeviceType;				// 设备类型
	char		cSAMID[16];					// sam id
}HSSVT, * PHSSVT;

//2.15	票卡信息
typedef struct _TicketInfo 
{
	char		cPhysicalID[20];			// 物理卡号,
	char		cLogicalID[20];				// 逻辑卡号
	BYTE		bTicketType[2];				// 车票类型(主类型+子类型)
	long		lBalance;					// 余值
	long 		lDepositorCost;				// 押金
	long		lLimitedBalance;			// 车票最高上限值
	BYTE		bIssueData[4];				// 发行时间
	BYTE		bExpiry[7];					// 物理有效期截止时间(BCD)
	BYTE		bStartDate[7];				// 逻辑有效期开始时间(BCD)
	BYTE		bEndDate[7];				// 逻辑有效期结束时间(BCD)
	BYTE		bStatus;					// 交易状态
	BYTE		bLastStationID[2];			// 上次交易线路站点(BCD)
	BYTE		bLastDeviceID[2];			// 上次交易设备编号(BCD),第字节仅低bit有效
	BYTE 		bLastDeviceType; 			// 上次交易设备类型
	BYTE		dtLastDate[7];				// 上次交易时间
	BYTE		bEntrySationID[2];			// 上次进站站点
	BYTE		dtEntryDate[7];				// 上次进站时间
	BYTE		bLimitMode;					// 限制模式
	BYTE		bLimitEntryID[2];			// 进站站点限制（BCD码）
	BYTE		bLimitExitID[2];			// 出站站点限制(BCD码)
	BYTE		bActiveStatus;				// 激活状态或激活标记
	char		cCityCode[4];				// 城市代码
	char		cSellerCode[4];				// 发行商代码
	long		lChargeCount;				// 充值计数
	long		lTradeCount;				// 消费计数
	BYTE		bCertificateType;			// 证件类型
	char		cCertificateCode[32];		// 证件代码
	char		cCertificateName[20];		// 证件持有人姓名
	char		cTestFlag;					// 卡应用标识
	BYTE		bUsefulCount;				// 有用的数据条数
	char		cTkAppMode;					// 卡应用模式，'1'：CPU，'2'：M1/UL, '3'：仿M1
	BYTE		bCertExpire[4];				// 证件有效期，目前主要用于公交学生票，当该有
											// 效期过期时，学生票按普通票扣费
	HSSVT	bhs[17];						// 历史记录，参见2.16 
}TICKETINFO, * PTICKETINFO;

//Star 联机相关结构体定义

//查询消息包结构
typedef struct _QueryMessagePacket
{
	char	PacketStar[1];			//开始标识 0xEB
	char	PacketType[1];			//数据类型 0x01
	char	PacketNo[1];			//序列号
	char 	DateLength[2];			//数据长度 0x0000
	char	PacketEnd[1];			//结束标识 0x03
}QueryMessagePacket;

//心跳请求"50"
typedef struct _HeartbeatReader
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
}HeartbeatReader;
typedef struct _PacketHeartbeatReader
{
	char	PacketStar[1];			//开始标识 0xEB
	char	PacketType[1];			//数据类型 0x01/0x02/0x03
	char	PacketNo[1];			//序列号
	char 	DateLength[2];			//数据长度
	HeartbeatReader	heartbeatReader;			//心跳请求
	char	PacketEnd[1];		//结束标识 0x03
}PacketHeartbeatReader;
//心跳响应"60"
typedef struct _HeartbeatServer
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	ErrorNum[2];			//响应码
	char	ErrorDescribe[2];		//错误描述
}HeartbeatServer;
typedef struct _PacketHeartbeatServer
{
	char	PacketStar[1];			//开始标识 0xEB
	char	PacketType[1];			//数据类型 0x01/0x02/0x03
	char	PacketNo[1];			//序列号
	char 	DateLength[2];			//数据长度
	HeartbeatServer	heartbeatServer;//心跳响应
	char	PacketEnd[1];		//结束标识 0x03
}PacketHeartbeatServer;


//充值申请"51"
typedef struct _TopupRequestReader
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	TerminalTransNo[4];		//终端交易序列号
	char	WebsiteCode[16];		//网点编码
	char	SendcardMaincode[4];	//发行者主编码
	char	SendcardSecondcode[4];	//发行者子编码
	char	CardCode[2];			//票卡类型(主类型代码＋子类型代码)
	char	CardLogicNo[20];		//票卡逻辑卡号(不足20位时左对齐，右补空格，缺省值：全0)
	char	CardPhysicsNo[20];		//票卡物理卡号(不足20位时左对齐，右补空格。默认值：全为0)
	char	TsetFlag[1];			//是否测试卡(0：正式票卡  1：测试票卡)
	char	CardOnlineNo[4];		//票卡联机交易计数
	char	CardOutlineNo[4];		//票卡脱机交易计数
	char	BusinessType[2];		//业务类型(固定填写‘14’)
	char	ValueType[1];			//值类型(0：无值类型；1：金额；2：次数；3：天数；)
	char	TopupMoney[4];			//充值金额(为金额时单位为”分”)
	char	CardRemainMoney[4];		//票卡余额(为金额时单位为”分”)
	char	MAC1[8];				//由卡片生成的认证码
	char	Random[8];				//卡片充值随机数(验证和生成MAC时使用，由卡片取得。)
	char	LasttimeTerinalNo[16];	//上次交易终端编号(如果上次无交易，为当前交易终端终端编号。)
	char	LasttimeTerinalTime[7];	//上次交易时间(如果上次无交易，为终端当前时间)
	char	OperatorNo[6];			//操作员编码(默认值：全为0)
}TopupRequestReader;
//充值申请响应"61"
typedef struct _TopupRequestServer
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char	SystemNumber[4];		//系统参照号(后台处理流水号)
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	TerminalTransNo[4];		//终端交易序列号
	char	CardLogicNo[20];		//票卡逻辑卡号(不足20位时左对齐，右补空格，缺省值：全0)
	char	MAC2[8];				//由中心生成的认证码，成功时有效 不成功时全0
	char	SystemTime[7];			//系统时间(由中心返回 充值设备依次作为票卡的充值时间，成功时有效 不成功时全0)
	char	ErrorNum[2];			//响应码(00：正常；01:不符合业务逻辑或系统处理过程中出现异常，详细原因见错误描述)
	char	ErrorDescribe[2];		//错误描述
}TopupRequestServer;


//充值确认"52"
typedef struct _TopupVerifyReader
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	TerminalTransNo[4];		//终端交易序列号
	char	WebsiteCode[16];		//网点编码
	char	SendcardMaincode[4];	//发行者主编码
	char	SendcardSecondcode[4];	//发行者子编码
	char	CardCode[2];			//票卡类型(主类型代码＋子类型代码)
	char	CardLogicNo[20];		//票卡逻辑卡号(不足20位时左对齐，右补空格，缺省值：全0)
	char	CardPhysicsNo[20];		//票卡物理卡号(不足20位时左对齐，右补空格。默认值：全为0)
	char	TsetFlag[1];			//是否测试卡(0：正式票卡  1：测试票卡)
	char	CardOnlineNo[4];		//票卡联机交易计数
	char	CardOutlineNo[4];		//票卡脱机交易计数
	char	BusinessType[2];		//业务类型(固定填写‘14’)
	char	ValueType[1];			//值类型(0：无值类型；1：金额；2：次数；3：天数；)
	char	TopupMoney[4];			//充值金额(为金额时单位为”分”)
	char	CardRemainMoney[4];		//票卡余额(为金额时单位为”分”)
	char	TAC[8];					//由卡片生成的认证码
	char	WriteCardResult[1];		//写卡结果(0：写卡成功．”1”：写卡失败．“2”:未知状态。)
	char	OperatorNo[6];			//操作员编码(默认值：全为0)
	char	SystemNumber[4];		//系统参照号(后台处理流水号,消息61返回的。)
	char	SystemTime[7];			//系统时间(消息61返回的充值时间)
}TopupVerifyReader;
//充值确认响应"62"
typedef struct _TopupVerifyServer
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char	SystemNumber[4];		//系统参照号(后台处理流水号)
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	TerminalTransNo[4];		//终端交易序列号
	char	CardLogicNo[20];		//票卡逻辑卡号(不足20位时左对齐，右补空格，缺省值：全0)
	char	ErrorNum[2];			//响应码(00：正常；01:不符合业务逻辑或系统处理过程中出现异常，详细原因见错误描述)
	char	ErrorDescribe[2];		//错误描述
}TopupVerifyServer;


//充值撤销申请"53"
typedef struct _TopupRepealReader
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	TerminalTransNo[4];		//终端交易序列号
	char	WebsiteCode[16];		//网点编码
	char	SendcardMaincode[4];	//发行者主编码
	char	SendcardSecondcode[4];	//发行者子编码
	char	CardCode[2];			//票卡类型(主类型代码＋子类型代码)
	char	CardLogicNo[20];		//票卡逻辑卡号(不足20位时左对齐，右补空格，缺省值：全0)
	char	CardPhysicsNo[20];		//票卡物理卡号(不足20位时左对齐，右补空格。默认值：全为0)
	char	TsetFlag[1];			//是否测试卡(0：正式票卡  1：测试票卡)
	char	CardOnlineNo[4];		//票卡联机交易计数
	char	CardOutlineNo[4];		//票卡脱机交易计数
	char	BusinessType[2];		//业务类型(固定填写‘18’)
	char	ValueType[1];			//值类型(0：无值类型；1：金额；2：次数；3：天数；)
	char	RepealMoney[4];			//撤销金额(为金额时单位为”分”)
	char	CardRemainMoney[4];		//票卡余额(为金额时单位为”分”)
	char	LasttimeTerinalNo[16];	//上次交易终端编号(如果上次无交易，为当前交易终端终端编号。)
	char	LasttimeTerinalTime[7];	//上次交易时间(如果上次无交易，为终端当前时间)
	char	OperatorNo[6];			//操作员编码(默认值：全为0)
}TopupRepealReader;
//充值撤销申请响应"63"
typedef struct _TopupRepealServer
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char	SystemNumber[4];		//系统参照号(后台处理流水号)
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	TerminalTransNo[4];		//终端交易序列号(充值申请63传入)
	char	CardLogicNo[20];		//票卡逻辑卡号(不足20位时左对齐，右补空格，缺省值：全0)
	char	SystemTime[7];			//系统时间(由中心返回 充值设备依次作为票卡的充值时间，成功时有效 不成功时全0)
	char	ErrorNum[2];			//响应码(00：正常；01:不符合业务逻辑或系统处理过程中出现异常，详细原因见错误描述)
	char	ErrorDescribe[2];		//错误描述
}TopupRepealServer;


//充值撤销确认"54"
typedef struct _TopupRepealVerifyReader
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	TerminalTransNo[4];		//终端交易序列号(与充值撤销申请的终端交易序号相同)
	char	WebsiteCode[16];		//网点编码(默认值：全0)
	char	SendcardMaincode[4];	//发行者主编码(默认值：全0)
	char	SendcardSecondcode[4];	//发行者子编码(默认值：全0)
	char	CardCode[2];			//票卡类型(主类型代码＋子类型代码)
	char	CardLogicNo[20];		//票卡逻辑卡号(不足20位时左对齐，右补空格，缺省值：全0)
	char	CardPhysicsNo[20];		//票卡物理卡号(不足20位时左对齐，右补空格。默认值：全为0)
	char	TsetFlag[1];			//是否测试卡(0：正式票卡  1：测试票卡)
	char	CardOnlineNo[4];		//票卡联机交易计数
	char	CardOutlineNo[4];		//票卡脱机交易计数
	char	BusinessType[2];		//业务类型(固定填写‘14’)
	char	ValueType[1];			//值类型(0：无值类型；1：金额；2：次数；3：天数；)
	char	RepealMoney[4];			//撤销金额(为金额时单位为”分”)
	char	CardRemainMoney[4];		//票卡余额(为金额时单位为”分”)
	char	TAC[8];					//由卡片生成的认证码
	char	WriteCardResult[1];		//写卡结果(0：写卡成功．”1”：写卡失败．“2”:未知状态。)
	char	OperatorNo[6];			//操作员编码(默认值：全为0)
	char	SystemNumber[4];		//系统参照号(后台处理流水号,消息63返回的。)
	char	SystemTime[7];			//系统时间(消息63返回的充值时间)
}TopupRepealVerifyReader;
//充值撤销确认响应"64"
typedef struct _TopupRepealVerifyServer
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char	SystemNumber[4];		//系统参照号(后台处理流水号)
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	TerminalTransNo[4];		//终端交易序列号
	char	CardLogicNo[20];		//票卡逻辑卡号(不足20位时左对齐，右补空格，缺省值：全0)
	char	ErrorNum[2];			//响应码(00：正常；01:不符合业务逻辑或系统处理过程中出现异常，详细原因见错误描述)
	char	ErrorDescribe[2];		//错误描述
}TopupRepealVerifyServer;


//激活"55"
typedef struct _EquipmentActivateReader
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	Random[16];				//随机数
}EquipmentActivateReader;
typedef struct _PacketEquipmentActivateReader
{
	char	PacketStar[1];			//开始标识 0xEB
	char	PacketType[1];			//数据类型 0x01/0x02/0x03
	char	PacketNo[1];			//序列号
	char 	DateLength[2];			//数据长度
	EquipmentActivateReader	equipmentActivateReader;//激活请求
	char	PacketEnd[1];			//结束标识 0x03
}PacketEquipmentActivateReader;
//激活响应"65"
typedef struct _EquipmentActivateServer
{
	char	MessageType[2];			//消息类型
	char	MessageTime[7];			//消息生成时间 YYYYMMDDHHNNSS
	char	SystemNumber[4];		//系统参照号(后台处理流水号)
	char 	TerminalID[9];			//终端编号  线路代码(2)+车站代码(2)+设备类型(2)+设备编码(3)
	char	SamLogicID[16];			//Sam卡逻辑卡号
	char	MAC[16];				//MAC
	char	ErrorNum[2];			//响应码(00：正常；01:不符合业务逻辑或系统处理过程中出现异常，详细原因见错误描述)
	char	ErrorDescribe[2];		//错误描述
}EquipmentActivateServer;
typedef struct _PacketEquipmentActivateServer
{
	char	PacketStar[1];			//开始标识 0xEB
	char	PacketType[1];			//数据类型 0x01/0x02/0x03
	char	PacketNo[1];			//序列号
	char 	DateLength[2];			//数据长度
	EquipmentActivateServer	equipmentActivateServer;//激活响应
	char	PacketEnd[1];			//结束标识 0x03
}PacketEquipmentActivateServer;
//End  联机相关结构体定义

//特别说明：如果wErrCode!=0，那么接口的调用一定失败；如果wErrCode==0，接口调用成功，不论wErrCode为何值，调用程序都应检查bNoticeCode，并根据bNoticeCode进行差异化操作。
//关联错误码描述主要正对人工设备，人工设备上应将其与错误码描述一起显示给操作人员，自动设备上由程序根据关联提示码自动进行相关操作。
//错误码，关联提示码以及描述信息具体参见附录一
//2.16	执行状态信息结构(函数返回值)
typedef struct _RetInformation{
	WORD		wErrCode;						// 错误码
	BYTE		bNoticeCode;					// 关联提示码
	BYTE		bRfu[2];						// 扩充保留字段
}RetInfo, * PRetInfo;


//2.17	读写器版本信息结构
typedef struct _READER_VERSION
{
	BYTE		verApi[2];						// API识别版本
	BYTE		verApiFile[10];					// API文件版本，日期＋序号
	BYTE		verRfDev;							// Rf驱动识别版本
	BYTE		verRfFile[10];					// Rf文件版本，日期＋序号
	BYTE		verSamDev;						// Sam驱动识别版本
	BYTE		verSamFile[10];					// Sam驱动文件版本，日期＋序号
 } READERVERSION, * PREADERVERSION;

//车票状态代码定义
typedef enum
{
	RW_STATUSCODE_INITIALIZATION			=200,//初始化
	RW_STATUSCODE_PREVALUE_LOADED_ES		=201,//Init II (Pre-value loaded @E/S)(预赋值)
	RW_STATUSCODE_SALE_BOM_OR_TVM			=202,//(BOM/TVM)发售
	RW_STATUSCODE_EXIT_STAION				=203,//出站(exit)
	RW_STATUSCODE_EXIT_TRAINFAULT			=204,//列车故障模式出站(exit during Train-disruption)
	RW_STATUSCODE_UPDATE_ENTRY_ATBOM		=205,//进站BOM更新(upgrade at BOM for Entry)
	RW_STATUSCODE_UPDATE_FREE_UNPAYAREA		=206,//非付费区免费更新(BOM/pca 非付费区)
	RW_STATUSCODE_UPDATE_PAYED_UNPAYAREA	=207,//非付费区付费更新(BOM/pca 非付费区)
	RW_STATUSCODE_ENTRY_STATION				=208,//进站(entry)
	RW_STATUSCODE_UPDATE_EXIT_ATBOM			=209,//出站BOM更新(upgrade at BOM for Exit)
	RW_STATUSCODE_UPDATE_NO_ENTRY_STATION	=210,//无进站码更新(BOM/pca 付费区)
	RW_STATUSCODE_UPDATE_TIMEOUT			=211,//超时更新(BOM/pca 付费区)
	RW_STATUSCODE_UPDATE_RANGEOUT			=212,//超乘更新(BOM/pca 付费区)
	RW_STATUSCODE_ET_FOR_EXIT				=213,//ET for Exit(出站票),
	RW_STATUSCODE_REBACK_CARD				=214,//退卡
	RW_STATUSCODE_DISPOSE					=215,//车票已注销
	RW_STATUSCODE_UNKNOWN					=255//未知状态
}RW_ENUM_STATUS_CODE;


typedef struct _STRU_RW_STATUS_CODE_TABLE
{
	RW_ENUM_STATUS_CODE	Code;				//错误代码
	char			Description[100];		//错误代码描述
}STRU_RW_STATUS_CODE_TABLE;

////车票状态代码描述定义
//const STRU_RW_STATUS_CODE_TABLE RW_STATUS_CODE_TABLE[]=
//{
//	{ RW_STATUSCODE_INITIALIZATION			,"初始化"},
//	{ RW_STATUSCODE_PREVALUE_LOADED_ES		,"Init II (Pre-value loaded @E/S)(预赋值)"},
//	{ RW_STATUSCODE_SALE_BOM_OR_TVM			,"(BOM/TVM)发售"},
//	{ RW_STATUSCODE_EXIT_STAION				,"出站(exit)"},
//	{ RW_STATUSCODE_EXIT_TRAINFAULT			,"列车故障模式出站(exit during Train-disruption)"},
//	{ RW_STATUSCODE_UPDATE_ENTRY_ATBOM		,"进站BOM更新(upgrade at BOM for Entry)"},
//	{ RW_STATUSCODE_UPDATE_FREE_UNPAYAREA	,"非付费区免费更新(BOM/pca 非付费区)"},
//	{ RW_STATUSCODE_UPDATE_PAYED_UNPAYAREA	,"非付费区付费更新(BOM/pca 非付费区)"},
//	{ RW_STATUSCODE_ENTRY_STATION			,"进站(entry)"},
//	{ RW_STATUSCODE_UPDATE_EXIT_ATBOM		,"出站BOM更新(upgrade at BOM for Exit)"},
//	{ RW_STATUSCODE_UPDATE_NO_ENTRY_STATION ,"无进站码更新(BOM/pca 付费区)"},
//	{ RW_STATUSCODE_UPDATE_TIMEOUT			,"超时更新(BOM/pca 付费区)"},
//	{ RW_STATUSCODE_UPDATE_RANGEOUT			,"超乘更新(BOM/pca 付费区)"},
//	{ RW_STATUSCODE_ET_FOR_EXIT				,"ET for Exit(出站票)"},
//	{ RW_STATUSCODE_REBACK_CARD				,"退卡"},
//	{ RW_STATUSCODE_DISPOSE					,"车票已注销"},
//	{ RW_STATUSCODE_UNKNOWN					,"未知状态"}
//};



//根据车票状态码获取车票状态字符串
//BOOL RWGetStatusCodeString(RW_ENUM_STATUS_CODE StatusCode, char * StatusCodeString);

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////
//车票生命周期代码定义（主要针对票卡历史区的上次操作)
typedef enum
{
	RW_LIFECODE_INITIALIZATION			=100,	//初始化
	RW_LIFECODE_PREVALUE_LOADED_ES		=101,	//Init II (Pre-value loaded @E/S)(预赋值)
	RW_LIFECODE_SALE_BOM_OR_TVM			=102,	//(BOM/TVM)发售
	RW_LIFECODE_EXIT_STAION				=103,	//出站(exit)
	RW_LIFECODE_EXIT_TRAINFAULT			=104,	//列车故障模式出站(exit during Train-disruption)
	RW_LIFECODE_UPDATE_ENTRY_ATBOM		=105,	//进站BOM更新(upgrade at BOM for Entry)
	RW_LIFECODE_UPDATE_FREE_UNPAYAREA	=106,	//非付费区免费更新(BOM/pca 非付费区)
	RW_LIFECODE_UPDATE_PAYED_UNPAYAREA	=107,	//非付费区付费更新(BOM/pca 非付费区)
	RW_LIFECODE_ENTRY_STATION			=108,	//进站(entry)
	RW_LIFECODE_UPDATE_EXIT_ATBOM		=109,	//出站BOM更新(upgrade at BOM for Exit)
	RW_LIFECODE_UPDATE_NO_ENTRY_STATION	=110,	//无进站码更新(BOM/pca 付费区)
	RW_LIFECODE_UPDATE_TIMEOUT			=111,	//超时更新(BOM/pca 付费区)
	RW_LIFECODE_UPDATE_RANGEOUT			=112,	//超乘更新(BOM/pca 付费区)
	RW_LIFECODE_ET_FOR_EXIT				=113,	//ET for Exit(出站票)//=
	RW_LIFECODE_REBACK_CARD				=114,	//退卡
	RW_LIFECODE_DISPOSE					=115,	//车票已注销
 	RW_LIFECODE_DEFER					=116,	//延期
	RW_LIFECODE_REVALUATE				=117,	//充值
	RW_LIFECODE_ACTIVE					=118,	//激活
	RW_LIFECODE_DEBIT					=119,	//减值
	RW_LIFECODE_LOCK					=120,	//票卡加锁
	RW_LIFECODE_UNLOCK					=121,	//票卡解锁
	RW_LIFECODE_EXIT_ET					=122,	//出站票出闸
	RW_LIFECODE_COMMON_CONSUMPTION		=180,	//普通消费
	RW_LIFECODE_COMPLEX_CONSUMPTION		=181,	//复合消费
	RW_LIFECODE_CONFIRM_TRANSACTIONRESULT=198,	//交易确认成功
	RW_LIFECODE_CANCEL_TRANSACTIONRESULT=199,	//解除交易确认
	RW_LIFECODE_UNKNOWN					=255	//未知操作
}RW_ENUM_LIFE_CODE;

//车票状态
typedef enum _EM_TICKET_TRAVEL_STATUS_
{
	EM_TICKET_TRAVEL_STATUS_INITIALIZATION			=1,	//e/s 初始化(init 0)
	EM_TICKET_TRAVEL_STATUS_PREVALUE_LOADED_ES		=2,	//e/s 预赋值(init 1)
	EM_TICKET_TRAVEL_STATUS_ISSUED					=3,	// SJT发售(init 2)
	EM_TICKET_TRAVEL_STATUS_ENTRY					=4,	//已进站
	EM_TICKET_TRAVEL_STATUS_EXITED					=5,	//已出站
	EM_TICKET_TRAVEL_STATUS_EXIT_TICKTE				=6,	//出站票
	EM_TICKET_TRAVEL_STATUS_EXIT_EMERGENCY_MODE		=7,	//列车故障模式出站(exit during Train-disruption)
	EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_UNPAYAREA	=8,	//非付费区免费更新(BOM/pca 非付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_PAYED_UNPAYAREA	=9,	//非付费区付费更新(BOM/pca 非付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_NO_ENTRY_STATION	=10,//无进站码更新(BOM/pca 付费区)
	EM_TICKET_TRAVEL_STATUS_UPDATE_EXIT				=11,//出站码更新
	EM_TICKET_TRAVEL_STATUS_UPDATE_TIMEOUT			=12,//超时更新
	EM_TICKET_TRAVEL_STATUS_RANGEOUT				=13,//超乖更新
	EM_TICKET_TRAVEL_STATUS_UPDATE_FREE_EXIT		=14,//免费出闸更新
	EM_TICKET_TRAVEL_STATUS_REFUND					=15,//已退卡

}EM_TICKET_TRAVEL_STATUS;


typedef struct _STRU_RW_LIFE_CODE_TABLE
{
	RW_ENUM_LIFE_CODE	Code;				//生命周期代码
	char				Description[128];	//中文含义描述
}STRU_RW_LIFE_CODE_TABLE;

////车票生命周期代码含义定义
//const STRU_RW_LIFE_CODE_TABLE RW_LIFE_CODE_TABLE[]=
//{
//
//	{ RW_LIFECODE_INITIALIZATION,			"初始化"},
//	{ RW_LIFECODE_PREVALUE_LOADED_ES,		"Init II (Pre-value loaded @E/S)(预赋值)"},
//	{ RW_LIFECODE_SALE_BOM_OR_TVM,			"(BOM/TVM)发售"},
//	{ RW_LIFECODE_EXIT_STAION,				"出站(exit)"},
//	{ RW_LIFECODE_EXIT_TRAINFAULT,			"列车故障模式出站(exit during Train-disruption)"},
//	{ RW_LIFECODE_UPDATE_ENTRY_ATBOM,		"进站BOM更新(upgrade at BOM for Entry)"},
//	{ RW_LIFECODE_UPDATE_FREE_UNPAYAREA,	"非付费区免费更新(BOM/pca 非付费区)"},
//	{ RW_LIFECODE_UPDATE_PAYED_UNPAYAREA,	"非付费区付费更新(BOM/pca 非付费区)"},
//	{ RW_LIFECODE_ENTRY_STATION,			"进站(entry)"},
//	{ RW_LIFECODE_UPDATE_EXIT_ATBOM,		"出站BOM更新(upgrade at BOM for Exit)"},
//	{ RW_LIFECODE_UPDATE_NO_ENTRY_STATION,	"无进站码更新(BOM/pca 付费区)"},
//	{ RW_LIFECODE_UPDATE_TIMEOUT,			"超时更新(BOM/pca 付费区)"},
//	{ RW_LIFECODE_UPDATE_RANGEOUT,			"超乘更新(BOM/pca 付费区)"},
//	{ RW_LIFECODE_ET_FOR_EXIT,				"ET for Exit(出站票)"},
//	{ RW_LIFECODE_REBACK_CARD,				"退卡"},
//	{ RW_LIFECODE_DISPOSE,					"车票已注销"},
// 	{ RW_LIFECODE_DEFER,					"延期"},
//	{ RW_LIFECODE_REVALUATE,				"充值"},
//	{ RW_LIFECODE_ACTIVE,					"激活"},
//	{ RW_LIFECODE_DEBIT,					"减值"},
//	{ RW_LIFECODE_LOCK,						"票卡加锁"},
//	{ RW_LIFECODE_UNLOCK,					"票卡解锁"},
//	{ RW_LIFECODE_EXIT_ET,					"出站票出闸"},
//	{ RW_LIFECODE_COMMON_CONSUMPTION,		"普通消费"},
//	{ RW_LIFECODE_COMPLEX_CONSUMPTION,		"复合消费"},
//	{ RW_LIFECODE_CONFIRM_TRANSACTIONRESULT,"交易确认成功"},
//	{ RW_LIFECODE_CANCEL_TRANSACTIONRESULT,	"解除交易确认"},
//	{ RW_LIFECODE_UNKNOWN,					"未知操作"},
//};

//根据车票状态码获取车票状态字符串
extern BOOL RWGetLifeCodeString(RW_ENUM_LIFE_CODE LifeCode, char * LifeCodeString,int MaxLen);


//API错误码取值
typedef enum
{

	RW_EC_OK										=0x00,//"操作成功处理完成","--"
	RW_EC_UNKNOWN									=0x01,//"未定义错误","错误类型未定义，需要结合关联提示码"
	RW_EC_NO_CARD_FOUND								=0x02,//"天线感应区无卡","调用相关接口时，读卡器没有发现卡"
	RW_EC_MULTI_CARD_FOUND							=0x03,//"天线感应区发现多张IC卡","调用相关接口时，读卡器发现多张卡"
	RW_EC_READ_FAILED								=0x04,//"读卡失败","--"
	RW_EC_WRITE_FAILED								=0x05,//"写卡失败","--"
	RW_EC_UNSALE									=0x06,//"未发售（ES预赋值）的车票","已写入密钥，但是未经票亭发售或ES预赋值"
	RW_EC_STATUS_CODE								=0x07,//"票卡状态错误","卡状态不在系统定义的状态范围内"
	RW_EC_STATUS_REFUND								=0x08,//"票卡已退款(注销)","--"
	RW_EC_BLACKLIST									=0x09,//"黑名单卡，执行锁卡","锁卡输出结构有效"
	RW_EC_INVALID_TICKET							=0x0A,//"无效票","--"
	RW_EC_PHYSICAL_PERIOD_TIMEOUT					=0x0B,//"物理有效期到期","--"
	RW_EC_LOGICAL_PERIOD_TIMEOUT					=0x0C,//"票卡逻辑有效期过期","包括未到启用开始时间和已过启用截止时间,已过启用截止时间的,可以根据BOM分析的可操作状态进行延期"
	RW_EC_ACTIVE_PERIOD_TIMEOUT						=0x0D,//"票卡激活有效期过期","--"
	RW_EC_HALT										=0x0E,//"票卡未启用（停止使用）","启用标识无效	"
	RW_EC_OTHER_SYSTEM_CARD							=0x0F,//"非本系统卡","票卡城市代码或发行商代码不在本系统中	"
	RW_EC_UNKNOW_TICKETTYPE							=0x20,//"票卡类型未定义","相关参数中不存在的票卡类型"
	RW_EC_INVALID_STATION_CODE						=0x21,//"非法的车站代码","相关参数中不存在的车站代码"
	RW_EC_OTHER_SATION								=0x22,//"非本站使用的车票","限制在特定车站或者线路使用的车票在其他车站使用"
	RW_EC_AMOUNT_INSUFFICIENT						=0x23,//"票卡余额不足","票卡余额低于一次乘车的最低费用	"
	RW_EC_AMOUNT_EXCEED_MAX_AMOUNT					=0x24,//"票卡余额超出上限","	"
	RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA		=0x25,//"非付费区非本站进站","需要更新"
	RW_EC_ENTRY_TIMOUT_UNPAID_AREA					=0x26,//"非付费区进站超时","需要更新"
	RW_EC_ENTRY_ENTRYCODE_WRITTEN_UNPAID_AREA		=0x27,//"非付费区有进站码","需要更新"
	RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA		=0x28,//"付费区无进站码","需要更新"
	RW_EC_EXIT_OUTRANGE_PAID_AREA					=0x29,//"付费区超乘","需要更新"
	RW_EC_EXIT_TIMOUT_PAID_AREA						=0x2A,//"付费区车站超时","需要更新"
	RW_EC_UPDATE_OTHER_SATION						=0x2B,//"非本站更新的车票","可以建议乘客去更新的车站出站，也可以根据乘客的要求做票卡更新"
	RW_EC_UPDATE_OTHER_DATE							=0x2C,//"非本日更新的车票","需要更新"
	RW_EC_AISLE_FOR_COMMON_TICKET					=0x2D,//"普通票通道不支持优惠票","应从优惠票通道或者正常通道刷卡"
	RW_EC_AISLE_FOR_SPECIAL_TICKET					=0x2E,//"优惠票通道不支持普通票","应从普通票通道或者正常通道刷卡"
	RW_EC_LAST_EXIT_BELOW_X_MINUTE					=0x2F,//"上次出站在X（固定值暂定10）分钟内","上次刷卡出闸的时间很近，认定出闸扣费正常，但设备故障或闸门误用造成乘客不能出站，提示操作员可免费放乘客离开"
	RW_EC_EXIT_OUTRANGE_AND_TIMEOUT					=0x30,//"既超时又超乘","需要更新"
	RW_EC_INVALID_API_CALL							=0x40,//"非法的接口调用","调用设备环境初始化时传入的设备类型不允许调用当前接口"
	RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE	=0x41,//"设备不支持的票卡类型","某些设备上需要屏蔽部分票卡的使用"
	RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKET			=0x42,//"进行处理的车票与分析时的车票不是同一张","BOM的相关操作要根据分析的结果，主要是防止分析和操作的卡不同，而操作时的判断范围有限"
	RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT	=0x43,//"票卡当前调用非法","主要作用,在0x42的基础上,车票在本地分析,在异地进行相关操作后,再回本地进行操作。如发售和充值等"
	RW_EC_ILLEGAL_INPUT_PARAM						=0x44,//"非法的传入参数","调用某些接口时，会对传入的参数进行范围判断，不在规定范围内的认定为非法"
	RW_EC_DEVICE_UNINITIALIZE						=0x45,//"设备未初始化","提醒设备程序调用设备环境初始化接口"
	RW_EC_UNKNOWN_COMMAND							=0x46,//"不存在的命令地址","命令码或者命令类码不合格"
	RW_EC_PARAMETER_FILE_NOT_EXIST					=0x0100,//"参数文件不存在","参数文件不存在"
	RW_EC_PARAMETER_FILE_ILLEGAL					=0x0101,//"参数文件不合法","校验错误	"
	RW_EC_FILE_PROCESS_ERROR						=0x0102,//"文件错误","包括创建，打开，读和写失败"
	RW_EC_INVALID_INPUT_PARAM						=0x0103,//"无效的输入参数","--" //不知道和非法的输入参数有什么区别?????????
	RW_EC_COMM_OPEN_PORT							=0x0104,//"通讯句柄打开错误","--"
	RW_EC_COMM_WRITE_FAILE							=0x0105,//"通讯发送数据失败","GUI需要关闭读写器连接，然后重新打开"
	RW_EC_COMM_READ_FAILED							=0x0106,//"通讯接收数据失败","GUI需要关闭读写器连接，然后重新打开
	RW_EC_COMM_DATA_INVALID							=0x0107,//"通讯数据非法","数据不完整，格式错误或者校验错误
	RW_ERR_SAM_RESPONSE								=0x0108//"SAM卡响应错误","需重新初始化操作或者未安装SAM卡"
}RW_ENUM_API_ERR_CODE;


typedef struct _STRU_RW_API_ERR_CODE_TABLE
{
	RW_ENUM_API_ERR_CODE	Code;			//生命周期代码
	char				Description[100];	//中文含义描述
	char				Maintance[256];		//维护方式
}STRU_RW_API_CODE_TABLE;

////读卡器返回值
//const  STRU_RW_API_CODE_TABLE RW_API_CODE_TABLE[]=
//{
//
//	{RW_EC_OK,										"操作成功处理完成","--"},
//	{RW_EC_UNKNOWN,									"未定义错误","错误类型未定义，需要结合关联提示码"},
//	{RW_EC_NO_CARD_FOUND,							"天线感应区无卡","调用相关接口时，读卡器没有发现卡"},
//	{RW_EC_MULTI_CARD_FOUND,						"天线感应区发现多张IC卡","调用相关接口时，读卡器发现多张卡"},
//	{RW_EC_READ_FAILED,								"读卡失败","--"},
//	{RW_EC_WRITE_FAILED,							"写卡失败","--"},
//	{RW_EC_UNSALE,									"未发售（ES预赋值）的车票","已写入密钥，但是未经票亭发售或ES预赋值"},
//	{RW_EC_STATUS_CODE,								"票卡状态错误","卡状态不在系统定义的状态范围内"},
//	{RW_EC_STATUS_REFUND,							"票卡已退款(注销)","--"},
//	{RW_EC_BLACKLIST,								"黑名单卡，执行锁卡","锁卡输出结构有效"},
//	{RW_EC_INVALID_TICKET,							"无效票","--"},
//	{RW_EC_PHYSICAL_PERIOD_TIMEOUT,					"物理有效期到期","--"},
//	{RW_EC_LOGICAL_PERIOD_TIMEOUT,					"票卡逻辑有效期过期","包括未到启用开始时间和已过启用截止时间,已过启用截止时间的,可以根据BOM分析的可操作状态进行延期"},
//	{RW_EC_ACTIVE_PERIOD_TIMEOUT,					"票卡激活有效期过期","--"},
//	{RW_EC_HALT,									"票卡未启用（停止使用）","启用标识无效	"},
//	{RW_EC_OTHER_SYSTEM_CARD,						"非本系统卡","票卡城市代码或发行商代码不在本系统中	"},
//	{RW_EC_UNKNOW_TICKETTYPE,						"票卡类型未定义","相关参数中不存在的票卡类型"},
//	{RW_EC_INVALID_STATION_CODE,					"非法的车站代码","相关参数中不存在的车站代码"},
//	{RW_EC_OTHER_SATION	,							"非本站使用的车票","限制在特定车站或者线路使用的车票在其他车站使用"},
//	{RW_EC_AMOUNT_INSUFFICIENT,						"票卡余额不足","票卡余额低于一次乘车的最低费用	"},
//	{RW_EC_AMOUNT_EXCEED_MAX_AMOUNT	,				"票卡余额超出上限","	"},
//	{RW_EC_ENTRY_NOT_SAME_STATION_UNPAID_AREA,		"非付费区非本站进站","需要更新"},
//	{RW_EC_ENTRY_TIMOUT_UNPAID_AREA,				"非付费区进站超时","需要更新"},
//	{RW_EC_ENTRY_ENTRYCODE_WRITTEN_UNPAID_AREA,		"非付费区有进站码","需要更新"},
//	{RW_EC_EXIT_ENTRYCODE_NOTWRITTEN_PAID_AREA,		"付费区无进站码","需要更新"},
//	{RW_EC_EXIT_OUTRANGE_PAID_AREA,					"付费区超乘","需要更新"},
//	{RW_EC_EXIT_TIMOUT_PAID_AREA,					"付费区出站超时","需要更新"},
//	{RW_EC_UPDATE_OTHER_SATION,						"非本站更新的车票","可以建议乘客去更新的车站出站，也可以根据乘客的要求做票卡更新"},
//	{RW_EC_UPDATE_OTHER_DATE,						"非本日更新的车票","需要更新"},
//	{RW_EC_AISLE_FOR_COMMON_TICKET,					"普通票通道不支持优惠票","应从优惠票通道或者正常通道刷卡"},
//	{RW_EC_AISLE_FOR_SPECIAL_TICKET,				"优惠票通道不支持普通票","应从普通票通道或者正常通道刷卡"},
//	{RW_EC_LAST_EXIT_BELOW_X_MINUTE,				"上次出站在X（固定值暂定10）分钟内","上次刷卡出闸的时间很近，认定出闸扣费正常，但设备故障或闸门误用造成乘客不能出站，提示操作员可免费放乘客离开"},
//	{RW_EC_EXIT_OUTRANGE_AND_TIMEOUT,				"既超时又超乘","需要更新"},
//	{RW_EC_INVALID_API_CALL	,						"非法的接口调用","调用设备环境初始化时传入的设备类型不允许调用当前接口"},
//	{RW_EC_UNSUPPORT_TICKETTYPE_ON_CURRENT_DEVICE,	"设备不支持的票卡类型","某些设备上需要屏蔽部分票卡的使用"},
//	{RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKET,			"进行处理的车票与分析时的车票不是同一张","BOM的相关操作要根据分析的结果，主要是防止分析和操作的卡不同，而操作时的判断范围有限"},
//	{RW_EC_PROCESS_ANALYZE_NOT_SAME_TICKETCONTENT,	"票卡当前调用非法","主要作用,在0x42的基础上,车票在本地分析,在异地进行相关操作后,再回本地进行操作。如发售和充值等"},
//	{RW_EC_ILLEGAL_INPUT_PARAM,						"非法的传入参数","调用某些接口时，会对传入的参数进行范围判断，不在规定范围内的认定为非法"},
//	{RW_EC_DEVICE_UNINITIALIZE,						"设备未初始化","提醒设备程序调用设备环境初始化接口"},
//	{RW_EC_UNKNOWN_COMMAND,							"不存在的命令地址","命令码或者命令类码不合格"},
//	{RW_EC_PARAMETER_FILE_NOT_EXIST,				"参数文件不存在","参数文件不存在"},
//	{RW_EC_PARAMETER_FILE_ILLEGAL,					"参数文件不合法","校验错误	"},
//	{RW_EC_FILE_PROCESS_ERROR,						"文件错误","包括创建，打开，读和写失败"},
//	{RW_EC_INVALID_INPUT_PARAM,						"无效的输入参数","--"}, //不知道和非法的输入参数有什么区别?????????
//	{RW_EC_COMM_OPEN_PORT,							"通讯句柄打开错误" , "--"},
//	{RW_EC_COMM_WRITE_FAILE,						"通讯发送数据失败","GUI需要关闭读写器连接，然后重新打开"},
//	{RW_EC_COMM_READ_FAILED,						"通讯接收数据失败","GUI需要关闭读写器连接，然后重新打开"},
//	{RW_EC_COMM_DATA_INVALID,						"通讯数据非法","数据不完整，格式错误或者校验错误"},
//	{RW_ERR_SAM_RESPONSE,							"SAM卡响应错误","需重新初始化操作或者未安装SAM卡"},
//};


//API错误码取值
typedef enum
{

	RW_SUBEC_OK							=0x00,//正确
	RW_SUBEC_LOGICAL_PERIOD_TIMEOUT		=0x01,//票种过期
	RW_SUBEC_LAST_EXIT_BELOW_X_MINUTE	=0x02,//上次出站在X秒内
	RW_SUBEC_WITHDRAW_TICKET			=0x10,//回收票
	RW_SUBEC_NEED_CONFIRM_TRANSACTION	=0x11,//需要进行交易确认
	RW_SUBEC_TRAIN_FAULT				=0x12,//列车故障模式出站

}RW_ENUM_API_ERR_SUBCODE;


typedef struct _STRU_RW_API_ERR_SUBCODE_TABLE
{
	RW_ENUM_API_ERR_SUBCODE	Code;			//生命周期代码
	char				Description[50];	//中文含义描述
	char				Maintance[512];		//维护方式
}STRU_RW_API_SUBCODE_TABLE;

////读卡器返回值
//const STRU_RW_API_SUBCODE_TABLE RW_API_SUBCODE_TABLE[]=
//{
//	{RW_SUBEC_OK,							"正确","无错误描述文字，仅表示无关联提示信息"},
//	{RW_SUBEC_LOGICAL_PERIOD_TIMEOUT,		"票种过期","正对某些特殊性质的票卡，有效期过了仍然可以当作其他票种使用，如学生票过期后按普通票扣费，视具体业务规则使用一般在查找票价前需要判断"},
//	{RW_SUBEC_LAST_EXIT_BELOW_X_MINUTE,	"上次出站在X秒内","X是固定值（暂定180）。对于某些付费区分析无进站码，但是上次刷卡出闸的时间很近，程序认为上次扣费正常，闸机扇门未正常打开或者被前面尾随人员占用。可由操作员自行处理是直接开边门还是更新票卡关联错误码：0x28付费区无进站码"},
//	{RW_SUBEC_WITHDRAW_TICKET,				"回收票","单程票出站刷卡成功时，根据当前值回收单程票，其他情况下主要是提示BOM操作人员没收不能使用的单程票主要在闸机进出闸和BOM分析时，BOM在对应区域分析时如果该字段有效，操作员应没收单程票，出闸错误码为0时也应回收单程票"},
//	{RW_SUBEC_NEED_CONFIRM_TRANSACTION,		"需要进行交易确认","处理：BOM接口时需调用交易确认接口，关联的错误码：0x05写卡失败"},
//	{RW_SUBEC_TRAIN_FAULT,					"列车故障模式出站","处理：出闸机放行，单程票不回收 关联错误代码：0"},
//};


typedef struct tag_CARD_STATUS_PROCESS_INFO_ACC_UL
{
	// 状态信息(0)

//	uint16	ProcessLine:6;	//最近一次处理线路
//	uint16	ProcessStation:6;//最近一次处理站点
//	uint16	ProcessEquType:4;//最近一次处理发生的设备类型
//	uint16	ProcessEquCode:10;//最近一次处理发生的设备编码
//	uint16	CardValue:14;		//最近一次处理发生后车票剩余额度
//	uint16	CardStatus:5;	//最近一次处理发生后车票所处状态
//	uint16	CardSpecialFlag:3;//最近一次处理发生后特殊标记
//	uint16	InGateLine:6;	//入站线路
//	uint16	InGateStation:6;	//入站站点
//	uint16	RFU0:4;		//保留

	uint32	ProcessLine;	//最近一次处理线路
	uint32	ProcessStation;//最近一次处理站点
	uint32	ProcessEquType;//最近一次处理发生的设备类型
	uint32	ProcessEquCode;//最近一次处理发生的设备编码
	uint32	CardValue;		//最近一次处理发生后车票剩余额度
	uint32	CardStatus;	//最近一次处理发生后车票所处状态
	uint32	CardSpecialFlag;//最近一次处理发生后特殊标记
	uint32	InGateLine;	//入站线路
	uint32	InGateStation;	//入站站点
	uint32	RFU0;		//保留
}CARD_STATUS_PROCESS_INFO_ACC_UL;


typedef struct tag_CARD_STATUS_INFO_ACC_UL
{
	// 状态信息(0)
	uint8	ProcessTime[7];//最近一次处理时间(GMT)
	CARD_STATUS_PROCESS_INFO_ACC_UL ProcessInfo;
//	uint8	ProcessLine0;	//最近一次处理线路
//	uint8	ProcessStation0;//最近一次处理站点
//	uint8	ProcessEquType0;//最近一次处理发生的设备类型
//	uint16	ProcessEquCode0;//最近一次处理发生的设备编码
//	uint16	CardValue0;		//最近一次处理发生后车票剩余额度
//	uint8	CardStatus0;	//最近一次处理发生后车票所处状态
//	uint8	CardSpecialFlag0;//最近一次处理发生后特殊标记
//	uint8	InGateLine0;	//入站线路
//	uint8	InGateStation0;	//入站站点
//	uint8	RFU0[2];		//保留
	uint16	TransactionTotal;//交易累计
	uint8	Check;			//效验
}CARD_STATUS_INFO_ACC_UL;

//szp   ul 卡原始数据结构-- 地铁ACC
typedef struct tag_CARD_ACC_UL
{

	// 初始信息
	uint8	CardPhyID[7];
	//系统锁定
	uint8	CardLock[2];
	//(OTP)保留
	uint8	OTP[4];
	// 发行信息
	uint8	SystemFlowID[4];//系统流水BCD
	uint8	MAC_Code[4];	//认证信息
	uint8	IssueDate[4];	//发行日期(TM2)+测试标记（0:正式卡   1:测试卡）
	uint8	TestFlag;	//测试标记 （0:正式卡   1:测试卡）
	uint8	MainType;	//主类型
	uint8	SubType;		//子类型
	uint8 	TicketCode[2];	//车票代码+效验位
	uint8	RFU[2];			//保留

	CARD_STATUS_INFO_ACC_UL cardProcessInfo[2];

	uint8   StatusPointer;  //状态指针 0 :状态 0; 1 :状态 1
	uint16  TranTotalNumber;  //状态指针 0 :状态 0; 1 :状态 1


	uint8	CardUL[65];		// 原始数据

}CARD_ACC_UL;

//MF_EF05
typedef struct _ST_ACC_CPU_CARD_MF_EF05_
{
	uint8 IssuerCode[2];//	发卡方代码
	uint8  CityCode[2];  //城市代码
	uint8  IndustryCode[2];//行业代码
	uint8  TestFlag;//测试标记
	uint8  Reserved1;//保留数据
	uint8  AppSn[8];//应用序列号
	uint8  MainType;//卡类型
	uint8  SubType;//卡子类型
	uint8  IssueDate[4];//发行日期（YYYYMMDD）
	uint8  IssueDeviceInfo[6];//发行设备信息
	uint16 CardVersionNo;//卡版本号。
	uint8  CardActiveDate[4];//卡启用日期（YYYYMMDD）
	uint8  CardValidDate[4];//卡有效日期（YYYYMMDD）。
	uint8  Reserved2[2];//保留数据
}ST_ACC_CPU_CARD_MF_EF05;

//ADF1_EF15
typedef struct _ST_ACC_CPU_CARD_ADF_EF15_
{
	uint8 IssuerCode[2];//	发卡方代码
	uint8  CityCode[2];  //城市代码
	uint8  IndustryCode[2];//行业代码
	uint8  Reserved1[2];//保留数据
	uint8  AppTypeFlag;//应用类型标识（启用标志）
	uint8  AppVersion;//应用版本
	uint8  Reserved2[2];//保留数据
	uint16 AppVersionNo;//应用序列号。
	uint8  AppActiveDate[4];//应用启用日期（YYYYMMDD）
	uint8  AppValidDate[4];//应用有效日期（YYYYMMDD）。
	uint8  Reserved3[2];//保留数据
}ST_ACC_CPU_CARD_ADF_EF15;

//ADF1_EF16
typedef struct _ST_ACC_CPU_CARD_ADF_EF16_
{
	uint8  CustomType;//持卡人类型标识 
	uint8  CustomSubType;//本单位职工标识
	uint8  CustomName[20];//持卡人姓名。
	uint8  CustomIDCode[32];//持卡人证件号码
	uint8  CustomIDType;//持卡人证件类别
	uint8  CustomSex;//持卡人性别
	uint8  Reserved1[36];//保留数据
}ST_ACC_CPU_CARD_ADF_EF16;

//ADF1_EF17_01 交易辅助
typedef struct _ST_ACC_CPU_CARD_ADF_EF17_01_
{
	uint8  Reserved0;//复合消费标志
	uint8  Reserved1;//记录长度。
	uint8  AppLockFlag;//应用锁定标志位。
	uint8  Reserved2[45];//保留数据

}ST_ACC_CPU_CARD_ADF_EF17_01;

//ADF1_EF17_02 轨道交通
typedef struct _ST_ACC_CPU_CARD_ADF_EF17_02_
{
	uint8  Reserved0;//复合消费标志
	uint8  Reserved1;//记录长度。
	uint8  AppLockFlag;//应用锁定标志位。
	uint8  Reserved2;//记录版本。
	uint8	CardStatus0;	//最近一次处理发生后车票所处状态
	uint8	InGateLine;	//入站线路
	uint8	InGateStation;	//入站站点
	uint16	InGateDeviceCode;//入站设备类型及编码
	uint8	InGateTime[7];//入站处理时间(GMT)
	uint8	ProcessLine;	//最近一次处理线路
	uint8	ProcessStation;//最近一次处理站点
	uint16	ProcessEquCode;//最近一次处理发生的设备类型及编码
	uint8	ProcessTime[7];//最近一次处理时间(GMT)
	uint8	UpdateCount;//行政处理次数(当日)
	uint8	Reserved3[20];		//保留
	uint8	CardStatus;	//最近一次处理发生后车票所处状态
	uint8	CardSpecialFlag;//最近一次处理发生后特殊标记
}ST_ACC_CPU_CARD_ADF_EF17_02;

//ADF1_EF17_11 应用控制记录
typedef struct _ST_ACC_CPU_CARD_ADF_EF17_11_
{
	uint8  Reserved0;//复合消费标志
	uint8  Reserved1;//记录长度。
	uint8  AppLockFlag;//应用锁定标志位。
	uint8  Reserved2;//记录版本。
	uint8  AppActiveBeginTime[7];//应用激活起始时间
	uint8  AppActiveEndTime[7];//应用激活起始时间
	uint8   IssueActiveFlag; //发售激活标志
	uint8   IssueDeposit;//发售押金（元）
	uint8   IssueDeviceInfo[6];//发售设备信息
	uint16   TopupLimit;  //充值上限。
	uint8	Reserved3[20];		//保留
}ST_ACC_CPU_CARD_ADF_EF17_11;

//ADF1_EF11 辅助信息文件
typedef struct _ST_ACC_CPU_CARD_ADF_EF11_
{
	uint8   EntryExitMode;		//出入模式判断
	uint8   AllowEntryLineCode;		//可入线路
	uint8   AllowEntryStationCode;		//可入站点
	uint8   AllowExitLineCode;		//可出线路
	uint8   AllowExitStationCode;		//可出站点
	uint8	Reserved3[27];		//保留
}ST_ACC_CPU_CARD_ADF_EF11;
//ADF1_历史交易机
typedef struct _ST_ACC_CPU_CARD_ADF_HISTORY_
{
	uint16  TranSN;		//脱机交易序号
	uint8   Reserved[3];		//保留数据
	long   TranValue;		//交易金额
	uint8   TranType;		//交易类型标识
	uint8   TranDeviceCode[6];		//交易终端编码
	uint8	TranTime[7];		//终端交易时间(YYYYMMDDHHMMSS)3[27];		//保留
}ST_ACC_CPU_CARD_ADF_HISTORY;


//szp   cpu 卡原始数据结构-- 地铁ACC
typedef struct tag_CARD_ACC_CPU
{
	ST_ACC_CPU_CARD_MF_EF05	IssueInfo_0005;			// 发卡基本信息文件0005 
	ST_ACC_CPU_CARD_ADF_EF15	PublicInfo_0015;		// 公共应用基本数据文件0015
	ST_ACC_CPU_CARD_ADF_EF16	PersonInfo_0016;		// 持卡人基本信息文件0016
	int32	Purse_EP_0002;					// 公共电子钱包0002
	uint8	LocalTradeRecord_0018[10][23];// 本地消费明细文件0018
	uint8	OtherTradeRecord_0010[10][23];// 异地消费明细文件0010
	uint8	TopupTradeRecord_001A[10][23];// 充值明细文件001A
	ST_ACC_CPU_CARD_ADF_EF17_01 TranRecord_01;            // 复合交易记录文件0017 01 交易辅助
	ST_ACC_CPU_CARD_ADF_EF17_02 TranRecord_02; 			 // 复合交易记录文件0017 02 轨道交通
	uint8	RFU1[48*4];					// 保留数据文件 公交应用 
	ST_ACC_CPU_CARD_ADF_EF17_11 TranRecord_11; // 复合交易记录文件0017 02  应用控制记录


	ST_ACC_CPU_CARD_ADF_EF11	AssistInfo_0011;		// 辅助信息文件0011
	uint8	RFU2[32];					// 保留数据文件0012

	int32	EP_BeforValue;				//交易前金额
	uint16	TradeMoney;					//交易金额
	int32	EP_AfterValue;				//交易后金额
	
	//原始数据
	uint8	Info_0005[40];
	uint8	Info_0015[30];
	uint8	Info_0016[92];
	uint8	Info_0002[4];
	uint8	Info_0018[10][23];
	uint8	Info_0010[10][23];
	uint8	Info_001A[10][23];
	uint8	Info_0017[7][48];
	uint8	Info_0011[32];
	uint8	Info_0012[32];

}ST_CARD_ACC_CPU;




typedef struct _ST_Param_Info_
{
	/*参数文件消息
	0：下载准备
	1：下载完成，参数生效
	*/
	uint8 u8MessageType;

	uint32 u32FileSize;//文件大小
	uint8 u8CRC[4];//文件crc32校验值
	uint8 u8FileNameLength;//文件名有效长度
	char FileName[256];//文件名
}ST_Parameter_Info;
#pragma pack(pop)

//1=现金，2=储值卡，3=一卡通
typedef enum _Token_PaymentType_
{
	EM_TOKEN_PAYMENT_TYPE_CASH=1,
	EM_TOKEN_PAYMENT_TYPE_SVC=2,
	EM_TOKEN_PAYMENT_TYPE_YKT=3,
}EM_TOKEN_PAYMENT_TYPE;

//长沙特殊标记
typedef enum _EM_CS_SPEC_FLAG_
{
	EM_CS_SPEC_FLAG_NORMAL=1,//正常
	EM_CS_SPEC_FLAG_FORBID=2,//禁止使用（退卡、非即时退款申请、行政处理）
	EM_CS_SPEC_FLAG_FAVOURABLE=3,//优惠标记
	EM_CS_SPEC_FLAG_BLACK_LIST=7,//黑名单。
}EM_CS_SPEC_FLAG;

//1－付费区，2－非付费区
typedef enum _EM_AREA_TYPE_
{
	EM_CS_AREA_TYPE_PAID_AREA=1,
	EM_CS_AREA_TYPE_UNPAID_AREA=2,
}EM_AREA_TYPE;

//状态机
typedef enum _EM_CS_RW_STATUS_
{
	EM_CS_RW_STATUS_FREE,//空闲
	EM_CS_RW_STATUS_READED,//已读到卡
	EM_CS_RW_STATUS_NEED_TO_CONFIRM,//交易未确定

}EM_CS_RW_STATUS;

//13.2. 交易类型代码定义
/*50	单程票售票记录
51	非单程票售票记录
52	记名卡申请
53	进站记录
54	钱包交易
55	票卡延期
56	票卡更新
57	退卡记录
58	非即时退款申请
59	卡加锁/解锁
60	卡被拒绝
61	行政处理
*/

typedef enum _EM_CS_TRAN_TYPE_
{
	EM_CS_TRAN_TYPE_SALE_SJT=50,//单程票售票记录
	EM_CS_TRAN_TYPE_SALE_SVT=51,//非单程票售票记录
	EM_CS_TRAN_TYPE_APPLICATION=52,//记名卡申请
	EM_CS_TRAN_TYPE_ENTRY=53,//进站记录
	EM_CS_TRAN_TYPE_PURSE=54,//钱包交易
	EM_CS_TRAN_TYPE_DELAY=55,//票卡延期
	EM_CS_TRAN_TYPE_UPDATE=56,//票卡更新
	EM_CS_TRAN_TYPE_REFUND=57,//退卡记录
	EM_CS_TRAN_TYPE_REFUND_APPLICATION=58,//非即时退款申请
	EM_CS_TRAN_TYPE_LOCK=59,//卡加锁/解锁
	EM_CS_TRAN_TYPE_REFUSE=60,//卡被拒绝
	EM_CS_TRAN_TYPE_ADM=61,//行政处理
}EM_CS_TRAN_TYPE;

//通道类型
//1	0	byte	1：普通通道（不接受优惠票）
//2：专用通道（只接受优惠票）
//3：正常通道（接受所有票票种）
typedef enum _EM_AG_AISLE_TYPE_
{
	EM_AG_AISLE_TYPE_NORMAL=1,//普通通道（不接受优惠票）
	EM_AG_AISLE_TYPE_SEC=2,//专用通道（只接受优惠票）
	EM_AG_AISLE_TYPE_ALL=3,//正常通道（接受所有票票种）
}EM_AG_AISLE_TYPE;

#endif

