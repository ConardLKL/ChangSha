#ifndef __YKTM1CARDENTITY_H__
#define __YKTM1CARDENTITY_H__

#include "../DataTypeDefine.h"
#include "../CSReaderCode.h"
#include "../CSYKTCardStruct.h"
#include "../XPublic/XTime.h"
#include "../XPublic/XDigital.h"
#include "../Globle.h"
#include "inc/LinuxHardwareDriver.h"

int Rfmif_Read_Data(uint8 u8Antenna,ST_CARD_YKT_M1 * stYktM1Info,BOOL bReadHistory);

//ConsumeFlag 00:普通消费   01:复合消费
int Rfmif_Write_Data(uint32 u32ConsumeMoney,ST_CARD_YKT_M1 * stYktM1Info,uint8 ConsumeFlag,uint16 *u8TerminalTradeNum);

void Rfmif_ProcessTime4ToBCD(unsigned char *pHexString, unsigned char *pBcd);

int Rfmif_TimeStrToProcessTime4(const char *pszStrDatetime,unsigned char *pszDestDatetime);

int Rfmif_Write_BlackList(ST_CARD_YKT_M1 * stYktM1Info);



#endif
