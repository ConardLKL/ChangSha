#include "PollingCardEntity.h"

void M500PcdRfReset()
{
	Rf_OnOff(0);
	Sleep(8);
	Rf_OnOff(1);
	Sleep(10);
}

int PollingCard(char AntennaMode,unsigned char *ucCardPhType,unsigned char *ucCardPhId,unsigned char *ucCardPhIdLen)
{
	printf("PollingCard\r\n");

	if(ucCardPhType==NULL||ucCardPhId==NULL||ucCardPhIdLen==NULL)
	{
		return CE_PARAM_ERROR;
	}

	int iRet=-1;

	*ucCardPhType=0x01;
	*ucCardPhIdLen=10;
	int i=0;
	INT32U sLot=AntennaMode+1;
	//INT32U sLot=1;
	unsigned char len=0;
	unsigned char IDM[10];
	unsigned short ATQA=0;
	unsigned char SAK=0;
	unsigned char ATS[20];
	unsigned char Serial[4];
	unsigned char TmpBuff[400];
	INT16U 	cpuApdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;
	memset(IDM,0x00,sizeof(IDM));
	memset(ATS,0x00,sizeof(ATS));
	memset(Serial,0x00,sizeof(Serial));



	SelectRFIDSlot(sLot);

	printf("SelectRFIDSlot(sLot=%d)\r\n",sLot);


	M500PcdRfReset();


	for(i=0;i<3;i++){

		iRet=Rfa_GetSNR(0,&len,IDM);
		switch(iRet)
		{
		  case 0:
			  break;
		  case 0x2a20:
			  printf("RFID............... MUL Card\r\n");
			  return RW_EC_MULTI_CARD_FOUND;
		  default:
			  printf("RFID............... NO Card iRet[%02X]\r\n",iRet);
			  continue;
		}

//		if(Rfa_GetSNR(0,&len,IDM)) continue;
//		printf("Rfa_GetSNR1_OK\r\n");


		ATQA =IDM[len-1]*256+IDM[len-2];
		SAK =IDM[len-3];
		printf("IDLE:ATQA =%04X,SAK=%02X\r\n",ATQA,SAK);
		Rfa_Halt();
		if(Rfa_GetSNR(0,&len,IDM) == 0){
			printf("RFID............... MUL Card\r\n");
			return RW_EC_MULTI_CARD_FOUND;
		}
		printf("Rfa_OneCard_OK(sLot=%d)\r\n",sLot);
		memcpy(Serial,IDM,4);


		if(Rfa_GetSNR(1,&len,IDM) == 0)
		{
			printf("Rfa_GetSNR ........... is SUCCES:Len=%d,SN=%s\r\n",len,BCD2ASC(IDM,len));
			ATQA =IDM[len-1]*256+IDM[len-2];
			SAK =IDM[len-3];
			memcpy(ucCardPhId,IDM,10);
			printf("HALT:ATQA =%04X,SAK=%02X\r\n",ATQA,SAK);
			if(((SAK& 0x20) != 0)  && (ATQA == 0x0008))
			{
				//步骤1：复位Cpu卡片
				if(Rfa_RATS(RevBuff))
				{
					printf("AccCpu_Reset....RATS is FAILE\r\n");
					return RW_EC_READ_FAILED;
			    }
				printf("AccCpu_Reset.......ATS=%s\r\n",BCD2ASC(RevBuff,10));
				*ucCardPhType = ACC_CPU_CARD;
				printf("RFID...............AccCpu\r\n");
				return 0;

			}
			else if(((SAK& 0x20) != 0)  && (ATQA == 0x0004))
			{

				//步骤1：复位Cpu卡片
				if(Rfa_RATS(RevBuff)){
					printf("PhoneCpu_Reset....RATS is FAILE\r\n");
					return RW_EC_READ_FAILED;
				}

				//步骤1：读0005发行基本信息文件  00B0850002//28
				TmpBuff[0] =0x00;
				TmpBuff[1] =0xA4;
				TmpBuff[2] =0x00;
				TmpBuff[3] =0x00;
				TmpBuff[4] =0x02;
				TmpBuff[5] =0x3F;
				TmpBuff[6] =0x00;
				if(Rfa_APDU(TmpBuff,7,RevBuff,&cpuApdu_rlen)){
					printf("APDU 00 A4 3F  00 Error\r\n");
					return RW_EC_READ_FAILED;
				}
				sw =RevBuff[cpuApdu_rlen-2]*256+RevBuff[cpuApdu_rlen-1];
				printf("Read A4 3F 00 OK!Data=%s\r\n",BCD2ASC(TmpBuff,5));
				printf("APDU:Len=%d,SW=%04X,Data=%s\r\n",cpuApdu_rlen,sw,BCD2ASC(RevBuff,cpuApdu_rlen));
				if(sw != 0x9000)
				{
					printf("Read 3F 00 Failed,test0\r\n");
					return RW_EC_READ_FAILED;
				}
				printf("Read 3F 00 OK,test1\r\n");

				//步骤2：读0005发行基本信息文件  00B0850002//28
				TmpBuff[0] =0x00;
				TmpBuff[1] =0xB0;
				TmpBuff[2] =0x85;
				TmpBuff[3] =0x00;
				TmpBuff[4] =0x1C;
				if(Rfa_APDU(TmpBuff,5,RevBuff,&cpuApdu_rlen)){
					printf("APDU 00 B0 read 0005 Error\r\n");
					return RW_EC_READ_FAILED;
				}
				sw =RevBuff[cpuApdu_rlen-2]*256+RevBuff[cpuApdu_rlen-1];
				printf("Read 0005 OK!Data=%s\r\n",BCD2ASC(TmpBuff,5));
				printf("APDU:Len=%d,SW=%04X,Data=%s\r\n",cpuApdu_rlen,sw,BCD2ASC(RevBuff,cpuApdu_rlen));
				if(sw != 0x9000)
				{
					printf("Read 0005 Failed,test0\r\n");
					return RW_EC_READ_FAILED;
				}
				printf("Read 0005 OK,test1\r\n");

				if((RevBuff[0]==0x07&&RevBuff[1]==0x31))//||(RevBuff[0]==0x53&&RevBuff[0]==0x02)//目前拿到的测试卡是0731，不确定5302的卡结构和0731卡结构是否一样，待遇到该类型的卡再判断
				{
					printf("ucCardPhType= ACC_NFC_CPU_CARD\r\n");
					*ucCardPhType = ACC_NFC_CPU_CARD;
				}
				else if(RevBuff[0]==0x59&&RevBuff[1]==0x44)
				{

					if(RevBuff[27]!=0x00)//启用标识
					{
						printf("ucCardPhType= CITY_CPU_CARD\r\n");
						*ucCardPhType = CITY_CPU_CARD;
					}else
					{
						M500PcdRfReset();

						if(Rfa_GetSNR(0,&len,IDM) != 0)
						{
							printf("RFID............... NO Card\r\n");
							return RW_EC_NO_CARD_FOUND;
						}
						printf("ucCardPhType= CITY_M1_CARD\r\n");
						*ucCardPhType = CITY_M1_CARD;
					}
				}
				else
				{
					printf("Unknown card\r\n");
					return RW_EC_UNKNOWN;
				}//非标准地铁CPU卡或一卡通CPU卡
				memcpy(Serial,IDM,4);

				return 0;
			}
			else if(ATQA == 0x0004){
				printf("RFID...............MIFARE 1K\r\n");


				//步骤1：复位Cpu卡片
				if(Rfa_RATS(RevBuff)){
					printf("PhoneCpu_Reset....RATS is FAILE\r\n");
					return RW_EC_UNKNOWN;
				}


				memcpy(Serial,IDM,4);
				*ucCardPhType = CITY_M1_CARD;
				//Beep(100);
				printf("RFID...............MIFARE\r\n");
				return 0;
			}
			else if(ATQA == 0x0044)
			{
				printf("RFID...............ultralight\r\n");
				*ucCardPhType = ACC_UL_CARD;
				//Beep(100);
				printf("RFID...............ultralight\r\n");
				return 0;
			}

//			Rf_OnOff(0);
//			Beep(100);
//			Rf_OnOff(1);
		}

	}
	printf("Rfa_GetSNR3_Error\r\n");

	return RW_EC_NO_CARD_FOUND;

}
