/*********************************************************
*程序名称:		ULCard_Entity.h
*版本号:		0.1			
*功能描述:		 <<长沙轨道交通1号线读卡器接口调用API文档.docx>>文档中,
				所有的与上位机的接口处理函数都定义在本文件中,函数名称与文档中的名称一致.
*作者:			licd			
*修改记录:		
				2015.01.13 创建 
*其他:						
***********************************************************/

#ifndef __ULCARDENTITY_H__
#define __ULCARDENTITY_H__

#include "../DataTypeDefine.h"
#include "../CSReaderCode.h"
#include "../XPublic/XTime.h"
#include "../XPublic/XDigital.h"


//int READ_UL_CARD_ISSUE_INFO(uint8 u8Antenna,CARD_ACC_UL * stULCardInfo);

int Read_ULCard_All_Info(unsigned char * szCardInfo);

int Write_ULCard_Info(uint8 u8Antenna,unsigned char * szCardInfo,uint8 point);

uint8 cal_crc8(unsigned char  *ptr, int len, unsigned char initv);
void decrypt(unsigned char *key, unsigned char *buffer);//解密
void encrypt(unsigned char *key, unsigned char *buffer);//加密

void ProcessTime2ToBCD(unsigned char *pHexString, unsigned char *pBcd);

void ProcessTime4ToBCD(unsigned char *pHexString, unsigned char *pBcd);

int TimeStrToProcessTime4(const char *pszStrDatetime,unsigned char *pszDestDatetime);

int TimeStrToProcessTime2(const char *pszStrDatetime,unsigned char *pszDestDatetime);

#endif
