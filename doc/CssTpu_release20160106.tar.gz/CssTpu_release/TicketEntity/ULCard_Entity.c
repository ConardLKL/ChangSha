#include "ULCard_Entity.h"
#include "PollingCardEntity.h"


static	uint8	CRC1_Check;		//信息1校验初始值
static	uint8	CRC2_Check;		//信息2校验初始值
static	uint8	KeyInit[4];		//加解密钥初始值



uint8 cal_crc8(unsigned char  *ptr, int len, unsigned char initv)
{
	unsigned char crc;
	unsigned char i;
	crc = initv;
	while(len--)
	{
		crc ^= *ptr++;
		for(i = 0;i < 8;i++)
		{
			if(crc & 0x01)
			{
				crc = (crc >> 1) ^ 0x8C;
			}
			else
			{
			 crc >>= 1;
			}
		}
	}
	return crc;
}


void decrypt(unsigned char *key, unsigned char *buffer)//解密
{
	unsigned char tmp_key[4];
	int i=0;

	memcpy(tmp_key, key, 4);
	for (i = 0; i < 4; i++)
	{
		buffer[i*4] = buffer[i*4] ^ tmp_key[0];
		buffer[i*4+1] = buffer[i*4+1] ^ tmp_key[1];
		buffer[i*4+2] = buffer[i*4+2] ^ tmp_key[2];
		buffer[i*4+3] = buffer[i*4+3] ^ tmp_key[3];

		tmp_key[0] = buffer[i*4];
		tmp_key[1] = buffer[i*4+1];
		tmp_key[2] = buffer[i*4+2];
		tmp_key[3] = buffer[i*4+3];
	}
}

void encrypt(unsigned char *key, unsigned char *buffer)//加密
{
	unsigned char tmp_key[4];
	unsigned char tmp_buff[16];
	int i=0;

	memcpy(tmp_key, key, 4);
	memcpy(tmp_buff, buffer, 16);
	for (i = 0; i < 4; i ++)
	{
		buffer[i*4] = buffer[i*4] ^ tmp_key[0];
		buffer[i*4+1] = buffer[i*4+1] ^ tmp_key[1];
		buffer[i*4+2] = buffer[i*4+2] ^ tmp_key[2];
		buffer[i*4+3] = buffer[i*4+3] ^ tmp_key[3];

		tmp_key[0] = tmp_buff[i*4];
		tmp_key[1] = tmp_buff[i*4+1];
		tmp_key[2] = tmp_buff[i*4+2];
		tmp_key[3] = tmp_buff[i*4+3];
	}
}

int Read_ULCard_All_Info(unsigned char * szCardInfo)
{
	unsigned char crc=0;
	CARD_ACC_UL  stULCardInfo;
	memset(&stULCardInfo,0,sizeof(CARD_ACC_UL));
	unsigned char CheckBuff[6]={0};

	if(Rful_Read(0,&(szCardInfo[0]))){
		printf("Read  BLOCK0...........Error\r\n");
		return 1;
	}
	printf("Read  BLOCK0...........OK\r\n");

	if(Rful_Read(4,&(szCardInfo[16]))){
		printf("Read  BLOCK16...........Error\r\n");
		return 1;
	}
	printf("Read  BLOCK1...........OK\r\n");

	memcpy(stULCardInfo.CardUL,szCardInfo,32);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard iRet= ",__FILE__,__LINE__);
	crc = PsamVerify_Issue_ULCard(stULCardInfo,CheckBuff);
	PrintLog("File[%s]Line[%d]Inner_Read_ULCard iRet=",__FILE__,__LINE__);
	if(crc != CE_OK)
	{
		return crc;
	}
	CRC1_Check = CheckBuff[0];
	CRC2_Check = CheckBuff[1];
	memcpy(KeyInit,&CheckBuff[2],4);


	if(Rful_Read(8,&(szCardInfo[32]))){
		printf("Read  BLOCK32...........Error\r\n");
		return 1;
	}
	printf("Read  BLOCK2...........OK\r\n");

	decrypt(KeyInit, &szCardInfo[32]);
	crc = cal_crc8(&szCardInfo[32], 15, CRC1_Check);
	if(crc != szCardInfo[47])
	{
		printf("Read  BLOCK2.........crc..Error\r\n");
		//return 1;
	}

	if(Rful_Read(12,&(szCardInfo[48]))){
		printf("Read  BLOCK48...........Error\r\n");
		return 1;
	}
	printf("Read  BLOCK3...........OK\r\n");
	decrypt(KeyInit, &szCardInfo[48]);
	crc = cal_crc8(&szCardInfo[48], 15, CRC2_Check);
	if(crc != szCardInfo[63])
	{
		printf("Read  BLOCK3.........crc..Error\r\n");
		//return 1;
	}


	return CE_OK;
}

int Write_ULCard_Info(uint8 u8Antenna,unsigned char * szCardInfo,uint8 point)
{
	//交易累计
	//校验


	int i=0;
	int iRet=0;
	unsigned char crc=0;
	uint8  PageData[16]={0};
	memcpy(PageData,szCardInfo,sizeof(PageData));
//	for(i=0;i<16;i++)//测试写卡
//	{PageData[i]=i;}

	//将CARD_STATUS_INFO_ACC_UL结构中的数据写入buff中（ PageData ）

	INT8U page=8+4*point;
	printf("point=%d\r\n",point);
	printf("Data=%02x%02x%02x%02x\r\n",PageData[0],PageData[1],PageData[2],PageData[3]);
	PrintLog("File[%s]Line[%d]Write_ULCard_Info point[%d]:",__FILE__,__LINE__,point);
	PrintLog("File[%s]Line[%d]Write_ULCard_Info Write_ULCard_Info:",__FILE__,__LINE__);
	PrintBuffer(PageData,16);
	if(point==0)//信息0
	{
		crc = cal_crc8(PageData, 15, CRC1_Check);
		PageData[15] = crc;
	}
	if(point==1)//信息1
	{
		crc = cal_crc8(PageData, 15, CRC2_Check);
		PageData[15] = crc;
	}
	encrypt(KeyInit, PageData);

	if(point==3)//3为测试
	{
		for(i=0;i<16;i++)//测试写卡
		{PageData[i]=i;}
		page=8;
	}

	PrintBuffer(PageData,16);
	if(Rful_Write(page,PageData)){
		printf("Write  BLOCK0...........Error page[%d]\r\n",page);
		return 1;
	}
	printf("Write  BLOCK0...........OK  page[%d]\r\n",page);

	page += 1;
	if(Rful_Write(page,PageData+4)){
		printf("Write  BLOCK1...........Error\r\n");
		return 1;
	}
	printf("Write  BLOCK1...........OK  page[%d]\r\n",page);

	page += 1;
	if(Rful_Write(page,PageData+8)){
		printf("Write  BLOCK2...........Error\r\n");
		return 1;
	}
	printf("Write  BLOCK2...........OK  page[%d]\r\n",page);

	page += 1;
	if(Rful_Write(page,PageData+12)){
		printf("Write  BLOCK3...........Error\r\n");
		return 1;
	}
	printf("Write  BLOCK3...........OK  page[%d]\r\n",page);

	printf("Write OK\r\n");

	return CE_OK;
}

BOOL ConvertDateTimeToTimeT(unsigned int uiTM4,unsigned int *uiTimeT)
{

	if(NULL==uiTimeT)
	{
		return FALSE;
	}

	unsigned short i=0;
	unsigned char leap=0;
	
	unsigned short years=0;
	unsigned char months=0;
	unsigned char days=0;
	unsigned char hours=0;
	unsigned char minutes=0;
	unsigned char seconds=0;

	years=((uiTM4&0xFFC00000>>22)/12)+2000; 

	months=((uiTM4&0xFFC00000>>22)%12)+1; 

	days  =  (uiTM4&0x003E0000)>>17;

	hours=(uiTM4&0x0001F000)>>12;

	minutes=(uiTM4&0x00000FC0)>>6;

	seconds=uiTM4&0x0000003F;

	//首先计算出距离2000-1-1 00:00:00有多少天
  for( i=2000;i<=(years-1);i++)
  {
  	//闰年366天,平年365天
  	if ( IsLeapYear(i))
 			days += 366;
		else
			days += 365;
  }
  if (IsLeapYear(years))
		leap = 1;
	else
		leap = 0;
    
  for( i=1;i<=months;i++) 
	  {
		  if(i==1||i==3||i==5||i==7||i==8||i==10||i==12)
		  {
			  days+=31;
		  }else if(i==2)
		  {
			  days=(leap==1)?29:28;
		  }else
		  {
			   days+=30;
		  }

	  }
	
	//转化出需要的TimeT值 
	*uiTimeT= days*(24*60*60) + hours*60*60 + minutes*60 + seconds;

	return TRUE;
}

BOOL ConvertTimeTtoDateTime(unsigned int uiTimeT,unsigned int *uiTM4)
{
	if(NULL==uiTM4)
	{
		return FALSE;
	}

	

	return TRUE;
}

/*! \fn		StringToBcd()
 * \brief 	字符串转BCD码
 * \param[in]  pString 字符串0x87 0x90”
 * \param[out] pBcd BCD码 0x20 0x45 0x03 0x08 0x13 0x23 0x45
 * \return 	 void
 * \author
 * \date
 */
void ProcessTime2ToBCD(unsigned char *pHexString, unsigned char *pBcd)
{
	if(pHexString == NULL || pBcd == NULL)
		return ;
	/*时间编码定义跨度为：2000年01月01日到2083年12月31日。
	举例：
	输入时间：2069年11月23日
	转换：
	月：距离2000年01月的距离为( 2069 – 2000 )×12 + ( 11 – 1 ) = 838( 二进制1101000110 )
	日：23( 二进制10111 )
	留用：0
	组合：1101 0001 1010 1110
	结果：D1 AE*/

	unsigned int iTotalMonth,year,month,day;
	unsigned int uiTemp0 = 0;
	unsigned int uiTemp1 = 0;

	uiTemp0 = pHexString[0];
	uiTemp1 = pHexString[1];

	iTotalMonth =(uiTemp0 << 2) + (uiTemp1 >> 6);
	year = 2000 + iTotalMonth / 12; //年
	month= iTotalMonth % 12 + 1;	//月
	day  = ((uiTemp1 & 0x3E) >> 1);	//日

	unsigned char szTmp[15] = {0};
	sprintf((char*)szTmp, "%04d%02d%02d", year, month, day);

	StringToBcd((char*)szTmp, pBcd);
	return;
}

/*! \fn		StringToBcd()
 * \brief 	字符串转BCD码
 * \param[in]  pString 字符串0x87 0x90 0xD5 0xED”
 * \param[out] pBcd BCD码 0x20 0x45 0x03 0x08 0x13 0x23 0x45
 * \return 	 void
 * \author
 * \date
 */
void ProcessTime4ToBCD(unsigned char *pHexString, unsigned char *pBcd)
{
	if(pHexString == NULL || pBcd == NULL)
		return ;
	unsigned int iTotalMonth,year,month,day,hour,minute,second;
	unsigned int uiTemp0 = 0;
	unsigned int uiTemp1 = 0;
	unsigned int uiTemp2 = 0;
	unsigned int uiTemp3 = 0;

	uiTemp0 = pHexString[0];
	uiTemp1 = pHexString[1];
	uiTemp2 = pHexString[2];
	uiTemp3 = pHexString[3];

	iTotalMonth =(uiTemp0 << 2) + (uiTemp1 >> 6);
	year = 2000 + iTotalMonth / 12; //年
	month= iTotalMonth % 12 + 1;	//月
	day  = ((uiTemp1 & 0x3E) >> 1);	//日
	hour = ((uiTemp1 & 1) << 4) | ((uiTemp2 >> 4));//小时
	minute = ((uiTemp2 & 0x0F)<< 2) | ((uiTemp3 >> 6));//分钟
	second = (uiTemp3 & 0x3F);//秒

	unsigned char szTmp[15] = {0};
	sprintf((char*)szTmp, "%04d%02d%02d%02d%02d%02d", year, month, day, hour, minute, second);
	StringToBcd(szTmp, pBcd);
	return;
}
/*TM4:1.4.3. 四字节时间编码
 时间编码定义跨度为：2000年01月01日 00:00:00 到2083年12月31日 23:59:59。
 举例：
	输入时间：2045年03月08日 13:23:45
 转换：
	月：距离2000年01月的距离为( 2045 - 2000 )×12 + ( 3 - 1 ) = 542( 二进制1000011110 )
	日：8( 二进制01000 )
	时：13( 二进制01101 )
	分：23( 二进制010111 )
	秒：45( 二进制101101 )
	组合：1000 0111  1001 0000 1101 0101 1110 1101
 结果：87 90 D5 ED
 */
int TimeStrToProcessTime4(const char *pszStrDatetime, unsigned char *pszDestDatetime)
{
	if(pszStrDatetime == NULL || pszDestDatetime  == NULL)
		return -1;

	char szTempString[5] = {0};
	//unsigned char szDestDatetime[10] = {0};
 	//unsigned int uiTemp0, uiTemp1, uiTemp2, uiTemp3;
	int  year, month, day, hour, minute, second;

	memcpy(szTempString, pszStrDatetime, 4);
	year = atoi(szTempString);

	memset(szTempString, 0, sizeof(szTempString));
	memcpy(szTempString, pszStrDatetime + 4, 2);
	month = atoi(szTempString);

	memset(szTempString, 0, sizeof(szTempString));
	memcpy(szTempString, pszStrDatetime + 6, 2);
	day = atoi(szTempString);

	memset(szTempString, 0, sizeof(szTempString));
	memcpy(szTempString, pszStrDatetime + 8, 2);
	hour = atoi(szTempString);

	memset(szTempString, 0, sizeof(szTempString));
	memcpy(szTempString, pszStrDatetime + 10, 2);
	minute =atoi(szTempString);

	memset(szTempString, 0, sizeof(szTempString));
	memcpy(szTempString, pszStrDatetime + 12, 2);
	second = atoi(szTempString);
	//2045年03月08日 13:23:45
	/*月：距离2000年01月的距离为( 2045 – 2000 )×12 + ( 3 – 1 ) = 542( 二进制1000011110 ) 10
	日：8( 二进制01000 ) 5
	时：13( 二进制01101 ) 5
	分：23( 二进制010111 ) 6
	秒：45( 二进制101101 )6
	组合：1000 0111  1001 0000 1101 0101 1110 1101
	结果：87 90 D5 ED*/
	ST_TM4 stTm4;
	memset(&stTm4, 0, sizeof(stTm4));
	stTm4.iTotalMonth = (year - 2000) * 12 + month - 1;    //距离2000年总的月数
	stTm4.iDay = day;
	stTm4.iHour = hour;
	stTm4.iMinute = minute;
	stTm4.iSecond = second;

	//注意位域字节序也是倒序的，因此需要转序处理。
	pszDestDatetime[0] = ((char*)&stTm4)[3];
	pszDestDatetime[1] = ((char*)&stTm4)[2];
	pszDestDatetime[2] = ((char*)&stTm4)[1];
	pszDestDatetime[3] = ((char*)&stTm4)[0];

	//memcpy(pszDestDatetime, &stTm4, 4);
	return 0;
}
/*TM2:两字节时间编码
 时间编码定义跨度为：2000年01月01日到2083年12月31日。
 举例：
 输入时间：2069年11月23日
 转换：
 月：距离2000年01月的距离为( 2069 - 2000 )×12 + ( 11 - 1 ) = 838( 二进制1101000110 )
 日：23( 二进制10111 )
 留用：0
 组合：1101 0001 1010 1110
 结果：D1 AE
 */
int TimeStrToProcessTime2(const char *pszStrDatetime, unsigned char *pszDestDatetime)
{
	if(pszStrDatetime == NULL || pszDestDatetime  == NULL)
		return -1;

	char szTempString[5] = {0};
	//unsigned int uiTemp0,uiTemp1;
	int year,month,day;

	memcpy(szTempString, pszStrDatetime, 4);
	year = atoi(szTempString);

	memcpy(szTempString, pszStrDatetime + 4, 2);
	month = atoi(szTempString);

	memcpy(szTempString, pszStrDatetime + 6, 2);
	day = atoi(szTempString);


	ST_TIME2 stTime2;
	memset(&stTime2, 0, sizeof(stTime2));
	stTime2.iMonth = (year - 2000) * 12 + month - 1;    //距离2000年总的月数
	stTime2.iDay = day;  //(iTotalMonth & 0xFF);
	stTime2.iResver = 0; //(((iTotalMonth & 0x0F00) << 6) |(day << 1) ) & 0xFE;

	pszDestDatetime[0] = ((char*)&stTime2)[1];
	pszDestDatetime[1] = ((char*)&stTime2)[0];

	return 0;
}
