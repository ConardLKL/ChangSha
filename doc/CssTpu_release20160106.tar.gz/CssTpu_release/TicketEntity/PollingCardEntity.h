#ifndef _POLLINGCARDENTITY_H
#define  _POLLINGCARDENTITY_H
#include "../CSReaderCode.h"

#include "inc/LinuxHardwareDriver.h"

void M500PcdRfReset();

int PollingCard(char AntennaMode,unsigned char *ucCardPhType,unsigned char *ucCardPhId,unsigned char *ucCardPhIdLen);

#endif
