#ifndef __YKTCPUCARDENTITY_H__
#define __YKTCPUCARDENTITY_H__
#include "../DataTypeDefine.h"
#include "../CSReaderCode.h"
#include "../CSYKTCardStruct.h"
#include "../XPublic/XTime.h"
#include "inc/LinuxHardwareDriver.h"


int Read_YKTCpuCard_All_Info(uint8 u8Antenna,ST_CARD_YKT_CPU * stYktCpuCardInfo,BOOL bReadHistory);

//yktCpu卡复合消费,普通消费  ,,//ConsumeFlag 00:普通消费   01:复合消费
int Write_YKTCpuCard_Recombine_Info(uint32 u32ConsumeMoney,uint8* bcdCurrentTime,ST_CARD_YKT_CPU * styktCpuCardInfo,uint8 ConsumeFlag,uint8 *TAC,uint32 *u8OutTerminalTradeNum);

int Write_Blacklist(ST_CARD_YKT_CPU * styktCpuCardInfo);

#endif
