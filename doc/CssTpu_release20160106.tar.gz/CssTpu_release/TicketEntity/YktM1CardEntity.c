#include "YktM1CardEntity.h"
#include "DataTypeDefine.h"
#include "CSReaderCode.h"
#include "Globle.h"
#include "./inc/DataType.h"



int Rfmif_Read_Data(uint8 u8Antenna,ST_CARD_YKT_M1 * stYktM1Info,BOOL bReadHistory)
{
	unsigned char szKeyA[6]={0};

	int iRet=-1;

	int iDataLength=0;


	unsigned char ucKeyAB=0x0A;

	//获取 KeyA
	iRet=Ykt_M1_GetM1KeyA(szKeyA);

	PrintLog("RFID...............Ykt_M1_GetM1KeyA Result[%d]",iRet);

	PrintBuffer((char*)szKeyA,6);

	unsigned char ucSecNo=0;

	unsigned char Serial[6]={0};

	//unsigned char RevBuff[512]={0};


	memcpy(Serial,g_BRContext.szCardPhID,6);


	//发行信息区  block no  0 1
	iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyA,Serial);
	PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Authen Failed,\r\n");
		return RW_EC_READ_FAILED;
	}

	iRet= Rfmif_Read((ucSecNo*4)+0, stYktM1Info->szIssueInfo+iDataLength);
	PrintBuffer((char*)stYktM1Info->szIssueInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Read Failed,\r\n");
		return RW_EC_READ_FAILED;
	}
	PrintLog(" Rfmif_Read OK,\r\n");

	iDataLength+=16;

	iRet= Rfmif_Read((ucSecNo*4)+1, stYktM1Info->szIssueInfo+iDataLength);
	PrintBuffer((char*)stYktM1Info->szIssueInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Read Failed,\r\n");
		return RW_EC_READ_FAILED;
	}

	PrintLog(" Rfmif_Read OK,\r\n");

	memcpy(&stYktM1Info->stIssueInfo,stYktM1Info->szIssueInfo,32);

	//应用索引区  block no s1b1  s1b2
	iDataLength=0;
	ucSecNo=1;

	iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyA,Serial);
	PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Authen Failed,\r\n");
		return RW_EC_READ_FAILED;
	}

	iRet= Rfmif_Read((ucSecNo*4)+1, stYktM1Info->szApplicationInfo+iDataLength);
	PrintBuffer((char*)stYktM1Info->szApplicationInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Read Failed,\r\n");
		return RW_EC_READ_FAILED;
	}
	PrintLog(" Rfmif_Read OK,\r\n");

	iDataLength+=16;

	iRet= Rfmif_Read((ucSecNo*4)+2, stYktM1Info->szApplicationInfo+iDataLength);
	PrintBuffer((char*)stYktM1Info->szApplicationInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Read Failed,\r\n");
		return RW_EC_READ_FAILED;
	}
	PrintLog(" Rfmif_Read OK,\r\n");

	//钱包区  block no  8 9

	if(stYktM1Info->stIssueInfo.SubType==0xA3||stYktM1Info->stIssueInfo.SubType==0x01)
	{

		iDataLength=0;
		ucSecNo=2;
		iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyA,Serial);
		PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
		if(iRet != 0)
		{
			PrintLog(" Rfmif_Authen Failed,\r\n");
			return RW_EC_READ_FAILED;
		}

		iRet= Rfmif_ReadValue((ucSecNo*4)+0, stYktM1Info->szPurseInfo+iDataLength);
		PrintBuffer((char*)stYktM1Info->szPurseInfo+iDataLength,16);
		if(iRet != 0)
		{
			PrintLog(" Rfmif_Read Failed,\r\n");
			return RW_EC_READ_FAILED;
		}
		PrintLog(" Rfmif_Read OK,\r\n");

	}else
	{
		//专用钱包
		iDataLength=0;
		ucSecNo=4;
		iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyA,Serial);
		PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
		if(iRet != 0)
		{
			PrintLog(" Rfmif_Authen Failed,\r\n");
			return RW_EC_READ_FAILED;
		}

		iRet= Rfmif_ReadValue((ucSecNo*4)+0, stYktM1Info->szPurseInfo+iDataLength);
		PrintBuffer((char*)stYktM1Info->szPurseInfo+iDataLength,16);
		if(iRet != 0)
		{
			PrintLog(" Rfmif_Read Failed,\r\n");
			return RW_EC_READ_FAILED;
		}
		PrintLog(" Rfmif_Read OK,\r\n");

	}

	//公共信息区  block no  s9b0  s9b1  s9b2
	iDataLength=0;
	ucSecNo=9;
	iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyA,Serial);
	PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Authen Failed,\r\n");
		return RW_EC_READ_FAILED;
	}

	iRet= Rfmif_Read((ucSecNo*4)+0, stYktM1Info->szPublicInfo+iDataLength);
	PrintBuffer((char*)stYktM1Info->szPublicInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Read Failed,\r\n");
		return RW_EC_READ_FAILED;
	}
	PrintLog(" Rfmif_Read OK,\r\n");

	iDataLength+=16;

	iRet= Rfmif_Read((ucSecNo*4)+1, stYktM1Info->szPublicInfo+iDataLength);
	PrintBuffer((char*)stYktM1Info->szPublicInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Read Failed,\r\n");
		return RW_EC_READ_FAILED;
	}
	PrintLog(" Rfmif_Read OK,\r\n");
	iDataLength+=16;
	iRet= Rfmif_Read((ucSecNo*4)+2, stYktM1Info->szPublicInfo+iDataLength);
	PrintBuffer((char *)stYktM1Info->szPublicInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Read Failed,\r\n");
		return RW_EC_READ_FAILED;
	}
	PrintLog(" Rfmif_Read OK,\r\n");
	//地铁信息区  block no  s11b0  s11b1  s11b2
	iDataLength=0;
	ucSecNo=11;
	iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyA,Serial);
	PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Authen Failed,\r\n");
		return RW_EC_READ_FAILED;
	}

	iRet= Rfmif_Read((ucSecNo*4)+0, stYktM1Info->szMetroInfo+iDataLength);
	PrintBuffer((char *)stYktM1Info->szMetroInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Read Failed,\r\n");
		return RW_EC_READ_FAILED;
	}
	PrintLog(" Rfmif_Read OK,\r\n");

	iDataLength+=16;

	iRet= Rfmif_Read((ucSecNo*4)+1, stYktM1Info->szMetroInfo+iDataLength);
	PrintBuffer((char *)stYktM1Info->szMetroInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Read Failed,\r\n");
		return RW_EC_READ_FAILED;
	}
	PrintLog(" Rfmif_Read OK,\r\n");
	iDataLength+=16;
	iRet= Rfmif_Read((ucSecNo*4)+2, stYktM1Info->szMetroInfo+iDataLength);
	PrintBuffer((char *)stYktM1Info->szMetroInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Read Failed,\r\n");
		return RW_EC_READ_FAILED;
	}
	PrintLog(" Rfmif_Read OK,\r\n");
	if(stYktM1Info->stIssueInfo.SubType==0xA3||stYktM1Info->stIssueInfo.SubType==0x01)
	{
	   memcpy(&stYktM1Info->uiTranSn,&stYktM1Info->szPublicInfo[3],2);
	   stYktM1Info->PurseFlag=0x01;
	}else
	{
	   memcpy(&stYktM1Info->uiTranSn,&stYktM1Info->szPublicInfo[5],2);
	   stYktM1Info->PurseFlag=0x02;
	}


	return 0;

}

int Rfmif_Write_Data(uint32 u32ConsumeMoney,ST_CARD_YKT_M1 * stYktM1Info,uint8 ConsumeFlag,uint16 *u8TerminalTradeNum)
{
	unsigned char szKeyA[6]={0};

	unsigned char szKeyB[6]={0};

	int iRet=-1;


	unsigned char ucKeyAB=0x0A;

	//获取 KeyA
	iRet=Ykt_M1_GetM1KeyA(szKeyA);

	PrintLog("RFID...............Ykt_M1_GetM1KeyA Result[%d]",iRet);

	PrintBuffer((char*)szKeyA,6);

	//获取 KeyB
	iRet=Ykt_M1_GetM1KeyB(szKeyB);

	PrintLog("RFID...............Ykt_M1_GetM1KeyB Result[%d]",iRet);

	PrintBuffer((char*)szKeyB,6);

	unsigned char ucSecNo=0;

	unsigned char Serial[6]={0};

	memcpy(Serial,g_BRContext.szCardPhID,6);

	PrintLog(" Rfmif_Write stYktM1Info.Purse[%d]<u32ConsumeMoney[%d],\r\n",stYktM1Info->Purse,u32ConsumeMoney);

	if((stYktM1Info->Purse)<u32ConsumeMoney)
	{
		PrintLog(" Rfmif_Write stYktM1Info.Purse<u32ConsumeMoney,\r\n");
		return RW_EC_AMOUNT_INSUFFICIENT;
	}


	// write s9b2

	ST_CARD_YKT_M1_HISTORY_INFO sthistoryInfo;
	memset(&sthistoryInfo,0,sizeof(ST_CARD_YKT_M1_HISTORY_INFO));

	ST_CARD_YKT_M1_PUBLIC_INFO stPublicInfo;
	memset(&stPublicInfo,0,sizeof(ST_CARD_YKT_M1_PUBLIC_INFO));
	memcpy(&stPublicInfo,stYktM1Info->szPublicInfo,sizeof(ST_CARD_YKT_M1_PUBLIC_INFO));


	PrintLog(" Rfmif_Write PubPurseCount[%d],SpcPurseCount[%d],\r\n",stPublicInfo.PubPurseCount,stPublicInfo.SpcPurseCount);





	if(stYktM1Info->PurseFlag==0x01)
	{
	    sthistoryInfo.TranType=0x03;
	    stPublicInfo.TranType=0x03;
	    stPublicInfo.TranProcFlag=0x11;
	    stPublicInfo.PubPurseCount=htons(stPublicInfo.PubPurseCount);
	    stPublicInfo.PubPurseCount= htons(stPublicInfo.PubPurseCount+1);
		*u8TerminalTradeNum=stPublicInfo.PubPurseCount;
	}else
	{
		sthistoryInfo.TranType=0x04;
		stPublicInfo.TranType=0x04;
		stPublicInfo.TranProcFlag=0x12;
		stPublicInfo.SpcPurseCount=htons(stPublicInfo.SpcPurseCount);
		stPublicInfo.SpcPurseCount=htons(stPublicInfo.SpcPurseCount+1);
		*u8TerminalTradeNum=stPublicInfo.SpcPurseCount;
	}

	unsigned char sztempPurse[4]={0};

	int itempPurse=0;

	itempPurse=htonl(stYktM1Info->Purse);

    memcpy(sztempPurse,&itempPurse,4);

	memcpy(sthistoryInfo.BeforeCardValue,&sztempPurse[1],3);

	memcpy(sthistoryInfo.ProcessDateTime4,stYktM1Info->stMetroInfo.ProcessDateTimeBCD+1,3);

	memcpy(stPublicInfo.ProcessDateTime4,stYktM1Info->stMetroInfo.ProcessDateTimeBCD,4);

	sthistoryInfo.TranValue=u32ConsumeMoney;

	sthistoryInfo.TranValue=htons(sthistoryInfo.TranValue);

	crc_cu((unsigned char*)&sthistoryInfo,16);

	ucSecNo=9;
	ucKeyAB=0x0B;
	iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyB,Serial);
	PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Authen Failed,\r\n");
		return RW_EC_WRITE_FAILED;
	}
	iRet= Rfmif_Write((ucSecNo*4)+2,(unsigned char*)&sthistoryInfo);
	PrintBuffer((char*)&sthistoryInfo,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Write s9b2 Failed,\r\n");
		return RW_EC_WRITE_FAILED;
	}
	PrintLog(" Rfmif_Write OK,\r\n");

	//write s9b0
	crc_cu((unsigned char*)&stPublicInfo,16);
	iRet= Rfmif_Write((ucSecNo*4)+0,(unsigned char*)&stPublicInfo);
	PrintBuffer((char*)&stPublicInfo,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Write s9b0 Failed,\r\n");
		return RW_EC_WRITE_FAILED;
	}
	PrintLog(" Rfmif_Write OK,\r\n");

	//地铁信息区  block no  s11b0  s11b1  s11b2
	ucSecNo=11;
	ucKeyAB=0x0B;
	iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyB,Serial);
	PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Authen Failed,\r\n");
		return RW_EC_WRITE_FAILED;
	}

	iRet= Rfmif_Write((ucSecNo*4)+0, stYktM1Info->szMetroInfo);
	PrintBuffer((char*)stYktM1Info->szMetroInfo,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Write Failed,\r\n");
		return RW_EC_WRITE_FAILED;
	}
	PrintLog(" Rfmif_Write OK,\r\n");

	//1 写钱包正本
	if(u32ConsumeMoney>0)
	{
		if(stYktM1Info->PurseFlag==0x01)
		{
		  ucSecNo=2;
		}
		else
		{
		  ucSecNo=4;
		}
		ucKeyAB=0x0A;
		iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyA,Serial);
		if(iRet != 0)
		{
			PrintLog("YKTm1 Rfmif_Authen[%d]Failed ucKeyAB[%02X] ucSecNo[%02X]",iRet,ucKeyAB,ucSecNo);
			return RW_EC_WRITE_FAILED;
		}

		iRet= Rfmif_DecrementTransfer((ucSecNo*4)+0,(ucSecNo*4)+0, (INT8U *)&u32ConsumeMoney);
		PrintBuffer((char*)&stYktM1Info->Purse,4);
		if(iRet != 0)
		{
			PrintLog(" Rfmif_Write Failed,\r\n");
			return RW_EC_WRITE_FAILED;
		}
		PrintLog(" Rfmif_Write OK,\r\n");
	}





	if(stYktM1Info->PurseFlag==0x01)
	{
	    stPublicInfo.TranProcFlag=0x13;
	}else
	{
		stPublicInfo.TranProcFlag=0x14;
	}

	ucSecNo=9;
	ucKeyAB=0x0B;
	iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyB,Serial);
	PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Authen Failed,\r\n");
	}
	//write s9b0
	crc_cu((unsigned char*)&stPublicInfo,16);
	iRet= Rfmif_Write((ucSecNo*4)+0,(unsigned char*)&stPublicInfo);
	PrintBuffer((char*)&stPublicInfo,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Write s9b0 Failed,\r\n");
	}else
	{
	  PrintLog(" Rfmif_Write OK,\r\n");
	}

	//1 写钱包副本
	if(u32ConsumeMoney>0)
	{
		if(stYktM1Info->PurseFlag==0x01)
		{
		  ucSecNo=2;
		}
		else
		{
		  ucSecNo=4;
		}
		ucKeyAB=0x0A;
		iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyA,Serial);
		if(iRet != 0)
		{
			PrintLog("YKTm1 Rfmif_Authen[%d]Failed ucKeyAB[%02X] ucSecNo[%02X]",iRet,ucKeyAB,ucSecNo);
		}else
		{
			PrintLog("YKTm1 Rfmif_Authen[%d]OK ",iRet);
		}

		iRet= Rfmif_RestoreTransfer((ucSecNo*4)+0,(ucSecNo*4)+1);
		PrintBuffer((char*)&stYktM1Info->Purse,4);
		if(iRet != 0)
		{
			PrintLog(" Rfmif_Write Failed,\r\n");
		}else
		{
		   PrintLog(" Rfmif_Write OK,\r\n");
		}
	}

	ucSecNo=9;
	ucKeyAB=0x0B;
	iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyB,Serial);
	PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Authen Failed,\r\n");
		return RW_EC_WRITE_FAILED;
	}
	//write s9b1
	crc_cu((unsigned char*)&stPublicInfo,16);
	iRet= Rfmif_Write((ucSecNo*4)+1,(unsigned char*)&stPublicInfo);
	PrintBuffer((char*)&stPublicInfo,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Write s9b0 Failed,\r\n");
	}else
	{
	  PrintLog(" Rfmif_Write OK,\r\n");
	}

	//地铁信息区  block no  s11b0  s11b1  s11b2
	ucSecNo=11;
	ucKeyAB=0x0B;
	iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyB,Serial);
	PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Authen Failed,\r\n");
	}

	iRet= Rfmif_Write((ucSecNo*4)+1, stYktM1Info->szMetroInfo);
	PrintBuffer((char*)stYktM1Info->szMetroInfo,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Write Failed,\r\n");
	}
	PrintLog(" Rfmif_Write OK,\r\n");

	return 0;
}

/*! \fn		StringToBcd()
 * \brief 	字符串转BCD码
 * \param[in]  pString 字符串0x87 0x90 0xD5 0xED”
 * \param[out] pBcd BCD码 0x20 0x45 0x03 0x08 0x13 0x23 0x45
 * \return 	 void
 * \author
 * \date
 */
void Rfmif_ProcessTime4ToBCD(unsigned char *pHexString, unsigned char *pBcd)
{
	if(pHexString == NULL || pBcd == NULL)
		return ;
	unsigned int iTotalMonth,year,month,day,hour,minute,second;
	unsigned int uiTemp0 = 0;
	unsigned int uiTemp1 = 0;
	unsigned int uiTemp2 = 0;
	unsigned int uiTemp3 = 0;

	uiTemp0 = pHexString[0];
	uiTemp1 = pHexString[1];
	uiTemp2 = pHexString[2];
	uiTemp3 = pHexString[3];

	iTotalMonth =(uiTemp0 << 2) + (uiTemp1 >> 6);
	year = 2000 + iTotalMonth / 12; //年
	month= iTotalMonth % 12 + 1;	//月
	day  = ((uiTemp1 & 0x3E) >> 1);	//日
	hour = ((uiTemp1 & 1) << 4) | ((uiTemp2 >> 4));//小时
	minute = ((uiTemp2 & 0x0F)<< 2) | ((uiTemp3 >> 6));//分钟
	second = (uiTemp3 & 0x3F);//秒

	unsigned char szTmp[15] = {0};
	sprintf((char*)szTmp, "%04d%02d%02d%02d%02d%02d", year, month, day, hour, minute, second);
	StringToBcd(szTmp, pBcd);
	return;
}
/*TM4:1.4.3. 四字节时间编码
 时间编码定义跨度为：2000年01月01日 00:00:00 到2083年12月31日 23:59:59。
 举例：
	输入时间：2045年03月08日 13:23:45
 转换：
	月：距离2000年01月的距离为( 2045 - 2000 )×12 + ( 3 - 1 ) = 542( 二进制1000011110 )
	日：8( 二进制01000 )
	时：13( 二进制01101 )
	分：23( 二进制010111 )
	秒：45( 二进制101101 )
	组合：1000 0111  1001 0000 1101 0101 1110 1101
 结果：87 90 D5 ED
 */
int Rfmif_TimeStrToProcessTime4(const char *pszStrDatetime, unsigned char *pszDestDatetime)
{
	if(pszStrDatetime == NULL || pszDestDatetime  == NULL)
		return -1;

	char szTempString[5] = {0};
	//unsigned char szDestDatetime[10] = {0};
 	//unsigned int uiTemp0, uiTemp1, uiTemp2, uiTemp3;
	int  year, month, day, hour, minute, second;

	memcpy(szTempString, pszStrDatetime, 4);
	year = atoi(szTempString);

	memset(szTempString, 0, sizeof(szTempString));
	memcpy(szTempString, pszStrDatetime + 4, 2);
	month = atoi(szTempString);

	memset(szTempString, 0, sizeof(szTempString));
	memcpy(szTempString, pszStrDatetime + 6, 2);
	day = atoi(szTempString);

	memset(szTempString, 0, sizeof(szTempString));
	memcpy(szTempString, pszStrDatetime + 8, 2);
	hour = atoi(szTempString);

	memset(szTempString, 0, sizeof(szTempString));
	memcpy(szTempString, pszStrDatetime + 10, 2);
	minute =atoi(szTempString);

	memset(szTempString, 0, sizeof(szTempString));
	memcpy(szTempString, pszStrDatetime + 12, 2);
	second = atoi(szTempString);
	//2045年03月08日 13:23:45
	/*月：距离2000年01月的距离为( 2045 – 2000 )×12 + ( 3 – 1 ) = 542( 二进制1000011110 ) 10
	日：8( 二进制01000 ) 5
	时：13( 二进制01101 ) 5
	分：23( 二进制010111 ) 6
	秒：45( 二进制101101 )6
	组合：1000 0111  1001 0000 1101 0101 1110 1101
	结果：87 90 D5 ED*/
	ST_TM4 stTm4;
	memset(&stTm4, 0, sizeof(stTm4));
	stTm4.iTotalMonth = (year - 2000) * 12 + month - 1;    //距离2000年总的月数
	stTm4.iDay = day;
	stTm4.iHour = hour;
	stTm4.iMinute = minute;
	stTm4.iSecond = second;

	//注意位域字节序也是倒序的，因此需要转序处理。
	pszDestDatetime[0] = ((char*)&stTm4)[3];
	pszDestDatetime[1] = ((char*)&stTm4)[2];
	pszDestDatetime[2] = ((char*)&stTm4)[1];
	pszDestDatetime[3] = ((char*)&stTm4)[0];

	//memcpy(pszDestDatetime, &stTm4, 4);
	return 0;
}

int Rfmif_Write_BlackList(ST_CARD_YKT_M1 * stYktM1Info)
{
	unsigned char szKeyA[6]={0};

	unsigned char szKeyB[6]={0};

	int iRet=-1;

	int iDataLength=0;

	unsigned char ucKeyAB=0x0A;

	//获取 KeyA
	iRet=Ykt_M1_GetM1KeyA(szKeyA);

	PrintLog("RFID...............Ykt_M1_GetM1KeyA Result[%d]",iRet);

	PrintBuffer((char*)szKeyA,6);

	//获取 KeyB
	iRet=Ykt_M1_GetM1KeyB(szKeyB);

	PrintLog("RFID...............Ykt_M1_GetM1KeyB Result[%d]",iRet);

	PrintBuffer((char*)szKeyB,6);

	unsigned char ucSecNo=0;

	unsigned char Serial[6]={0};


	memcpy(Serial,g_BRContext.szCardPhID,6);


	ucSecNo=9;
	ucKeyAB=0x0B;
	iRet=Rfmif_Authen(ucKeyAB,ucSecNo,szKeyB,Serial);
	PrintLog("RFID...............YKTm1 Rfmif_Authen[%d]",iRet);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Authen Failed,\r\n");
		return RW_EC_WRITE_FAILED;
	}

	iRet= Rfmif_Write((ucSecNo*4)+0, stYktM1Info->szPublicInfo);
	PrintBuffer((char*)stYktM1Info->szPublicInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Write Failed,\r\n");
		return RW_EC_WRITE_FAILED;
	}
	PrintLog(" Rfmif_Write OK,\r\n");

	iDataLength+=16;

	iRet= Rfmif_Write((ucSecNo*4)+1, stYktM1Info->szPublicInfo);
	PrintBuffer((char*)stYktM1Info->szPublicInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Write Failed,\r\n");
		return RW_EC_WRITE_FAILED;
	}
	PrintLog(" Rfmif_Write OK,\r\n");

	iDataLength+=16;

	iRet= Rfmif_Write((ucSecNo*4)+2, stYktM1Info->szPublicInfo);
	PrintBuffer((char*)stYktM1Info->szPublicInfo+iDataLength,16);
	if(iRet != 0)
	{
		PrintLog(" Rfmif_Write Failed,\r\n");
		return RW_EC_WRITE_FAILED;
	}
	PrintLog(" Rfmif_Write OK,\r\n");


	return 0;

}


