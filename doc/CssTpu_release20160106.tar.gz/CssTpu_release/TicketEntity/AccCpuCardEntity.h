#ifndef __ACCM1CARDENTITY_H__
#define __ACCM1CARDENTITY_H__


#include "../DataTypeDefine.h"
#include "../CSReaderCode.h"
#include "../XPublic/XTime.h"
#include "inc/LinuxHardwareDriver.h"

int Read_AccCpuCard_All_Info(uint8 u8Antenna,ST_CARD_ACC_CPU * stAccCpuCardInfo,BOOL bReadHistory);

//ConsumeFlag 00:普通消费   01:复合消费
int Write_AccCpuCard_Recombine_Info(uint32 u32ConsumeMoney,uint8* bcdCurrentTime,ST_CARD_ACC_CPU * stAccCpuCardInfo,uint8 ConsumeFlag,uint8 *TAC,uint32 *u8OutTerminalTradeNum);

int Write_AccCpuCard_Sail_Info(ST_CARD_ACC_CPU * stAccCpuCardInfo,uint8 SailFlag);

//u8LockFlag 0 lock  1 unlock
int Lock_AccCpuCard_Info(uint32 u32ConsumeMoney,uint8* bcdCurrentTime,ST_CARD_ACC_CPU * stAccCpuCardInfo,uint8 *TAC,uint32 *u8OutTerminalTradeNum);

int Unlock_AccCpuCard_Info(ST_CARD_ACC_CPU * stAccCpuCardInfo);


#endif
