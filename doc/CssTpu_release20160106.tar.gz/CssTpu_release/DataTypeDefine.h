#ifndef __DATATYPEDEFINE_H__
#define __DATATYPEDEFINE_H__

#define	 SOFTWARE_VERSION		"20150306.01"
#define	 HARDWARE_VERSION		31
#define  RUN_PATH				"/tpu/run"
#define  LOG_PATH				"/tpu/log"
#define  DATA_PATH				"/tpu/data"
#define  PARAM_PATH				"/tpu/parameter"
#define  UPGRADE_PATH           "/tpu/upgradedir"
#define  UPGRADE_BAK_PATH       "/tpu/upgradebak"

//2015.12.11 TPU临时目录
#define  TPU_TEMP_PATH          "/tmp"

//清空临时目录
#define  SHELL_CMD_DELETE_TMP "rm -f /tmp/*"

#define  SAM_SLOT_ACC			1
#define  SAM_SLOT_YKT_CPU		2
#define  SAM_SLOT_YKT_M1		3

#define RUN_PROGRAM				"tpu"

typedef unsigned char Bool;
/// defined for unsigned 8-bits integer variable     无符号8位整型变量
typedef unsigned char  uint8;
/// defined for signed 8-bits integer variable       有符号8位整型变量
typedef signed   char  int8;
/// defined for unsigned 16-bits integer variable    无符号16位整型变量
typedef unsigned short uint16;
/// defined for signed 16-bits integer variable      有符号16位整型变量
typedef signed   short int16;
/// defined for unsigned 32-bits integer variable    无符号32位整型变量
typedef unsigned long   uint32;
/// defined for signed 32-bits integer variable      有符号32位整型变量
typedef signed   long   int32;

typedef unsigned long       DWORD;
typedef int                 BOOL;
typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef float               FLOAT;

#ifndef NOMINMAX

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

#endif  /* NOMINMAX */

#define MAKEWORD(a, b)      ((WORD)(((BYTE)(((DWORD_PTR)(a)) & 0xff)) | ((WORD)((BYTE)(((DWORD_PTR)(b)) & 0xff))) << 8))
#define MAKELONG(a, b)      ((LONG)(((WORD)(((DWORD_PTR)(a)) & 0xffff)) | ((DWORD)((WORD)(((DWORD_PTR)(b)) & 0xffff))) << 16))
#define LOWORD(l)           ((WORD)(((DWORD_PTR)(l)) & 0xffff))
#define HIWORD(l)           ((WORD)((((DWORD_PTR)(l)) >> 16) & 0xffff))
#define LOBYTE(w)           ((BYTE)(((DWORD_PTR)(w)) & 0xff))
#define HIBYTE(w)           ((BYTE)((((DWORD_PTR)(w)) >> 8) & 0xff))

#define FALSE   0
#define TRUE    1

//设备类型 ，供内部判断设备类型使用。
typedef enum _EM_DEVICE_TYPE_
{
	EM_DEVICE_TYPE_TVM,  
	EM_DEVICE_TYPE_AGM_ENTRY,
	EM_DEVICE_TYPE_AGM_EXIT,
	EM_DEVICE_TYPE_AGM_DOUBLE,
	EM_DEVICE_TYPE_BOM,
	EM_DEVICE_TYPE_TCM,
	EM_DEVICE_TYPE_AVM,

}EM_DEVICE_TYPE;

//月：距离2000年01月的距离为( 2045 – 2000 )×12 + ( 3 – 1 ) = 542( 二进制1000011110 )
//日：8( 二进制01000 )
//时：13( 二进制01101 )
//分：23( 二进制010111 )
//秒：45( 二进制101101 )
//组合：1000 0111  1001 0000 1101 0101 1110 1101
//结果：87 90 D5 ED
typedef struct __ST_TM4__
{
	unsigned int iSecond:6; //bit 0~5
	unsigned int iMinute:6; //bit 6~11
	unsigned int iHour:5;   //bit 12~16
	unsigned int iDay:5;    //bit 17~21
	unsigned int iTotalMonth:10;//bit21~31
}ST_TM4;

typedef struct __ST_TIME2_
{
	unsigned short iResver:1;
	unsigned short iDay:5;
	unsigned short iMonth:10;
}ST_TIME2;



#endif
