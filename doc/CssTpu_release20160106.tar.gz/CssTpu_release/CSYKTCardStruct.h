/*
 * CSYKTCardStruct.h
 *
 *  Created on: Oct 9, 2015
 *      Author: root
 */

#ifndef CSYKTCARDSTRUCT_H_
#define CSYKTCARDSTRUCT_H_

#include "DataTypeDefine.h"

#pragma pack(push,1)








typedef struct _YKT_CPU_EF_05_
{
	uint8  IssuerCode[2];//	发卡方代码
	uint8  CityCode[2];  //城市代码
	uint8  IndustryCode[2];//行业代码
	uint8  Reserved1[2];//保留数据
	uint8  AppSn[8];//应用序列号
	uint8  MainType;//卡类型  80 普通用户卡   81 员工卡  82  系统管理卡
	uint8  SubType;//卡子类型
	uint8  IssueDate[4];//发行日期（YYYYMMDD）
	uint8  IssueDeviceInfo[3];//POS 机编号
	uint8  AreaCode[2];//区域代码
	uint8  StartFlag;//启用标志
	uint16 CardVersionNo;//应用版本号。
	uint8  TicketType;//票制类型
	uint8  SaleCardDate[4];//售卡日期（YYYYMMDD）
	uint8  SaleCardTime[3];//售卡实间（HHMMSS）。
	uint8  SaleCardOperID[3];//售卡员编号。
	uint8  SaleCardStationID[2];//售卡点编号。
	uint8  SaleCardDeposit;//售卡押金。
	uint8  CardValidDate[4];//卡有效期
}YKT_CPU_EF_05;

typedef struct _YKT_CPU_EF_06_
{
	uint8  Resvered[12];//	预留
	uint8  AuditDate[3];  //年检日期
	uint8  crc8;//crc

}YKT_CPU_EF_06;


typedef struct _YKT_CPU_EF_15_
{
	uint8  IssuerCode[2];//	发卡方代码
	uint8  CityCode[2];  //城市代码
	uint8  IndustryCode[2];//行业代码
	uint8  Reserved1[2];//保留数据
	uint8  StartFlag;//启用标志  00 未启用 01 启用
	uint8  CardVersionNo;//应用版本号。
	uint16 Flag;//互联互通标识
	uint8  CardSn[8]; //卡面编号
	uint8  CardStartDate[4];//应用启用日期（YYYYMMDD）
	uint8  CardValidDate[4];//应用有效期
	uint8  Reserved[2];//
}YKT_CPU_EF_15;

typedef struct _YKT_CPU_EF_16_
{
	uint8  AppUnit;//	应用单位类型  00 本单位  01 非本单位
	uint8  PersonIDFlag;  //持卡人身份标识
	uint8  PersonCode[3];//内部职工自编号
	uint8  PersonName[10];//   GBK 持卡人姓名 不足10 个字节 右端补空格
	uint8  PersonSex;//持卡人性别
	uint8  CityCode[2];  //城市代码
	uint8  IndustryCode[2];//行业代码
	uint8  SalerCode[2];  //商户代码
	uint8  ShcoolCode[2];//学校代码
    uint8  PersonID[20];
    uint8  PersonIDType;
    uint8  PersonAttrib[2];
	uint8  Reserved[8];//
}YKT_CPU_EF_16;

typedef struct _YKT_CPU_EF_17_03_
{
	uint8  Reserved0;//复合消费标志
	uint8  Reserved1;//记录长度。
	uint8  AppLockFlag;//应用锁定标志位。
	uint8  Reserved2;//记录版本。
	uint8	CardStatus0;	//最近一次处理发生后车票所处状态
	uint8	InGateLine;	//入站线路
	uint8	InGateStation;	//入站站点
	uint16	InGateDeviceCode;//入站设备类型及编码
	uint8	InGateTime[7];//入站处理时间(GMT)
	uint8	ProcessLine;	//最近一次处理线路
	uint8	ProcessStation;//最近一次处理站点
	uint16	ProcessEquCode;//最近一次处理发生的设备类型及编码
	uint8	ProcessTime[7];//最近一次处理时间(GMT)
	uint8	UpdateCount;//行政处理次数(当日)
	uint8	Reserved3[4];		//保留
	uint8	CardStatus;	//最近一次处理发生后车票所处状态
	uint8	CardSpecialFlag;//最近一次处理发生后特殊标记
}YKT_CPU_EF_17_03;

//ADF1_历史交易机
typedef struct _ST_YKT_CPU_CARD_HISTORY_
{
	uint16  TranSN;		//脱机交易序号
	uint8   Reserved[3];		//保留数据
	long   TranValue;		//交易金额
	uint8   TranType;		//交易类型标识
	uint8   TranDeviceCode[6];		//交易终端编码
	uint8	TranTime[7];		//终端交易时间(YYYYMMDDHHMMSS)3[27];		//保留
}ST_YKT_CPU_CARD_HISTORY;


//licd   cpu 卡原始数据结构-- ykt cpu
typedef struct tag_CARD_YKT_CPU
{

    unsigned char sz3F00_1A[16];
	YKT_CPU_EF_05  EF05;
	YKT_CPU_EF_06  EF06;
	YKT_CPU_EF_15  EF15;
	YKT_CPU_EF_16  EF16;
	uint32         Purse;
	YKT_CPU_EF_17_03  EF_17_03;
    uint8          LocalHistory[10][23];
    uint8          RechargeHistory[10][23];

    YKT_CPU_EF_05  EF05_BAK;

}ST_CARD_YKT_CPU;

typedef struct tag_CARD_YKT_M1_ISSUE_INFO
{

	unsigned char CardLogicNo[4]; //卡片唯一号
	unsigned char CardIssuerInfo[12];//卡片制造商信息
	unsigned char MainType; //卡片主类型。
	unsigned char SubType;  //应用子类型
	unsigned char CardCode[4];//应用卡编号
	unsigned char SaleCardDate[3];//售卡日期 yymmdd
	unsigned char SaleCardTime[2];//售卡时间 hhmm
	unsigned char SaleCardStation[2];//售卡地点
	unsigned char SaleCardDeposit;//售卡押金  元
	unsigned char StartFlag;//启用标记  AA 未启用  BB 启用
	unsigned char crc8;

}ST_CARD_YKT_M1_ISSUE_INFO;


typedef struct tag_CARD_YKT_M1_APP_INFO
{

	unsigned char reserved1[9];

	unsigned char Ticketway; //票制方式

	unsigned char EmployeeType[2]; //员工类型

	unsigned  char EmployeeCode[3];//员工编号

	unsigned char  crc81;

	unsigned char  AuidtInfo[3]; //yymmdd

	unsigned char  PurseType;//卡内初值情况。

	unsigned char  CityCode[2];//城市代码

	unsigned char  IndustryCode[2];//行业代码

	unsigned char CardMac[4];//卡认证码

	unsigned char reserved[4];

}ST_CARD_YKT_M1_APP_INFO;

typedef struct tag_CARD_YKT_M1_METRO_INFO
{

	unsigned char DeviceType;//设备类型
	unsigned char DeviceCode0[2];//车票状态及设备编码
    unsigned char StationCode[2];//设备站点
    unsigned char ProcessDateTime4[4];//处理时间
    unsigned char EntryStation[2];//入口站点
    unsigned char reserved[5];

    //转换后数据
	unsigned char CardStatus;//车票状态
	unsigned char DeviceCode[2];//设备编码
	unsigned char ProcessDateTimeBCD[7];//处理时间 7BCD
}ST_CARD_YKT_M1_METRO_INFO;

typedef struct tag_CARD_YKT_M1_PUBLIC_INFO
{

	unsigned char TranProcFlag;//交易过程标志
	unsigned char TranType;//交易类型
	unsigned char TranPointer;//交易指针
	unsigned short PubPurseCount;//公共钱包计数
    unsigned short SpcPurseCount;//专用钱包计数
    unsigned char ProcessDateTime4[4];//交易时间
    unsigned char BlockCardFlag;//锁卡标记
    unsigned char Reverse[3];
    unsigned char Crc8;//交易类型

}ST_CARD_YKT_M1_PUBLIC_INFO;


typedef struct tag_CARD_YKT_M1_HISTORY_INFO
{

	unsigned char TranType;//交易类型
	unsigned char SalerCode[2];//商户编码
    unsigned char POSCode[4];//POS 编码
    unsigned char ProcessDateTime4[3];//处理时间
    unsigned char BeforeCardValue[3];
    unsigned short TranValue;
    unsigned char Crc8;//交易类型

}ST_CARD_YKT_M1_HISTORY_INFO;




//licd   cpu 卡原始数据结构-- ykt cpu
typedef struct tag_CARD_YKT_M1
{

	ST_CARD_YKT_M1_ISSUE_INFO stIssueInfo;
	ST_CARD_YKT_M1_ISSUE_INFO stIssueInfo_BAK;

	ST_CARD_YKT_M1_APP_INFO  stAppInfo;

	int   Purse;

	unsigned short   uiTranSn;  //交易流水号

	unsigned short   PurseFlag; // 1 公共 ,  2专用 钱包

	ST_CARD_YKT_M1_METRO_INFO  stMetroInfo;

	ST_CARD_YKT_M1_METRO_INFO  stMetroInfo1;

	ST_CARD_YKT_M1_PUBLIC_INFO stPublicInfo;

	ST_CARD_YKT_M1_PUBLIC_INFO stPublicInfo1;

	ST_CARD_YKT_M1_HISTORY_INFO stHistoryInfo;

	unsigned char  szIssueInfo[64];
	unsigned char  szApplicationInfo[32];
	unsigned char  szPurseInfo[32];
	unsigned char  szPublicInfo[48];
	unsigned char  szMetroInfo[48];

}ST_CARD_YKT_M1;

#pragma pack(pop)


#endif /* CSYKTCARDSTRUCT_H_ */
