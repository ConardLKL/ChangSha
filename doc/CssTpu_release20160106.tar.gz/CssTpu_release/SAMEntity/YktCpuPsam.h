/*
 * YktCpuPsam.h
 *
 *  Created on: Oct 12, 2015
 *      Author: root
 */

#ifndef YKTCPUPSAM_H_
#define YKTCPUPSAM_H_

#include "../DataTypeDefine.h"
#include "../CSReaderCode.h"
#include "../Globle.h"
#include "../XPublic/XTime.h"
#include "inc/LinuxHardwareDriver.h"


int YktCpuSamInit(INT32U  slot,uint8 *CardNum,uint8 *CardNumLen);

int YktCpuSamGetRandom(INT32U  slot,uint8 *CardRandom);


#endif /* YKTCPUPSAM_H_ */
