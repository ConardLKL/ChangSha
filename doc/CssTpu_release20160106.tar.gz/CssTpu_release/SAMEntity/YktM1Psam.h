/*
 * YktM1Psam.h
 *
 *  Created on: Oct 12, 2015
 *      Author: root
 */

#ifndef YKTM1PSAM_H_
#define YKTM1PSAM_H_


#include "../DataTypeDefine.h"
#include "../CSReaderCode.h"
#include "../Globle.h"
#include "../XPublic/XTime.h"
#include "inc/LinuxHardwareDriver.h"

int YktM1SamInit(INT32U  slot,uint8 *CardNum,uint8 *CardNumLen);

int Ykt_M1_GetM1KeyA(unsigned char *ucKeyA);

int Ykt_M1_GetM1KeyB(unsigned char *ucKeyB);

int GetYKTM1CardUDTAC(uint8 * u8SystemFlowID,uint32 u32CardValue,uint16 u16TranValue,uint8 u8TranType,
		uint8 *ucProcessTime,uint16 u16TranNum, uint8 *TAC);

int YktM1SamGetRandom(INT32U  slot,uint8 *CardRandom);

#endif /* YKTM1PSAM_H_ */
