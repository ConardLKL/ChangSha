/*
 * YktM1Psam.c
 *
 *  Created on: Oct 12, 2015
 *      Author: root
 */

#include "YktM1Psam.h"

static int m_Psamslot;

static unsigned char m_ucKeyA[6];

static unsigned char m_ucKeyB[6];

int YktM1SamInit(INT32U  slot,uint8 *CardNum,uint8 *CardNumLen)
{

	//根据卡信息 判断卡的有效性。
	INT32U baud=38400;
	INT8U 	rlen=0;
	INT32U 	apdu_rlen=0;
	INT16U	sw;
	unsigned char TmpBuff[400];
	INT8U 	RevBuff[400];

	memset(TmpBuff,0x00,sizeof(TmpBuff));
	memset(RevBuff,0x00,sizeof(RevBuff));

								   //00     A4   04   00  09    A3 00   00     57   64   62   69   61   6F
	unsigned char selectAppDir[64]={0x00,0xA4,0x04,0x00,0x09,0xA3,0x00,0x00,0x57,0x64,0x62,0x69,0x61,0x6F};
								// 80   1A   28   01   08   07   56   71   68   90   72   89   68
	unsigned char array801A[64]={0x80,0x1A,0x28,0x01,0x08,0x07,0x56,0x71,0x68,0x90,0x72,0x89,0x68};
								// 80   FA   00   00   08  07   56   08  56   05   51     07  73
	unsigned char array80FA[64]={0x80,0xFA,0x00,0x00,0x08,0x07,0x56,0x08,0x56,0x05,0x51,0x07,0x73};

	unsigned char array801AKeyB[64]={0x80,0x1A,0x28,0x02,0x08,0x07,0x56,0x71,0x68,0x90,0x72,0x89,0x68};

	m_Psamslot=-1;

	memset(m_ucKeyA,0,6);

	memset(RevBuff,0x00,sizeof(RevBuff));


	if(IccSimReset(slot, baud, 3, &rlen,  RevBuff,0)){
		printf("Reset %d is ERROR\r\n",slot);
		return 1;
	}
	printf("Reset %d is OK\r\n",slot);
	printf("RESET SIM:Len=%d,Data=%s\r\n",rlen,BCD2ASC(RevBuff,rlen));


	//步骤1：PSAM卡获取UL卡验证信息和密钥初始值 80FC01010D UID3/4/5/6 流水号 验证信息 A5
	TmpBuff[0] =0x00;
	TmpBuff[1] =0xB0;
	TmpBuff[2] =0x95;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x0E;
	if(Sim_Apdu(slot,TmpBuff,5,RevBuff,&apdu_rlen,&sw)){
		printf("PSAM-Read0015 %d is ERROR\r\n",slot);
		return 1;
	}
	printf("PSAM-Read0015 OK!Data=%s\r\n",BCD2ASC(TmpBuff,5));
	printf("PSAM-Read0015:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		// SAM获取逻辑卡号失败
		printf("SAM获取逻辑卡号失败 sw=[%02X]\r\n",sw);
		return 1;
	}
	*CardNumLen=8;
	TmpBuff[0]=0;
	TmpBuff[1]=0;
	memcpy(&TmpBuff[2],RevBuff+4,6);
	memcpy(CardNum,TmpBuff,8);//实际发现需要偏移两个字节才是逻辑卡号  与文档不符   szp add 2015-05-06
	m_Psamslot=slot;
	printf("SamInit 0k\r\n");


	//步骤2：PSAM卡读0016终端信息文件 00B0960006
	TmpBuff[0] =0x00;
	TmpBuff[1] =0xB0;
	TmpBuff[2] =0x96;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x06;
	if(Sim_Apdu(slot,TmpBuff,5,RevBuff,&apdu_rlen,&sw)){
		printf("PSAM-Read0016 %d is ERROR\r\n",slot);
		return 1;
	}
	printf("PSAM-Read0016 OK!Data=%s\r\n",BCD2ASC(TmpBuff,5));
	printf("PSAM-Read0016:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		return 1;
	}
	memcpy(g_BRContext.u8YktM1PsamTerminalID,RevBuff,6);//获取终端机编号


	//选目录
	if(Sim_Apdu(slot,selectAppDir,14,RevBuff,&apdu_rlen,&sw))
	{
		printf("yktM1PSAM-selectappdir %d is ERROR\r\n",slot);
		return 1;
	}
	printf("PSAM-selectappdir OK!Data=%s\r\n",BCD2ASC(selectAppDir,14));
	printf("PSAM-selectappdir:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000)
	{
		printf("SAM获取逻辑卡号失败 sw=[%02X]\r\n",sw);
		return 1;
	}
	// KeyA
	if(Sim_Apdu(slot,array801A,13,RevBuff,&apdu_rlen,&sw))
	{
		printf("PSAM-array801A %d is ERROR\r\n",slot);
		return 1;
	}
	printf("PSAM-array801A OK!Data=%s\r\n",BCD2ASC(array801A,13));
	printf("PSAM-array801A:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000)
	{
		printf("SAM获取逻辑卡号失败 sw=[%02X]\r\n",sw);
		return 1;
	}


	if(Sim_Apdu(slot,array80FA,13,RevBuff,&apdu_rlen,&sw))
	{
		printf("PSAM-array80FA %d is ERROR\r\n",slot);
		return 1;
	}
	printf("PSAM-array80FA OK!Data=%s\r\n",BCD2ASC(array80FA,13));
	printf("PSAM-array80FA:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000)
	{
		printf("PSAM-array80FA  is ERROR sw=[%02X]\r\n",sw);
		return 1;
	}

	memcpy(m_ucKeyA,RevBuff+2,6);
	printf("PSAM-m_ucKeyA OK!Data=%s\r\n",BCD2ASC(m_ucKeyA,6));

	//KeyB
	if(Sim_Apdu(slot,array801AKeyB,13,RevBuff,&apdu_rlen,&sw))
	{
		printf("PSAM-array801A %d is ERROR\r\n",slot);
		return 1;
	}
	printf("PSAM-array801A OK!Data=%s\r\n",BCD2ASC(array801A,13));
	printf("PSAM-array801A:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000)
	{
		printf("SAM获取逻辑卡号失败 sw=[%02X]\r\n",sw);
		return 1;
	}


	if(Sim_Apdu(slot,array80FA,13,RevBuff,&apdu_rlen,&sw))
	{
		printf("PSAM-array80FA %d is ERROR\r\n",slot);
		return 1;
	}
	printf("PSAM-array80FA OK!Data=%s\r\n",BCD2ASC(array80FA,13));
	printf("PSAM-array80FA:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000)
	{
		printf("PSAM-array80FA  is ERROR sw=[%02X]\r\n",sw);
		return 1;
	}

	memcpy(m_ucKeyB,RevBuff+2,6);
	printf("PSAM-m_ucKeyA OK!Data=%s\r\n",BCD2ASC(m_ucKeyA,6));

	return CE_OK;


}

int Ykt_M1_GetM1KeyA(unsigned char *ucKeyA)
{

	if(ucKeyA==NULL)
	{
		printf("PSAM-GetM1KeyA filed!ucKeyA==NULL\r\n");
		return -1;
	}

	memcpy(ucKeyA,m_ucKeyA,sizeof(m_ucKeyA));

	return 0;

}

int Ykt_M1_GetM1KeyB(unsigned char *ucKeyB)
{

	if(ucKeyB==NULL)
	{
		printf("PSAM-GetM1KeyA filed!ucKeyA==NULL\r\n");
		return -1;
	}

	memcpy(ucKeyB,m_ucKeyB,sizeof(m_ucKeyB));

	return 0;

}

int GetYKTM1CardUDTAC(uint8 * u8SystemFlowID,uint32 u32CardValue,uint16 u16TranValue,uint8 u8TranType
		,uint8 *ucProcessTime,uint16 u16TranNum, uint8 *TAC)
{
   /*801A280108+应用卡编号(4BYTE)+80000000
   "80FA010010+
    交易类型(1BYTE)+交易时间(7BYTE)+交易前余额(4BYTE)+交易金额(2BYTE)+票卡交易计数(2BYTE)"
    * */

	int i =0;
	INT32U slot=SAM_SLOT_YKT_M1;
	unsigned char TmpBuff[400];
	INT32U 	samApdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;

	uint8 u8Terminal[6];//终端机编号
	uint8 Random[8];//Cpu卡随机数
	uint8 MAC[4];//MAC


	u32CardValue=htonl(u32CardValue);//交易金额 反序
	u16TranValue=htons(u16TranValue);//交易序列号 反序
	u16TranNum=htons(u16TranNum);//交易序列号 反序

	memset(u8Terminal,0x00,sizeof(u8Terminal));
	memset(Random,0x00,sizeof(Random));
	memset(MAC,0x00,sizeof(MAC));

//	//步骤0：PSAM卡选应用目录:  00A4040009A3000057646269616F
//	                         //00A4040009A3000057646269616F
//	TmpBuff[0] =0x00;
//	TmpBuff[1] =0xA4;
//	TmpBuff[2] =0x04;
//	TmpBuff[3] =0x00;
//	TmpBuff[4] =0x09;
//	TmpBuff[5] =0xA3;
//	TmpBuff[6] =0x00;
//	TmpBuff[7] =0x00;
//	TmpBuff[8] =0x57;
//	TmpBuff[9] =0x64;
//	TmpBuff[10] =0x62;
//	TmpBuff[11] =0x69;
//	TmpBuff[12] =0x61;
//	TmpBuff[13] =0x6F;
//	if(Sim_Apdu(slot,TmpBuff,14,RevBuff,&samApdu_rlen,&sw)){
//		PrintLog("PSAM-Select1001 %d is ERROR\r\n",slot);
//		return 1;
//	}
//	PrintLog("PSAM-Select1001 OK!Data=%s\r\n",BCD2ASC(TmpBuff,14));
//	PrintLog("PSAM-Select1001:Len=%d,SW=%04X,Data=%s\r\n",samApdu_rlen,sw,BCD2ASC(RevBuff,samApdu_rlen));
//	if(sw != 0x9000){
//		return 1;
//	}


	//步骤1：PSAM卡指令:801A280108+应用卡编号(4BYTE)+80000000
	TmpBuff[0] =0x80;
	TmpBuff[1] =0x1A;
	TmpBuff[2] =0x28;
	TmpBuff[3] =0x01;
	TmpBuff[4] =0x08;
	memcpy(&TmpBuff[5],u8SystemFlowID,4);	//8用户卡应用序号
	TmpBuff[9] =0x80;
	TmpBuff[10] =0x00;
	TmpBuff[11] =0x00;
	TmpBuff[12] =0x00;
	PrintBuffer((char*)TmpBuff,13);
	if(Sim_Apdu(slot,TmpBuff,13,RevBuff,&samApdu_rlen,&sw)){
		PrintLog("PSAM-801A %d is ERROR\r\n",slot);
		PrintBuffer((char*)RevBuff,13);
		return 1;
	}
	PrintLog("PSAM-801A OK!Data=%s\r\n",BCD2ASC(TmpBuff,i));
	PrintLog("PSAM-801A:Len=%d,SW=%04X,Data=%s\r\n",samApdu_rlen,sw,BCD2ASC(RevBuff,samApdu_rlen));
	if(sw != 0x9000){
		return 1;
	}

	//步骤1：PSAM卡指令: 80FA010010+交易类型(1BYTE)+交易时间(7BYTE)+交易前余额(4BYTE)+交易金额(2BYTE)+票卡交易计数(2BYTE)"
	TmpBuff[0] =0x80;
	TmpBuff[1] =0xFA;
	TmpBuff[2] =0x01;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x10;
	TmpBuff[5] =u8TranType;
	memcpy(&TmpBuff[6],ucProcessTime,7);
	memcpy(&TmpBuff[13],&u32CardValue,4);
	memcpy(&TmpBuff[17],&u16TranValue,2);
	memcpy(&TmpBuff[19],&u16TranNum,2);
	PrintBuffer((char*)TmpBuff,21);
	if(Sim_Apdu(slot,TmpBuff,21,RevBuff,&samApdu_rlen,&sw)){
		PrintLog("PSAM-80FA %d is ERROR\r\n",slot);
		PrintBuffer((char*)RevBuff,37);
		return 1;
	}
	PrintLog("PSAM-80FA OK!Data=%s\r\n",BCD2ASC(TmpBuff,i));
	PrintLog("PSAM-80FA:Len=%d,SW=%04X,Data=%s\r\n",samApdu_rlen,sw,BCD2ASC(RevBuff,samApdu_rlen));
	if(sw != 0x9000){
		return 1;
	}
	memcpy(TAC,RevBuff,4);

	return 0;


}

int YktM1SamGetRandom(INT32U  slot,uint8 *CardRandom)
{
	//根据卡信息 判断卡的有效性。
	unsigned char TmpBuff[400];
	INT32U 	apdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;

	memset(TmpBuff,0x00,sizeof(TmpBuff));
	memset(RevBuff,0x00,sizeof(RevBuff));

//	CloseSimModule();
//	if(OpenSimMoudle()){
//		PrintLog("OpenSimMoudle ERROR !!!!\n");
//		return 1;
//	}
//	PrintLog("OpenSimMoudle OK !!!!\n");
//	if(IccSimReset(slot, baud, 3, &rlen,  RevBuff,0)){
//		PrintLog("Reset %d is ERROR\r\n",slot);
//		//CloseSimModule();
//		return 1;
//	}
//	PrintLog("Reset %d is OK\r\n",slot);
//	PrintLog("RESET SIM:Len=%d,Data=%s\r\n",rlen,BCD2ASC(RevBuff,rlen));

//	//步骤1：SAM选择应用
//	TmpBuff[0] =0x00;
//	TmpBuff[1] =0xA4;
//	TmpBuff[2] =0x00;
//	TmpBuff[3] =0x00;
//	TmpBuff[4] =0x02;
//	TmpBuff[5] =0x10;
//	TmpBuff[6] =0x01;
//	if(Sim_Apdu(slot,TmpBuff,7,RevBuff,&apdu_rlen,&sw)){
//		PrintLog("PSAM-Select1001 %d is ERROR\r\n",slot);
//		return 1;
//	}
//	PrintLog("PSAM-Select1001 OK!Data=%s\r\n",BCD2ASC(TmpBuff,7));
//	PrintLog("PSAM-Select1001:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
//	if(sw != 0x9000){
//		// SAM获取逻辑卡号失败
//		PrintLog("SAM选择应用失败 sw=[%02X]\r\n",sw);
//		return 1;
//	}

	//步骤2：SAM获取随机数0084000008
	TmpBuff[0] =0x00;
	TmpBuff[1] =0x84;
	TmpBuff[2] =0x00;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x08;
	if(Sim_Apdu(slot,TmpBuff,5,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-GetRandom %d is ERROR\r\n",slot);
		return 1;
	}
	PrintLog("PSAM-GetRandom !Data=%s\r\n",BCD2ASC(TmpBuff,5));
	PrintLog("PSAM-GetRandom:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		// SAM获取逻辑卡号失败
		PrintLog("SAM获取随机数失败 sw=[%02X]\r\n",sw);
		return 1;
	}

	memcpy(CardRandom,RevBuff,8);
	PrintLog("PSAM-GetRandom 0k\r\n");
	return CE_OK;
}
