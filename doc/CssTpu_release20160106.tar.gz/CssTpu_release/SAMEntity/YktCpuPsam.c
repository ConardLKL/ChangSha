/*
 * YktCpuPsam.c
 *
 *  Created on: Oct 12, 2015
 *      Author: root
 */

#include "YktCpuPsam.h"

static int m_Psamslot;

int YktCpuSamInit(INT32U  slot,uint8 *CardNum,uint8 *CardNumLen)
{

	//根据卡信息 判断卡的有效性。
	INT32U baud=38400;
	INT8U 	rlen=0;
	unsigned char TmpBuff[400];
	INT32U 	apdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;

	m_Psamslot=-1;

	memset(TmpBuff,0x00,sizeof(TmpBuff));
	memset(RevBuff,0x00,sizeof(RevBuff));


	if(IccSimReset(slot, baud, 3, &rlen,  RevBuff,0)){
		printf("Reset %d is ERROR\r\n",slot);
		return 1;
	}
	printf("Reset %d is OK\r\n",slot);
	printf("RESET SIM:Len=%d,Data=%s\r\n",rlen,BCD2ASC(RevBuff,rlen));

	//步骤1：PSAM卡获取UL卡验证信息和密钥初始值 80FC01010D UID3/4/5/6 流水号 验证信息 A5
	TmpBuff[0] =0x00;
	TmpBuff[1] =0xB0;
	TmpBuff[2] =0x95;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x0E;
	if(Sim_Apdu(slot,TmpBuff,5,RevBuff,&apdu_rlen,&sw)){
		printf("PSAM-Read0015 %d is ERROR\r\n",slot);
		return 1;
	}
	printf("PSAM-Read0015 OK!Data=%s\r\n",BCD2ASC(TmpBuff,5));
	printf("PSAM-Read0015:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		// SAM获取逻辑卡号失败
		printf("SAM获取逻辑卡号失败 sw=[%02X]\r\n",sw);
		return 1;
	}
	*CardNumLen=8;
	//memcpy(CardNum,RevBuff,8);
	memcpy(CardNum,RevBuff+2,8);//实际发现需要偏移两个字节才是逻辑卡号  与文档不符   szp add 2015-05-06
	m_Psamslot=slot;
	printf("SamInit 0k\r\n");


	//步骤2：PSAM卡读0016终端信息文件 00B0960006
	TmpBuff[0] =0x00;
	TmpBuff[1] =0xB0;
	TmpBuff[2] =0x96;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x06;
	if(Sim_Apdu(slot,TmpBuff,5,RevBuff,&apdu_rlen,&sw)){
		printf("PSAM-Read0016 %d is ERROR\r\n",slot);
		return 1;
	}
	printf("PSAM-Read0016 OK!Data=%s\r\n",BCD2ASC(TmpBuff,5));
	printf("PSAM-Read0016:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		return 1;
	}
	memcpy(g_BRContext.u8YktCpuPsamTerminalID,RevBuff,6);//获取终端机编号

	//步骤0：PSAM卡选1001应用目录:00A4040006BDA8C9E8B2BF
	TmpBuff[0] =0x00;
	TmpBuff[1] =0xA4;
	TmpBuff[2] =0x04;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x06;
	TmpBuff[5] =0xBD;
	TmpBuff[6] =0xA8;
	TmpBuff[7] =0xC9;
	TmpBuff[8] =0xE8;
	TmpBuff[9] =0xB2;
	TmpBuff[10] =0xBF;
	if(Sim_Apdu(slot,TmpBuff,11,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-Select1001 %d is ERROR\r\n",slot);
		return 1;
	}
	PrintLog("PSAM-Select1001 OK!Data=%s\r\n",BCD2ASC(TmpBuff,11));
	PrintLog("PSAM-Select1001:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		return 1;
	}

	return CE_OK;


}
int YktCpuSamGetRandom(INT32U  slot,uint8 *CardRandom)
{
	//根据卡信息 判断卡的有效性。
	unsigned char TmpBuff[400];
	INT32U 	apdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;


	memset(TmpBuff,0x00,sizeof(TmpBuff));
	memset(RevBuff,0x00,sizeof(RevBuff));

//	CloseSimModule();
//	if(OpenSimMoudle()){
//		PrintLog("OpenSimMoudle ERROR !!!!\n");
//		return 1;
//	}
//	PrintLog("OpenSimMoudle OK !!!!\n");
//	if(IccSimReset(slot, baud, 3, &rlen,  RevBuff,0)){
//		PrintLog("Reset %d is ERROR\r\n",slot);
//		//CloseSimModule();
//		return 1;
//	}
//	PrintLog("Reset %d is OK\r\n",slot);
//	PrintLog("RESET SIM:Len=%d,Data=%s\r\n",rlen,BCD2ASC(RevBuff,rlen));

//	//步骤1：SAM选择应用
//	TmpBuff[0] =0x00;
//	TmpBuff[1] =0xA4;
//	TmpBuff[2] =0x00;
//	TmpBuff[3] =0x00;
//	TmpBuff[4] =0x02;
//	TmpBuff[5] =0x10;
//	TmpBuff[6] =0x01;
//	if(Sim_Apdu(slot,TmpBuff,7,RevBuff,&apdu_rlen,&sw)){
//		PrintLog("PSAM-Select1001 %d is ERROR\r\n",slot);
//		return 1;
//	}
//	PrintLog("PSAM-Select1001 OK!Data=%s\r\n",BCD2ASC(TmpBuff,7));
//	PrintLog("PSAM-Select1001:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
//	if(sw != 0x9000){
//		// SAM获取逻辑卡号失败
//		PrintLog("SAM选择应用失败 sw=[%02X]\r\n",sw);
//		return 1;
//	}

	//步骤2：SAM获取随机数0084000008
	TmpBuff[0] =0x00;
	TmpBuff[1] =0x84;
	TmpBuff[2] =0x00;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x08;
	if(Sim_Apdu(slot,TmpBuff,5,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-GetRandom %d is ERROR\r\n",slot);
		return 1;
	}
	PrintLog("PSAM-GetRandom !Data=%s\r\n",BCD2ASC(TmpBuff,5));
	PrintLog("PSAM-GetRandom:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		// SAM获取逻辑卡号失败
		PrintLog("SAM获取随机数失败 sw=[%02X]\r\n",sw);
		return 1;
	}

	memcpy(CardRandom,RevBuff,8);
	PrintLog("PSAM-GetRandom 0k\r\n");
	return CE_OK;
}

