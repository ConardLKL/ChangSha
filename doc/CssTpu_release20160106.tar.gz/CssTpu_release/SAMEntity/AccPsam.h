/*
 * AccPsam.h
 *
 *  Created on: Apr 23, 2015
 *      Author: root
 */

#ifndef ACCPSAM_H_
#define ACCPSAM_H_

#include "../DataTypeDefine.h"
#include "../CSReaderCode.h"
#include "../Globle.h"
#include "../XPublic/XTime.h"
#include "inc/LinuxHardwareDriver.h"


int PsamVerify_Issue_ULCard(CARD_ACC_UL  stULCardInfo,uint8 *CheckBuff);

int SamInit(INT32U  slot,uint8 *CardNum,uint8 *CardNumLen);

int SamGetRandom(INT32U  slot,uint8 *CardRandom);

int SamExternalAuthentication(INT32U  slot,uint8 *MAC);

int GetULCardUDTAC(uint8 * u8SystemFlowID,uint32 u32Money,uint32 u32TranSn,uint8 *ucProcessTime, uint8 *TAC);

int GetULCardSn(unsigned char * ucULCardSn);

int PlusULCardSn();

#endif /* ACCPSAM_H_ */
