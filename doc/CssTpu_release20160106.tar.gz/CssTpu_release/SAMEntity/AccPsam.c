/*
 * AccPsam.c
 *
 *  Created on: Apr 23, 2015
 *      Author: root
 */
#include "AccPsam.h"

static int m_AccPsamslot;
static char m_u8AccPsamTerminalID[6];

int PsamVerify_Issue_ULCard(CARD_ACC_UL  stULCardInfo,uint8 *CheckBuff)
{
	//根据卡信息 判断卡的有效性。
	int i =0;
	INT32U slot=m_AccPsamslot;//默认地铁的PSAM卡槽是1
	unsigned char TmpBuff[400];
	INT32U 	apdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;


	memset(TmpBuff,0x00,sizeof(TmpBuff));
	memset(RevBuff,0x00,sizeof(RevBuff));



	PrintLog("File[%s]Line[%d]Inner_Read_ULCard iRet=",__FILE__,__LINE__);
//	if(IccSimReset(slot, baud, 3, &rlen,  RevBuff,0)){
//		PrintLog("Reset %d is ERROR\r\n",slot);
//		//CloseSimModule();
//		return 1;
//	}
//	PrintLog("Reset %d is OK\r\n",slot);
//	PrintLog("RESET SIM:Len=%d,Data=%s\r\n",rlen,BCD2ASC(RevBuff,rlen));


//	TmpBuff[0] =0x00;
//	TmpBuff[1] =0xA4;
//	TmpBuff[2] =0x00;
//	TmpBuff[3] =0x00;
//	TmpBuff[4] =0x02;
//	TmpBuff[5] =0x10;
//	TmpBuff[6] =0x01;
//	if(Sim_Apdu(slot,TmpBuff,7,RevBuff,&apdu_rlen,&sw)){
//		PrintLog("PSAM-Select1001 %d is ERROR\r\n",slot);
//		return 1;
//	}
//	PrintLog("PSAM-Select1001 OK!Data=%s\r\n",BCD2ASC(TmpBuff,7));

	//步骤1：PSAM卡获取UL卡验证信息和密钥初始值 80FC01010D UID3/4/5/6 流水号 验证信息 A5
	TmpBuff[0] =0x80;
	TmpBuff[1] =0xFC;
	TmpBuff[2] =0x01;
	TmpBuff[3] =0x01;
	TmpBuff[4] =0x0D;i=5;
	memcpy(&TmpBuff[i],&stULCardInfo.CardUL[1*4],4);i+=4;
	memcpy(&TmpBuff[i],&stULCardInfo.CardUL[4*4],4);i+=4;
	memcpy(&TmpBuff[i],&stULCardInfo.CardUL[5*4],4);i+=4;
	TmpBuff[i] =0xA5;i+=1;
	if(Sim_Apdu(slot,TmpBuff,i,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-GetCheckInfo %d is ERROR\r\n",slot);
		return 1;
	}
	PrintLog("PSAM-GetCheckInfo OK!Data=%s\r\n",BCD2ASC(TmpBuff,i));
	PrintLog("PSAM-GetCheckInfo:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		// 有效性不通过，返回 无效卡。
		return 1;
	}
//	stULCardInfo.CRC1_Check = RevBuff[0];
//	stULCardInfo.CRC2_Check = RevBuff[1];
//	memcpy(stULCardInfo.KeyInit,&RevBuff[2],4);
	memcpy(CheckBuff,RevBuff,6);

	return CE_OK;
}


int SamInit(INT32U  slot,uint8 *CardNum,uint8 *CardNumLen)
{


	//根据卡信息 判断卡的有效性。
	INT32U baud=38400;
	INT8U 	rlen=0;
	unsigned char TmpBuff[400];
	INT32U 	apdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;

	m_AccPsamslot=-1;

	memset(TmpBuff,0x00,sizeof(TmpBuff));
	memset(RevBuff,0x00,sizeof(RevBuff));

//
//	if(OpenSimMoudle()){
//		PrintLog("OpenSimMoudle ERROR !!!!\n");
//		return 1;
//	}
	PrintLog("IccSimReset OK !!!!\n");
	if(IccSimReset(slot, baud, 3, &rlen,  RevBuff,0)){
		PrintLog("Reset %d is ERROR\r\n",slot);
		//CloseSimModule();
		return 1;
	}
	PrintLog("Reset %d is OK\r\n",slot);
	PrintLog("RESET SIM:Len=%d,Data=%s\r\n",rlen,BCD2ASC(RevBuff,rlen));

	//步骤1：PSAM卡获取UL卡验证信息和密钥初始值 80FC01010D UID3/4/5/6 流水号 验证信息 A5
	TmpBuff[0] =0x00;
	TmpBuff[1] =0xB0;
	TmpBuff[2] =0x95;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x0E;
	if(Sim_Apdu(slot,TmpBuff,5,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-Read0015 %d is ERROR\r\n",slot);
		return 1;
	}
	PrintLog("PSAM-Read0015 OK!Data=%s\r\n",BCD2ASC(TmpBuff,5));
	PrintLog("PSAM-Read0015:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		// SAM获取逻辑卡号失败
		PrintLog("SAM获取逻辑卡号失败 sw=[%02X]\r\n",sw);
		return 1;
	}
	*CardNumLen=8;
	//memcpy(CardNum,RevBuff,8);
	memcpy(CardNum,RevBuff+2,8);//实际发现需要偏移两个字节才是逻辑卡号  与文档不符   szp add 2015-05-06
	m_AccPsamslot=slot;
	PrintLog("SamInit 0k\r\n");


	//步骤2：PSAM卡读0016终端信息文件 00B0960006
	TmpBuff[0] =0x00;
	TmpBuff[1] =0xB0;
	TmpBuff[2] =0x96;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x06;
	if(Sim_Apdu(slot,TmpBuff,5,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-Read0016 %d is ERROR\r\n",slot);
		return 1;
	}
	PrintLog("PSAM-Read0016 OK!Data=%s\r\n",BCD2ASC(TmpBuff,5));
	PrintLog("PSAM-Read0016:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		return 1;
	}
	memcpy(g_BRContext.u8AccPsamTerminalID,RevBuff,6);//获取终端机编号
    memcpy(m_u8AccPsamTerminalID,RevBuff,6);//获取终端机编号

	//步骤1：SAM选择应用
	TmpBuff[0] =0x00;
	TmpBuff[1] =0xA4;
	TmpBuff[2] =0x00;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x02;
	TmpBuff[5] =0x10;
	TmpBuff[6] =0x01;
	if(Sim_Apdu(slot,TmpBuff,7,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-Select1001 %d is ERROR\r\n",slot);
		return 1;
	}
	PrintLog("PSAM-Select1001 OK!Data=%s\r\n",BCD2ASC(TmpBuff,7));
	PrintLog("PSAM-Select1001:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		// SAM获取逻辑卡号失败
		PrintLog("SAM选择应用失败 sw=[%02X]\r\n",sw);
		return 1;
	}

	return CE_OK;
}


int SamGetRandom(INT32U  slot,uint8 *CardRandom)
{
	//根据卡信息 判断卡的有效性。
	INT8U 	rlen=0;
	unsigned char TmpBuff[400];
	INT32U 	apdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;

	m_AccPsamslot=-1;

	memset(TmpBuff,0x00,sizeof(TmpBuff));
	memset(RevBuff,0x00,sizeof(RevBuff));

//	CloseSimModule();
//	if(OpenSimMoudle()){
//		PrintLog("OpenSimMoudle ERROR !!!!\n");
//		return 1;
//	}
//	PrintLog("OpenSimMoudle OK !!!!\n");
//	if(IccSimReset(slot, baud, 3, &rlen,  RevBuff,0)){
//		PrintLog("Reset %d is ERROR\r\n",slot);
//		//CloseSimModule();
//		return 1;
//	}
//	PrintLog("Reset %d is OK\r\n",slot);
//	PrintLog("RESET SIM:Len=%d,Data=%s\r\n",rlen,BCD2ASC(RevBuff,rlen));

//	//步骤1：SAM选择应用
//	TmpBuff[0] =0x00;
//	TmpBuff[1] =0xA4;
//	TmpBuff[2] =0x00;
//	TmpBuff[3] =0x00;
//	TmpBuff[4] =0x02;
//	TmpBuff[5] =0x10;
//	TmpBuff[6] =0x01;
//	if(Sim_Apdu(slot,TmpBuff,7,RevBuff,&apdu_rlen,&sw)){
//		PrintLog("PSAM-Select1001 %d is ERROR\r\n",slot);
//		return 1;
//	}
//	PrintLog("PSAM-Select1001 OK!Data=%s\r\n",BCD2ASC(TmpBuff,7));
//	PrintLog("PSAM-Select1001:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
//	if(sw != 0x9000){
//		// SAM获取逻辑卡号失败
//		PrintLog("SAM选择应用失败 sw=[%02X]\r\n",sw);
//		return 1;
//	}

	//步骤2：SAM获取随机数0084000008
	TmpBuff[0] =0x00;
	TmpBuff[1] =0x84;
	TmpBuff[2] =0x00;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x08;
	if(Sim_Apdu(slot,TmpBuff,5,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-GetRandom %d is ERROR\r\n",slot);
		return 1;
	}
	PrintLog("PSAM-GetRandom !Data=%s\r\n",BCD2ASC(TmpBuff,5));
	PrintLog("PSAM-GetRandom:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		// SAM获取逻辑卡号失败
		PrintLog("SAM获取随机数失败 sw=[%02X]\r\n",sw);
		return 1;
	}

	memcpy(CardRandom,RevBuff,8);
	m_AccPsamslot=slot;
	PrintLog("PSAM-GetRandom 0k\r\n");
	return CE_OK;
}


int SamExternalAuthentication(INT32U  slot,uint8 *MAC)
{
	//根据卡信息 判断卡的有效性。
	unsigned char TmpBuff[400];
	INT32U 	apdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;

	m_AccPsamslot=-1;

	memset(TmpBuff,0x00,sizeof(TmpBuff));
	memset(RevBuff,0x00,sizeof(RevBuff));

	//步骤1：SAM外部认证0082000108+data
	TmpBuff[0] =0x00;
	TmpBuff[1] =0x82;
	TmpBuff[2] =0x00;
	TmpBuff[3] =0x01;
	TmpBuff[4] =0x08;
	memcpy(&TmpBuff[5],MAC,8);
	PrintLog("File[%s]Line[%d] SamExternalAuthentication",__FILE__,__LINE__);
	PrintBuffer((char*)TmpBuff,13);
	usleep(1000);//偶尔认证超时，测试
	if(Sim_Apdu(slot,TmpBuff,13,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-ExternalAuthentication %d is ERROR\r\n",slot);
		PrintLog("PSAM-ExternalAuthentication:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
		return 1;
	}
	PrintLog("PSAM-ExternalAuthentication OK!Data=%s\r\n",BCD2ASC(TmpBuff,13));
	PrintLog("PSAM-ExternalAuthentication:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		// SAM外部认证失败
		PrintLog("SAM外部认证失败 sw=[%02X]\r\n",sw);
		return 1;
	}

	memcpy(MAC,RevBuff,8);
	m_AccPsamslot=slot;
	PrintLog("SamInit 0k\r\n");
	return CE_OK;
}

int GetULCardUDTAC(uint8 * u8SystemFlowID,uint32 u32Money,uint32 u32TranSn,uint8 *ucProcessTime, uint8 *TAC)
{
	int i =0;
	INT32U slot=SAM_SLOT_ACC;//默认地铁CPU卡的PSAM卡槽是1
	unsigned char TmpBuff[400];
	INT32U 	samApdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;

	uint8 u8Terminal[6];//终端机编号
	uint8 Random[8];//Cpu卡随机数
	uint8 MAC[4];//MAC


	u32Money=htonl(u32Money);//交易金额 反序
	u32TranSn =htonl(u32TranSn);
	memset(u8Terminal,0x00,sizeof(u8Terminal));
	memset(Random,0x00,sizeof(Random));
	memset(MAC,0x00,sizeof(MAC));



//	//步骤0：PSAM卡选1001应用目录:00A40000021001
//	TmpBuff[0] =0x00;
//	TmpBuff[1] =0xA4;
//	TmpBuff[2] =0x00;
//	TmpBuff[3] =0x00;
//	TmpBuff[4] =0x02;
//	TmpBuff[5] =0x10;
//	TmpBuff[6] =0x01;
//	if(Sim_Apdu(slot,TmpBuff,7,RevBuff,&samApdu_rlen,&sw)){
//		PrintLog("PSAM-Select1001 %d is ERROR\r\n",slot);
//		return 1;
//	}
//	PrintLog("PSAM-Select1001 OK!Data=%s\r\n",BCD2ASC(TmpBuff,7));
//	PrintLog("PSAM-Select1001:Len=%d,SW=%04X,Data=%s\r\n",samApdu_rlen,sw,BCD2ASC(RevBuff,samApdu_rlen));
//	if(sw != 0x9000){
//		return 1;
//	}

	//步骤1：PSAM卡指令:801A240108|0010100123456788
	TmpBuff[0] =0x80;
	TmpBuff[1] =0x1A;
	TmpBuff[2] =0x24;
	TmpBuff[3] =0x01;
	TmpBuff[4] =0x08;
	TmpBuff[5] =0x00;
	TmpBuff[6] =0x00;
	TmpBuff[7] =0x00;
	TmpBuff[8] =0x03;
	memcpy(&TmpBuff[9],u8SystemFlowID,4);	//8用户卡应用序号
	PrintBuffer((char*)TmpBuff,13);
	if(Sim_Apdu(slot,TmpBuff,13,RevBuff,&samApdu_rlen,&sw)){
		PrintLog("PSAM-801A %d is ERROR\r\n",slot);
		PrintBuffer((char*)RevBuff,13);
		return 1;
	}
	PrintLog("PSAM-801A OK!Data=%s\r\n",BCD2ASC(TmpBuff,i));
	PrintLog("PSAM-801A:Len=%d,SW=%04X,Data=%s\r\n",samApdu_rlen,sw,BCD2ASC(RevBuff,samApdu_rlen));
	if(sw != 0x9000){
		return 1;
	}

															// 410002A01131
	//                 80FA050020|0000000000000000|000000C8|05|410002A01131|00000001|20151109101909|8000
	//步骤1：PSAM卡指令: 80FA050020|0000000000000000|00000011|05|112233445566|00000001|20080105163100|8000
	TmpBuff[0] =0x80;
	TmpBuff[1] =0xFA;
	TmpBuff[2] =0x05;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x20;
	TmpBuff[5] =0x00;
	TmpBuff[6] =0x00;
	TmpBuff[7] =0x00;
	TmpBuff[8] =0x00;
	TmpBuff[9] =0x00;
	TmpBuff[10] =0x00;
	TmpBuff[11] =0x00;
	TmpBuff[12] =0x00;//VI(全00)  8 bytes
	memcpy(&TmpBuff[13],&u32Money,4);//4 HEX(M) 交易金额
	TmpBuff[17]=0x05;				// 1 Hex,05，交易类型标识
	memcpy(&TmpBuff[18],m_u8AccPsamTerminalID,6); //6 Hex 终端机编号
	memcpy(&TmpBuff[24],&u32TranSn,4); //终端机交易序号
	memcpy(&TmpBuff[28],ucProcessTime,7); //交易时间
	TmpBuff[35]=0x80;TmpBuff[36]=0x00;; //8000，结束标志
	PrintBuffer((char*)TmpBuff,37);
	if(Sim_Apdu(slot,TmpBuff,37,RevBuff,&samApdu_rlen,&sw)){
		PrintLog("PSAM-80FA %d is ERROR\r\n",slot);
		PrintBuffer((char*)RevBuff,37);
		return 1;
	}
	PrintLog("PSAM-80FA OK!Data=%s\r\n",BCD2ASC(TmpBuff,i));
	PrintLog("PSAM-80FA:Len=%d,SW=%04X,Data=%s\r\n",samApdu_rlen,sw,BCD2ASC(RevBuff,samApdu_rlen));
	if(sw != 0x9000){
		return 1;
	}
	memcpy(TAC,RevBuff,4);

	return 0;
}

int GetULCardSn(unsigned char * ucULCardSn)
{

	if(ucULCardSn==NULL)
	{
		return CE_FAIL;
	}

	//根据卡信息 判断卡的有效性。

	unsigned char TmpBuff[400];
	INT32U 	apdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;

	unsigned int uiTranSn=0;

	INT32U slot=SAM_SLOT_ACC;//默认地铁CPU卡的PSAM卡槽是1

	memset(TmpBuff,0x00,sizeof(TmpBuff));
	memset(RevBuff,0x00,sizeof(RevBuff));

//	//步骤0：PSAM卡选1001应用目录:00A40000021001
//	TmpBuff[0] =0x00;
//	TmpBuff[1] =0xA4;
//	TmpBuff[2] =0x00;
//	TmpBuff[3] =0x00;
//	TmpBuff[4] =0x02;
//	TmpBuff[5] =0x10;
//	TmpBuff[6] =0x01;
//	if(Sim_Apdu(slot,TmpBuff,7,RevBuff,&apdu_rlen,&sw)){
//		PrintLog("PSAM-Select1001 %d is ERROR\r\n",slot);
//		return 1;
//	}
//	PrintLog("PSAM-Select1001 OK!Data=%s\r\n",BCD2ASC(TmpBuff,7));
//	PrintLog("PSAM-Select1001:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
//	if(sw != 0x9000){
//		return 1;
//	}

	//步骤2：PSAM卡读0015逻辑加密卡终端交易计数文件
	TmpBuff[0] =0x00;
	TmpBuff[1] =0xB0;
	TmpBuff[2] =0x98;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x04;
	if(Sim_Apdu(slot,TmpBuff,5,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-Read0016 %d is ERROR\r\n",slot);
		return 1;
	}
	PrintLog("PSAM-Read0016 OK!Data=%s\r\n",BCD2ASC(TmpBuff,5));
	PrintLog("PSAM-Read0016:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		return 1;
	}
	memcpy(&uiTranSn,RevBuff,4);//逻辑加密卡终端交易计数
	uiTranSn=htonl(uiTranSn);
	memcpy(ucULCardSn,&uiTranSn,4);//逻辑加密卡终端交易计数

	return CE_OK;

}

int PlusULCardSn()
{
	//根据卡信息 判断卡的有效性。

	unsigned char TmpBuff[400];
	INT32U 	apdu_rlen=0;
	INT8U 	RevBuff[400];
	INT16U	sw;

	int ulCardSn=0;

	INT32U slot=SAM_SLOT_ACC;//默认地铁CPU卡的PSAM卡槽是1

	memset(TmpBuff,0x00,sizeof(TmpBuff));
	memset(RevBuff,0x00,sizeof(RevBuff));

//	//步骤0：PSAM卡选1001应用目录:00A40000021001
//	TmpBuff[0] =0x00;
//	TmpBuff[1] =0xA4;
//	TmpBuff[2] =0x00;
//	TmpBuff[3] =0x00;
//	TmpBuff[4] =0x02;
//	TmpBuff[5] =0x10;
//	TmpBuff[6] =0x01;
//	if(Sim_Apdu(slot,TmpBuff,7,RevBuff,&apdu_rlen,&sw)){
//		PrintLog("PSAM-Select1001 %d is ERROR\r\n",slot);
//		return 1;
//	}
//	PrintLog("PSAM-Select1001 OK!Data=%s\r\n",BCD2ASC(TmpBuff,7));
//	PrintLog("PSAM-Select1001:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
//	if(sw != 0x9000){
//		return 1;
//	}
	//步骤2：PSAM卡读0015逻辑加密卡终端交易计数文件
	TmpBuff[0] =0x00;
	TmpBuff[1] =0xB0;
	TmpBuff[2] =0x98;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x04;
	if(Sim_Apdu(slot,TmpBuff,5,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-Read0018 %d is ERROR\r\n",slot);
		return 1;
	}
	PrintLog("PSAM-Read0018 OK!Data=%s\r\n",BCD2ASC(TmpBuff,5));
	PrintLog("PSAM-Read0018:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		return 1;
	}
	memcpy(&ulCardSn,RevBuff,4);//逻辑加密卡终端交易计数

	ulCardSn=htonl(ulCardSn);
	ulCardSn+=1;
	ulCardSn=htonl(ulCardSn);
	//步骤2：PSAM卡写0018逻辑加密卡终端交易计数文件
	TmpBuff[0] =0x00;
	TmpBuff[1] =0xD6;
	TmpBuff[2] =0x98;
	TmpBuff[3] =0x00;
	TmpBuff[4] =0x04;
	memcpy(TmpBuff+5,&ulCardSn,4);
	if(Sim_Apdu(slot,TmpBuff,9,RevBuff,&apdu_rlen,&sw)){
		PrintLog("PSAM-write0018 %d is ERROR\r\n",slot);
		return 1;
	}
	PrintLog("PSAM-write0018 OK!Data=%s\r\n",BCD2ASC(TmpBuff,9));
	PrintLog("PSAM-write0018:Len=%d,SW=%04X,Data=%s\r\n",apdu_rlen,sw,BCD2ASC(RevBuff,apdu_rlen));
	if(sw != 0x9000){
		return 1;
	}
	return CE_OK;
}

