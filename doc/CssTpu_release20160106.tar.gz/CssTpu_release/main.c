/*********************************************************
*程序名称:		main.cpp
*版本号:		0.1			
*功能描述:  	长沙读卡器主程序
*作者:			王洪峰			
*创建日期:		2015.1.12		
*修改记录:		
				
*其他:						
***********************************************************/
 
#include "msgprocess.h"	//消息处理函数
#include "CSReaderCode.h"

#include "main.h"
#include "XPublic/crc.h"
#include "RWParam/RWParameter.h"
#include "RWBusiness/DegradeModeBusinuess.h"

#include "TicketEntity/PollingCardEntity.h"
#include "TicketEntity/AccCpuCardEntity.h"

#define  COM_NAME  "/dev/ttyS1"

int main(int argc, char ** argv)
{





	int iRet=-1;
	int icommHandle=-1;

	//Init log module
	InitLog(LOG_FILE_TPU);

	SetLogLevel(LOG_LEVEL_INFO);

	InitModeList();

	//打开串口
	char szcomPort[128]={0};
	strcpy(szcomPort,COM_NAME);

	icommHandle=OpenComPort(szcomPort, 115200, 'N');
	if(icommHandle<0)
	{
		PrintLog("File[%s]Line[%d]读卡器应用程序打开串口[%s]失败",__FILE__,__LINE__,COM_NAME);
		exit(0);
	}

	PrintLog("File[%s]Line[%d]读卡器应用程序启动!!!",__FILE__,__LINE__);

	//todo : Init device;

	DeviceInit();

	//todo:  Init Parameter;
	InitParam();

	//todo: Init biz
	//InitBiz();


	while(TRUE)
	{

//		PrintHexMsg(szcomPort,128,TRUE);
//		PrintLog("File[%s]Line[%d]XXXXXXXXXXxxx33",__FILE__,__LINE__);
//		PrintError("File[%s]Line[%d]Xoooooopppplllkkkxx111",__FILE__,__LINE__);
//		PrintBuffer(szcomPort,128);
//		continue;


		//判断串口是否打开,如果打开,未打开则退出程序
		if(!CheckComStatus())
		{
			PrintLog("File[%s]Line[%d]串口未打开则退出程序",__FILE__,__LINE__);
			continue;
		}
		
		fd_set readFds;
		struct timeval timeout;
		FD_ZERO(&readFds);
		timeout.tv_sec = 1000;
		timeout.tv_usec = 0;
		FD_SET(icommHandle,  &readFds);

		//阻塞式读取串口信息，当串口有数据时，即可返回，无数据时，则阻塞指定时间，防止CPU占用率很高；
		iRet = select(icommHandle+1, &readFds, NULL, NULL, &timeout);
		if(iRet!=1)
		{
			//PrintLog("read massage timeout]",__FILE__,__LINE__);
			continue;
		}

		//读取通讯头
		if(ReadMsgStx(100)==FALSE)
		{ 
			continue;
		}

		PrintLog("File[%s]Line[%d] ReadMsgStx end",__FILE__,__LINE__);
		//1秒钟以内必须读完全部数据体,并存入全局结构体g_RecvCommData
		iRet = ReadCommMsgBody(2000);
		switch(iRet) //数据体全部读取正确(包括CRC16校验)
		{
			//处理读到的消息,并存入全局结构体g_SendCommData
		case RW_EC_OK:
			MsgProcess();
			break;
		default:
			PrintLog("File[%s]Line[%d] ReadCommMsgBody iRet=[%d]",__FILE__,__LINE__,iRet);
			break;

		}
	}

	return 1;
}



void DeviceInit()
{

	printf("Openning SimMoudle  !!!!\n");
	if(OpenSimMoudle())
	{
		printf("OpenSimMoudle ERROR !!!!\n");
		return ;
	}

	//init rfid

	if(RFIDModuleOpen(1))
	{
		printf("RFID.........Open Module is FAILE\r\n");
	}

	printf("RFID.........Open Module 1 is ok\r\n");

	SelectRFIDSlot(1);

	printf("RFID.........SelectRFIDSlot 1\r\n");

	if(Rf_Init(1))
	{
		printf("RFID...........uRF Init is FAILE\r\n");
	}

	printf("RFID.........Rf_Init 1\r\n");

	if(RFIDModuleOpen(2))
	{
		printf("RFID.........Open Module is FAILE\r\n");
	}

	printf("RFID.........Open Module 2 is ok\r\n");

	SelectRFIDSlot(2);

	printf("RFID.........SelectRFIDSlot 2\r\n");

	if(Rf_Init(2))
	{
		printf("RFID...........uRF Init is FAILE\r\n");
	}
	printf("RFID.........Rf_Init 2\r\n");

	printf("Openning FeromRtcOpen  !!!!\n");
	if(FeromRtcOpen())
	{
		printf("FeromRtcOpen ERROR !!!!\n");
	}

	//Beep open
	BeepKeyOpen();
    //beep 100
	Beep(100);

}




