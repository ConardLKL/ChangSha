/*
 * cthreadlog.h
 *
 *  Created on: 2015年11月3日
 *      Author: whf
 */

#ifndef XPUBLIC_CTHREADLOG_H_
#define XPUBLIC_CTHREADLOG_H_

#include <stdlib.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

#include "DataTypeDefine.h"

//#pragma pack(push,1)

#define LOG_FILE_TPU 	0 //业务日志
#define LOG_FILE_UD  	1 //交易数据
#define LOG_FILE_COMM 	2 //通讯日志

#define PER_BLOCK_SIZE 2000//4096

#define LOG_BUFFER_MAX_SIZE  1024*15

//日志级别
//DEBUG Level指出细粒度信息事件对调试应用程序是非常有帮助的。
#define LOG_LEVEL_DEBUG 0

//INFO level表明 消息在粗粒度级别上突出强调应用程序的运行过程。
#define LOG_LEVEL_INFO 1

//WARN level表明会出现潜在错误的情形。
#define LOG_LEVEL_WARN 2

//ERROR level指出虽然发生错误事件，但仍然不影响系统的继续运行。
#define LOG_LEVEL_ERROR 3

//FATAL level指出每个严重的错误事件将会导致应用程序的退出。
#define LOG_LEVEL_FATAL 4

typedef struct _stMsgQueue
{
   long msgtype;
   unsigned char LogFileType;
   char msgtext[PER_BLOCK_SIZE+1]; //定义消息的最大长度是4096,最后一个是'\0'
} stMsgQueue;

typedef struct _ST_LOG_FILE_INFO_
{
	FILE    *fp ;
	uint8    szFileDate[128];
}ST_LOG_FILE_INFO;


//初始化
BOOL InitLog(BYTE LogFileId);

//判断是否调用已经结束,如果已经结束则
BOOL CheckIfCallFinished();

//打印string串日志
void PrintDebug(const char *pszLog, ...);
void PrintLog(const char *pszLog, ...);
void PrintWarn(const char *pszLog, ...);
void PrintError(const char *pszLog, ...);
void PrintBuffer(const char *pszCmd,int iLen);
void PrintUD(const char *pszCmd,int iLen);
void WriteLog(BYTE LogLevel,BYTE FileType,const char *pszLog);

//打印hex数组串日志
void PrintHexMsg(const char *pszCmd, int iLen,BOOL bIsTx);

//强制写磁盘
void  FlushDisk();

//设置日志级别
BOOL  SetLogLevel(BYTE LogLevel);

//获取文件大小(-1表示失败)
unsigned long GetFileSize(const char *path);

//读取文件内容
BOOL ReadFileData(char *szFileName, //读取文件名
				int Pos, 	//读取文件的起始位置
				WORD len,  //读取文件的长度
				BYTE * pReadedData); //读取的文件内容
				//WORD * pReadedLen);  //实际读取到的长度



void OpenAndWriteFile(FILE ** fLogFile,uint8 *LogFileDate,stMsgQueue * pmsg);

void CloseFile(FILE * fLogFile);

BOOL ProcessHistoryLog(int DayCount, uint8 CurDate[4]);

void CreatThread_ReadMsg();

//线程函数
static void * ThreadProc(void *arg);



#endif /* XPUBLIC_CTHREADLOG_H_ */
