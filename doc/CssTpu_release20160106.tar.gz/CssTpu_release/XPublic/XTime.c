
#include "XTime.h"

static const char daytab[2][13] =
{
    //    Jan  Feb  Mar  Apr  May  Jun  Jul  Aug  Sep  Oct  Nov  Dec
    { 0 , 31 , 28 , 31 , 30 , 31 , 30 , 31 , 31 , 30 , 31 , 30 , 31 } ,	// Non-leap year
    { 0 , 31 , 29 , 31 , 30 , 31 , 30 , 31 , 31 , 30 , 31 , 30 , 31 }		// Leap year
};

void TimeT_to_BCD(uint32  in_put, uint8 * out_put)
{
	uint16 year,month,day,hour,minute,second,i,leap;
	uint32 days;
	uint32 temp = 0;
	
  //转化方法: 首先计算出有多少天,再推算年月日 时分秒
  days = in_put/(24*60*60);
	year = 2000;
  while(	(		(days >= 365)	&&	!IsLeapYear(year)		) 		||  //如果不是闰年,剩余366或365天,继续循环
			  	(		(days >= 366)	&&	 IsLeapYear(year)		)					//如果是闰年,剩余366天,继续循环
			 )									
	{
		if (IsLeapYear(year))
 			days -= 366;
		else
			days -= 365;
	  year++;	
	}

  //计算出月份
  if ( IsLeapYear(year))
		leap = 1;
	else
		leap = 0;
    
  for(i=0;i<=12;i++) 
  {
    if (days >= (uint32)daytab[leap][i])
    {
			days -= daytab[leap][i] ;
			month = i+1;
    }
	  else
			break;
  }
  //计算出天
	day = (uint16)days+1;
	//计算出小时
	temp = in_put%(24*60*60);
	hour = (uint16)(temp/(60*60));
	//计算出分钟
	temp = temp%(60*60);
	minute = (uint16)(temp/60);
	//计算出秒
	second = (uint16)(temp%60);

	Decimal_to_BCD((uint32)year, 2, out_put);
	Decimal_to_BCD((uint32)month, 1, out_put+2);
	Decimal_to_BCD((uint32)day, 1, out_put+3);
	Decimal_to_BCD((uint32)hour, 1, out_put+4);
	Decimal_to_BCD((uint32)minute, 1, out_put+5);
	Decimal_to_BCD((uint32)second, 1, out_put+6);
}



void BCD_to_TimeT(uint8 * in_put, uint32 * out_put)
{
	uint16 year,month,day,hour,minute,second,i,leap;
	uint32 days;
	
    year = ((in_put[0]&0xF0)>>4)*1000  + (in_put[0]&0x0F)*100 + ((in_put[1]&0xF0)>>4)*10 + (in_put[1]&0x0F) ;
	month = BCD_to_Decimal(in_put[2]);
	day = BCD_to_Decimal(in_put[3]);
	hour = BCD_to_Decimal(in_put[4]);
	minute = BCD_to_Decimal(in_put[5]);
	second = BCD_to_Decimal(in_put[6]);
	days = 0;

	//首先计算出距离1970-1-1 00:00:00有多少天
  for(i=2000;i<=(year-1);i++)
  {
  	//闰年366天,平年365天
  	if ( IsLeapYear(i))
 			days += 366;
		else
			days += 365;
  }
  if (IsLeapYear(year))
		leap = 1;
	else
		leap = 0;
    
  for(i=0;i<month;i++) days += daytab[leap][i] ;
	days = days+(day-1);	//注意这一步很重要
	
	//转化出需要的TimeT值 
	*out_put = days*(24*60*60) + hour*60*60 + minute*60 + second;
}

void BCDTimeAddSeconds(uint32  u32Senconds,uint8 * u8inBCDTime,uint8 * u8outBCDTime)
{
	uint32 tempTimeT=0;

	BCD_to_TimeT(u8inBCDTime,&tempTimeT);

	tempTimeT+=u32Senconds;

	TimeT_to_BCD(tempTimeT,u8outBCDTime);

}


BOOL IsLeapYear(unsigned int year)
{
	if ( (year%400==0) || ((year%100!=0) && (year%4==0)))
		return TRUE;
	else
		return FALSE;
}


/*! \fn		ProcessTime4ToWeekDay()
 * \brief 	从票卡中Time4获取周数
 * \param[in]  0x20150405121110
 * \return 	 int 周几 0~6
 * \author
 * \date
 */
int GetWeekDayOf7BCDTime(unsigned char *pszHexString)
{

	int y=0;
	int m=0;
	int d=0;
	int iWeek=0;

	y=BCD_to_Decimal(pszHexString[0])*100+BCD_to_Decimal(pszHexString[1]);
	m=BCD_to_Decimal(pszHexString[2]);
	d=BCD_to_Decimal(pszHexString[3]);

	if(m==1||m==2)
	{
		m+=12;
		y--;
	}
	iWeek=(d+2*m+3*(m+1)/5+y+y/4-y/100+y/400)%7;

	switch(iWeek)
	{
	case 0: //星期一
		//printf("星期一\n");
		iWeek=1;
		break;
	case 1: //星期二
		//printf("星期二\n");
		iWeek=2;
		break;
	case 2:
		//printf("星期三\n");
		iWeek=3;
		break;
	case 3:
		//printf("星期四\n");
		iWeek=3;
		break;
	case 4:
		//printf("星期五\n");
		iWeek=4;
		break;
	case 5:
		//printf("星期六\n");
		iWeek=5;
		break;
	case 6:
		//printf("星期日\n");
		iWeek=0;
		break;
	}


	return iWeek;
}

/*!\fn   8    clock_t  PubClockTickAddms(unsigned long ulClockTickSpan)
*  \brief     Jiffies与固定时长相加，返回两数之和
*  \param	   unsigned long ulTimeSpanOfms 以毫秒为单位的时间间隔
*  \return    clock_t
*  \author	   licd
*  \date	   2012-10-31
*  \note
*/
int InitClockTickTimeOut(struct  timespec *pTimeOutClockTick,unsigned long ulTimeSpecOfms)
 {

 	if(pTimeOutClockTick ==NULL)
 	 return -1;

	int iRet=0;
	unsigned long ulTimeoutsec=0;
	unsigned long ulTimeoutMsec=0;
	unsigned long ulTimeoutNsec=0;

	iRet=clock_gettime(CLOCK_MONOTONIC,pTimeOutClockTick);

	 ulTimeoutsec=ulTimeSpecOfms/1000;
	 ulTimeoutMsec=ulTimeSpecOfms%1000;

	 if(ulTimeoutMsec!=0)
	 {

		 ulTimeoutNsec=pTimeOutClockTick->tv_nsec+ulTimeoutMsec*(1000*1000);
		 ulTimeoutsec+=ulTimeoutNsec/(1000*1000*1000);
		 ulTimeoutNsec=ulTimeoutNsec%(1000*1000*1000);
	 }

	 pTimeOutClockTick->tv_sec+=ulTimeoutsec;
	 pTimeOutClockTick->tv_nsec+=ulTimeoutNsec;

	 return iRet;
 }

/*!\fn   8  BOOL PubClockTickIsTimeOut(unsigned long ulClockTick)
*  \brief    判断 ulClockTick 是否小于系统当前ClockTick
*  \param    unsigned long ulJiffiesTime 以10毫秒为单位的时刻值
*  \return    BOOL true 超时，false 未超时
*  \author	   licd
*  \date		2012-10-31
*  \note
*/
BOOL CheckClockTickTimeOut( struct  timespec  * pTimeOutClockTick)
 {

	BOOL bRet=FALSE;
	struct timespec currentTime;
	 memset(&currentTime,0,sizeof(currentTime));
	 clock_gettime(CLOCK_MONOTONIC,&currentTime);

	 if(currentTime.tv_sec-pTimeOutClockTick->tv_sec>0)
	 {
		 bRet=TRUE;
	 }
	 else if(currentTime.tv_sec-pTimeOutClockTick->tv_sec==0&&currentTime.tv_nsec-pTimeOutClockTick->tv_nsec>0)
	 {
		 bRet=TRUE;
	 }
	 return bRet;
 }
/**
 * \brief  		GetCurrentTime 获取当前的系统时间 BCD编码
 * \param[in]:	入参：无
 * \param[out]:	出参：char *szDate,char *szTime
 * \return: 		返回类型：void
 * \author:		作者：songyn
 * \date:			时间：2010-04-13
 */
void GetCurrentTime(unsigned char *szDateTime)
{
	//gCoreLog.LogInfo(0,0,(char*)"[%s][%d]计算时间。",__FILE__,__LINE__);
	time_t timep;
	struct tm *p;
	time(&timep);
	//p = localtime(&timep); //获取当前时间
	struct tm ptm = { 0 };
	p = localtime_r(&timep,&ptm);

	unsigned char szYear[2] = { 0 };
	//int iyear = 1900+p->tm_year;
	//memcpy(szYear,(void*)iyear,sizeof(iyear));
	szYear[1] = (1900 + p->tm_year) % 100 / 10 * 16 + (1900 + p->tm_year) % 100
			% 10;
	szYear[0] = (1900 + p->tm_year) / 100 / 10 * 16 + (1900 + p->tm_year) / 100
			% 10;
	unsigned char szMonth = (1 + p->tm_mon) / 10 * 16 + (1 + p->tm_mon) % 10;
	unsigned char szDay = p->tm_mday / 10 * 16 + p->tm_mday % 10;

	unsigned char szHour = p->tm_hour / 10 * 16 + p->tm_hour % 10;
	unsigned char szMin = p->tm_min / 10 * 16 + p->tm_min % 10;
	unsigned char szSec = p->tm_sec / 10 * 16 + p->tm_sec % 10;

	memcpy(szDateTime, szYear, sizeof(szYear));
	memcpy(szDateTime + sizeof(szYear), &szMonth, sizeof(szMonth));
	memcpy(szDateTime + sizeof(szYear) + sizeof(szMonth), &szDay, sizeof(szDay));

	memcpy(szDateTime + sizeof(szYear) + sizeof(szMonth)+sizeof(szDay), &szHour, sizeof(szHour));
	memcpy(szDateTime +sizeof(szYear) + sizeof(szMonth)+sizeof(szDay)+ sizeof(szHour), &szMin, sizeof(szMin));
	memcpy(szDateTime +sizeof(szYear) + sizeof(szMonth)+sizeof(szDay)+ sizeof(szHour) + sizeof(szMin), &szSec, sizeof(szSec));
}
