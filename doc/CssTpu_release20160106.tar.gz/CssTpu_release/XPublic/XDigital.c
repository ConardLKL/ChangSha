
#include "XDigital.h"

static	unsigned long longMaskArray[33]; //掩码

uint8 BCD_to_Decimal(uint8 in_put)
{
	//本函数将1个字节的压缩BCD转化为10进制数值
	//例如: 0x2008转化成20
  return ((in_put&0xF0)>>4)*10 + (in_put&0x0F);	
}

uint8 Byte_Decimal_to_BCD(uint8 in_put)
{
	//本函数将10进制数值转化为压缩BCD形式存放,目前最多支持1个字节的BCD
	//例如: 20转化成0x20
   return (uint8)((in_put/10<<4) + (in_put%10));
}

void Decimal_to_BCD(uint32 in_put,uint8 length,uint8 * out_put)
{
	//本函数将10进制数值转化为压缩BCD形式存放,目前最多支持4个字节的BCD
	//例如: 2008转化成0x2008
	
	int i;
	uint32 temp;
	if(length > 4) length = 4;
	for(i=length;i>0;i--)
	{
		temp = in_put % 100;
		out_put[i-1] = (uint8)((temp/10<<4) + (temp%10));
		in_put /= 100;
	}
}

/*! \fn		BcdToString()
 * \brief 	字符串转BCD码
 * \param[in]  pszBcd 字符串0x20 0x15 0x26 0x12 0x12 0x12”
 * \param[in]  iStringLength 需要转换数据的字节数
 * \param[out]  pszBcdString 字符串
 * \return 	 int 秒数
 * \author
 * \date
 */
void BcdToString(unsigned char *pszBcd, int iStringLength,  char *pszBcdString)
{
	char szTemp[16]={0};
	int i=0;
	for(i=0; i<iStringLength; i++)
	{
		memset(szTemp,0,sizeof(szTemp));
		sprintf(szTemp, "%02X", (int)pszBcd[i]);
		strcat((char*)pszBcdString, szTemp);
	}
	return;
}

/*! \fn		StringToBcd()
 * \brief 	字符串转BCD码
 * \param[in]  pString 字符串 “20100308”
 * \param[out] pBcd BCD码 0x20 0x10 0x03 0x08
 * \return 	 void
 * \author
 * \date
 */
void StringToBcd( char *pString, unsigned char *pBcd)
{
	int k = 0;
	unsigned i = 0;
	unsigned char ucValue = 0;
	unsigned char szPack[32] = { 0 };

	memcpy(szPack, pString, strlen((const char *) pString));
	if ((strlen((const char *) szPack) % 2) != 0)
	{
		return;
	}

	for (i = 0; i < strlen((const char *) szPack); i++)
	{
		ucValue = (szPack[i++] & 0x0F) << 4; //例如："2015" 内存保存形式：0x32 0x30 0x31 0x35
		ucValue |= szPack[i] & 0x0F;
		pBcd[k++] = ucValue;
	}

	return;
}
/*
 *	9.3.23 BR.BitstreamInitMasks
 *	给每一个字段长度可能在1 到32 位之间的字段生成长数值位屏蔽。
 *	此函数必须在初始化屏蔽时只调用一次。
 */
 /* A pre-defined array of bit masks for each bit length up to 32 */

void BitstreamInitMasks(void)
{
	int i;
	longMaskArray[0] = 0;
	for ( i = 1; i <= 32; i++ )
	{
		longMaskArray[ i ] = ( 0xFFFFFFFF >> (32 - i ) );
	}
 }


/*
 *	9.3.21 BR.BitStreamPack
 *	将长达32 位的数据入列为数据流。
 */
 /*
 * Description:
 * Converts a long word value to a non U8_t aligned bit field value into
 * the bit stream.
 *
 * Inputs:
 * U32_t longValue long value of the field in the endian format
 * of the processor
 * U8_t *pRawDataRecord pointer to the raw bit stream
 * U16_t bitOffset offset of start of bit field in the bit stream
 * U16_t bitLength length of bit field in the bit stream
 *
 * Outputs:
 * None. (raw bit stream is modified)
 *
 * Returns:
 * 0 No error if bitLength <= 32
 * -1 If conversion failed due to bitLength > 32
 *
 * The algorithm
 * The raw data is in big endian format.
 *
 * Given a data stream of U8_ts: b0 b1 b2 b3, then
 * the long value in big endian format is = b0<<24 + b1<<16 + b2<<8 +
 * b3.
 *
 * set most significant U8_t offset = bitOffset / 8
 * set least significant U8_t offset = ( bitOffset + bitLength - 1 ) / 8
 * set number of field U8_ts = numU8_ts = lsU8_tOffset - msU8_tOffset + 1
 *
 * set the number of bit alignment shifts = numLongShifts = 7 –
 * ((bitOffset + bitLength-1) mod 8)
 *
 * set longValue = mask of longValue to bit field size
 * set reverseMask = reverse mask of bit field mask
 *
 * if numU8_ts == 5 then
 * Extract the top U8_t of the long value to later merge into the 5th
 * U8_t bit field
 * Shift the top U8_t by the number of long shifts
 * Create an reverse and shifted mask for the 5th U8_t bit field
 * endif
 *
 * shift the longValue by the number of long shifts to align the long
 * bit value with the bit field
 * shift the inverted long mask by the number of long shifts maintaining
 * the inverted mask
 *
 * set the ls U8_t bit field value to zero using the reverse mask
 * set the ls U8_t bit field value to the actual value using the
 * longValue
 *
 * for each U8_t in the raw bit field from (ls U8_t - 1) to ms U8_t for a
 * total of 3 U8_ts
 * set the U8_t bit field value to zero using the reverse mask
 * set the U8_t bit field value to the actual value using the
 * longValue
 * endfor
 *
 * if numU8_ts == 5
 * set the ms U8_t bit field value to zero using the most sig word
 * reverse mask
 * set the ms U8_t bit field value to the actual value using the most
 * sig word value
 * endif
 */
int BitStreamPack(unsigned long longValue,
		unsigned char *pRawDataRecord,
		unsigned short bitOffset,
		unsigned short bitLength)
 {
	 unsigned short  msU8_tOffset; /* offset of most significant U8_t */
	 unsigned short  lsU8_tOffset; /* offset of least significant U8_t */
	 unsigned short  numU8_ts; /* number of U8_ts containing the value */
	 unsigned long msWordValue = 0;
	 int numLongShifts;
	 int i;
	 unsigned long invLongMask;
	 unsigned long msWordInvMask=0;
	 if ( bitLength > 32 )
	 {
	 /* ERROR: there are more than 32 bits in the field! Can only convert
		 ** up to 32!*/
		 return -1;
	 }
	 /* Determine the least significant U8_t offset and most significant
	 ** U8_t offset of the field bit span...
	 */
	 msU8_tOffset = (unsigned short)(bitOffset / 8);
	 lsU8_tOffset = (unsigned short)((bitOffset + bitLength - 1 ) / 8);
	 /* Determine the number of U8_ts containing the field bit span. */
	 numU8_ts = (unsigned short)(lsU8_tOffset - msU8_tOffset + 1);
	 /* Determine number of long bit alignment shifts...*/
	 numLongShifts = 7 - (( bitOffset + bitLength - 1 ) % 8);
	 /* Mask the long value to determine the actual value of the bit
	 ** field...
	 * Uses a precalculated mask for speed...
	 */
	 longValue &= longMaskArray[ bitLength ];
	 /* determine the inverted long mask... */
	 invLongMask = ~longMaskArray[ bitLength ];
	 /* Shift and merge in the most significant word of the long value,
	 ** offset by the bit alignment
	 */
	 if ( numU8_ts == 5 )
	 {
		 msWordValue = longValue & 0xFFFF0000;
		 msWordValue >>= ( 24 - numLongShifts );
		 msWordInvMask = (invLongMask >> 24) | 0xFFFFFF00;
		 msWordInvMask <<= numLongShifts;
	 }
	 /* Shift the long value by the offset from the least significant
	 ** U8_t...
	 */
	 longValue <<= numLongShifts;
	 /* Shift the inverted mask by the offset... */
	 for ( i = 1; i <= numLongShifts; i++ )
	 {
		 invLongMask = (invLongMask << 1) | 1;
	 }
	 /* Store the bit field back into the bit stream... */
	 i = lsU8_tOffset;
	 /* Mask out the value in the stream to fill... */
	 *( pRawDataRecord + i ) &= (unsigned char)(invLongMask);
	 /* Mask in the value... */
	 *( pRawDataRecord + i ) |= (unsigned char)(longValue);
	 /* Merge the shifted and masked long value into the bit stream..*/
	 for ( --i; (i >= msU8_tOffset) && (i >= lsU8_tOffset-3); --i )
	 {
		 longValue >>= 8;
		 invLongMask >>= 8;
		 *( pRawDataRecord + i ) &= (unsigned char)(invLongMask);
		 *( pRawDataRecord + i ) |= (unsigned char)(longValue);
	 }
	 return 0;
}

 /*
*	9.3.22 BR.BitStreamUnPack
*	将长达32 位的数据自数据流出列。
*/
/*
* Description:
* Converts a non U8_t aligned bit field value of up to 32 bits from the
* bit stream to a U8_t, U16_t or U32_t value.
*
* Inputs:
* void *pValue pointer to storage for unpacked value
* U16_t sizeOfpValue size of storage element in bytes (sizeof() )
* U8_t *pRawDataRecord pointer to the raw bit stream
* U16_t bitOffset offset of start of bit field in the bit
* stream
* U16_t bitLength length of bit field in the bit stream
*
* Outputs:
* *pValue value of the field in the endian format
* of the processor
*
* Returns:
* 0 No error if bitLength <= 32
* -1 Error: conversion failed due to bitLength > 32
*
* The algorithm:
* The raw data is in big endian format.
* Given a data stream of U8_ts: b0 b1 b2 b3, then
* the long value in big endian format is = b0<<24 + b1<<16 + b2<<8 +
* b3.
*
* set most significant U8_t offset = bitOffset / 8
* set least significant U8_t offset = (bitOffset + bitLength - 1) / 8
* set number of field U8_ts = numU8_ts = lsU8_tOffset - msU8_tOffset + 1
*
* set the number of bit alignment shifts = numLongShifts = 7 –
* ((bitOffset + bitLength - 1) mod 8 )
*
* for each U8_t in the raw bit field from most significant to the least
* significant
* set the longValue least sig U8_t to the raw bit field U8_t
* longValue = longValue << 8
* if the bit field U8_t is the most significant + 1 and numU8_ts = 5
* set most significant word value = msWordValue = the top word of
* the longValue
* endif
* endfor
*
* shift the longValue by the number of long shifts to align the long bit
* value with the bit field value
*
* if numU8_ts = 5 then
* shift the msWordValue by the number of long shifts to align the bit
* value with the bit field value
* merge the msWordValue into the longValue
* endif
*
* set longValue = mask of longValue to bit field size
*/
int BitStreamUnPack(void *pValue,
		unsigned short sizeOfpValue,
		unsigned char *pRawDataRecord,
		unsigned short bitOffset,
		 unsigned short bitLength)
{
	unsigned short msU8_tOffset; /* offset of most significant U8_t */
	unsigned short lsU8_tOffset; /* offset of least significant U8_t */
	unsigned short numU8_ts; /* number of U8_ts containing the value */
	unsigned long msWordValue = 0;
	int numLongShifts;
	int i;
	unsigned long longValue;

	if ( bitLength > 32 )
	 {
	 /* ERROR: there are more than 32 bits in the field! Can only convert
		 ** up to 32!*/
		 return -1;
	 }
	 /* Determine the least significant U8_t offset and most significant
	 ** U8_t offset of the field bit span...
	 ** For a long word, the U8_t sequence would be: b0 b1 b2 b3, where
	 ** msU8_t=b0, lsU8_t=b3.
	 */
	 msU8_tOffset = (unsigned short)(bitOffset / 8);


	 lsU8_tOffset = (unsigned short)((bitOffset + bitLength - 1 ) / 8);

	 /* Determine the number of U8_ts containing the field bit span..*/
	 numU8_ts = (unsigned short)(lsU8_tOffset - msU8_tOffset + 1);

	 /* Calculate the long value of the field... */
	 i = msU8_tOffset;

	 longValue = 0;
	 longValue |= (((unsigned int)*( pRawDataRecord + i )) & 0x000000FF);

	 for ( ++i; i <= lsU8_tOffset; ++i )
	 {
		 longValue <<= 8;


		 longValue |= (((unsigned int)*( pRawDataRecord + i )) & 0x000000FF);


		 if ( (numU8_ts == 5) && (i == ( msU8_tOffset + 1 )) )
		 {
			 msWordValue = longValue;
		 }
	 }
	 /* Determine number of long bit alignment shifts... */
	 numLongShifts = 7 - (( bitOffset + bitLength - 1 ) % 8);
	 /* Shift the long value by the offset from the least significant
	 ** U8_t...
	 */
	 longValue >>= numLongShifts;
	 /* Shift and merge in the most significant word of the long value,
	 ** offset by the bit alignment
	 */
	 if ( numU8_ts == 5 )
	 {
		 msWordValue <<= ( 24 - numLongShifts );
		 longValue |= msWordValue;
	 }

	 /* Mask the long value to determine the actual value of the field...
	 * Uses a precalculated mask for speed...
	 */
	 longValue &= longMaskArray[bitLength];

	 switch (sizeOfpValue)
	 {
	 	 case sizeof(unsigned char):
	 			 *((unsigned char*)pValue) = (unsigned char) longValue;
	 	 break;
	 	 case sizeof(unsigned short):
	 			 *((unsigned short*)pValue) = (unsigned short)longValue;
	 	 break;
	 	 case sizeof(unsigned int):
	 			// *((unsigned int*)pValue) = (unsigned int)longValue;
	 	     memcpy(pValue,&longValue,sizeof(unsigned int));
	     	//PrintLog("File[%s]Line[%d]  pValue=[%d] longValue[%d]",__FILE__,__LINE__,*((unsigned int*)pValue),longValue);
	 	 break;
	 }

	 return 0;
}
