/*********************************************************
*程序名称:		crc16.h
*版本号:		0.1			
*功能描述:  	计算Crc16位多项式0x1021
*作者:			王洪峰			
*修改记录:		
				2015.01.09 创建 
*其他:						
***********************************************************/

#ifndef __CRC16_H__
#define __CRC16_H__

unsigned short crc16_ccitt(unsigned char *q, int len);
void TestUnit_crc16_ccitt();

unsigned int crc32(unsigned char *string, unsigned int size);  

unsigned char crc_c(unsigned char x,unsigned char temp);

void crc_cu(unsigned char *string_cu,unsigned char length);

void TestUnit_crc32();
#endif

