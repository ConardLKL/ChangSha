
/*********************************************************
*程序名称:		XTime.h
*版本号:		0.1			
*功能描述:		 <<长沙轨道交通1号线读卡器接口调用API文档.docx>>文档中,
				所有的与上位机的接口处理函数都定义在本文件中,函数名称与文档中的名称一致.
*作者:			licd			
*修改记录:		
				2015.01.13 创建 
*其他:						
***********************************************************/

#ifndef __XTIME_H__
#define __XTIME_H__


#include "XDigital.h"

#include <time.h>
#include <string.h>


void TimeT_to_BCD(uint32  in_put, uint8 * out_put);

void BCD_to_TimeT(uint8 * in_put, uint32 * out_put);

void BCDTimeAddSeconds(uint32  u32Senconds,uint8 * u8inBCDTime,uint8 * u8outBCDTime);

BOOL IsLeapYear(unsigned int year);

int GetWeekDayOf7BCDTime(unsigned char *pszHexString);

//RSR232动态库中，引用了该函数
int InitClockTickTimeOut(struct  timespec *pTimeOutClockTick,unsigned long ulTimeSpecOfms);
//RSR232动态库中，引用了该函数
BOOL CheckClockTickTimeOut( struct  timespec  * pTimeOutClockTick);

void GetCurrentTime(unsigned char *szDateTime);

#endif
