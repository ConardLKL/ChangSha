

#ifndef __XDIGITAL_H__
#define __XDIGITAL_H__
#include "../DataTypeDefine.h"
#include "Log.h"
uint8 BCD_to_Decimal(uint8 in_put);

void Decimal_to_BCD(uint32 in_put,uint8 length,uint8 * out_put);

void BcdToString(unsigned char *pszBcd, int iStringLength,  char *pszBcdString);

void StringToBcd( char *pString, unsigned char *pBcd);


int BitStreamPack(unsigned long longValue, unsigned char *pRawDataRecord,
							unsigned short bitOffset, unsigned short  bitLength);

/* 按Bit 解包Buffer
 *
 * 举例：
 * //序列号，在一次可编程区,读此字段是为了判断其是否初始化
   BitStreamUnPack((void*)&card.serialNumber,sizeof(card.serialNumber),&RawData[0], 96, 32);

   //版本号，此字段读取后判断卡初始化，写票卡之前都会在CD中取得此字段
   BitStreamUnPack((void*)&card.version,sizeof(card.version),&RawData[0], 128, 2);

   //生命周期，必须读取，此字段用来判断生命周期以及对生命周期做加一处理
   BitStreamUnPack((void*)&card.lifecycleCount,sizeof(card.lifecycleCount),&RawData[0], 130, 10);

   //密钥版本，用读取，写票卡不需要用到此字段,并且UD也不需要此字keySetNumber段
   BitStreamUnPack((void*)&card.keySetNumber,sizeof(card.keySetNumber),&RawData[0], 140, 3);

 * */
int BitStreamUnPack(void *pValue, unsigned short sizeOfpValue, unsigned char *pRawDataRecord,
							unsigned short bitOffset, unsigned short bitLength);


/* 按Bit 组包Buffer
 *
 * Generate the long value bit masks for each possible field bit length from 1 to 32.
   给每一个字段长度可能在到位之间的字段生成长数值位屏蔽

   This function must only be called once to initialise the masks.
   此函数必须在初始化掩码时只调用一次。

   A pre-defined array of bit masks for each bit length up to 32
*/
void BitstreamInitMasks(void);




#endif

