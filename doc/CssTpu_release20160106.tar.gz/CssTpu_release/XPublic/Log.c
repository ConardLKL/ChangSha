/*
 * cthreadlog.cpp
 *
 *  Created on: 2015年11月3日
 *      Author: whf
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <error.h>
#include <string.h>
#include <errno.h>
#include <stdarg.h>
#include <dirent.h>
#include <sys/stat.h>

#include "Log.h"
#include"../Globle.h"

//#pragma pack(push,1)



//日志文件类型
//static BYTE m_LogFileID;

//线程ID
static pthread_t m_thread_id;

//线程运行标志
static BOOL m_RunFlag;

//消息队列ID
static int  m_MsgID;

//日志几倍
static BYTE m_LogLevel;


static char m_LogBuffer[15000];

BOOL InitLog(BYTE LogFileID)
{


	//获取消息队列
	key_t msgkey;
	msgkey = ftok("/tpu/run",LogFileID);// LogFileID);
	if(msgkey == -1)
	{
		perror("ftok");
		return FALSE;
	}
	//m_LogFileID = LogFileID;

	m_MsgID = msgget(msgkey, IPC_CREAT | 0666);
	if(m_MsgID == -1)
	{
		perror("msgget");
		return FALSE;
	}else
	{
		printf("m_LogFileID=%d,m_MsgID = %d \n",LogFileID,m_MsgID);
	}

	return TRUE;
}

//创建线程
void  CreatThread_ReadMsg()
{
	int ret;

	m_RunFlag = TRUE;

	//创建线程
  	if((ret=pthread_create(&m_thread_id, NULL, ThreadProc, NULL)) != 0)
  	{
		fprintf(stderr, "call pthread_create() error. msg:%s\n", strerror(ret));
		 exit(0);
	}

}


//线程函数
void * ThreadProc(void *arg)
{
	stMsgQueue msg={0};

	unsigned char szCurrentDate[10]={0};
	unsigned char szLastDate[10]={0};

	//日志文件句柄

	ST_LOG_FILE_INFO  LogFile_TPU ;
	ST_LOG_FILE_INFO  LogFile_COMM;
	ST_LOG_FILE_INFO  LogFile_UD;

	memset(&LogFile_TPU,0,sizeof(ST_LOG_FILE_INFO));
	memset(&LogFile_COMM,0,sizeof(ST_LOG_FILE_INFO));
	memset(&LogFile_UD,0,sizeof(ST_LOG_FILE_INFO));

	GetCurrentTime(szLastDate);

	printf("thread log(m_MsgID=%d) begin... \n\n", m_MsgID);
	while(m_RunFlag)
	{

		/*从标识符为msqid的消息队列读取消息并存于msgp中，读取后把此消息从消息队列中删除*/
		/*msgp 存放消息的结构体，结构体类型要与msgsnd函数发送的类型相同*/
		/*msgsz 要接收消息的大小，不含消息类型占用的4个字节*/
		/*msgtyp 0 接收第一个消息*/
		/*msgtyp <0 接收类型等于或者小于msgtyp绝对值的第一个消息*/
		/*msgtyp >0 接收类型等于msgtyp的第一个消息*/
		/*msgflg 0 阻塞式接收消息，没有该类型的消息msgrcv函数一直阻塞等待*/
		/*msgflg IPC_NOWAIT 如果没有返回条件的消息调用立即返回，此时错误码为ENOMSG*/
		/*msgflg IPC_EXCEPT 与msgtype配合使用返回队列中第一个类型不为msgtype的消息*/
		/*msgflg IPC_NOERROR 如果队列中满足条件的消息内容大于所请求的size字节，则把该消息截断，截断部分将被丢弃*/

		//读取日志数据
		//ssize_t msgrcv(int msqid, void *msgp, size_t msgsz, long msgtyp, int msgflg);
		if(msgrcv(m_MsgID , (void *)&msg, sizeof(stMsgQueue) - sizeof(long),0,MSG_NOERROR) == -1)
		{
			perror("msgrcv");
			printf("m_MsgID = %d \n",m_MsgID);

			sleep(1);
			continue;
		}

		//判断是否是刷新磁盘
		if(msg.msgtype ==2)
		{
			if(LogFile_TPU.fp!=NULL)
			{
				printf("\n fflush disk log file(0) msgtype=2!\n");
				fflush(LogFile_TPU.fp);
			}
			if(LogFile_UD.fp!=NULL)
			{
				printf("\n fflush disk log file(1) msgtype=2!\n");
				fflush(LogFile_UD.fp);
			}
			if(LogFile_COMM.fp!=NULL)
			{
				printf("\n fflush disk log file(2) msgtype=2!\n");
				fflush(LogFile_COMM.fp);
			}
			continue;
		}

		GetCurrentTime(szCurrentDate);

		if(memcmp(szCurrentDate,szLastDate,4)!=0)
		{
			memcpy(szLastDate,szCurrentDate,4);
			//删除5天以前的日志
			printf("\n ProcessHistoryLog msgtype =1!\n");
			ProcessHistoryLog(5,szCurrentDate);

		}



		switch(msg.LogFileType)
		{
		case LOG_FILE_TPU:
			OpenAndWriteFile(&LogFile_TPU.fp,LogFile_TPU.szFileDate,&msg);
			break;
		case LOG_FILE_UD:
			OpenAndWriteFile(&LogFile_UD.fp,LogFile_UD.szFileDate,&msg);
			break;
		case LOG_FILE_COMM:
			OpenAndWriteFile(&LogFile_COMM.fp,LogFile_COMM.szFileDate,&msg);
			break;
		default:
			break;
		}
	}

	CloseFile(LogFile_TPU.fp);
	CloseFile(LogFile_COMM.fp);
	CloseFile(LogFile_UD.fp);

	return NULL;
}

void CloseFile(FILE * fLogFile)
{
	if(fLogFile!=NULL)
	{
		fclose(fLogFile);
		fLogFile = NULL;

	}
}


void OpenAndWriteFile(FILE * *fLogFile,uint8 *LogFileDate,stMsgQueue * pmsg)
{


	BYTE Temp[256];
	char szTemp[128];
	char szFileName[128];
	char szCmd[128]={0};

	int TotalWriteSize =0;
	//日志文件的日期
	//BYTE LogFileDate[8]={0};
	//printf("\n get msg id=%ld\n",msg.msgtype);


	//判断当前文件日期和系统指定的日期是否相同,如果不同则关闭当前日期,打开新的日期文件
	GetCurrentTime(Temp);
	//printf("\n LogFileDate(%02X%02X%02X%02X) msgtype=2!\n",LogFileDate[0],LogFileDate[1],LogFileDate[2],LogFileDate[3]);
	//printf("\n Temp msgtype=2!\n",Temp[0],Temp[1],Temp[2],Temp[3]);
	//printf("\n *fLogFile(%02X) msgtype=2!\n",*fLogFile);
	if(memcmp(LogFileDate,Temp,4)!=0 || *fLogFile ==NULL) //比较年月日
	{

		if(pmsg->LogFileType == LOG_FILE_TPU)  	//业务日志
			sprintf(szTemp,"/tpu/log/tpu");
		else if(pmsg->LogFileType == LOG_FILE_UD)	//交易数据
			sprintf(szTemp,"/tpu/log/ud");
		else if(pmsg->LogFileType == LOG_FILE_COMM)//通讯日志
			sprintf(szTemp,"/tpu/log/comm");
		else
		{
			sleep(1);
		}


		//关闭之前的日志文件
		if(*fLogFile!=NULL)
		{
			sprintf(szFileName,"%s_%02X%02X%02X%02X.log",
					szTemp,
					LogFileDate[0],LogFileDate[1],LogFileDate[2],LogFileDate[3]);

//			//刷新磁盘
//			printf("\n fflush disk log file(%d) msgtype =1!\n",pmsg->LogFileType);
//			fflush(*fLogFile);

			fclose(*fLogFile);
			*fLogFile = NULL;
		}

		//打开新的日志文件
		memcpy(LogFileDate,Temp,4); //获取新的时间
		sprintf(szFileName,"%s_%02X%02X%02X%02X.log",
				szTemp,
				LogFileDate[0],LogFileDate[1],LogFileDate[2],LogFileDate[3]);
		printf("\n fopen szFileName(%s)!\n",szFileName);
		*fLogFile=fopen(szFileName,"at") ;
		if(*fLogFile==(FILE *)0)
		{
			fprintf(stderr,"tpu write log ():can't open the file %s !\n",szTemp);
			sleep(1);
		}
	}
	//确保字符串不会溢出.
	pmsg->msgtext[sizeof(pmsg->msgtext)-1]='\0';
	fputs(pmsg->msgtext,*fLogFile);
	//TotalWriteSize+=strlen(msg.msgtext);
	TotalWriteSize++;
	/*if(TotalWriteSize>1000)
	{
		fflush(fLogFile);
		TotalWriteSize = 0;
	}*/

	//fflush(fLogFile);
	//if(TotalWriteSize>999)
	//printf("recv : %s ",msg.msgtext);

}

void  WriteLog(BYTE LogLevel,BYTE FileType,const char *pszLog)
{

	stMsgQueue msg;
	int i;
	char szTimeStr[100]={0};
//	int Second=0; //系统时间消耗的秒(从SetTransactionTime调用开始)
	int MilliSecond=0; //系统时间消耗的毫秒(从SetTransactionTime调用开始)
	int iStrLen =0;

	//只有级别高过当前系统设置的日志级别才能记录
	if(LogLevel< m_LogLevel )
	{
		return; //无需记录
	}

	//2015.11.06增加本地时间值,主要是用于获取消耗的秒数和毫秒数用于记录日志
//	printf("Print Log::> m_LogFileID=%d,m_MsgID = %d \n",m_LogFileID,m_MsgID);

	struct  tm *p_tm ;
	int imicroSeconds=0;

	struct timeval tp;
	gettimeofday(&tp,NULL);
	p_tm=localtime(&tp.tv_sec) ;

	memset(m_LogBuffer,0,sizeof(m_LogBuffer));

	//可能会出现60秒的情况
//	sprintf(szTimeStr,"%02X%02X%02X%02X %02X:%02X:%02d.%03d ",
//			bcdDateTime[0],bcdDateTime[1],bcdDateTime[2],bcdDateTime[3],
//			bcdDateTime[4],bcdDateTime[5],
//			BCD_to_Decimal(bcdDateTime[6])+MilliSecond/1000,
//			MilliSecond%1000);

	imicroSeconds=tp.tv_usec/1000;
	sprintf(szTimeStr,"%04d%02d%02d %02d:%02d:%02d.%03d ",
			p_tm->tm_year+1900,
			p_tm->tm_mon+1,
			p_tm->tm_mday,
			p_tm->tm_hour,
			p_tm->tm_min,
			p_tm->tm_sec,
			imicroSeconds);

	iStrLen=strlen(szTimeStr);
	memcpy(m_LogBuffer,szTimeStr,iStrLen);


   sprintf(m_LogBuffer+iStrLen,"%s\n",pszLog);

	iStrLen = strlen(m_LogBuffer);

	if(iStrLen<=PER_BLOCK_SIZE)
	{
		//写入到消息队列中去.
		msg.msgtype = 1;
		msg.LogFileType=FileType;
		strcpy(msg.msgtext,m_LogBuffer);
		if (msgsnd(m_MsgID,&msg,4+iStrLen,0) < 0 )//IPC_NOWAIT
		//if (msgsnd(m_MsgID,&msg,sizeof(stMsgQueue),0) < 0 )//IPC_NOWAIT
		{
			printf("msgsnd() write msg failed,errno=%d[%s]\n",errno,strerror(errno));
		}
	}else
	{
		int BlockCount=iStrLen/(PER_BLOCK_SIZE); //的目的是为了保证最后一个字符是0

		//将消息写到消息队列中去,如果操作4K,则进行截取.
		for(i=0;i<BlockCount;i++)
		{
			//写入到消息队列中去.
			msg.msgtype = 1;
			msg.LogFileType=FileType;
			memcpy(msg.msgtext,m_LogBuffer+i*PER_BLOCK_SIZE,PER_BLOCK_SIZE);
			if ( msgsnd(m_MsgID,&msg,sizeof(stMsgQueue),IPC_NOWAIT) < 0 )
			{
				printf("msgsnd() write msg failed,errno=%d[%s]\n",errno,strerror(errno));
			}
		}
		if(iStrLen%PER_BLOCK_SIZE != 0) //最后一块
		{
			msg.msgtype = 1;
			msg.LogFileType=FileType;
			strcpy(msg.msgtext,m_LogBuffer+i*PER_BLOCK_SIZE);
			if ( msgsnd(m_MsgID,&msg,sizeof(stMsgQueue),IPC_NOWAIT) < 0 )
			{
				printf("msgsnd() write msg failed,errno=%d[%s]\n",errno,strerror(errno));
			}
		}
	}
//	printf("send: ");
//	printf(szTimeStr);
//	//added by wanghongfeng 2015.08.18,为了打印也能够显示(便于调试)
//	va_start(ap,pszLog);
//	vprintf(pszLog,ap) ;
//	va_end(ap);
	//printf("\n");
}

//强制写磁盘
void  FlushDisk()
{
	void  FlushDisk();
 	stMsgQueue msg;

	//写入到消息队列中去.
	msg.msgtype = 2;
	msg.LogFileType=LOG_FILE_TPU;
	if (msgsnd(m_MsgID,&msg,4+1,0) < 0 )//IPC_NOWAIT
	{
		printf("msgsnd() write msg failed,errno=%d[%s]\n",errno,strerror(errno));
	}

	//printf("send Flush Disk File(%d) \n",m_LogFileID);
}

//设置日志级别
BOOL  SetLogLevel(BYTE LogLevel)
{
	//DEBUG Level指出细粒度信息事件对调试应用程序是非常有帮助的。
	if(LogLevel ==LOG_LEVEL_DEBUG)
		m_LogLevel = LOG_LEVEL_DEBUG;
	else if(LogLevel ==LOG_LEVEL_INFO)
		m_LogLevel = LOG_LEVEL_INFO;
	else if(LogLevel ==LOG_LEVEL_WARN)
		m_LogLevel = LOG_LEVEL_WARN;
	else if(LogLevel ==LOG_LEVEL_ERROR)
		m_LogLevel = LOG_LEVEL_ERROR;
	else if(LogLevel ==LOG_LEVEL_FATAL)
		m_LogLevel = LOG_LEVEL_FATAL;
	else
		return FALSE;

	return TRUE;
}

//打印hex串日志
void PrintHexMsg(const char *pszCmd, int iLen,BOOL bIsTx)
{

	char szCmdFlag[8] ={0};
	char szlogBuffer[LOG_BUFFER_MAX_SIZE] ={0};

	int i=0;

	if( bIsTx)
	{
		memcpy(szCmdFlag, "TX:", sizeof("TX:"));
	}
	else
	{
		memcpy(szCmdFlag, "RX:", sizeof("RX:"));

	}

	for(i=0; i<iLen; i++)
	{
		char szTmp[8] ={0};
		sprintf(szTmp, "%02X ", *((unsigned char *)pszCmd+i));
		memcpy(szlogBuffer+i*3, szTmp, 3);
	}

 	WriteLog(LOG_LEVEL_INFO,LOG_FILE_COMM,szlogBuffer);
}


//获取文件大小
unsigned long GetFileSize(const char *path)
{
    unsigned long filesize = -1;
    struct stat statbuff={0};
    if(stat(path, &statbuff) < 0)
    {
        return filesize;
    }else{
        filesize = statbuff.st_size;
    }
    return filesize;
}

//读取文件内容
BOOL ReadFileData(char *szFileName, //读取文件名
							int Pos, 	//读取文件的起始位置
							WORD len,  //读取文件的长度
							BYTE * pReadedData //读取的文件内容
							)
{
	BOOL bReturn = FALSE ;
	FILE *fp;
	int  numread;
	//WORD  ReadedLen; //实际读取到的长度

   if( (fp = fopen(szFileName, "r+b" )) != NULL )
   {
	  if(fseek(fp,Pos,SEEK_SET)==0);
	  {
		  numread = fread( pReadedData, sizeof( char), len, fp );
		   //ReadedLen = (WORD) numread;
		 if(numread == len )
		 {
			 bReturn = TRUE;
		 }
	  }
   }
   else
   {
	  return FALSE;
   }
   fclose(fp);
   return bReturn;
 }


//处理历史记录
//将今天和今天之前15天以内的文件名全部记录下来,然后按照这些文件名将当前目录下的文件如果不在该记录
//表中的其它文件全部删除,对于同时存在.tar.gz文件和文本文件时(非今天的文件),将文本文件压缩到tar.gz中,同时删除文本文件.
//DayCount表示是保留的天数
//CurDate,今天的年月日
BOOL ProcessHistoryLog(int DayCount, uint8 CurDate[4])
{
	char szDateArray[31][20];
	int i;
	char szTemp[255];
	int length;
	char szCmd[256];
	char szTempFileName[32];

	//步骤1:获取所有的在时间范围内的文件名称
	if(DayCount>31)
	{
		DayCount =31; //防止溢出
	}

	struct tm t;
	struct tm *tp;
	time_t tick;

	memset(&t, 0, sizeof(t));
	t.tm_year = BCD_to_Decimal(CurDate[0])*100 + BCD_to_Decimal(CurDate[1])  -1900; /* years since 1900 */
	t.tm_mon  = BCD_to_Decimal(CurDate[2]) -1 ;  /* months since January - [0,11] */
	t.tm_mday = BCD_to_Decimal(CurDate[3]);     /* day of the month - [1,31] */
	t.tm_isdst = 0;   /* daylight savings time flag */

	tick = mktime(&t);
	sprintf(szDateArray[0],"%02X%02X%02X%02X",CurDate[0],CurDate[1],CurDate[2],CurDate[3]);
	for(i=1;i<DayCount;i++)
	{
		tick -= 86400;
		tp =  localtime(&tick);
		if(tp==NULL)
			return FALSE;
		sprintf(szDateArray[i],"%04d%02d%02d",tp->tm_year+1900,tp->tm_mon+1,tp->tm_mday);
		printf("day[%d]=%s \n",i,szDateArray[i]);
	}

	//步骤2:轮询日志目录,删除任何不在上述表中的文件.
	//获取当前可以使用的参数文件名称,参数为BCD[2]格式,例如{0x03,0x01},通过时间和版本来判断
	 //获取的参数文件名中的时间内容必须小于等于curData(否则是将来版本),同时最后的2位数字版本号取最大值.
 	 {
 	 	DIR *d; //声明一个句柄
	    struct dirent *file; //readdir函数的返回值就存放在这个结构体中
 	 	BOOL bFinded = FALSE; //是否找到标志

	     if(!(d = opendir("/tpu/log")))
	     {
	 		printf(" \n open dir(/tpu/parameter)) failed!\r\n");
	        return FALSE;
	     }
	     while((file = readdir(d)) != NULL)
	     {
		    //目录跳过
			if(strcmp(file->d_name,".")==0  || strcmp(file->d_name,"..")==0 )
			{
				continue;
			}
			bFinded = FALSE;
			for(i=0;i<DayCount;i++)
			{

				sprintf(szTempFileName,"tpu_%s.log",szDateArray[i]);
				if(strcmp(file->d_name,szTempFileName)==0)
				{
						bFinded = TRUE;
						break;
				}

				sprintf(szTempFileName,"tpu_%s.log.tar.gz",szDateArray[i]);
				if(strcmp(file->d_name,szTempFileName)==0)
				{
						bFinded = TRUE;
						break;
				}

				sprintf(szTempFileName,"ud_%s.log",szDateArray[i]);
				if(strcmp(file->d_name,szTempFileName)==0)
				{
						bFinded = TRUE;
						break;
				}

				sprintf(szTempFileName,"ud_%s.log.tar.gz",szDateArray[i]);
				if(strcmp(file->d_name,szTempFileName)==0)
				{
						bFinded = TRUE;
						break;
				}

				//通讯日志仅仅记录2天
				if(i<2)
				{
					sprintf(szTempFileName,"comm_%s.log",szDateArray[i]);
					if(strcmp(file->d_name,szTempFileName)==0)
					{
							bFinded = TRUE;
							break;
					}

					sprintf(szTempFileName,"comm_%s.log.tar.gz",szDateArray[i]);
					if(strcmp(file->d_name,szTempFileName)==0)
					{
							bFinded = TRUE;
							break;
					}
				}
			}
			if(!bFinded) //如果不在保留的名单之内,立即删除.
			{
				 sprintf(szTemp,"/tpu/log/%s",file->d_name);
				 remove(szTemp);
			}
	     }
 	    closedir(d);
	 } //end 步骤2,删除历史记录
 	 //步骤3: 遍历当前目录下的log文件,每找到一个log,则进行压缩成tar.gz文件,并且删除log文件
 		 {
 	 	 	DIR *d; //声明一个句柄
 		    struct dirent *file; //readdir函数的返回值就存放在这个结构体中
 	 	 	//char szTempFileName[30]={0};
 	 	     if(!(d = opendir("/tpu/log")))
 		     {
 		 		printf(" \n open dir(/tpu/log)) failed!\r\n");
 		        return FALSE;
 		     }
 		     while((file = readdir(d)) != NULL)
 		     {
 		    	//目录跳过
 				if(strcmp(file->d_name,".")==0  || strcmp(file->d_name,"..")==0 )
 				{
 					continue;
 				}

 				//今天的日志文件不用压缩处理,因为今天还要使用.
 				sprintf(szTempFileName,"tpu_%02X%02X%02X%02X.log",CurDate[0],CurDate[1],CurDate[2],CurDate[3]);
 				if(strcmp(file->d_name,szTempFileName)==0)
 				{
 					continue;
 				}
 				sprintf(szTempFileName,"comm_%02X%02X%02X%02X.log",CurDate[0],CurDate[1],CurDate[2],CurDate[3]);
 				if(strcmp(file->d_name,szTempFileName)==0)
 				{
 					continue;
 				}
 				sprintf(szTempFileName,"ud_%02X%02X%02X%02X.log",CurDate[0],CurDate[1],CurDate[2],CurDate[3]);
 				if(strcmp(file->d_name,szTempFileName)==0)
 				{
 					continue;
 				}

 				//区分是.log文件还是.log.tar.gz文件
 				length = strlen(file->d_name);


 				if(length>3 && memcmp(file->d_name+length-3,"log",3)==0)
 				{
 					//进行压缩
 					sprintf(szCmd,"gtar zcpvf /tpu/log/%s.tar.gz  /tpu/log/%s",file->d_name,file->d_name);
 		 			system(szCmd);

 		 			//删除已有文件
 					sprintf(szCmd,"rm -rf /tpu/log/%s",file->d_name);
 		 			system(szCmd);
 				}
 		     }
 			system("sync");
 	 	    closedir(d);
 		 } //end 步骤3: 遍历当前目录下的log文件,每找到一个log,则进行压缩成tar.gz文件,并且删除log文件
 		return TRUE;
}



void PrintDebug(const char *pszLog, ...)
{
	va_list ap ;
	char  szlogBuffer[LOG_BUFFER_MAX_SIZE]={0};
	va_start(ap,pszLog);
	vsprintf(szlogBuffer,pszLog,ap);
	va_end(ap);
	WriteLog(LOG_LEVEL_DEBUG,LOG_FILE_TPU,szlogBuffer);

	return ;
}

void PrintLog(const char *pszLog, ...)
{
	va_list ap ;
	char  szlogBuffer[LOG_BUFFER_MAX_SIZE]={0};
	va_start(ap,pszLog);
	vsprintf(szlogBuffer,pszLog,ap);
	va_end(ap);
	WriteLog(LOG_LEVEL_INFO,LOG_FILE_TPU,szlogBuffer);

	return ;
}

void PrintWarn(const char *pszLog, ...)
{
	va_list ap ;
	char  szlogBuffer[LOG_BUFFER_MAX_SIZE]={0};
	va_start(ap,pszLog);
	vsprintf(szlogBuffer,pszLog,ap);
	va_end(ap);
	WriteLog(LOG_LEVEL_WARN,LOG_FILE_TPU,szlogBuffer);

	return ;
}
void PrintError(const char *pszLog, ...)
{
	va_list ap ;
	char  szlogBuffer[LOG_BUFFER_MAX_SIZE]={0};
	va_start(ap,pszLog);
	vsprintf(szlogBuffer,pszLog,ap);
	va_end(ap);
	WriteLog(LOG_LEVEL_ERROR,LOG_FILE_TPU,szlogBuffer);

	return;
}
void PrintBuffer(const char *pszCmd,int iLen)
{
	char szlogBuffer[LOG_BUFFER_MAX_SIZE] ={0};
	int i=0;
	for(i=0; i<iLen; i++)
	{
		char szTmp[8] ={0};
		sprintf(szTmp, "%02X ", *((unsigned char *)pszCmd+i));
		memcpy(szlogBuffer+i*3, szTmp, 3);
	}

	WriteLog(LOG_LEVEL_INFO,LOG_FILE_TPU,szlogBuffer);

	return ;
}

void PrintUD(const char *pszCmd,int iLen)
{
	char szlogBuffer[LOG_BUFFER_MAX_SIZE] ={0};
	int i=0;
	for(i=0; i<iLen; i++)
	{
		char szTmp[8] ={0};
		sprintf(szTmp, "%02X ", *((unsigned char *)pszCmd+i));
		memcpy(szlogBuffer+i*3, szTmp, 3);
	}

	WriteLog(LOG_LEVEL_INFO,LOG_FILE_UD,szlogBuffer);

	return ;

}




