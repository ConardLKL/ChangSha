
#include "HashDictionary.h"
#include <stdio.h>
#include <malloc.h>
#include <math.h>
#include <limits.h>
#include <string.h>

int GetHashCode(char* str)
{
    int hashcode=0;
    char *p;
    for(p=str; *p; p++){
        hashcode = hashcode*CM_STR_HASHFUNC_CONSTANT + *p;
    }
    return hashcode;
}

BOOL IsPrime(int candidate)
{
    if ((candidate & 1) != 0)
    {
        int limit = (int)sqrt((double)candidate);
        int divisor;
        for (divisor = 3; divisor <= limit; divisor += 2)
        {
            if ((candidate % divisor) == 0)
                return FALSE;
        }
        return TRUE;
    }
    return (candidate == 2);
}

int GetPrime(int min)
{
    if (min < 0)
        return 3;
    int i;
    int length=sizeof(primes)/sizeof(primes[0]);
    for (i = 0; i < length; i++)
    {
        int prime = primes[i];
        if (prime >= min)
            return prime;
    }
    for ( i = (min | 3); i < INT_MAX;i+=2)
    {
        if (IsPrime(i))
            return i;
    }
    return min;
}

//void Initialize(HashDictionary** hd)
//{
//    Initialize(*hd,3);
//}

void Initialize(HashDictionary* hd,int capacity)
{
    int size=GetPrime(capacity);
    hd->buckets=(int*)malloc(sizeof(int)*size);

    int i = 0;
    for (; i < size; i++)
    {
        hd->buckets[i]=-1;
    }
    hd->bucketslength=size;
    hd->entrys=(Entry*)malloc(sizeof(Entry)*size);
    i = 0;
    for (; i < size; i++)
    {
        hd->entrys[i].hashCode=-1;
        hd->entrys[i].next=-1;
        memset(hd->entrys[i].value,0,sizeof(hd->entrys[i].value));
    }
    hd->entryslength=size;

    hd->count=0;
    hd->freeCount=0;
    hd->freeList=-1;
};

void Disponse(HashDictionary* hd)
{
    free(hd->buckets);
    free(hd->entrys);
}

void Resize(HashDictionary* hd)
{
    int newsize=hd->count*2;
    int* newbuckets=(int*)malloc(sizeof(int)*newsize);
    Entry* newentrys=(Entry*)malloc(sizeof(Entry)*newsize);

    int i = 0;
    for (; i < newsize; i++)
    {
        newbuckets[i]=-1;
    }
    for ( i = 0; i < newsize; i++)
    {
        newentrys[i].hashCode=-1;
        newentrys[i].next=-1;
        memset(newentrys[i].value,0,sizeof(newentrys[i].value));
    }

    hd->bucketslength=hd->entryslength=newsize;

    memcpy(newentrys,hd->entrys,sizeof(Entry)*hd->count);

    free(hd->buckets);
    free(hd->entrys);

    hd->buckets=newbuckets;
    hd->entrys=newentrys;

    //重新排列
    for ( i = 0; i < hd->count; i++) {
        if (hd->entrys[i].hashCode >= 0) {
            int bucket = hd->entrys[i].hashCode % hd->bucketslength;
            hd->entrys[i].next = hd->buckets[bucket];
            hd->buckets[bucket] = i;
        }
    }
}

int Insert(HashDictionary* hd,char* key,void* value,BOOL add)
{
    int hashCode = GetHashCode(key) & 0x7FFFFFFF;
    int targetBucket = hashCode % hd->bucketslength;
    //new value
    int i = hd->buckets[targetBucket];
    for (i = hd->buckets[targetBucket]; i >= 0; i = hd->entrys[i].next) {
        if (hd->entrys[i].hashCode == hashCode && strcmp(hd->entrys[i].key,key)==0) {
            if (add) {
                return -1;
            }
            //hd->entrys[i].value = value;
            memcpy(hd->entrys[i].value,value,VALUESIZE);
            return 2;
        }
    }
    int index;
    if (hd->freeCount > 0) {
        index = hd->freeList;
        hd->freeList =hd-> entrys[index].next;
        hd->freeCount--;
    }
    else {
        if (hd->count == hd->entryslength)
        {
            Resize(hd);
            targetBucket = hashCode % hd->bucketslength;
        }
        index = hd->count;
        hd->count++;
    }
    /*if( buckets[targetBucket]!=-1)
    printf("碰撞");*/
    hd->entrys[index].hashCode = hashCode;
    hd->entrys[index].next = hd->buckets[targetBucket];
    memcpy(hd->entrys[index].key,key,strlen(key)+1);
    //hd->entrys[index].value = value;
    memcpy(hd->entrys[index].value,value,VALUESIZE);
    hd->buckets[targetBucket] = index;
    return 1;
}

int FindEntryIndex(HashDictionary* hd,char* key)
{
    int hashCode = GetHashCode(key) & 0x7FFFFFFF;
    int i = hd->buckets[hashCode % hd->bucketslength];
    for (; i >= 0; i = hd->entrys[i].next) {
        //printf("%s find item \n",entrys[i].key);
        if (hd->entrys[i].hashCode == hashCode &&  strcmp(hd->entrys[i].key,key)==0)
        {
            return i;
        }
    }
    return -1;
}

Entry* FindEntry(HashDictionary* hd,char* key)
{
    int index=FindEntryIndex(hd,key);
    if(index>=0)
    {
        return &hd->entrys[index];
    }
    return 0;
}

BOOL Remove(HashDictionary* hd,char* key)
{
    int hashCode = GetHashCode(key) & 0x7FFFFFFF;
    int bucket = hashCode % hd->bucketslength;
    int last = -1;
    int i=0;
    for ( i = hd->buckets[bucket]; i >= 0; last = i, i = hd->entrys[i].next) {
        if (hd->entrys[i].hashCode == hashCode && strcmp(hd->entrys[i].key,key)==0) {
            if (last < 0) {
                hd->buckets[bucket] = hd->entrys[i].next;//如果第一个
            }
            else {
                hd->entrys[last].next = hd->entrys[i].next;
            }
            hd->entrys[i].hashCode = -1;
            hd->entrys[i].next = hd->freeList;//串连逻辑删除链表
            memset(hd->entrys[i].key,0,20);
            memset(hd->entrys[i].value,0,sizeof(hd->entrys[i].value));
            hd->freeList = i;
            hd->freeCount++;
            return TRUE;
        }
    }
        return FALSE;

}

BOOL ContainsKey(HashDictionary* hd,char* key)
{
    return FindEntryIndex(hd,key) >= 0;
}

int GetCount(HashDictionary* hd)
{
    return hd->count-hd->freeCount;
}


