/*********************************************************
*程序名称:		msgprocess.h
*版本号:		0.1			
*功能描述:  	定义所有的与上位机之间
*作者:			王洪峰			
*修改记录:		
				2015.01.13 创建 
*其他:						
***********************************************************/

#ifndef __MSGPROCESS_H__
#define __MSGPROCESS_H__

#include "DataTypeDefine.h"
#include "XPublic/Log.h"
#include "comm232.h"
#pragma pack(push, 1)

#define MSG_SEND2RW_HEADER	0xAA		//上位机给读卡器发送命令的固定头长度
#define MSG_SEND2RW_FIX_LEN 18			//上位机给读卡器发送命令除数据区外的固定长度

#define MSG_RECV_FROM_RW_HEADER 0xBB	//读卡器给上位机给发送应答的固定头长度
#define MSG_RECV_FROM_RW_FIX_LEN 9		//读卡器给上位机给发送应答除数据区外的固定长度

#define MAX_COM_DATA_FIELD_LEN	4096+10 //定义数据域的最大长度


//定义读卡器接收数据结构体(和上位机端相反)
typedef struct _RecvCommData 
{	 	
	unsigned char	ucHeadStx;		//消息头部,AA（设备主程序发送）
	unsigned char	ucNodeID;		//节点编码,接收端地址码，用于一个端口接多个读写器
	unsigned char	ucMsgSeq;		//报文序列号,由上位机管理，0开始，每次通讯完加1，到0xFF后重新归零。
	unsigned char	ucCmdClass;		//指令类码
	unsigned char	ucCmdCode;		//命令码
	unsigned char	ucParam0;		//预留
	unsigned char	ucParam1;		//命令码
	//bit7-bit4预留
	//bit3-bit2:蜂鸣次数:最多三次
	//bit1-bit0:天线模式 0=主天线，1=副天线
	unsigned char	TimeStamp[7];	//时间戳,主控设备当前时间,bcd码表示,YYYYMMDDHHNNSS
	unsigned short	usDataLen;		//数据域长度，可以等于0；最大为4KByte
	unsigned char	ucData[MAX_COM_DATA_FIELD_LEN];	//数据域内容；最大为4KByte
	unsigned short	usCRC16;		//以上所有数据的CRC16计算值,Crc多项式0x1021,Crc预值0x00
	//例: 0x31 0x32 0x33 0x34 计算的结果为 0xD789
}RECVCOMMDATA;

extern RECVCOMMDATA g_RecvCommData; //接收数据结构体

//定义读卡器发送数据结构体
typedef struct _SendCommData 
{	 	
	unsigned char	ucHeadStx;		//消息头部,BB（读写器发送）
	unsigned char	ucNodeID;		//节点编码,本设备地址码
	unsigned char	ucMsgSeq;		//报文序列号,填充当次处理指令收到的序列号
	unsigned char	ucCmdClass;		//指令类码
	unsigned char	ucCmdCode;		//命令码
	unsigned short	usDataLen;		//数据域长度，可以等于0；最大为4KByte
	unsigned char	ucData[MAX_COM_DATA_FIELD_LEN];	//数据域内容；最大为4KByte
	unsigned short	usCRC16;		//以上所有数据的CRC16计算值,Crc多项式0x1021,Crc预值0x00
	//例: 0x31 0x32 0x33 0x34 计算的结果为 0xD789
}SENDCOMMDATA;
extern SENDCOMMDATA g_SendCommData; //发送结构体

extern int g_hComm;  //打开的串口句柄


//在指定的时间内读取消息头字段0xAA
BOOL ReadMsgStx(int iTimeout);

//读取串口数据消息体(除了标志头以外的内容)
int ReadCommMsgBody(int iReadTimeout);//设备通信端口编号

//将g_SendCommData结构体发送到上位机.
BOOL WriteCommMsg(void);




//对上位机消息解析分发处理函数
int MsgProcess(void);


#endif


