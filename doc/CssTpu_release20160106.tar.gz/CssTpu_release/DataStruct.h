

#ifndef __DATASTRUCT_H__
#define __DATASTRUCT_H__

//#include "DataTypeDefine.h"
#include "RWParam/RWParameter.h"


typedef struct _ST_SPC_TICKET_TRAN_INFO_
{
	uint8 szCardPhID[11];
	uint8 szTranTime[8];
	uint8 szWriteCardInfo[128];
	uint8 szTranUD[512];
}ST_SPC_TICKET_TRAN_INFO;

// szp   BRContext 结构定义
typedef struct tag_BR_CONTEXT_H
{
	// TPU 参数如初始化信息等
	uint8 bCurrentLineID;  //线路
	uint8 bCurrentStationID[2];	//线路站点，2字节BCD编码, 如"\x03\x01"，表示3号线第1个站点
	uint8 bCurrentDeviceTypeCode;		//设备类型，十进制表示。1字节BCD编码
	uint8 bCurrentDeviceID[2];	//当前设备编码，"\x09\x87"表示设备号为987的设备

	EM_DEVICE_TYPE emCurrentDeviceType;  //当前设备类型。

	//当前设备编码。
	char szDeviceCode[10];

	//操作员号	6		char	6个字符的操作员ID
	uint8 CurrentUserID[7];

	//班次号	1		bcd	操作人员班次号，每天重新记录班次
	uint8 CurrentClassID;

	//通道类型
	//1	0	byte	1：普通通道（不接受优惠票）
	//2：专用通道（只接受优惠票）
	//3：正常通道（接受所有票票种）
	uint8 AGMAisleType;

	// 公用参数的过程变量
	uint8	TransactionTime[7];		// 交易时间BCD  7B
	uint32	TranTime;				// 交易时间GMT


	// 参数结构"票卡参数"0301参数
	Para0301  TicktPara0301;

	//RW 状态机。
	EM_CS_RW_STATUS emCsRwStatus;
	//保存业务处理结果
	uint32 Result;

	// SAM卡逻辑卡号（ACC）
	char szYptSAMID[17];

	//


	//SAM卡信息
	SAMSTATUS  stSamInfo[8];
	uint8 u8AccPsamTerminalID[6];//地铁PSAM卡终端机编号
	uint8 u8YktCpuPsamTerminalID[6];//ykt cpuPSAM卡终端机编号
	uint8 u8YktM1PsamTerminalID[6];//ykt m1 PSAM卡终端机编号

	//当前站模式
	uint8 ucCurrentStationMode;

	//当前用户卡最近交易车站模式
	uint8 ucTicketLastProcessStationMode;

	//当前票卡物理ID（UL,YKT,）
	uint8 szCardPhID[11];
	uint8 szCardLocgicID[21];
	uint8 u8CardPhType;

	uint8 szLastEntryCardPhID[11];
	struct  timespec szLastEntryTime;
	uint32 u32LastEntryResult;

	uint8 szLastExitCardPhID[11];
	struct  timespec szLastExitTime;
	uint32 u32LastExitResult;

	ST_SPC_TICKET_TRAN_INFO stSpcTicketTranInfo;


}BR_CONTEXT_H;




#endif
