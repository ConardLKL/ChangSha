/*********************************************************
*程序名称:		Comm232.cpp
*版本号:		0.1			
*功能描述:  	提供串口操作功能,包括打开串口,设置串口,读写串口,,关闭串口基础函数
*作者:			王洪峰			
*创建日期:		2015.01.07		
*修改记录:					
*其他:						
***********************************************************/
#include "comm232.h"

#include "XPublic/XTime.h"

static int m_hComm = -1;  //打开的串口句柄

/*函数名称：OpenComPort
* 函数功能：打开串口,如果该串口已经打开,则返回失败
* 输入参数：
	pszPort:指定要初始化的串口字符串(从COM1开始),之所以从数字改为字母,主要是便于linux移植(linux串口是设备字符串,例如/dev/ttyS0)
	iBoudrate串口的波特率;一般为:9600,19200,38400,57600,115200
	iparity校验方式:
		#define NOPARITY     0  无校验位
		#define ODDPARITY    1	奇数校验
		#define EVENPARITY   2	偶数校验
* 输出参数：
* 返 回 值：成功返回串口句柄,失败返回INVALID_HANDLE_VALUE
* 编写作者：王洪峰
* 修订记录: 2015.01.07 创建
*/
int OpenComPort(char *pszCommName, int  iBoudrate, int iparity)
{

	struct termios newtio,oldtio;
	int iStop=1;
	int iBits=8;
	
	if(pszCommName==NULL || strlen(pszCommName)<4)
	{
		return -1;
	}
	
	if(m_hComm>0)
	{
	  close(m_hComm);
	}

	m_hComm = open(pszCommName,O_RDWR|O_NONBLOCK,RW);
	if(-1 == m_hComm)
	{
		return -1;
	}
    if(fcntl(m_hComm,F_SETFL,0) < 0)
    { //判断是否能加锁
   	  return -1;
    }
    if( isatty(STDIN_FILENO) == 0 )
    { //判断是否有终端设备
    }

	if (tcgetattr(m_hComm,&oldtio) != 0)
	{
		return -1;
	}
	bzero(&newtio,sizeof(newtio));
	newtio.c_cflag |= CLOCAL | CREAD;
	newtio.c_cflag &= ~CSIZE;
	switch(iBits)
	{
	case 7:
		newtio.c_cflag |= CS7;
		break;
	case 8:
		newtio.c_cflag |= CS8;
		break;
	}
	switch(iparity)
	{
	case 'O':
		newtio.c_cflag |= PARENB;
		newtio.c_cflag |= PARODD;
		newtio.c_iflag |= (INPCK);
		break;
	case 'E':
		newtio.c_iflag |=(INPCK);
		newtio.c_cflag |= PARENB;
		newtio.c_cflag &= ~PARODD;
		break;
	case 'N':
		newtio.c_cflag &= ~PARENB;
		break;
	}
	switch(iBoudrate)
	{
	case 2400:
		cfsetispeed(&newtio,B2400);
		cfsetospeed(&newtio,B2400);
		break;
	case 4800:
		cfsetispeed(&newtio,B4800);
		cfsetospeed(&newtio,B4800);
		break;
	case 9600:
		cfsetispeed(&newtio,B9600);
		cfsetospeed(&newtio,B9600);
		break;
	case 19200:
		cfsetispeed(&newtio,B19200);
		cfsetospeed(&newtio,B19200);
		break;
	case 38400:
		cfsetispeed(&newtio,B38400);
		cfsetospeed(&newtio,B38400);
		break;
	case 57600:
		cfsetispeed(&newtio,B57600);
		cfsetospeed(&newtio,B57600);
		break;
	case 115200:
		cfsetispeed(&newtio,B115200);
		cfsetospeed(&newtio,B115200);
		break;
	default:
		cfsetispeed(&newtio,B38400);
		cfsetospeed(&newtio,B38400);
		break;
	}
	if (iStop == 1)
	{
		newtio.c_cflag &= ~CSTOPB;
	}
	else if (iStop == 2)
	{
		newtio.c_cflag |= CSTOPB;
	}
	newtio.c_cc[VTIME] = 0;
	newtio.c_cc[VMIN] = 0;
	tcflush(m_hComm,TCIFLUSH);//清空串口缓存
	if((tcsetattr(m_hComm,TCSANOW,&newtio))!=0)
	{//激活新配置
		return -1;
	}

	return m_hComm;
}


/*ReadCommBuffer
* 函数功能：向串口发送数据
* 输入参数：
	lpBuf	:读取数据缓冲区
	dwToRead:需要读取的数据字节数
	iTimeoutMillisecond:超时时间(ms),如果为0表示使用默认超时时间2秒,
		如果大于系统默认的最大超时时间,则超时时间使用系统默认超时时间
	pReadedCount:实际读取的数据字节数(超时时间范围内)
* 输出参数：
* 返 回 值：TRUE表示成功,FALSE表示失败
* 编写作者：王洪峰
* 修订记录: 2015.01.07 创建
* 说明: 该函数是从VC MSDN帮助文档中拷贝而来
		<<\\Technical Articles\Windows Platform\Base Services\Serial Communications in Win32>>
		唯一的修改在于判断了句柄号
 */
BOOL ReadCommBuffer(char * lpBuf, DWORD dwToRead,int iTimeoutMillisecond,DWORD * pReadedCount)
{

	unsigned int iReadSize=0;
	int iReadSizeOnce=0;

	//检查参数
	if(m_hComm<0 || lpBuf==NULL|| dwToRead<1 || pReadedCount==NULL)
	{
		return FALSE;
	}

	lseek(m_hComm,0,SEEK_SET);
	struct  timespec TimeOutClockTick;
	//memset(&TimeOutClockTick,0,sizeof(timespec));
	InitClockTickTimeOut( &TimeOutClockTick,iTimeoutMillisecond);

	while(TRUE)
	{
		if(dwToRead-iReadSize < 0)
		{
			return FALSE;
		}
		iReadSizeOnce = 0;
		iReadSizeOnce=read(m_hComm,lpBuf+iReadSize,dwToRead-iReadSize);
		if (iReadSizeOnce < 0)
		{//没读到数据
			if (iReadSizeOnce == EAGAIN)
			{
				return FALSE;
			}
		}
		else if(iReadSizeOnce > 0)
		{
			//for(int i = 0; i<iReadSizeOnce;i++)
			{
				//sprintf(szTemp,"%.2x ",(RxBuf+iReadSize)[i]);
				//strcat(szTxTemp,szTemp);
				//memset(szTemp,0,sizeof(szTemp));
			}
			iReadSize += iReadSizeOnce;

			if (iReadSize == dwToRead)
			{
				*pReadedCount=iReadSize;
				break;
			}
		}

		if(CheckClockTickTimeOut(&TimeOutClockTick))
		{
			*pReadedCount=iReadSize;
			break;
		}
		usleep(100);

	}

	return TRUE;
}



/*WriteCommBuffer
* 函数功能：向串口发送数据
* 输入参数：
	lpBuf	:发送数据缓冲区
	dwToWrite:发送数据的字节数
* 输出参数：
* 返 回 值：TRUE表示成功,FALSE表示失败
* 编写作者：王洪峰
* 修订记录: 2015.01.07 创建
* 说明: 该函数是从VC MSDN帮助文档中拷贝而来
		<<\\Technical Articles\Windows Platform\Base Services\Serial Communications in Win32>>
		唯一的修改在于判断了句柄号
 */
int WriteCommBuffer( char * lpBuf, DWORD dwToWrite)
{


	unsigned int iWriteSize = 0;
	int iWriteSizeOnce = 0;
	int iTimeout=100;

	//检查参数
	if(lpBuf==NULL || m_hComm<0||dwToWrite<=0)
	{
		return FALSE;
	}

	struct  timespec TimeOutClockTick;
	InitClockTickTimeOut( &TimeOutClockTick,iTimeout);

	PrintLog("File[%s]Line[%d] WriteCommBuffer  lpBuf",__FILE__,__LINE__);
	PrintBuffer(lpBuf,dwToWrite);

	ClearPort(ClearWriteBuf);
	while(TRUE)
	{
		iWriteSizeOnce = write(m_hComm,lpBuf+iWriteSize,dwToWrite-iWriteSize);
		if( iWriteSizeOnce < 0 )
		{
			PrintLog("File[%s]Line[%d] WriteCommBuffer. iWriteSizeOnce[%d]",__FILE__,__LINE__,iWriteSizeOnce);
			break;
		}
		else
		{
			iWriteSize += iWriteSizeOnce;
			if( iWriteSize == dwToWrite)
			{//写入成功
				PrintLog("File[%s]Line[%d] WriteCommBuffer. iWriteSize == dwToWrite[%d]",__FILE__,__LINE__,iWriteSize);
				break;
			}else if( iWriteSize > dwToWrite)
			{
				PrintLog("File[%s]Line[%d] WriteCommBuffer. iWriteSize > dwToWrite[%d]",__FILE__,__LINE__,iWriteSize);
				break;
			}else
			{
				iWriteSizeOnce = 0;
				usleep(1000);
				continue;
			}
		}

		if(CheckClockTickTimeOut(&TimeOutClockTick))
		{
			PrintLog("File[%s]Line[%d] WriteCommBuffer. timeout[%d]",__FILE__,__LINE__,iWriteSize);
			break;
		}
	}

	return iWriteSize;
}

/*! CComApi::ClearPort(enum ClearType iType)

 * 函数功能 清理串口缓冲区
 * \param	enum ClearType iType 要清空的缓冲区类型
 * \return FUN_OK 成功 FUN_ERROR失败
*/
BOOL ClearPort(EM_CLEAR_TYPE iType)
{
	if(iType==ClearReadBuf)
	{
		tcflush(m_hComm,TCOFLUSH);//清空串口线上的读数据缓冲
	}else if(iType==ClearWriteBuf)
	{
		tcflush(m_hComm,TCIFLUSH);//清空串口线上的写数据缓冲
	}else if(iType==ClearAllBuf)
	{
		tcflush(m_hComm,TCIOFLUSH);//清空串口线上的数据缓冲
	}else
	{
		return FALSE;
	}
	return TRUE;
}

/*! ClosePort()

 * 函数功能 关闭串口
 * \return 0 成功, FUN_ERROR 失败
*/
BOOL CloseComport()
{
	int iResult = -1;
	iResult = close(m_hComm);
	if(iResult == 0)
	{
		m_hComm=-1;
		return TRUE;
	}

	return FALSE ;
}

BOOL CheckComStatus()
{
	if(m_hComm>0)
		return TRUE;
	return FALSE;

}
