#ifndef	__DATATYPE_H
#define	__DATATYPE_H

#include <fcntl.h>
#include <pthread.h>

#define TRUE		1
#define FALSE		0
#define	STATUS_ERR	1
#define	STATUS_OK	0
typedef	void (* PrVoid)(void);
typedef	PrVoid (*PrPrVoid)(void);
	
typedef	unsigned char U8;
typedef	unsigned char INT8U;
typedef unsigned short U16,INT16U;
typedef unsigned int U32,INT32U;
typedef	signed char S8,INT8S;
typedef signed short S16,INT16S;
typedef signed int S32,INT32S;


#define EXTERN		extern
#define SWAP16(x)	(((x & 0xff) << 8) | (x >> 8))
#define SWAP32(x)   (((x>>24)&0x000000ff) |((x>>8)&0x0000ff00)|((x<<8)&0x00ff0000)|((x<<24)&0xff000000))

#define PACK_STRUCT_FIELD(x) x __attribute__((packed))
#define PACK_STRUCT_STRUCT   __attribute__((packed))
#define PACK_STRUCT_BEGIN
#define PACK_STRUCT_END

#define EN_FECIAL_CARD

#define HANDLE	int

#ifndef DWORD
#define DWORD	INT32U
#endif

#ifndef IN
#define IN
#define OUT
#endif

#ifndef UNUSED
#define UNUSED(x)	(void)(x)
#endif

typedef struct{
	INT8U cer;
	INT8U year;
	U8 month;
	U8 day;
	U8 hour;
	U8 min;
	U8 sec;
}TIME_STRUC;

typedef union
{
	INT8U	CharBuff[2];
	INT16U	IntBuff;
}TYPE_CHAR_INT ;

typedef union 
{
	INT8U	CharBuff[4];
	INT16U	IntBuff[2];
	INT32U	LongBuff;
}TYPE_CHAR_LONG;

typedef struct
{
   	unsigned char Command[4]; 
   	unsigned char Lc;
   	unsigned char  DataIn[512];
   	unsigned char Le;
}APDU_SEND;

typedef struct
{
	unsigned char LenOut; 
   	unsigned char  DataOut[512];
   	unsigned int  SW;
}APDU_RESP;

typedef struct
{
	unsigned char CLA;
	unsigned char INS;
	unsigned char P1;
	unsigned char P2;

	unsigned char LC;
	unsigned char DATA[240];

	unsigned char LE;

}ISO7816_ADPU_SEND;

typedef struct
{
	unsigned char LE;
	unsigned char DATA[240];

	unsigned char SW1;
	unsigned char SW2;
}ISO7816_ADPU_RESPONSE;


typedef struct
{
	INT8U	cSeLen;
	INT8U	cSendBuff[100];
	INT8U	cReLen;
	INT8U	cReBuff[100];
	INT8U	cTimeOut;
}DES_EXCHANGE;


typedef struct
{
	unsigned int	Le;
	unsigned char	inf[200];
	unsigned short	SW;
}APDU_RET;



#define APP_LOG_NAME		"JC5620"

#define new_free(p)					free(p)
#define new_malloc(s)				malloc(s)

 #define NEW(T, nItems)					\
			(T *)new_malloc( sizeof(T)*(nItems) )
#define DELETE(p)						new_free(p)




// Alt+/ :Look up reference 
//   F9 :Ident left
//    F10 :Ident right
//shift+F8 : hilight word
#endif

