/*********************************************************
*程序名称:		Comm232.h
*版本号:		0.1			
*功能描述:  	提供串口操作功能,包括打开串口,读写串口,,关闭串口基础函数
*作者:			王洪峰			
*创建日期:		2015.01.7		
*修改记录:					
*其他:						
***********************************************************/

#ifndef _COMM232_H
#define  _COMM232_H
#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<errno.h>
#include<fcntl.h>
#include<sys/file.h>
#include<unistd.h>
#include<termios.h>
#include<stdlib.h>

#include "XPublic/XTime.h"

//定义串口的内部缓冲区大小,该参数用于打开串口时SetCommBufferSize函数.
//由于长沙最大数据区域为4K,加上通讯头尾等,定义为整数5000.
#define MAX_COMM_DRIVER_BUFFER_SIZE 5000 
#define MAX_COMM_READ_TIMEOUT	2000 //毫秒

#define RW			0666//可读可写

typedef enum _EM_ClearType
{
	ClearReadBuf,
	ClearWriteBuf,
	ClearAllBuf
}EM_CLEAR_TYPE;

/*函数名称：OpenComPort
* 函数功能：打开串口,如果该串口已经打开,则返回失败
* 输入参数：
	pszPort:指定要初始化的串口字符串(从COM1开始),之所以从数字改为字母,主要是便于linux移植(linux串口是设备字符串,例如/dev/ttyS0)
	iBoudrate串口的波特率;一般为:9600,19200,38400,57600,115200
	iparity校验方式:
		#define NOPARITY     0  无校验位
		#define ODDPARITY    1	奇数校验
		#define EVENPARITY   2	偶数校验
* 输出参数：
* 返 回 值：成功返回串口句柄,失败返回INVALID_HANDLE_VALUE
* 编写作者：王洪峰
* 修订记录: 2015.01.07 创建
*/
int OpenComPort(char *pszCommName, int  iBoudrate, int iparity);

/*ReadCommBuffer
* 函数功能：向串口发送数据
* 输入参数：
	lpBuf	:读取数据缓冲区
	dwToRead:需要读取的数据字节数
	iTimeoutMillisecond:超时时间(ms),如果为0表示使用默认超时时间2秒,
		如果大于系统默认的最大超时时间,则超时时间使用系统默认超时时间
	pReadedCount:实际读取的数据字节数(超时时间范围内)
* 输出参数：
* 返 回 值：TRUE表示成功,FALSE表示失败
* 编写作者：王洪峰
* 修订记录: 2015.01.07 创建
* 说明: 该函数是从VC MSDN帮助文档中拷贝而来
		<<\\Technical Articles\Windows Platform\Base Services\Serial Communications in Win32>>
		唯一的修改在于判断了句柄号
 */

BOOL ReadCommBuffer(char * lpBuf,DWORD dwToRead,int iTimeoutMillisecond,DWORD * pReadedCount);


/*WriteCommBuffer
* 函数功能：向串口发送数据
* 输入参数：
	lpBuf	:发送数据缓冲区
	dwToWrite:发送数据的字节数
* 输出参数：
* 返 回 值：TRUE表示成功,FALSE表示失败
* 编写作者：王洪峰
* 修订记录: 2015.01.07 创建
* 说明: 该函数是从VC MSDN帮助文档中拷贝而来
		<<\\Technical Articles\Windows Platform\Base Services\Serial Communications in Win32>>
		唯一的修改在于判断了句柄号
 */
int WriteCommBuffer(char * lpBuf,DWORD dwToWrite);

/*!清空串口缓存*/
BOOL ClearPort( EM_CLEAR_TYPE iType);

/*CloseComport
* 函数功能：关闭指定串口
* 输入参数：
	iPort	:串口号
* 输出参数：
* 返 回 值：TRUE表示成功,FALSE表示失败
* 编写作者：王洪峰
* 修订记录: 2015.01.08 创建
		
 */
BOOL CloseComport();

BOOL CheckComStatus();


#endif

